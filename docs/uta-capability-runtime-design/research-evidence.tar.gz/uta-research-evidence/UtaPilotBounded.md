以下只基于 pilot brief 指定的原文范围；“原文事实”“条件推论”和“未定问题”分开。

## 发现一：结果依赖不是一种统一的 `flatMap`；下一计算消费的是不同控制载体

**原文事实。** Query 的 `flatMap` 确实把前一步的 `A` 交给函数，以构造下一 Query，并把两步的失败、服务要求、权限要求分别合并；如果分支是在运行时选择，声明仍必须覆盖所有可选分支，运行时才发现的能力不能绕过权限计算（`docs/uta-capability-runtime-design.md:367-378`）。这是一种“值决定下一次 Query 构造”的局部依赖。

渐进决定消费的不是普通 Query 返回值：边界先形成有来源的事实，`decide(state, command, facts, now)` 只能纯地产生 `Rejected`，或 `Accepted` 的 events/effects；后续决定读取的是前一步 `evolve` 后的状态，不能都对同一旧快照独立通过（`docs/uta-capability-runtime-design.md:527-535`）。初版关系也明确区分了 durable event、跨边界 effect 和纯 `evolve`（`docs/uta-effect-runtime-architecture.md:315-338`）。

Deferred 场景再多一层：`advance(checkpoint, sourceFact, futureBoundary)` 的结果是 `NoActivation | Candidate<Evidence> | Gap`；`Candidate` 是有 checkpoint 和来源的证据，不是交易许可。以 Candle 预设为例，crossing 只先形成决定请求，`RequestSubmission` 才重新进入普通 prepare/approval/start 边界；命中条件本身不直接发单（`docs/uta-capability-runtime-design.md:704-743, 846-864`）。

EF04 也把这种差异写成了结果 ADT：可恢复的单 item 错误才是 `ItemFailure`；child terminal 是 `Completed|Failed|Cancelled`；outer 只有在显式 partial-result profile 下才可为 `Partial<MemberOutcome[]>`，否则 child `Failed` 使 outer `Failed`（`docs/uta-capability-runtime-design/event-flows.md:388-396, 484-490`）。因此下游不能只消费一个“成功值”而抹掉 coverage、finality、terminal 或 gap。

**条件成功路径。** 可以得到一条连贯但有前提的路径：先执行一个已注册的 `Q0`，得到带来源/coverage/finality 的 `A`；根据 `A` 从已声明的 `Q_low | Q_high` 中构造下一 Query，保留全部 branch 的失败、服务和权限联合；把形成的事实送入纯 `decide`，将 Accepted event 交给 `evolve`，再以演进后的状态决定下一步。若目标是尚未发送的 Order，则将后续行情事实交给唯一 activation owner 的 `advance`：连续且无 gap 时产出 `Candidate<Evidence>`，再产生 `RequestDecision`；只有收到身份、epoch、intent revision 均匹配的 `RequestSubmission`，才进入 prepare/approval/start。Candle Pull 的 Partial/provisional 结果在 projection 后仍是 Partial/provisional，不能借下一步分支升级成 Complete（`docs/uta-capability-runtime-design.md:829-844`）。

这条路径成立的前提是：分支集合及其权限在注册时可枚举；`A` 的控制元数据没有被 projection 丢弃；决定确实读取演进后的状态；checkpoint 连续、owner 唯一；最后的授权在受控边界按当前策略复核。原文支持这些前提的约束，但没有证明任意 provider 都能满足它们。

**有区分力的反例/时序。** Candle 的 baseline 在 `t10` 为 false，随后出现 gap，`t12` 第一条高于阈值的值到达。若把最新值当作普通 `A`，由 Query 分支或旧式 guard 直接选择“提交”分支，表面上的值依赖是闭合的，但正确的 `advance` 结果必须是 `Gap`；`t12` 只能重建 baseline，不能证明发生了 crossing（`docs/uta-capability-runtime-design.md:719-725, 862-864`）。这同时说明了两件事：值级 `flatMap` 可以保留，但不能承担 checkpoint/连续性证明；deferred 的 `Candidate` 也不能被当作 Query 的普通成功值消费。

**取舍与下一最小调查。** 值得保留的是 Query 层的“已声明分支 + 联合要求”规律，以及 Decision 层的“event→evolve→下一决定”规律；不宜把 Query 成功值、durable event 和 activation evidence 合并成一个泛型结果。最小区分调查是选一个实际的动态分支，逐项列出其所有可能 binding 的 `P/E/finality/coverage` 槽位，并追一条 partial 或 gap 输入是否仍以 ADT 到达下一计算；若做不到，问题是 binding/输出契约缺失，而不是再加一个分支标签。

## 发现二：旧 guard 高阶组合是一次性本地短路，不足以证明渐进或 deferred 的持久控制语义

**原文事实。** `createGuardPipeline` 返回一个包装函数。只要有 guard，它先用 `Promise.all` 读取一次 positions 和 account，构造一个共享 `GuardContext`，再按数组顺序逐个 `await guard.check(ctx)`；首个非空 rejection 立即返回字符串错误，不调用 dispatcher；全部通过才调用 `dispatcher(op)`（`services/uta/src/domain/trading/guards/guard-pipeline.ts:13-36`）。guards 为空时直接返回原 dispatcher，连 account 读取也绕过（同文件 `:18`）。这确实是高阶组合：前一步 guard 的结果控制是否继续下一 guard 或进入 dispatch，但展示出的输出是 transient rejection string / `Promise<unknown>`，不是带 revision、receipt、checkpoint 或事件的受控结果。

**条件成功路径。** 对“不等待、不重放、只做一次本地前置检查”的操作，它的成功语义是清楚的：在同一次调用中读取一个 account/positions 快照；每个 guard 都接受同一 context；循环结束后调用 dispatcher。它保留了短路性质——一个 guard 拒绝就不会 dispatch——但仅能推出这次调用中 guard 链接受了该快照，不能推出交易批准、原生成功、持久 admission 或未来时间点仍然有权执行。

**有区分力的反例/时序。** 在 `t0`，这段 pipeline 读取快照且所有 guard 通过；随后操作被排队、等待行情，或只是把 dispatcher 延迟到 `t1`；`t1` 时账户范围/策略 revision 已改变。若把 `t0` 的“全部 guard 通过”当作当前授权并继续 dispatch，就把一次性检查结果冒充了 deferred 的 intent revision、activation epoch 和发送时授权复核。Deferred 原文明确要求响应匹配 request/control version/intent revision/epoch，并在发送时按冻结范围和当前策略取得许可；来源事件或决定文字本身不是交易许可（`docs/uta-capability-runtime-design.md:392, 727-743`）。旧 pipeline 本身没有表达这些持久身份与竞争关系，所以不能从它的高阶形状推出上述语义。

这也给出了对旧组合的准确保留边界：它可以作为一个特化的“本地 pre-dispatch guard”继续存在；但若业务想把 guard 成功交给 progressive decision 或 deferred continuation，必须另外规定成功结果的身份、时效、失败/重试、权限 revision 和 dispatch 边界，而不能仅把 `Promise<unknown>` 包一层。这个判断是对代码现状的条件解释，不是断言所有调用者都已经错误。

**未定问题与下一最小调查。** 需要区分的只有一个真实分叉：现有调用者把 guard 成功当作“瞬时前置条件”，还是当作“可跨时间复用的授权/接纳”。最小调查是追一条真实 pipeline caller 到 dispatcher，记录 guard 快照获取与实际 dispatch 是否可能跨队列/等待/重试，并查 dispatch 前是否重新检查当前策略；若没有跨时间复用，可保留为局部 guard；若存在，则必须把它接入显式的 decision/admission/deferred 契约，不能由高阶包装自动补齐。
