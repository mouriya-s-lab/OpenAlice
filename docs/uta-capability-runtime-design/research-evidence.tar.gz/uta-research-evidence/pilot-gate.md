# 首轮 Gate：不放行扩大研究

这是 Main 对实际两份输出的裁决，不是架构结论。

## 核对与拒收

- UtaPilotSpecified §2 把 Candle gap 行为安到旧 guard 上。真实 `guard-pipeline.ts:13-36` 只有 Operation、account reads、guard.check、dispatcher，没有 Candle/checkpoint/event 输入。这只能是人为加装后的反例，不是旧实现已发生的行为。
- 同段称 Promise.all “静默伪造快照”。源码只证明两个读并发后组成 context，不能推出它承诺原子快照。也不能仅因多个 guard 读取同一 context，就认定它违反渐进决定；纯 predicate 合取可以合法共享 immutable facts。需另查改变的状态是什么。
- UtaPilotSpecified 在 gap 后一概禁止决定请求；主书:721 明确保留请求决定策略。“没有 crossing”与“不能因 gap 请求决定”是不同断言。其成功段还混淆 NoActivation/Candidate/Gap 的 outcome 与 failure channel。
- UtaPilotBounded 把主书:376 的“声明覆盖所有可选分支”推进成“注册时可枚举”。有限静态目录是一种候选实现，不是给定事实，也未排除有界参数化 family 或调用阶段校验。
- 两者区分结果载体有价值，但不能从控制协议不同推出计算构造不能共享，或 Candidate 永远不能作为 Query 的普通读取结果。表示、消费权与效果权要分别判断。

## 对派发方式的修正

首轮源包偏重已命名目标协议，问题虽然要求推演，结果仍有顺着术语确认现有模式的倾向。不能靠增加禁止句解决：下一小轮将源码溯源与有限逻辑比较拆开，改变材料与推理任务。

第二档追现有真实 caller/guard state，区分当前行为与新目标要求。第三档在明确前提下比较三种构造解释并寻找区分条件；它承担思考，不承担未知系统事实的独立验证。初始独立输出完整保存，不回改成看似首轮已通过。

两个模型和相同输入只提供观点差异，不是统计 A/B 性能测量。Gate 失败针对这些论断及本轮材料设计，不给模型作普遍能力排名。
