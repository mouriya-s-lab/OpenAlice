#!/bin/sh
# Run from the OpenAlice checkout. Only local injected reads/dispatcher are used.
node --import tsx --conditions=openalice-source --input-type=module <<'NODE'
import assert from 'node:assert/strict';
import Decimal from 'decimal.js';
import { Contract, Order } from '@traderalice/ibkr';
import { CooldownGuard } from './services/uta/src/domain/trading/guards/cooldown.ts';
import { createGuardPipeline } from './services/uta/src/domain/trading/guards/guard-pipeline.ts';
const contract = new Contract();
contract.symbol = 'UTA-RESEARCH-ONLY';
const order = new Order();
order.action = 'BUY';
order.orderType = 'MKT';
order.totalQuantity = new Decimal('1');
const operation = { action: 'placeOrder', contract, order };
let dispatches = 0;
const account = { getPositions: async () => [], getAccount: async () => ({ netLiquidation: '1000' }) };
const execute = async () => { dispatches++; return { success: true }; };
const reject = { name: 'later-reject', check: () => 'intentional local rejection' };
const stateful = createGuardPipeline(execute, account, [new CooldownGuard({ minIntervalMs: 60000 }), reject]);
const first = await stateful(operation);
const second = await stateful(operation);
assert.match(first.error, /later-reject/);
assert.match(second.error, /cooldown/);
assert.equal(dispatches, 0);
const observations = [];
const pure = createGuardPipeline(execute, account, [
  { name: 'pure-one', check: (ctx) => { observations.push(ctx); return null; } },
  { name: 'pure-two', check: (ctx) => { observations.push(ctx); return null; } },
]);
await pure(operation);
assert.equal(observations[0], observations[1]);
assert.equal(dispatches, 1);
console.log(JSON.stringify({
  purpose: 'actual source control flow with injected local reads/dispatcher; no Broker connection',
  node: process.version,
  stateful: { first: first.error, second: second.error, dispatches: 0 },
  pureReadOnly: { sameContext: observations[0] === observations[1], acceptedDispatches: dispatches },
  conclusion: 'shared context alone is not the discriminator; eager guard state mutation survives a later rejection'
}, null, 2));
NODE
