# 持久记录消费试验

一个新的 bounded 研究者只按落盘实践与活动计划接手 Instrument 来源决定后继查询的小切口，没有继承本会话对话。实际输出选择了 Instrument 到 1h Candle 有限页的一条消费者路径，并用当前 BarSourceCandidate/BarSourceRef/getBars 分辨身份提示与可调用 binding。

Main 复读 src/domain/market-data/bars/types.ts:94-168 和 bar-service.ts:237-274,371-387：候选包含 barId/sourceId/assetClass/barCapability，vendor barId 需assetClass，UTA fetch仍读取当前capability。它们支持该局部研究入口；不把当前读取服务说成新Instrument契约。

接受的是接手行为：没有遍历全部Provider、没有宣布最终API、没有把描述范围与授权时机绑成同一个二选一，能用目标和源码提出下一小调查。只在已指定业务操作/交付（Candle有限Pull）范围内讨论后继，不从InstrumentRef自动推出任意操作。

不接受原报告提出的新错误名字或“必然需要二次discover”作为已选协议；是否需要再解析、如何保持参数化描述仍是待研究关系。它是一次实际可用性证据，不证明未来研究者永不偏离。
