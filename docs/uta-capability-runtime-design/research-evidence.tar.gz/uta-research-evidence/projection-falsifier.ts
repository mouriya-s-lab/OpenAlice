import assert from 'node:assert/strict';
import { richCandleAt } from './specimen/source.js';
import {
  richFeedDefinition, baseFeedDefinition, richFeedEventSchema,
  projectRichEventToBase, FeedControlMachine,
} from './specimen/types.js';

const identity = (eventId: string, sequence: number) => ({
  eventId, sequence, binding: richFeedDefinition.binding,
  bindingLabel: richFeedDefinition.bindingLabel, source: 'fixture',
  generation: 'g1', partition: 'research',
  lineage: { sourceBinding: richFeedDefinition.binding, sourceEventId: eventId, operators: [] },
});
const started = richFeedEventSchema.parse({ ...identity('research-start', 0), tag: 'Started' });
const payload = richCandleAt(0, 'research-data');
const original = richFeedEventSchema.parse({ ...identity('research-data', 1), tag: 'Data', payload });
const changed = richFeedEventSchema.parse({
  ...identity('research-data', 1), tag: 'Data', payload: { ...payload, vwap: '102.25' },
});
const rich = new FeedControlMachine(richFeedDefinition);
const base = new FeedControlMachine(baseFeedDefinition);
for (const event of [started, original]) {
  const richResult = rich.accept(event);
  const baseResult = base.accept(projectRichEventToBase(event));
  if (richResult.tag !== 'accepted' || baseResult.tag !== 'accepted') throw new Error('Setup must be accepted on both independent paths');
  assert.equal(richResult.evolution, 'advanced');
  assert.equal(baseResult.evolution, 'advanced');
}
const richResult = rich.accept(changed);
const baseResult = base.accept(projectRichEventToBase(changed));
if (richResult.tag !== 'rejected' || baseResult.tag !== 'accepted') throw new Error('Expected rich conflict and projected duplicate');
assert.equal(richResult.code, 'duplicate-id-conflict');
assert.equal(baseResult.evolution, 'duplicate');
assert.deepEqual(projectRichEventToBase(original), projectRichEventToBase(changed));
console.log(JSON.stringify({
  source: 'Unmodified archived source.ts and types.ts; independent accept-first and project-first paths',
  node: process.version,
  changedField: 'vwap', before: payload.vwap, after: '102.25',
  baseProjectionEqual: true,
  richAcceptance: { tag: richResult.tag, code: richResult.code },
  projectFirstAcceptance: { tag: baseResult.tag, evolution: baseResult.evolution },
  supports: 'A total payload projection does not preserve acceptance equivalence when duplicate classification consumes erased extension fields.',
  doesNotProve: 'No production failure or general rejection of transparent projection; this conflict input tests a wider domain than already-accepted valid traces.',
}, null, 2));
