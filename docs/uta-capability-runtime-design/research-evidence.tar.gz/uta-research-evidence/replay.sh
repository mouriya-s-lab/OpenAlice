#!/bin/sh
set -eu
repo=${1:?Pass the OpenAlice checkout path}
work=${2:?Pass a new isolated output directory}
evidence=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo=$(CDPATH= cd -- "$repo" && pwd)
if [ -e "$work" ]; then
  printf '%s\n' 'Refusing to reuse or overwrite the output directory' >&2
  exit 2
fi
mkdir -p "$work"
work=$(CDPATH= cd -- "$work" && pwd)
tar -xzf "$repo/docs/uta-capability-runtime-design/verification-evidence.tar.gz" -C "$work"
tar -xzf "$repo/docs/uta-capability-runtime-design/event-flow-evidence.tar.gz" -C "$work"
base="$work/uta-design-evidence"
events="$work/uta-event-flow-evidence"
npm ci --ignore-scripts --no-audit --no-fund --prefix "$base" > "$work/install.stdout" 2> "$work/install.stderr"
ln -s "$base/node_modules" "$events/node_modules"
cp "$evidence/permission-falsifier.ts" "$base/permission-falsifier.ts"
cp "$evidence/projection-falsifier.ts" "$events/projection-falsifier.ts"
(cd "$repo" && sh "$evidence/guard-observation.sh") > "$work/guard.stdout" 2> "$work/guard.stderr"
(cd "$base" && node --import tsx permission-falsifier.ts) > "$work/permission.stdout" 2> "$work/permission.stderr"
(cd "$events" && node --import tsx projection-falsifier.ts) > "$work/projection.stdout" 2> "$work/projection.stderr"
printf 'Three isolated research experiments completed. Outputs: %s\n' "$work"
