import assert from 'node:assert/strict';
import { Context, Effect } from 'effect';
import { z } from 'zod';
import { definePull, combineReads, type Meaning } from './specimen/algebra.js';
import { Catalog, pullEntry } from './specimen/catalog.js';

interface LocalRead { readonly read: (input: number) => number }
const LocalRead = Context.GenericTag<LocalRead>('research/local-read');
const meaning = (path: string, permission: string): Meaning => ({
  provider: 'research', path: [path], revision: '1', semanticVersion: 'research-only',
  description: 'Isolated archived-specimen permission experiment',
  permission, transformations: [], dependencies: [],
});
const slots = {
  input: z.number(), output: z.number(),
  failure: z.strictObject({ tag: z.literal('read-failed') }),
};
let leftCalls = 0;
let rightCalls = 0;
const left = definePull(LocalRead)(meaning('left', 'left:read'), slots,
  (service, input) => Effect.sync(() => service.read(input)))
  .provide(LocalRead, { read: (input) => { leftCalls++; return input; } });
const right = definePull(LocalRead)(meaning('right', 'right:read'), slots,
  (service, input) => Effect.sync(() => service.read(input)))
  .provide(LocalRead, { read: (input) => { rightCalls++; return input; } });
const combined = combineReads(left, right, meaning('combined', 'left:read'));
const catalog = new Catalog();
catalog.register(pullEntry(left));
catalog.register(pullEntry(right));
catalog.register(pullEntry(combined));
const principal = { id: 'research-only', permits: ['left:read'] };
assert.throws(() => catalog.resolve(principal, 'research', 'right', right.descriptor.binding), /not visible/);
const entry = catalog.resolve(principal, 'research', 'combined', combined.descriptor.binding);
if (entry.tag !== 'pull') throw new Error('Expected finite Pull specimen');
const output = await entry.invoke({ left: 1, right: 2 });
assert.deepEqual(output, { tag: 'output', value: { left: 1, right: 2 } });
assert.equal(leftCalls, 1);
assert.equal(rightCalls, 1);
console.log(JSON.stringify({
  source: 'Unmodified archived algebra.ts and catalog.ts',
  node: process.version,
  directRightDenied: true,
  combinedPermission: combined.descriptor.permission,
  principalPermissions: principal.permits,
  leftCalls, rightCalls, output,
  supports: 'The specimen does not mechanically preserve the permission requirements of both members.',
  doesNotProve: 'No production vulnerability, Broker behavior, or impossibility of the candidate composition law is established.',
}, null, 2));
