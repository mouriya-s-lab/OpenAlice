# UTA 结果依赖组合：独立推演报告

## 0. 本报告的地位

- 只用共同 brief 指定的材料做有限逻辑推演，不做外部调查、不运行代码、不改文件。
- 稿中的“实施规格”（特别是组合代数签名）当候选关系，不当已接受模型。原文自己声明：签名是类型关系记法，同名 TS API 的机械可行性由可执行样例检验，不能把关系记法当成已实现库（docs/uta-capability-runtime-design.md:327）。
- 区分四类陈述：【原文事实】有锚点；【条件推论】写明前提；【候选取舍】是我认为值得保留/修正的关系；【未定】是不知道的实现事实，不补造。
- 不做四种禁止推论：不从“都是 IO”推出同一交易协议；不因缺 Provider 实测拒绝推演已声明黑箱契约；不从类型闭合推出业务正确；不把新目标缩为旧 UTA 迁移，也不把局部问题升级为通用语言/万能 workflow。

## 1. 成功推演：连续基线下的 Candle crossing 经通用激活关系到达决定

【原文事实】`DeferredInvocation` 关联尚未开始发送的 IntentRevision、激活拥有者、来源集合、纯 predicate、checkpoint schema、未来边界、有效期、冻结 disposition、有责任 decision channel，不是新 Order 类型（docs/uta-capability-runtime-design.md:708）。`advance(Checkpoint,SourceFact,FutureBoundary): {checkpoint, outcome: NoActivation|Candidate<Evidence>|Gap}`（同文件:714-717）。predicate 冻结实现身份、配置、单位、来源和 checkpoint 版本，不能隐式读全局“最后价格”（同文件:719）。非命中事实若改变必要 checkpoint 也必须持久化（同文件:721）。事件身份/epoch 去重、checkpoint 更新、意图状态变化及下一 outbox 在一个 writer transaction 提交；同一意图版本只有一个 live owner，多源在该 owner 内组合（同文件:723）。disposition 有限选择 RequestDecision/SeekAuthorizedExecution/CloseWithoutDispatch（同文件:729）；RequestDecision 产生含 revision、来源与 predicate、选中证据、触发原因、有效期、授权状态、责任渠道、允许响应 schema 的精确请求（同文件:731）。响应 Keep/Rearm/Revise/Discard/RequestSubmission 各有持久结果和禁止隐含的效果（同文件:735-739），必须匹配 request、控制版本、revision、epoch、主体与有效期，迟到返回 stale/conflict（同文件:741）。到期与回复竞争同一控制版本 CAS，只有一个生效；Keep 保留期限、请求有效期、批准有效期、投递租约分别建模（同文件:743）。实例槽位见 13.3 表：受控意图、已绑定 Candle 来源+连续性契约、版本化 crossing 算法+单位、唯一 live owner、注册时未来边界、显式 RequestDecision、SuspendControl、响应 schema、独立授权（同文件:850-860）。false baseline 可在非命中时持久化；连续新事实构成 crossing 后只产生选中证据和决定请求；Rearm 产生新 epoch 和未来边界，旧响应不能改新 epoch（同文件:862）。需执行时 RequestSubmission 仍进普通 prepare/approval/start 边界（同文件:739,864）。

推演（成功路径）：
1. T1 收到 false@9：`advance(baseline=∅, fact=false@9, boundary=B0)` 返回 `NoActivation`，但按 721+862 把 `baseline=9@r1` 作为有界 checkpoint 持久化。这一步的“结果”不是 bool，而是“更新后的 checkpoint + 无候选”。
2. T2 收到连续 true-crossing@11，且连续性契约 intact（无 Gap、无 Correction）：`advance(baseline=9, fact=11, B0)` 返回 `Candidate<Evidence>`，Evidence 内含来源绑定（Instrument/interval/generation）、predicate 版本、选中事实 lineage、触发原因。
3. 同一 writer transaction 提交去重+新 checkpoint+意图状态不变+新 outbox（RequestDecision 请求）。后继的输入不是裸价 `11`，而是 `Candidate` 这个结果种类+证据包+控制版本。
4. Agent 按允许 schema 回复；若需执行，`RequestSubmission` 进入 prepare/approval/dispatch。安装解释器可消解 native 服务要求，但不能消去执行权限；发送时仍按冻结范围与当前策略取许可（同文件:392；`provide` 只消解服务、权限不变，`authorize` 绑定主体/能力/范围/策略版本，不能从 Context 有 BrokerClient 推导，同文件:359-363）。
5. 全程保留四种语义：失败保留为显式变体（NoActivation vs Candidate vs Gap，不收窄成字符串）；资源保留为单 owner 内组合+进程内 Scope 不跨持久权威（同文件:365,723）；权限保留为冻结+发送时复核两段；时间保留为 baseline/连续性+未来边界+epoch+四时钟分离。

【条件推论】若 predicate 算法、单位、来源绑定、checkpoint 版本确实如 719 被冻结，且 writer transaction 如 723 原子提交，则“前结果决定后继”成立：后继构造函数消费的是前步的结果种类与证据，不是前步的值字段。反之任一冻结缺失，成功不成立。

## 2. 反例/时序：同一阈值函数在 Gap 下必须不激活；旧 guard 管道在此时会错误激活

构造时序（与成功用同一 predicate、同一阈值，仅历史不同）：
- T1 `false@10` 已持久为 baseline。
- T2 断流：无来源声明的 event-time watermark/snapshot barrier/有限 Pull 完成，也无声明的 processing-deadline Partial。按 EF04，只有三者之一才能证明完整性；`receivedAt`、本地 `Date.now()`、数组位置、chunk 名都不能代替（docs/uta-capability-runtime-design/event-flows.md:486-487）；deadline 能关闭投影但必须带 Partial/deadline reason，绝不暗示 watermark/finality（同文件:487,412-413）。
- T3 收到 `true@12`。

【原文事实】边沿需 baseline 与连续性；false@10 后断流再收 true@12，不能凭空证明穿越；Gap 使所需 baseline 失效，策略选等待新可信边界、请求决定或关闭（docs/uta-capability-runtime-design.md:721）。13.3 实例明言：若中间存在 gap，第一个高于阈值的值只重建 baseline，不能宣称 crossing（同文件:862）。Correction/Retraction 经证据依赖找已选证据和 checkpoint，不依赖谓词再命中；未发送工作被栅栏化并请求新决定，已发送或 Unknown 保留，不能用修订撤销外部现实（同文件:725）。

正确行为：T3 的 `advance` 必须返回 `Gap`（或重建 baseline 后的 `NoActivation`），不产生 Candidate，不产生决定请求。旧匹配不可重消费（同文件:856,736）。

朴素错误行为（有区分力）：`if (price > threshold) dispatch(order)` 会在 T3 直接发送。这犯了三种被方法论边界点名的错误：把类型/条件闭合当业务正确（同文件:104-115，以远端 ACK 当交易完成为喻）；把到达顺序当事件时间顺序（IBKR decoder 到达序≠event-time 序，无 native seq 只能保 adapter transport evidence，event-flows.md:481）；用 `receivedAt`/now 补 watermark（event-flows.md:487 明确禁止）。

旧 guard 管道恰好是这种朴素行为的实例化：

【原文事实】`createGuardPipeline(dispatcher, account, guards)` 对 `account.getPositions()` 与 `account.getAccount()` 做 `Promise.all`，组装同一 `GuardContext` 依次过 `guard.check`，遇 rejection 返回 `{success:false, error: "[guard:...]..."}`，否则 `dispatcher(op)`（services/uta/src/domain/trading/guards/guard-pipeline.ts:20-36）。注释称它是唯一触 account 处，guard 不直接见 account（同文件:1-7）。

它丢失的三件事，正是成功路径保留的三件事：
1. 联合读无声明：`Promise.all` 把两次独立读合成一个隐式原子快照，无 JoinPolicy、无来源/一致性窗口、无部分失败策略。设计稿要求 `combine` 明确部分失败策略、来源和一致性窗口，联合结果不是原子快照（docs/uta-capability-runtime-design.md:376）；`combineReads` 保留两份结果及两边资源/失败要求，不制造同一时刻快照（同文件:840）。旧管道若一读失败则整 await 抛异常，无 `E1+E2+F` 联合；若两读时刻不一致则静默伪造快照。
2. 复合决定读旧快照：后续 guard 读同一 ctx，不读前一步演进后状态。设计稿要求复合命令后续决定读前一步演进后状态（同文件:533）；任何一步拒绝，同原子本地决定的先前 guard/reservation 变化一并不提交，独立批次保留逐项结果（同文件:533-534）。旧管道 early return 无回滚/保留语义。
3. 失败收窄成字符串：`{success:false, error:string}` 丢失 sourceBinding、terminal 与可恢复 item 失败的区分。EF04 要求 `MemberItem=Item|ItemFailure` 仅当 ItemFailure 已在 Unit 声明可恢复；`MemberOutcome` 是带 sourceBinding 的 Completed/Failed/Cancelled 和；`CompositeResult=Complete|Partial<MemberOutcome[]>|Unavailable` 需 operator/recipe 显式声明 profile；默认 child Failed 使 outer Failed，只有声明 partial profile 才保留 MemberOutcome（event-flows.md:392-396,464-473,490）。旧管道无法表达“Partial 保留失败成员+覆盖证据仍 outer Completed 但 coverage=Partial”与“默认 outer Failed 并释放 B 拥有权、不接受已关闭 A 后续 Data”（event-flows.md:462-473）的区别。

时序后果：把 T3 的 true@12 喂给旧管道，它基于 T1 旧 baseline+新读快照直接通过并 dispatch，绕过 Gap 栅栏、绕过未来边界/epoch（旧响应改新 epoch 被 741,736,856 禁止）、绕过发送时授权复核（363,392），并可能用 Discard 抹掉已发送意图（738,864 明确禁止：Discard 仅对未发送本地退休，不能把已发送伪装撤销）。

## 3. 发现一：值组合与控制组合分两层，共享的是“结果种类决定后继构造”的协议

【原文事实】`flatMap(Query, A->Query): Query<E1+E2,R1+R2,P1∪P2>` 保留错误/服务/权限联合，动态分支须覆盖所有可选分支（docs/uta-capability-runtime-design.md:370-376）。`provide` 只消解服务，权限不变（同文件:359-363）。`withTransaction` 不接受已可调用 Query，native dispatch 只在私有解释器，公开结果是 receipt/handle（同文件:390-392）。`deferUntil` 只关联未开始意图版本与单 owner，多源在 owner 内组合，不是 Agent 工作流图（同文件:394,708-710）。内核 `decide(state,command,facts,now)->Rejected|Accepted(events+外部工作描述)` 与 `evolve(state,event)->下一状态` 不能起 Promise/调 SDK/读全局时钟/改共享 guard（同文件:531；初版 decide/evolve 纯粹穷尽，见 docs/uta-effect-runtime-architecture.md:315-338）。运行中 Effect 是工作说明+资源解释，持久 Plan 是编码值，非同种可序列化对象（docs/uta-capability-runtime-design.md:535）。

论证：前结果决定后继有两种不同含义。值层：前 Query 的成功值 `A` 决定下一个 Query 如何构造（flatMap 的 `A->Query`），失败/服务/权限取联合，这是纯构造关系。控制层：前激活的 `Candidate<Evidence>`/`Gap`/终态决定意图走 RequestDecision/等待/关闭哪条处置，且处置冻结的授权、边界、租约在发送时重核。旧管道把两者压成一种“同一 ctx 过同一 guard 链再 dispatch”：看起来都是 IO，实则把批准、补偿、持久化协议混同。方法论边界已预警：行情订阅和订单提交都是 IO，但不能推出共享同一批准/补偿/持久化协议（同文件:119）；“能装进泛型”不能证明领域抽象恰当（同文件:121）；在哪层共享构造/组合/消费规律、在哪层保留业务语义，必须判断（同文件:123）。

【候选取舍】保留 `flatMap/combine` 的值联合律 + `deferUntil/withTransaction/decide-evolve` 的控制分离 + `authorize` 与 `provide` 分离 + Effect/Plan 分离；修正/不迁移旧管道：它的 Promise.all 快照、同一 ctx 复用、字符串失败、dispatch 直通，应视为反例而非迁移目标。这不把新目标缩为旧迁移（新预设场景会提旧系统没有的要求，同文件:42），也不新增强制核心分支：业务 predicate/join key/watermark 来源/disposition 配置作为业务函数/构造进入共同规则即可（符合 brief 允许的特化）。

前提与反例：前提是调用者如 376/719/840 所要求声明分支覆盖、触发语义、coverage/finality。若某业务确实无多分支、无权限、无时间敏感，则旧管道的简化在此特例成立——但这恰是条件弱化后的特例成立，不是通用规律成立。区分输入见 §5。

## 4. 发现二：终态/时间/完成度是声明的策略选择，不是值推导的产物；后继无权升级前结果

【原文事实】`extend/sum/constrain` 与投影规则：投影声明丢弃信息并携 source/coverage/finality，不能把 Partial 变 Complete、provisional 变 closed、估算值标原生证据（docs/uta-capability-runtime-design.md:350）；对 Feed 同值投影不得丢 gap/correction/终止语义（同文件:352）。candlePull 成功页是 Partial、Candle 是 provisional，投影后不升级（同文件:840）。EF04 透明投影只能重编码，不得过滤 invalid、改失败分类、改 terminal/coverage、提级 provider 保证，任何改变留 binding+lineage（event-flows.md:491）。outer terminal 只按声明的 all/any/quorum/explicit barrier 发一次，无默认 best-effort，closed member 不 resume（event-flows.md:490,396）。Window 关闭需 watermark/barrier 或声明 deadline，deadline 不宣称 finality（event-flows.md:412-413）。Bars 同名 symbol 跨 provider 不合并，需 InstrumentId/source identity 作 join key（event-flows.md:479）；News 跨 feed 不凭文本合并，除非声明跨源 canonicalization 并保留 lineage（event-flows.md:480）。Keep/Rearm/Revise/Disposition 四时钟分别建模（docs/uta-capability-runtime-design.md:743）。静态已知 rich Candle 与运行时发现的外部词汇要区分，不用预写 RichCandle 桥冒充动态类型（同文件:842）；scoped stream 只证进程内释放与终态选择，不证外部 credit/replay（同文件:842）。

论证：Gap、Partial、provisional、child Failed、outer Failed/Completed 都是“谁有权宣布完成”的问题。来源用 watermark/barrier/有限 Pull 完成宣布自己完整；composite 用 partial profile+barrier 政策宣布 outer 终态；激活用未来边界+epoch+CAS 宣布旧证据不可重消费；四时钟宣布各自到期。值本身（价格数字、bar 字段、文本相似度）无权宣布这些。若允许后继升级（Partial→Complete、provisional→closed、deadline→watermark、ItemFailure↔child Failed 互换、closed resume），则类型仍可闭合但业务错误——这正是边界 104-115 警告的“表达成立≠表达正确”，黑箱边界契约必须写清要求保证什么 vs 实际能保证什么（同文件:115）。

【候选取舍】保留 EF04 显式 ADT（MemberItem/MemberOutcome/CompositeResult）+ operator binding（name/version/digest、输入 binding/revision、scope/failure/coverage/terminal/late policy，event-flows.md:386）+ source event 永留、派生另给 derivedEventId+lineage（同文件:386）。任何 merge/join/window 若缺 key/边界/watermark/缺侧策略即按 398-404 表拒绝为非透明扩展，不补默认值。

前提与反例：前提是 watermark/barrier/deadline 来源被诚实声明。若某来源谎报 watermark（如用 receivedAt 冒充），则 outer Complete 的保证即被掏空——此时错不在组合律，而在边界契约失真，需最小实验定位（属设计问题还是实现验证，见同文件:148-150）。反例即 §2 的 gap-then-true 与 provisional 升级、deadline 冒充、跨源按 display symbol 合并三例，任一发生即证伪“值相似即 same 结果”。

## 5. 最能区分不同解释的一个小调查

问题：`advance` 的 Gap 语义与旧管道的值直通语义，在什么最小输入下必然分叉？

建议的最小区分调查（只读+推演，不连服务、不执行源码）：
- 输入：同一 predicate（阈值 crossing，edge 语义）+ 同一三事实序列 `false@10 → 断流（无 watermark、无 deadline 声明）→ true@12`，外加一次 `Correction(target=false@10, revision=r2)` 在 T3 之后到达。
- 两种解释的预测：解释 A（本报告：Gap 失效 baseline）预测 T3 只重建 baseline、无 Candidate，Correction 经证据依赖找旧 checkpoint、未发送则栅栏+请求新决定、已发送则保留（725）；解释 B（值直通：阈值即 dispatch，Correction 即重算重发）预测 T3 直接 Candidate/dispatch，且 Correction 直接撤销/重发。
- 判定：若按稿子 721+862+725，A 与 B 在 T3 是否产生 Candidate、Correction 是否触发送后撤销两点上必然分叉；任一分叉点即判定旧管道不可直接复用，且 outer terminal/Partial 政策必须显式声明。若材料不能判定断流是否算 Gap（即 watermark/deadline 声明缺失算输入错误还是默认等待），则定位到未定问题：operator binding stale/watermark missing 应 reject（event-flows.md:410-411）与注册缺冻结策略算输入错误（docs/uta-capability-runtime-design.md:743）的衔接缺口，需补一个明确前提（默认是等待还是拒绝），而不是补实现。

【未定清单（不补造）】5.x 组合子的可执行形态（327）；Python Provider 动态加载的 binding/slot 认证细节（842）；IBKR/CCXT 各自 watermark/barrier 的真实来源与 credit/replay 协议（842 明确 scoped stream 不能证明）；`getPositions/getAccount` 的失败模式与并发更新窗口；四时钟的具体超时值与 CAS 载体。这些属实现阶段最小实验验证（148-152），不影响本次条件推论。

