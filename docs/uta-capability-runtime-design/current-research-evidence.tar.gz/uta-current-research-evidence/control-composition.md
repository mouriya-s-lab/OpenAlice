# UTA 控制组合：纯决定、writer barrier 与异构成员

## 范围与结论

本报告只研究当前候选主书 §§9–10、§13.4，以及 `event-flows.md` EF06–EF09；原 guard 源码只作为当前行为锚点。没有修改仓库，也没有编写或运行代码、测试、实验、脚本、build、lint 或 formatter。

结论分为四层：

1. **纯决定与顺序演进已有可用构造。** 同一受控 RecipeAssociation `A` 已经把 intent、ReadFacts、Prepared、阶段失败、criterion、resolution、exposure/compensation 及 binding 关联在一起。纯决定可在给定的 `I`、有来源 facts、writer-owned local state 和显式时间上提出候选事件；`evolve` 可先把候选事件折叠为推测状态，让后继决定消费前一步的结果。候选不是 authority，只有 writer commit 后才是 DomainEvent。
2. **EF06 的“writer 外 guard”与 §9.1/§10.5 不是概念冲突，但文字缺少一条不可省略的 barrier。** EF06 的 PrepareWorker 评估只能是 tentative candidate/evidence；`RecordPrepared` 只能保存 plan/candidate，不能消费共享额度或 cooldown。规则声明的 approval/queue 或 `DispatchStarted` 消费触点必须由 writer 读取最新 progressive state、重验声明的 guard/precondition，并把共享 reservation 与 job/outbox/receipt 放在同一原子写集。若只做 intent revision 的 CAS 而不重验风险事实，旧 prepare 仍可能通过；因此 EF06:691–692、740–748 需要明确写出这条连接。
3. **组合 coordinator 不能把成员压成一个成功布尔值。** 每个成员自己的 `decideCriterion`、`decideResolution` 和 exposure/observation reducer 产生不同轴的精确结果；coordinator 消费这些结果、reservation 状态和责任 owner，形成 `ChildProgress` 与组级控制进度。`CriterionSatisfied` 可以和 `ResolutionUnknown`、未解决 exposure 同时存在。`Ack`、业务目标、尝试是否解析和责任是否可释放各自回答不同问题。
4. **Independent / AllOrCompensate / VenueNativeAtomic 是不同承诺。** Independent 不提供全组回滚；AllOrCompensate 只提供声明等级和证据条件下的新 compensation recipe；NativeAtomic 只有精确 provider/作用域/操作组合的 conformance 才可用。两个成员一部分成功、另一个 Unknown 时，Unknown 绝不能变成 known rejection 或零敞口，也不能据此推出无条件安全补偿。

---

## 1. 当前稿已经给出的构造

### 1.1 纯决定、演进和持久边界

主书 §9.1（`docs/uta-capability-runtime-design.md:627–637`）已明确：

- `decide(state, command, facts, now)` 返回 `Rejected`，或 `Accepted` 的候选事件与外部 WorkDescription；它不启动 Promise、不调用 SDK、不读全局时钟、不改共享 guard 对象。
- `evolve(state, event)` 是同一个纯演进函数，既可重建已接纳历史，也可在候选阶段计算推测状态。
- 在一项顺序复合决定中，从 `s0` 提出前一步事件并用 `evolve` 得到推测 `s1`，后一步在 `s1` 上判断；最后仍只是候选写集。writer 复核版本/失效条件，原子写入事件、决定性 projection、必要 work/outbox 和 receipt 后才形成 authority。
- 任一步拒绝或提交失败时，推测状态和整个候选写集都不成为权威。

主书 §9.2（`:641–659`）把持久记录按槽位分开：`Intent / Prepared / Dispatch / Ack / Observation / Recovery / Compensation`。计划至少关联 intent revision、Provider/binding、AccountScope、编译/codec/observer/compensator/predicate/criterion/resolution 身份、精确输入和事实、授权、原生查找、expected version、reservation、attempt 与 outbox。它禁止用所有字段 optional 的大并集把这些状态混在一起。

主书 §9.4–9.5（`:675–724`）已给出 writer authority：同一 transaction 读取 command key/expected version、验证授权和 reservation、运行纯决定、追加事件、更新 projection、写入 work/outbox 和 receipt；成功 receipt 只能在 commit 后返回。对批准、reservation、计划状态和成功判据有影响的 projection 必须和权威事件同事务更新。

### 1.2 同一 RecipeAssociation 的阶段消费者

主书 §10.1（`:728–751`）从一个 recipe `A` 派生：

- `prepare(A.Intent, A.ReadFacts) -> Result<A.Prepared, A.PrepareFailure>`；
- `start(A.Prepared, DispatchGrant<A.Binding,A.Plan,A.Attempt>)`；
- `observe(A.Prepared, A.AttemptEvidence)`；
- `decideCriterion(A.Prepared, A.ObservationHistory)`；
- `decideResolution(A.Prepared, A.AttemptEvidence, A.ObservationHistory)`；
- `planCompensation(A.Prepared, A.ExposureEvidence, A.Policy)`。

这里的 `A` 不是调用者可以自由拼接的泛型，而是同一个 declaration association 的精确 slots、服务、权限、parser、codec 和解释器身份。`prepare` 的环境读取在边界形成 ReadFacts，纯 compiler 再消费这些 facts；`start` 只存在于私有 writer-issued grant 之后。接纳 receipt 只证明 intent 已保存，不吞掉后续 prepare/dispatch/observation 的阶段失败。

主书 §10.1.1（`:753–770`）已给出控制消费者的共同构造：同一 `A` 派生提交 parser、receipt、事件 envelope、Prepared 编码、阶段状态/失败和 runtime consumers；重启后按完整 binding、slot、实现身份重新绑定。该构造统一外层控制形状，不抹平每个叶子的 Prepared、Observation、criterion、resolution 或 compensation 语义。

主书 §10.2（`:772–803`）又明确把业务 criterion 与控制结案拆开：criterion 判断目标是否满足，resolution 判断本次 native attempt 是否解析；writer 还要检查未决 work、reservation 和恢复责任。目标满足但 attempt 仍可能产生效果时，可以同时报告“业务目标满足”和“需要恢复”。

### 1.3 EF06–EF09 已有控制方向

EF06（`event-flows.md:682–779`）已经区分：

1. writer 在短事务中接纳 `A.Intent`，提交 `IntentAccepted + receipt + PrepareWork`；
2. trusted Read Interpreter 在 writer 外读 scoped facts 并运行纯 compiler/guards；
3. `RecordPrepared` 带 plan digest、Prepared、fact/evaluator evidence 和 expected intent revision 回 writer；
4. `RequestSubmission` 不是 `Approve`；匹配的真实 approver/delegated witness 才能绑定 approval；
5. 没有 approver witness 时只能得到 `AwaitingApproval`，不创建 `ApprovalBound`、reservation 或 dispatch。

EF07（`:783–868`）规定 `DispatchStarted` 由 scheduler/private worker 请求，writer 在 approval、lease/epoch、scope 和 expected revision 上做 CAS，**先提交 started，再交付一次性 grant**。raw ack/observation 先回 writer；Ack 不等于 fill、cancel 或 finality；transport loss/crash/timeout 进入已有 evidence 判断或 `OutcomeUnknown + RecoveryRequired`，而不是盲目重发。

EF08（`:872–983`）把 Cancel、Replace、Close 作为独立 recipe。Close 的 `All` 与 `QuantityTarget` 是 genuine alternatives；Close criterion、Cancel 的 `NoFurtherWorking`、Replace 的 amendment criterion 和 exposure criterion 不可互换。部分成交后的 cancel 不能抹掉 fills、费用或 exposure。

EF09（`:987–1141`）已明确三种 batch policy、每个 child 的 recipe/slot/digest/scope/attempt/criterion/history，以及 `BatchRegistered`、`GroupPolicyBound`、`ChildProgress`、`GroupReady`、`BatchCompensationRequired`、`CompensationProgress` 和 `GroupSatisfied/RecoveryRequired` 的控制事件方向。

---

## 2. 纯业务规则怎样由同一声明产生候选与失败

### 2.1 操作数应怎样理解

这里的“同一声明”不是让 `RuleDeclaration` 私藏一个可变状态对象，而是要求以下关系都来自同一个 `A`/rule binding：

- `I`：该叶子的精确 semantic intent，包括 provider extension、单位、scope/identity 关联；不是 SDK `Order` 或调用者自填 facts。
- `F`：由 trusted read boundary 取得并解码的 `A.ReadFacts`，例如 account/position/quote/valuation/permission observation，带 scope、source identity、generation、as-of、sequence 和 completeness。它不是调用者传来的 `balance`、`position` 或“已批准”字符串。
- `L`：writer-owned 的最新 local state slice，例如已接纳 activity、尚未结清的 controlled intents、durable reservations、policy revision、attempt/recovery ownership。它不是 `CooldownGuard` 的进程内 Map。
- `t`：边界提供的显式 `Instant`。纯规则不调用 `Date.now()`。
- `A`：同时持有 input/fact/prepared/observation/failure/criterion/resolution/compensation 的 schema、applicability、实现身份和版本；guard HOF 只能从该 A 的 semantic projection 取得自己的精确输入。

因此可用关系记为：


声明绑定的决定 `D_A(L, I, F, t)` `= Rejected<A.Failure> | Accepted<A.CandidateEvents, A.WorkDescription>`。

`A.CandidateEvents` 是拟议的事件/状态更新；`A.WorkDescription` 是提交后交给受信解释器的工作描述。二者都不是已提交 DomainEvent、ExecutionReservation、DispatchGrant 或 provider call。writer commit 之后，同样的事件才以 `EffectEvent(A, ...)` 或相应 `Control<A.binding, ...>` 进入 authority。

guard 作为该决定内部的一个纯消费者，可以再写成：

- `Rule_A(I, F, L, t) -> NotApplicable | Pass<PassFacts> | Issue<A.TypedIssue>`；
- 只有 A 的 applicability 声明证明某叶子不消费该规则时才允许 `NotApplicable`。缺 canonical target、required valuation、FX/multiplier、有效 equity 或必要 native term 时不能借 `NotApplicable` 放行；应是 `InstrumentResolutionRequired`、`ValuationUnavailable`、`InvalidEquity` 或相应 typed failure。
- `PassFacts` 只是 `D_A` 生成 Prepared candidate、precondition 和 proposed event 的输入。它不是 reservation receipt。

这正面解释了“业务规则如何消费 I/facts/local state”：声明给出输入投影和失败槽位，事实边界给出 immutable evidence，pure evaluator 给出 finite decision，外层 `D_A` 在同一 A 上形成候选事件/work。任何独立维护的 CLI schema、自由 callback 或 provider-name switch 都不构成这项关联。

### 2.2 顺序组合怎样让后继看到推测状态

设初态为 `s0`。第一步由 A 消费 `I_A/F_A`，得到：

- `Rejected(f_A)`：组合在此停止；不产生后续候选、reservation 或 work；
- 或 `Accepted(E_A, W_A)`：用同一个 `evolve_A` 把候选事件折叠为推测 `ŝ1 = evolve_A(s0, E_A)`。

第二步的决定消费 `ŝ1`，而不是旧 `s0`：`D_B(ŝ1, I_B, F_B, t)`。如果第二步也通过，则继续形成 `ŝ2`；最终 `ŝn` 只表示这次候选写集的内部一致性。writer 以当前持久 state 重放同一顺序并进行 CAS/失效检查，才能将它转成一笔提交。

这一关系有三个限制：

1. 后继看到的是**前一步候选状态**，不是前一步 remote effect 的结果。A 的接纳 receipt、Prepared 或 `DispatchPlanned` 不等于 A 已成交；B 只有在声明明确需要 A 的已提交 criterion/observation 时才能以它为门槛。
2. 如果 B 的 facts 需要一次新的网络/账户读取，读取必须成为显式 WorkDescription/prepare 阶段；不能藏在纯 `D_B` 里。读取结果回到 writer 后还要带版本和来源证据。
3. 一个后继失败不会倒写或“撤回”一个已经发生的外部效果。若 A 已经 `DispatchStarted`，B 的失败只由 batch policy 解释；是否补偿取决于实际 exposure 和 compensation declaration。

所以，顺序 `evolve` 是本地控制状态的组合律，不是跨 Provider 的远程事务原子性，也不是 Promise 顺序本身的安全证明。

### 2.3 规则顺序和副作用泄漏

EF06:776 已经要求声明的 guard 顺序保持确定性，并要求前 guard 的 cooldown、risk occupation 或 evaluator state 不因后 guard reject 而泄漏。纯化后的解释是：

- 每个规则只返回 `PassFacts`、`Issue` 或候选 local-state event，不修改共享状态；
- 后一个规则可消费前一个规则的 speculative event/evolved state；
- 任一规则拒绝时，全部 candidate events 被丢弃，且 writer 没有 reservation write；
- 只有通过后的审批/queue barrier 才将需要消费的状态作为 durable event 写入。

这保留了“首个确定性拒绝”和顺序短路，同时修正了旧 API 将“检查通过”误当成“已消费”。cooldown 的消费时点由规则声明明确选择（例如 approval/queue 或 `DispatchStarted`）；函数式组合本身不替业务选择。

---

## 3. EF06 guard 外置评估与 writer 原子风控是否冲突

### 3.1 当前文字能够相容的解释

EF06:691–692、740–748 的 PrepareWorker 在 writer 外运行 Read Interpreter、pure compiler 和 declaration-bound guards，之后以 `RecordPrepared` 回 writer。若把该结果理解为 **prepared candidate + evidence**，它与主书 §9.1、§10.5 相容：

- 网络 IO、provider codec 和事实读取在 writer 外，避免把不确定网络调用放入 SQLite/控制事务；
- 纯 guard 不修改 Map，不消费 execution reservation；
- writer 只把 candidate 与其 fact/version/precondition 关联到当前 intent revision；
- 真正的共享额度/cooldown consumption 仍由交易 writer 在当前状态上原子完成。

主书 §10.5（`:831–837`）和旧承接 LTX-WRITER（`legacy-accommodation.md:7813–7836`）已经给出这条方向：guard facts 可以在 writer 外收集，但 writer 要重验失效条件；多个订单不能各自从相同额度读取后都通过；共享 scope/key 要有一致锁顺序。

### 3.2 必须补强的文字连接

当前 EF06 的显式序列在 `RecordPrepared` 处写的是 binding/slot/digest/CAS，在 Approve 处写的是 plan/approval/reservation；它没有把“writer 重新运行/验证 risk decision”作为独立动作写出来。若实现只照这两行做版本 CAS，就会出现以下错误解释：

- P1 和 P2 都从相同 `used=40, limit=100` 读到 60 可用，均形成 60 的 Prepared；
- P1 先取得 approval，P2 只要自己的 intent revision 没变也取得 approval；
- 两笔 reservation 共计 120，超过共享额度。

因此必要修订不是把所有 guard 网络读取搬进 writer，而是明确一个 **writer risk barrier**：

1. writer 读取当前 aggregate/control revision、当前 policy fingerprint、candidate plan digest、approved scope、fact sequence/as-of/precondition 和所有影响该规则的 durable pending intents/reservations；
2. 对需要当前 local state 的规则，在该 writer transaction 的当前读取上重新调用同一声明绑定的纯 evaluator，或验证一个等价且版本化的 candidate precondition；
3. 对远端 facts，Read Interpreter 可以在事务外取得最新 typed observation，但 writer 必须 CAS/核对其 source sequence、generation、freshness 或 projection revision；变化或过期就返回 `PreconditionFailed`/`StalePrepared` 并要求重新 prepare，不能继续使用旧 plan；
4. 对所有共享 conflict keys 以声明的确定顺序取得 writer 侧锁/行版本，并把 approval binding、cooldown/exposure reservation、queued intent/job、decision projection、outbox 和 receipt 一起提交；
5. 任一校验失败都不能产生 reservation/job/grant 或成功的 approval/admission receipt；失败可按 command contract 返回 typed rejection/failure、记录可查询的未完成状态，或在存储失败时仅报告未提交错误。事务冲突只能触发重新读取和重新决定，不能在旧 candidate 上盲重试。

这应在 EF06:691–692、740–748 或其紧邻的 6.4/EF09 说明中落地为明确语义：`RecordPrepared` 是候选保存；规则声明的 approval/queue 或 `DispatchStarted` barrier 才是风险准入 authority。当前 `GuardSummary` 仍可保存为 prepared evidence，但不能被查询/投影解释为已占额度。

### 3.3 cooldown 与 shared exposure 的具体消费

**Cooldown。** 纯 assessor 读取 `AccountScope + canonical InstrumentId`、已接纳 activity/active reservation 和显式 `t`，返回 remaining/retry evidence 或 candidate。writer 在其选择的消费点以当前 `lastAcceptedAt`/reservation row 和当前时间复核。两个同 key prepare 即使都通过，也只能由一个 writer transaction 插入/更新消费事实；另一个得到 `CooldownActive` 或 `VersionConflict`，并重新 prepare。不同 scope 或 canonical identity 不得由同 display symbol 互相阻塞。

**Gross exposure。** 纯 assessor 消费带单位、currency、multiplier、FX、equity、existing exposure 和 durable unsettled-intent projection 的 facts；缺必要证据 fail closed。writer 重新计算或校验 projected gross exposure，且将当前待执行效果纳入 reservation。`PreparedConflictLocks` 如果存在，只能被理解为 revision-scoped candidate/冲突事实；它不能替代 execution reservation，除非声明明确把它在同一 barrier 原子提升为该 reservation。

**消费时点是声明级契约，不是业务定理。** 主书 §9.1:635 明确允许 approval 与 `DispatchStarted` 两种 cooldown 消费触点。统一要求是规则声明标出消费触点；相应 writer 在该 barrier 以当前 local state 重算/核验完整 read-set，并原子写入 consumption/reservation。EF06:761–764 的 `ApprovalBound + ReservationHeld + DispatchPlanned + outbox/job` 是一个 approval-bound 例子，不应被历史事件流提升为所有声明的默认；若声明选择 `DispatchStarted`，则在该事件提交处应用同一 barrier。两者都必须声明 release/expiry/retry 规则，不能让 guard 顺序替业务选择。

### 3.4 writer 能保证什么，不能保证什么

在以下前提下可以作局部推导：

- 所有影响某个共享额度或 cooldown 的受控意图都使用同一个 writer authority；
- conflict key 覆盖整个共享范围，而不是只覆盖各自的 intent revision；
- writer transaction 是可串行化/CAS 且在提交前读取最新 durable state；
- candidate 的 policy/fact/precondition version 与当前状态不匹配时必拒；
- 每次冲突后都重新决定，而不是重放旧 candidate。

则两个从相同旧 prepare 产生的同 key reservation 不可能都成功：先线性化者更新占用/版本，后线性化者必看到容量不足或版本冲突。这个结论只覆盖 UTA 自己的 durable reservation。

它**不**推出远端 venue 的余额、position 或其他 agent 不会同时变化。主书 §13.4:1011 已明确，发送前 re-read 只能证明读取时所见关系；没有原生条件写、可验证栅栏或等价证据，不能把它提升为“绝不反向开仓”的保证。需要更强承诺时，必须由该 provider leaf 声明 native conditional/conformance；否则保留 check-before-submit 的竞态风险和恢复责任。

---

## 4. 异构成员的正面组合

### 4.1 coordinator 应消费的成员产品

设 batch 有成员 `A_i`。每个成员保留自己的 `I_i/F_i/P_i/O_i/R_i/Comp_i`、binding、scope、plan digest 和 attempt。coordinator 不把这些 payload 变成一个 `JoinedOrder` 或 provider-name switch，而是对每个已经认证/提交的成员消费一个带引用的进度产品：

- **criterion 结果**：`decideCriterion_i(P_i, ObservationHistory_i)` 对该成员业务目标的判断；例如是否达到数量、是否完成 amendment、是否停止继续工作。它不回答 attempt 是否已解析。
- **resolution 结果**：`decideResolution_i(P_i, AttemptEvidence_i, ObservationHistory_i)` 对发送尝试的可解析程度和责任结案条件的判断。Ack 可能只支持“已接收”，不能自动给出 filled/cancelled/final。
- **exposure 结果**：由成员 observation/accounting reducer 产生的 `ExposureEvidence_i`，包括已知 partial fill、剩余敞口、单位、scope、source identity、coverage 和 uncertainty。它是 `planCompensation_i` 或组补偿 planner 的输入，不由 ack 或 order status 字符串猜出来。
- **reservation/责任结果**：当前 reservation 是否仍持有、是否可释放、是否已原子转给 observation/recovery owner；attempt、lease、recovery case 和未决 work 的引用必须保留。

因此 `ChildProgress_i` 应是上述各项的**带 binding/证据引用的 product**，而不是 `success: boolean`。现 EF09:1007 的 `ChildProgress` 已列 status、ack/observation/criterion、attempt resolution 和 recovery responsibility lineage；为使补偿和释放推导闭合，必要修订是把成员的 exposure evidence/coverage/uncertainty 明确列入同一 progress 消费关系，而不是只在 `BatchCompensationRequired` 时临时读取一个 group snapshot。

coordinator 的纯消费者可理解为 `advanceGroup(GState, Policy, {ChildProgress_i})`：它只根据组 policy、成员 typed results、当前 group state 和 declaration-bound constraints 生成 `GroupReady`、`ChildProgress`、`BatchCompensationRequired`、`GroupSatisfied` 或 `RecoveryRequired` 等候选控制事件。writer 再验证 revisions/ownership 并提交；`ChildProgress` 是 UTA control projection，不是 provider native fact。

### 4.2 三个 policy 的不同承诺

| policy | coordinator 消费和提交 | 失败/Unknown/补偿语义 | 不能宣称 |
|---|---|---|---|
| `IndependentBatch` | 先登记组关系；每个 child 独立 `SubmitIntent → Prepare → Approve/Awaiting → Start → Observe`。coordinator 汇总各 child 的精确 progress，但不把它们绑成一笔接纳。 | 一个 child 的成功、known rejection 或 failure 不回滚其他 child；未开始 child 可按自身 policy retire/release；started/Unknown child 由自己的 recovery owner 继续。若公开 group summary，必须保留 mixed member outcomes。 | 全部 child 原子成功、失败后全组 undo、A receipt 意味着 B 等待 A 成交。 |
| `AllOrCompensate` | `GroupPolicyBound` 先冻结 required members、失败条件、释放责任和可接受 compensation grade。各 child 仍独立 prepare/approve/reserve；只有所有当前 gate 成员满足约束，才提交 `GroupReady` 并允许 dispatch。 | 成员开始后不能用本地事务倒流远端效果。known failure 或实际 exposure 违反组 criterion 时，以各成员 exposure/criterion/resolution 产生新的 compensation intent。Unknown 不是 known failure；保守 policy 先进入 `RecoveryRequired`，保持 reservation/owner。 | 时间倒流、费用归零、原 native identity/queue priority 恢复，或未确认 compensation 已安全。 |
| `VenueNativeAtomic`（当前 EF09 名为 `VenueNativeAtomic`；主书同语义） | 只有精确 provider、AccountScope、操作组合存在 `NativeConformanceRecord`，才可使用 native group leaf；group ack/observation 按该 leaf 的 exact slots 解码。 | conformance 不可用时在 dispatch 前返回 `ConformanceRequired/PolicyUnavailable`，不默默拆为 native atomic。group 的 criterion/resolution/exposure 仍由 native group declaration 解释。 | 同一 venue、同一批 request、同一字段形状或 Promise.all 自动有原子性。 |

若 AllOrCompensate policy 要求自动补偿而任何成员只能提供 `None`，EF09:996/1072–1074 的接纳应直接拒绝该组 policy；不能失败之后才临时把 `None` 当作 Economic 或 Exact。若调用者愿意改选 Independent，则这是明确的 policy change，不是 coordinator 自动 fallback。

### 4.3 组内顺序和推测状态

在同一 writer 决定中，`BatchRegistered`/`GroupPolicyBound` 先经 `evolve` 进入推测 `GroupState`，后续 child admission 或 group gate 消费该新状态。因此一个 child 的**本地已接纳成员关系、candidate reservation request 或 group constraint**可以被后续步骤看到；它不等于该 child 已经 remote accepted/filled。

如果业务确实要求 B 只有在 A 的业务目标成立后才可 dispatch，协调器必须把 A 的已提交 `CriterionSatisfied`（以及 policy 要求的 `Resolution`/exposure 条件）作为 B 的显式 gate。仅在调用进程内先 await A receipt 再调用 B 只建立调用因果，不保证重启后 B 仍会被接纳，也不证明 A 已成交。相反，IndependentBatch 默认不建立这种 gate；它只保留 child-level 独立进度。

---

## 5. 两成员 partial/Unknown 推演

### 5.1 前提

取异构的 A、B 两个 recipe：A 的 Prepared/ack/observation 是数量型订单叶子，B 使用另一种 provider/native 条款和自己的观察器；两者不共享 payload schema。两者都已经通过 prepare，且在 AllOrCompensate 的 group gate 下各取得自己的 approval/reservation。设：

- A 请求数量 6；A 已收到可信的 partial fill 4，成员 exposure reducer 能证明 4 的实际敞口，但 A 的业务 criterion 仍是“达到目标数量”或其叶子声明的对应条件；
- B 已成功 `DispatchStarted`，随后 response channel/进程丢失，现有 provider evidence 不足以判断 B 是否已发送、working、filled 或 rejected；B 的 resolution 是 Unknown，exposure 也是 Unknown，而不是零；
- 没有额外假定 venue 的 idempotency、完整 listing、cancel atomicity 或 compensation safety。

### 5.2 IndependentBatch

coordinator 从成员消费者得到：

- `A.criterion = 尚未满足/partial`（精确 variant 由 A 声明），`A.resolution = 已知 partial/仍需观察`，`A.exposure = 4 的有证据敞口`，A 的 reservation 继续由 A 的 effect/recovery owner 持有；
- `B.criterion = 未知或未决定`，`B.resolution = Unknown`，`B.exposure = Unknown`，B 的 recovery owner 持有 B 的 reservation/conflict responsibility。

组级 `ChildProgress` 只能报告这两个成员的混合结果。它不触发全组 compensation，也不把 B 的 Unknown 改成 rejected；A 可以继续独立观察/完成，B 进入 history/position reconciliation。若 A 后来达到 criterion，A 可以进入自己的 resolved terminal，但 group summary 仍必须显示 B 的 Unknown/recovery。只有 B 获得 conclusive no-effect evidence 后，B 的 reservation 才能按其自身规则释放；空 listing、timeout 或失去 worker 不能证明 no-effect。

若 B 最终是“未开始且有完整 no-effect 证据”的 known rejection，IndependentBatch 仍只记录 B rejected，A 的已知 partial/成功不被回滚。这样保留了旧顺序 `ContinueOnKnownRejection` 的可选语义，同时不把 Unknown 混入 known rejection continuation。

### 5.3 AllOrCompensate

B Unknown 时，组不能直接走 `GroupSatisfied`：

1. 如果组 criterion 要求所有成员目标满足且所有 attempt/responsibility 解析，B 的 Unknown 直接阻断结案；A 的 criterion 即使后来满足，也不能清掉 B 的恢复责任。
2. 在没有一条显式“允许基于不确定成员进行风险化补偿”的 policy 时，保守且可推导的结果是 `RecoveryRequired`，保存 A 的 4 exposure、B 的 Unknown、两者的原 attempt identity、reservation 和 recovery owners，先做 scoped lookup/position observation。
3. 如果 B 后来有完整证据证明 no-effect，而 A 仍仅 partial，coordinator 可以产生 `BatchCompensationRequired`，让 compensation planner 消费 A 的已知 exposure 和 AllOrCompensate 的允许等级。planner 产生的是新的 C recipe（例如只针对已知 A exposure 的受控 close/restore），C 自己重新 prepare/approve/DispatchStarted/observe；不能调用 A 的旧函数 inverse，也不能把 C 的计划当作已执行。
4. 如果 B 后来证明也有 exposure，planner 必须消费 A/B 各自的带单位、scope、identity、coverage 的证据；不能把异构数量、币种或 provider status 直接相加。若某一项证据不足，仍是 RecoveryRequired 或显式 policy failure。
5. 如果 A 的 partial fill 后 attempt 仍可能晚到更多 fill，单独看到 4 不足以证明可安全补偿；必须由 A 的 resolution/observation 规则先给出允许补偿的责任条件，或者把未决责任移交给明确 recovery owner。`CriterionSatisfied` 本身不能释放 A 的 exposure lock。

若已知的是“B 在 start 前有完整 known rejection”，则 AllOrCompensate 可以按组 failure policy 为 A 的实际 exposure 规划 compensation；但这仍只在允许 grade 和新 C 的独立批准/观察成功后达到对应的 `StateRestoring` 或 `Economic` 结果。它不把 B known rejection 误写成 B Unknown，也不证明 A 的原成交被撤销。

### 5.4 VenueNativeAtomic

如果 A、B 真的是两个异构 provider members，通常没有一个 provider-level native group leaf 能同时声明它们的 atomic operation；在没有 `NativeConformanceRecord` 时，`VenueNativeAtomic` 应在 dispatch 前返回明确的 unavailable/conformance failure，而不是分别发送 A/B 后把它们包装为 atomic。

只有 provider 自己提供精确 group capability、并有 scope/operation-specific conformance 时，才可把 native group request 交给一个 group interpreter。即使如此：

- group Ack 只代表该 native group 的 ack slot 语义；不能自动映射为每一 leg Filled；
- group observation 必须由 native group declaration 的 criterion/resolution/exposure consumers 解码；
- response loss 仍是该 group attempt 的 Unknown，不能因为“一个请求”就判全组 no-effect 或安全重发。

---

## 6. 状态与责任不变量及有前提推导

### 6.1 纯度和同声明消费

对固定的 `A、L、I、F、t`，`D_A` 必须确定地产生同一 typed candidate 或同一 typed failure；不得读取 hidden clock、broker/DB、Promise 结果或可变 registry。`A` 同时产生输入 projection、Prepared/criterion/resolution/failure slot 和解释身份，防止“同一个描述配另一个业务 callback”。这只能推出结构/绑定一致，不能自动证明 callback 的业务正确性或事实充分性。

### 6.2 candidate 与 authority 分离

Prepare 的 candidate、PassFacts、GuardSummary、plan evidence 和 WorkDescription 不消费 execution reservation，也不发 provider call。只要审批/queue 或声明的 start barrier 因 guard issue、stale fact、policy/permission conflict 或 storage failure 未成功，便不产生 reservation/job/grant 或成功的 approval/admission receipt；command contract 仍可返回 typed rejection/failure、记录可查询的失败/等待状态，或报告未提交错误。IntentAccepted 仍可作为已接纳意图保留；`PrepareFailure` 不应被压成 `ApprovalRejected`。

### 6.3 progressive state 的线性化

若同一 writer transaction 逐步按 `evolve` 应用前序候选，并且后一步的 `decide` 从事务的最新 state 读取，则后一步不会依据旧 state 重复占用前一步刚提出的 local capacity。若把多个 step 都从 `s0` 预计算后批量落盘，这个性质不成立；这正是 §9.1 和 C04 所禁止的行为。

### 6.4 shared quota/cooldown 的并发安全（条件结论）

在“一个 writer authority、覆盖完整共享范围的 conflict key、可串行化/CAS、提交前重验 candidate preconditions、冲突后重新决定”五项前提下，先提交的同 key reservation 会改变 durable state；后提交者不可能继续以旧 prepare 获得同一额度。该结论是 UTA 本地 reservation 的 safety property，不是 remote provider 的余额/position atomicity。

如果 writer 只校验每个 child 自己的 intent revision、没有共享 key，或把 prepare 中计算的 gross exposure 当成永远有效，则无法推出该结论。若 policy/fact/FX/equity 或 external exposure 的 revision 已变化，正确分支是 typed stale/precondition failure 和新 prepare，不是重用旧 approval。

### 6.5 终态必须同时消费 criterion、resolution、exposure 和 responsibility

可以推出以下不可互换关系：

- `CriterionSatisfied + ResolutionUnknown`：目标值满足，但 attempt 仍可能产生后续外部效果；保留 Unknown/recovery，不结案、不释放未决 exposure。
- `CriterionUnsatisfied + ResolutionResolvedNoEffect`：本次尝试已确定无效果；按 policy 可结为 rejected/no-effect，并释放对应未执行 responsibility。
- `CriterionSatisfied + ResolutionResolved + Exposure unresolved`：业务目标可能已满足，但残余敞口/补偿责任仍未结清；进入 recovery/compensation，而非 Satisfied。
- `AckRecorded`：只记录该叶子 ack slot；除非 A 的声明明确把它作为 criterion/resolution 的充分证据，否则不能变成 Filled/Cancelled/GroupSatisfied。

这解释了为什么 `ChildProgress` 必须保留多个轴，且 `GroupSatisfied` 只能在组目标满足并且每个成员的 attempt/reservation/recovery responsibility 已结清或原子移交时产生。

### 6.6 三种组合 policy 的责任不变量

- Independent：成员责任隔离；组 summary 不取得 rollback 权，也不产生跨 child compensation。
- AllOrCompensate：组 gate 只保证“本地所有 required child 在 dispatch 前同时满足当前约束”；一旦任何 child 已 start，外部效果不可由本地事务撤销。补偿责任由新 recipe/C 的 attempt 和 observation 继续承担；补偿未确认前原 exposure reservation 不释放。
- VenueNativeAtomic：原子性属于 `NativeConformanceRecord` 的精确证据，不属于 coordinator 事件相邻、同一 provider 名或同一 HTTP request 的推断。没有 conformance 时 policy unavailable，不是 core 缺一个通用 switch。

### 6.7 责任转移和释放

`DispatchStarted`/Unknown/partial exposure/不完整 listing/position unavailable 都保留 recovery owner。只有 conclusive no-effect、声明的 terminal evidence，或明确记录原 attempt、风险和约束的 recovery-owner handoff 才能释放对应 reservation。Keep、CLI 退出、approval expiry、lease expiry、transport timeout 和 projection/Git 写入成功都不是单独的释放证明。

### 6.8 补偿等级的条件推导

- `Exact`：只有 provider/recipe 能证明精确逆操作和所需 identity/terms，才可宣称 Exact；同一 schema 或反向数量不足以证明。
- `StateRestoring`：可以恢复目标 observable state，但保留历史事件、费用、滑点和 identity 变化。
- `Economic`：只恢复声明的经济敞口，仍保留滑点/手续费/残余风险。
- `None`：不包装成可回滚；要求自动补偿的 AllOrCompensate 在组接纳时拒绝。

在有完整 exposure evidence、允许的 grade、独立批准和 compensation attempt 已解析的前提下，可以推出达到该 grade 的补偿终态；不能推出时间倒流、原成交消失或 Unknown 成员被安全覆盖。

---

## 7. 必要修订清单（只修连接，不扩大抽象）

1. **EF06 Prepare/RecordPrepared 标出 tentative 语义。** 明确 writer 外的 guard/compiler 输出是 candidate/evidence；`RecordPrepared` 不绑定 execution reservation，不等于 approval。
2. **在 EF06 Approve/queue 旁明确 writer risk barrier。** 写出最新 local state、共享 conflict keys、policy/fact revision、纯 guard re-evaluation 或等价 precondition validation，以及失败时 typed stale/reprepare 分支。不要把网络 IO 搬进 writer；远端 facts 通过版本化 observation/CAS 连接。
3. **让规则声明明确 cooldown consumption policy。** 每个声明必须命名 approval/queue、`DispatchStarted` 或另一个明确的受控触点，并规定相应 writer barrier 的完整 read-set、release/expiry/retry 规则。EF06 的 approval-bound 事件流只是一个具体例子；主书 §9.1 的两种触点都保留，不能把历史流提升为通用默认。
4. **EF09 的 `ChildProgress` 明确是多轴 product。** 至少引用每个 child 的 criterion result、resolution result、ExposureEvidence（含 coverage/unknown）、reservation disposition、attempt/recovery owner；group summary 不得只存 bool/status。
5. **EF09 补一条 Unknown→compensation 的门槛。** Unknown 默认进入 recovery；只有组 policy 显式允许、且 compensation planner 能消费足够的 actual exposure/uncertainty evidence 时，才允许产生新的 compensation work；不能把 unknown catch continuation 当 known rejection 或安全 undo。
6. **保留 NativeAtomic 的 policy availability 语义。** exact conformance 不可用时返回 `ConformanceRequired/PolicyUnavailable`，不要按 provider 名称或“同一批 request”分支；若要改走 Independent/AllOrCompensate，由调用者提交明确 policy change。

这些都是对已有关系的精确化，不需要新增公共 `sequenceAdmission`、通用 workflow language、`JoinedOrder`、全局 `EventUnion` 或 provider-name switch。

---

## 8. 源码事实定位与证据边界

| 当前源码事实 | 定位 | 对目标推导的用途/限制 |
|---|---|---|
| 旧 pipeline 先并发读 positions/account，随后按数组顺序执行 guard，全部通过才调用 dispatcher | `services/uta/src/domain/trading/guards/guard-pipeline.ts:13–36`，尤其 `20–35` | 证明当前是 shared context + nullable-string short-circuit；不证明纯度、durable reservation 或 writer CAS。 |
| guard 接口返回 `Promise<string \| null> \| string \| null` | `services/uta/src/domain/trading/guards/types.ts:4–15` | 证明当前 API 没有 typed Pass/Issue、事实版本或 candidate event；readonly context 也不等于 immutable runtime state。 |
| Cooldown 在 `check` 内读 `Date.now()`、使用进程内 symbol Map，并在允许返回前写入 Map | `services/uta/src/domain/trading/guards/cooldown.ts:6–31`，尤其 `15–31` | 证明后置 guard/dispatcher 失败时旧 cooldown 可能已消费；支持将消费移到纯 candidate + writer barrier 的必要性。 |
| MaxPositionSize 只找第一笔同 symbol position，无法估值的新 symbol 使 `addedValue=0`，非正 net liquidation 令 percent=0 | `services/uta/src/domain/trading/guards/max-position-size.ts:15–47` | 证明旧实现没有 canonical identity、pending reservations、multiplier/FX/fail-closed evidence；不证明目标 GrossExposure evaluator 已实现。 |
| SymbolWhitelist 把 raw options cast 成 string[]，literal `unknown` 通过 | `services/uta/src/domain/trading/guards/symbol-whitelist.ts:4–24` | 证明目标必须由 declaration/identity applicability 决定 NotApplicable；target-bearing unknown 不能继续 fail open。 |
| registry 是 process-global Map，unknown type warning-and-skip | `services/uta/src/domain/trading/guards/registry.ts:6–34` | 证明当前不是 versioned immutable RuleSet；不影响本报告对目标组合根的设计推导。 |
| dispatcher 在 `place/modify/close/cancel` 上直接调用 broker；Close 显式数量在调用前重新读取 position | `services/uta/src/domain/trading/UnifiedTradingAccount.ts:180–205`、`:565–595` | 证明旧 check-before-dispatch 与目标 close 行为锚点；重新读取不是跨 actor 的原子条件写。 |
| stage close 只解析 contract/subaccount/qty 并加入 Git operation | `services/uta/src/domain/trading/UnifiedTradingAccount.ts:742–766` | 支持 §13.4 将 staging 与 dispatch-time exposure preflight 分离；不证明新 controlled plan 已实现。 |
| TradingGit 按 operation 顺序直接执行 callback，之后才 snapshot/append commit/onCommit | `services/uta/src/domain/trading/git/TradingGit.ts:119–185`，尤其 `141–184` | 证明旧 Git push 没有 durable intent/attempt/unknown barrier，也没有 batch-level atomicity；不能把旧 callback 顺序当目标 writer 证据。 |

旧源码和历史测试只回答“当前实现做了什么”。它们不证明 SQLite transaction、cross-process recovery、native idempotency、provider atomicity、complete absence、finality 或 compensation safety。目标文档中的 EF06–EF09 仍是设计关系，直到各自实现 gate/运行验证完成都不能包装成已运行事实。

---

## 9. 仍未证明事项

1. **writer 运行时实现**：当前仓库没有新 UTA SQLite JournalWriter、approval-bound reservation、group gate、lease fencing 或 crash-recovery 运行证据；本报告只给出其必须满足的消费/线性化关系。
2. **外部 facts 的原子性**：Provider account/position/valuation observation 与本地 writer transaction 之间仍不是同一事务。若没有 native conditional write、sequence fence 或等价 conformance，只有本地 stale detection/check-before-submit 承诺。
3. **每个 leaf 的 criterion/resolution/exposure 完备性**：主书给出这些 slots 和消费者关系，但每个真实 Provider 如何定义 partial fill、late ack、position attribution、native rejection、lookup absence、finality 和 exposure unit 仍需 leaf-specific evidence。
4. **补偿安全**：没有证据时不能把逆向下单、cancel+replace、相同数量或同一 Provider 名称当 Exact/StateRestoring。尤其 B Unknown 时，是否允许基于不确定性规划有限风险 compensation 是 AllOrCompensate 的显式 policy 问题，不是 coordinator 可以自行决定的默认。
5. **NativeAtomic conformance**：没有 provider/作用域/操作组合的 `NativeConformanceRecord`，不能宣称 VenueNativeAtomic；异构成员通常必须选 Independent 或 AllOrCompensate，除非存在一项真正的 native group leaf。
6. **事实充分性与业务正确性**：schema、digest、Typed Issue、通过 compiler 或完整 `ChildProgress` 都不能自动证明业务函数没有漏掉隐含依赖，也不能证明 exposure reducer 正确归因于本次 attempt。需要各声明提供自己的 criterion/resolution/exposure 证据和可重放规则。
7. **跨文档命名**：EF09 使用 `VenueNativeAtomic`，旧 LTX-WRITER/部分历史材料出现 `ProviderDeclaredAtomic` 等同义词；整合时应统一一个当前 tag 或明确它们只是历史措辞，避免把命名差异误当 policy fallback。

在上述未证明事项之外，当前文档已经足以正面表达：纯规则如何从同一 A 消费 I/facts/local state 形成 typed candidate/failure；顺序 `evolve` 如何让后继看到推测控制状态；writer 如何在共享 reservation barrier 上拒绝 stale prepare；以及异构 batch 如何按各成员的 criterion、resolution、exposure 和责任 owner 产生控制级进度。