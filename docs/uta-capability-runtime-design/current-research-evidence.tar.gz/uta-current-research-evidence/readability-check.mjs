import { createRequire } from 'node:module';
import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, extname, join, relative, resolve } from 'node:path';

const args = process.argv.slice(2);
const toolingRootFlag = args.indexOf('--tooling-root');
if (toolingRootFlag < 0 || !args[toolingRootFlag + 1]) throw new Error('Pass --tooling-root <directory>');
const toolingRoot = resolve(args[toolingRootFlag + 1]);
const repository = resolve(args[toolingRootFlag + 2] ?? process.cwd());
const outputDirectory = resolve(args[toolingRootFlag + 3] ?? join(repository, '.readability-output'));
const inputs = args.slice(toolingRootFlag + 3).filter((arg) => arg !== repository && arg !== outputDirectory);
if (inputs.length === 0) throw new Error('Pass at least one Markdown input after tooling root/repository/output');
const requireTooling = createRequire(join(toolingRoot, 'package.json'));
const { marked } = requireTooling('marked');
const { JSDOM } = requireTooling('jsdom');
const dom = new JSDOM('<!doctype html><html><body></body></html>');
globalThis.window = dom.window;
globalThis.document = dom.window.document;
const mermaid = (await import(requireTooling.resolve('mermaid'))).default;
mermaid.initialize({ startOnLoad: false, securityLevel: 'strict' });

const readCache = new Map();
async function readText(path) {
  const absolute = resolve(path);
  if (!readCache.has(absolute)) readCache.set(absolute, await readFile(absolute, 'utf8'));
  return readCache.get(absolute);
}
function githubSlug(text, used) {
  const plain = text.replace(/<[^>]*>/g, '').replace(/[`*_~]/g, '').replace(/!?\[([^\]]+)\]\([^)]*\)/g, '$1').trim().toLowerCase();
  const base = plain.replace(/[^\p{L}\p{N}\s_-]/gu, '').replace(/\s+/g, '-');
  const count = used.get(base) ?? 0;
  used.set(base, count + 1);
  return count === 0 ? base : `${base}-${count}`;
}
function anchorSet(text) {
  const anchors = new Set([...text.matchAll(/\bid=["']([^"']+)["']/g)].map((match) => match[1]));
  const used = new Map();
  for (const match of text.matchAll(/^(#{1,6})\s+(.+?)\s*#*\s*$/gm)) anchors.add(githubSlug(match[2], used));
  return anchors;
}
function linksFromWikilinks(text) {
  return [...text.matchAll(/\[\[([^\]|#]+)(?:#([^\]|]+))?(?:\|[^\]]*)?\]\]/g)].map((match) => ({ href: `${match[1]}${match[2] ? `#${match[2]}` : ''}`, kind: 'wikilink' }));
}
function splitHref(href) {
  const hash = href.indexOf('#');
  return hash < 0 ? { relative: href, fragment: undefined } : { relative: href.slice(0, hash), fragment: href.slice(hash + 1) };
}
function isExternal(href) {
  return /^[a-z][a-z\d+.-]*:/i.test(href) || href.startsWith('//');
}
function parseLineRange(fragment) {
  const match = /^L(\d+)(?:-L(\d+))?$/.exec(fragment);
  return match ? { first: Number(match[1]), last: Number(match[2] ?? match[1]) } : undefined;
}
const linkResults = [];
const linkFailures = [];
const tableResults = [];
const tableFailures = [];
const mermaidResults = [];
const renderResults = [];
await mkdir(outputDirectory, { recursive: true });
for (const input of inputs) {
  const sourcePath = resolve(repository, input);
  const text = await readText(sourcePath);
  const tokens = marked.lexer(text);
  const links = [];
  marked.walkTokens(tokens, (token) => { if (token.type === 'link') links.push({ href: token.href, kind: 'markdown' }); });
  if (sourcePath.endsWith('AGENTS.md') || sourcePath.endsWith('docs/README.md')) links.push(...linksFromWikilinks(text));
  for (const { href, kind } of links) {
    if (isExternal(href)) {
      linkResults.push({ input, href, kind, status: 'skipped-external' });
      continue;
    }
    const { relative: rel, fragment } = splitHref(href);
    const target = rel ? resolve(kind === 'wikilink' ? repository : dirname(sourcePath), decodeURIComponent(rel)) : sourcePath;
    const deferredArtifact = input === 'docs/uta-capability-runtime-design/current-research.md' && rel === 'current-research-evidence.tar.gz' && !fragment;
    if (deferredArtifact) {
      let present = true;
      try { await access(target); } catch { present = false; }
      linkResults.push({ input, href, kind, status: 'deferred-artifact', present, target: relative(repository, target) || '.' });
      continue;
    }
    try {
      await access(target);
      if (fragment) {
        const targetText = await readText(target);
        const range = parseLineRange(fragment);
        if (range && extname(target) !== '.md') {
          const lines = targetText.trimEnd().split('\n').length;
          if (range.first < 1 || range.last < range.first || range.last > lines) throw new Error(`line range outside target (${lines} lines)`);
        } else if (!anchorSet(targetText).has(decodeURIComponent(fragment))) {
          throw new Error('anchor not found as explicit id or heading slug');
        }
      }
      linkResults.push({ input, href, kind, status: 'passed', target: relative(repository, target) || '.' });
    } catch (error) {
      const result = { input, href, kind, status: 'failed', error: String(error) };
      linkResults.push(result);
      linkFailures.push(result);
    }
  }
  for (const token of tokens) {
    if (token.type !== 'table') continue;
    const line = text.slice(0, text.indexOf(token.raw)).split('\n').length;
    const headerColumns = token.header.length;
    const badRows = token.rows.map((row, index) => ({ row: index + 1, columns: row.length })).filter((row) => row.columns !== headerColumns);
    const result = { input, line, columns: headerColumns, rows: token.rows.length, status: badRows.length ? 'failed' : 'passed', badRows };
    tableResults.push(result);
    if (badRows.length) tableFailures.push(result);
  }
  const blocks = [...text.matchAll(/^```mermaid\s*\n([\s\S]*?)^```\s*$/gm)];
  for (const block of blocks) {
    const line = text.slice(0, block.index).split('\n').length;
    try {
      const parsed = await mermaid.parse(block[1]);
      const result = { input, line, status: parsed === false ? 'failed' : 'passed', diagramType: parsed === false ? undefined : parsed.diagramType };
      mermaidResults.push(result);
      if (result.status === 'failed') result.error = 'Parser returned false';
    } catch (error) {
      mermaidResults.push({ input, line, status: 'failed', error: String(error) });
    }
  }
  const html = await marked.parse(text);
  const outputPath = join(outputDirectory, input.replaceAll('/', '__') + '.html');
  await writeFile(outputPath, `<!doctype html><meta charset="utf-8"><article>${html}</article>\n`);
  renderResults.push({ input, output: outputPath, bytes: Buffer.byteLength(html) });
}
const result = {
  node: process.version,
  marked: requireTooling('marked/package.json').version,
  mermaid: requireTooling('mermaid/package.json').version,
  inputs,
  rendered: renderResults,
  links: { total: linkResults.length, checked: linkResults.filter((x) => x.status === 'passed').length, externalSkipped: linkResults.filter((x) => x.status === 'skipped-external').length, deferred: linkResults.filter((x) => x.status === 'deferred-artifact'), failures: linkFailures, results: linkResults },
  tables: { total: tableResults.length, failures: tableFailures, results: tableResults },
  mermaidResults,
  mermaidSummary: { total: mermaidResults.length, passed: mermaidResults.filter((x) => x.status === 'passed').length, failures: mermaidResults.filter((x) => x.status === 'failed') },
};
await writeFile(join(outputDirectory, 'readability-results.json'), `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ node: result.node, marked: result.marked, mermaid: result.mermaid, rendered: renderResults.length, links: result.links, tables: { total: result.tables.total, failures: result.tables.failures.length }, mermaid: result.mermaidSummary }));
if (linkFailures.length || tableFailures.length || result.mermaidSummary.failures.length) process.exitCode = 1;
