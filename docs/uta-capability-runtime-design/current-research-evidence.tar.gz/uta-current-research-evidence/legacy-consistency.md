# UTA 当前 legacy 一致性研究报告

**支线**：LegacyConsistency  
**状态**：已完成本轮限定范围调查；未编辑 repo 文档，未写代码/测试/脚本，未运行 build/lint/formatter/tests。  
**供 Main 使用**：本报告只给出当前结论冲突、精确替换建议、正面构造/事件消费的核实结果，以及 remaining 范围。`legacy-accommodation.md` 与 `.json` 中的原始调查材料、`currentBehavior`、source references、legacy-bindings 原文均不应被清理或改写。

## 1. 调查边界与证据分类

本轮对照了三类当前材料：

1. 候选主书 `docs/uta-capability-runtime-design.md`，以 §5 组合、§7 外层调用、§10 writer/guard、§11 deferred activation、§14 单一权威迁移为权威设计。
2. `docs/uta-capability-runtime-design/legacy-accommodation.md` 的各 section 中 `abstractExpression`、`preservedContract`、`具体替代与修正`、`单一权威切换` 等当前字段；同一本中的 `旧行为与来源约束`、原始 MAP/NOTE 文本仍是输入/历史记录。
3. `legacy-accommodation.json` 的 machine mirror；只应同步修改相应 section 的当前字段，不应改动 `currentBehavior`、`sourceReferences` 或嵌入的原始调查记录。`legacy-bindings.md` 保留原文与当前关系映射，不承担替换目标。

### 1.1 当前结论

以下属于当前设计承诺，必须与主书一致：

- 主书明确要求：先确认持久形状是否已发布；未发布形状直接替换，不建立永久 compatibility parser（`docs/uta-capability-runtime-design.md:1170-1172`）。
- 已发布协议的 compatibility 也不能凭名称或 Provider 类型推断；只有已确认的 published external protocol responsibility 才可保留 versioned、one-way、read-only projection。没有该证据时，内部 callers 应迁移到 typed relation，旧 export/bridge/parser 删除。
- `legacy-accommodation.md` 的“选定的抽象表达/具体替代与修正/单一权威切换”和 JSON 对应 current fields 是当前候选设计；其中出现的无条件 `compatibility`、`legacy export`、`outer edge` 不是自动获得的已发布责任。

### 1.2 历史引述（保持原样）

- 每个 section 的 `旧行为与来源约束`、MAP/NOTE 原文、`legacy-bindings.md` 中的引用块是调查材料，不应为了本轮一致性替换。
- JSON 的 `currentBehavior` 和 `sourceReferences` 同样是原始证据/历史记录；不要把它们误当成当前承诺，也不要静默改写以消除冲突。
- 旧 `EventLog`、TradingGit callback-before-persistence、raw DTO/nullable/zero 等事实需保留，因为它们正是 recovery 和 cutover 约束的来源。

### 1.3 未调查/不可从现有材料推出的事实

- 当前 repo 没有证明哪些 legacy parser/export/DTO 是已经发布并被外部消费者依赖的协议；也没有证明 pack API、HTTP shape、supervisor route/carrier、历史 export 的具体发布责任。
- 当前源码/fixtures 不证明 foreign wire protocol、native idempotency/atomicity/finality、credential isolation、真实 Provider conformance；主书和 accommodation 中已有的 evidence-boundary/future-falsifier 仍是未完成的未来义务。
- 因此这些未知不能作为保留无条件 compatibility promise 的理由。正确处理是把 future evidence boundary 写成条件，或在没有 published responsibility 时删除内部兼容层；不是扩展 generic shim。

## 2. 结论摘要

### P0：一个硬冲突，必须先修

`LCORE-SCOPE-ROUTING` 同时规定 `LegacyUtaIdAlias` 只用于离线 import/provider-local lookup、绝不成为 runtime live alias/dual-read/shim（`legacy-accommodation.md:63-69`），但在当前 `具体替代与修正` 又写：

> `MAP-7AF82C011B: Keep a compatibility parser only at protocol edge during cutover, with typed failures.`（`legacy-accommodation.md:99-100`；JSON `:80-81`）

主书 §14.2 要求先确认 published shape；没有确认时不建立永久 compatibility parser（`docs/uta-capability-runtime-design.md:1170-1172`），且 §14.3 要求 compatibility 仅在确认的 published external protocol responsibility 下成立（`docs/uta-capability-runtime-design.md:1176-1178` 附近的当前规则）。这不是可以用“protocol edge”泛化消解的例外，因为当前行没有声明已发布责任，且它直接与本 section 前面的“绝不成为 compatibility shim”冲突。

### P1：其余是当前字段里的无条件/证据不足承诺

下列不是要求删除所有历史能力，而是要求把“compatibility”收窄为已确认的外部协议/历史导入/非破坏性投影；如果没有对应证据，则内部 callers 迁移后删除。冲突主要是当前文字没有写证据门槛：

1. CCXT/provider 聚合类、global `IBroker`/barrel/re-export、pack API。
2. Runtime route、supervisor optional carrier、`Promise<void>` lifecycle shape。
3. Leverup protocol index 的“内部 compatibility projection”。
4. Observation export、HTTP mapping、TradingGit compatibility read path。
5. zero `AccountInfo`、listing empty/null/omission/`[]`、market-data static arrays/legacy DTO。
6. controlled-effect 的 `Cancelled`/nullable/legacy order shape。
7. migration 末尾的“保留 legacy exports 为只读”。
8. `Partial/Gap` 在失败列表中的术语混合；这会把局部 Gap 误读为全局 Coverage variant。

这些项目不要求重写 1.5MB 原始资料，也不要求修改 `event-flows.md`。按下面的最小替换，改当前 field 中相应句子，并对 JSON mirror 做同源同步即可。

## 3. 精确替换清单

下表的“当前证据”是当前字段位置；重复出现的 `当前章节切换`/`保留事实` 应保持同一语义，不要只改一个重复副本。每一组给出最小可复制的 replacement principle/句子。

### 3.1 P0：LCORE scope parser

**当前证据**

- `legacy-accommodation.md:63-69`：`LegacyUtaIdAlias` 仅 offline import/provider-local lookup，绝不 runtime live alias、dual-read 或 compatibility shim。
- `legacy-accommodation.md:99-100`：无条件 `Keep a compatibility parser only at protocol edge during cutover`。
- JSON：`legacy-accommodation.json:80-81` 的 `LCORE-SCOPE-ROUTING.selectedChanges`。

**精确 replacement**

将 `MAP-7AF82C011B` 的 parser 行替换为：

> `MAP-7AF82C011B：仅将 aliceId/native-key 旧值送入离线 import decoder 或 provider-local lookup；所有运行时 caller 迁移到 branded codec/InstrumentResolver。若未来确认存在已发布外部协议责任，另行在该 protocol boundary 定义 versioned decoder；这不构成当前 UTA 的 live alias、dual-read 或 compatibility shim。`

不要把“protocol edge”单独当作保留理由；必须同时有“已确认已发布外部协议责任”的条件。JSON 只改 `selectedChanges` 对应字符串，保留 `currentBehavior`/`sourceReferences`/原 MAP 资料。

### 3.2 Provider/CCXT 聚合类、IBroker、pack API、credential/config adapter

**当前证据**

- CCXT foundation：`legacy-accommodation.md:1295-1306`（尤其 `:1303-1305`），`preservedContract:1325-1332`，重复 current/cutover：`:1458-1473`。
- JSON mirror：`:1566-1568`、`:1587-1593`、`:1612-1616`、`:1725-1729`。
- product-independent pack API：`legacy-accommodation.md:2749-2751`；JSON `:3582-3584`。
- connection/config lifecycle：`legacy-accommodation.md:3762-3770`、`:3781-3800`；其中 `Promise<void> compatibility` 在 `:3765-3766`、`:3788-3791`。
- compiler cutover：`legacy-accommodation.md:7795-7799`，尤其 `:7798` 的 “global IBroker compatibility re-export ... adapter bridge”。

**当前问题**

这些行已经正确拒绝 universal broker authority、raw SDK authority 和未证明的 native guarantee；问题是仍把 legacy IBroker、provider methods、pack API、credential aliases、global re-export 或 lifecycle shape 当作当前 compatibility，而 repo 没有给出已发布外部责任证据。`legacy IBroker only as an edge projection` 只有在“已确认 published boundary”成立时才是合法 projection；否则它仍可被内部 caller 当成 de facto API。

**建议替换句**

- `MAP-8240582100` / `MAP-373EFE107B`：

> `仅在已确认的 published external pack/API protocol boundary 保留一向、versioned、read-only legacy IBroker/DTO projection；它不能作为 core 或内部 domain authority。若无该已发布责任，切换所有 internal callers 到 provider-declared leaves 后删除 legacy class、barrel export、raw SDK/DTO 与 bridge。`

- `MAP-AB521AFE64`（pack API）：

> `仅在发行记录证明 product-independent pack API 是已发布外部协议时保留其 versioned boundary projection；否则保留旧 release 作为 immutable repair evidence，拒绝 generic v1 module，并在内部 callers 切换后删除 compatibility API。`

- `MAP-434A149C16`（credential aliases/config）：

> `credential aliases 仅可由已确认的 persisted/shipped config migration decoder 在输入边界消费；runtime fromConfig 不保留双路径，不由 loose keyless/mode 字段推导 AccountId、environment 或 permission。`

- `MAP-022EF0154D`/`MAP-AF39887E35` 的 “loud compatibility CONFIG behavior at legacy edge”：

> `仅在已确认的 published config/error protocol boundary 保留 legacy CONFIG projection；core 返回精确 typed variant。未确认外部责任时，内部 callers 迁移后删除该 projection。`

- `MAP-D9AB7D19DE`/`MAP-C1097A9D6C` 的 `Promise<void> compatibility`：

> `仅在已确认的 published lifecycle wire/API 仍要求 Promise<void> 外层 projection 时保留；内部 lifecycle 必须消费 typed shutdown/finalizer outcome，Promise<void> 不表示 remote effect success、cancel、fill 或 recovery 已完成。无该外部责任时删除该 compatibility shape。`

- `legacy-accommodation.md:7798`：

> `将 UnifiedTradingAccount dispatcher switch 收窄为 provider-owned adapter leaves，并移除 global IBroker compatibility re-export；仅在已确认的 published external pack boundary 才允许独立 read-only projection。内部 callers 不得经 global re-export 或 runtime command adapter 绕过 declaration/writer。`

**JSON 同源位置**

同步修改 `legacy-accommodation.json:1566-1568,1587-1593,1612-1616,1725-1729,3582-3584` 中相应当前字段；不要改该文件中 `currentBehavior` 或 original `rationale/sourceReferences`。connection mirror 的当前字段在 `:4645-4651,4668-4679,4697-4707,4853-4864`，同样只改当前 compatibility clause。

### 3.3 Runtime route / supervisor carrier

**当前证据**

- `legacy-accommodation.md:3620-3648`，尤其 `:3626` 的“迁移期 route compatibility”。
- `legacy-accommodation.md:3661-3669`，尤其 `:3663` 的 optional carrier transport result 与 `:3668` 的“preserve optional-carrier compatibility”。
- JSON mirror：runtime `preservedContract:4451-4452`；supervisor `:4502-4503`。

`optional carrier is transport compatibility result, not Ready` 本身是正确的类型区分；问题在于“compatibility”没有说明是否为已发布 supervisor/health wire protocol。

**精确 replacement**

> `仅在已确认的 published versioned runtime transport/health protocol boundary 保留 route 或 optional-carrier compatibility；否则只做迁移期 parity，所有 internal consumers 切换到 UtaHealthResponse/ReadinessResult 后删除旧 route/carrier。optional carrier 永远只是 transport result，不是 Ready、PermissionWitness 或 trading admission。`

### 3.4 Leverup protocol index 的内部 compatibility projection

**当前证据**

- `legacy-accommodation.md:4474-4517`，尤其 `:4497` 已要求删除 legacy exports，` :4517` 却写“legacy exports 作为内部 compatibility projection”。
- JSON 对应 `:5595`。

这是本组除 P0 外最明确的当前文字冲突：`内部 compatibility projection` 没有 published boundary 条件，且会保留被同 section 宣布删除的内部 exports。

**精确 replacement**

> `切换完成后 index 只保留 v2 safe boundary；legacy exports 仅在已确认的 published external read/import protocol 下作为一向、versioned、read-only projection。没有该责任时，迁移 callers 后删除 legacy IBroker/raw private-key/NetworkConstants exports；任何 projection 都不是运行 authority。`

JSON `:5595` 只改这一条 current migrationCutover 字符串；保留 `currentBehavior` 和 evidence boundary。

### 3.5 Observation export、HTTP mapping、TradingGit read path

**当前证据**

- `legacy-accommodation.md:4791-4805`：`:4793` “Preserve export for current consumers as compatibility”，`:4805` “Keep a compatibility mapping at HTTP boundary only”。
- `legacy-accommodation.md:7211-7213`：projection-store query APIs and compatibility mapping、retire direct TradingGit。
- `legacy-accommodation.md:7337-7357`：`:7338` reader import/projection-only，`:7357` “keep export compatibility read path only”。
- JSON observation mirror `:5949-5960`；JSON 其余 LTX projection/current fields 对应同义句。

**精确 replacement**

将无条件 export/mapping 句统一收窄为：

> `仅在发行记录确认该 read/reporting/export shape 是 published external protocol，或该路径明确是 historical import boundary 时，保留一向、versioned、read-only projection。内部 callers 迁移到 typed ProjectionReader/Query 后删除 direct export/mapping；projection 不得成为 authorization、recovery、dispatch 或 accounting authority。`

针对 `MAP-229EF12AA4` 的 HTTP 行可用：

> `仅在已确认的 published HTTP read contract 下保留 compatibility mapping；route 内部和所有新 callers 使用 generated typed schema/ProjectionReader，transport failure 不映射为 absence。`

针对 `MAP-502614A0DB`/`MAP-6B72864B5E` 的 projection 行可用：

> `projection-store query API 是当前唯一内部读入口；legacy export/read path 只有在 confirmed published read/import responsibility 下保留，否则在 callers cutover 后删除。它永不写 Git、授权、恢复或交易状态。`

JSON `:5949-5960`、与 `:7211`/`:7357` 对应的 current mirror 仅同步当前字段；不要改 original investigation entries。

### 3.6 zero AccountInfo

**当前证据**

- `legacy-accommodation.md:5524-5535` 已正确规定 core `AccountScope`、三值 Coverage 和不伪造 unknown=0；但 `:5534`、`:5560` 仍写 `Keep zero AccountInfo only as a compatibility projection at the outer edge`。
- JSON：`:6869-6872` 的 selected/current paragraph，`:6894` 的 preservedContract。

**精确 replacement**

> `Core snapshot 与所有内部 UTA response 保留 NoAccount/Unavailable evidence；仅当已确认的 published external display/read protocol 明确要求 zero AccountInfo 时，才增加一向 outer projection，并携带其 legacy mapping/provenance；该 projection 不能反馈 accounting、authorization、reconciliation 或 dispatch。没有该外部责任时删除 zero projection。`

注意：有证据的真实 zero balance/zero exposure 仍保留；本替换只针对 keyless/no-account 被伪造成 funded zero 的 legacy shape。

### 3.7 Listings：nullable、empty、omission、`[]`

**当前证据**

- `legacy-accommodation.md:5782-5789`：typed scoped per-ID/listing 已正确；但 `:5785-5789`、`:5797-5804`、`:5811-5819` 仍将 nullable/empty/omission/`[]` 作为 legacy display/compatibility edge，没有 published responsibility 条件。
- JSON：对应 LCCXT listing current fields `:7133-7137`、preserved `:7144-7146`、current transition `:7159-7162` 等。

**精确 replacement**

> `内部 consumers 只消费 scoped Found|DefinitiveNotFound|Unknown|Malformed|NoAccount 与 Complete|Partial|Unavailable。nullable/empty/omission/[] 仅在已确认的 published external display/read protocol 中作为一向、非破坏性 projection；不能进入 reconciliation、clear、retry、authorization、compensation 或 dispatch。无 published responsibility 时，内部 callers 切换后删除该 legacy shape。`

`Keep symbol hint/fallback` 可以保留，但明确为 provider-local lookup evidence，不是 canonical identity、scope 或 compatibility API：

> `symbol hint/fallback 与 endpoint sequence 仅是 provider-local lookup evidence；cache 只作速度优化，不能成为 restart identity、scope、capability 或 authority。`

已有的 `empty input as no-op`、sequential lookup、strict/permissive provider read policy 不应删除；它们属于 query semantics，不能与 outer `[]` projection 混写。

### 3.8 Market data static arrays、legacy DTO、historicalBars shape

**当前证据**

- `legacy-accommodation.md:5921-5934`：finite Pull、source/observed/asOf、Coverage 三值和禁止 fake zero/now 是正确当前结论；但 `:5927-5934` 将 static arrays、historicalBars、compatibility DTO 写成 edge/outer compatibility，未写已发布责任。
- `legacy-accommodation.md:5946-5962` 重复这些保留承诺；` :5978-5980` 的 current transition 也重复。
- JSON：LCCXT data 对应 current fields `:7312-7319`、`:7330-7345`、`:7371`、`:7526` 附近。

**精确 replacement**

> `static CRYPTO/CRYPTO_PERP/MKT/LMT arrays、historicalBars shape 与 legacy DTO 仅在 provider evidence 或已确认的 published outer read/display protocol 下保留；core leaf 与内部 callers 使用 typed source/observed/asOf/Coverage。没有 external protocol 证据时，metadata 留在 provider adapter，不形成 compatibility promise；不得用它补造 scope、capability、finality、zero 或 local-now source time。`

保持以下已查实的正面结论不变：精确 Decimal/string 字段、unresolved identity refusal、interval/limit policy、source time 与 observedAt 区分、unsupported feature refusal；这些不是兼容层冲突。

### 3.9 Controlled effects：Cancelled/null/legacy order shape

**当前证据**

- `legacy-accommodation.md:8035-8059` 当前 clauses，尤其 `:8043`、`:8046-8047`、`:8051`、`:8058-8059`。
- `:8064`、`:8074`、`:8076`、`:8088`、`:8108` 的 preservedContract 重复。
- JSON：`:9919-9936` current transition，`:9939-9948` preservedContract，`:10023`/`:10257` current/cutover duplicate。

细分如下：

- `Keep Cancelled only after confirmed observation, not directly from Ack`（`:8043`, `:8064`）已经是正确的 semantic guard；不要删除，但应说明输出若面向 legacy consumer 必须经过已确认的 published display protocol。
- `nullable result only in a legacy display adapter`（`:8046`, `:8074`）和 `null only as an explicit legacy mapping of typed NotFound`（`:8047`, `:8076`）已是单向语义，但仍应补“confirmed published external display/read protocol”；内部 endpoint 不应返回 nullable authority。
- `legacy compatibility shape`（`:8059`, `:8108`）是无条件承诺，应明确只保留在已确认外部 display/read boundary；否则删掉该 shape。
- `symbol/secType only as compatibility resolution`（`:8051`, `:8088`）如果指 provider-local lookup 可以保留，但改成“provider-local lookup evidence”，不能被误读为 canonical identity 或公开兼容 API。

**精确 replacement**

> `legacy Cancelled/null/order-state view 只可在已确认的 published external display/read protocol 中作为一向 projection，并且只能建立在 typed observation/NotFound mapping 上；内部 callers 消费 typed outcome。Ack 不证明 Cancelled，transport failure 不得映射为 missing/NotFound，Unknown 保持 recovery。symbol/secType hint 仅为 provider-local lookup evidence，绝不是 canonical scope/identity。`

已确认观察、Ack≠fill、Unknown/recovery、精确 MKT/LMT/TP-SL/native extension/refusal 等正面 provider semantics 不受此替换影响。

### 3.10 Migration 末尾 legacy exports

**当前证据**

- `legacy-accommodation.md:10060-10064`，尤其 `:10062`：`删除 fallback/direct dispatch → 保留 legacy exports 为只读`。
- JSON `:12485` 同句。

**精确 replacement**

> `Authority cutover 顺序为：盘点 legacy files/config/external liabilities → 冻结受影响 admission → 携 provenance 迁移/replay → 分类 unknown/recovery，并在任何 no-start retirement 前要求 positive no-callback evidence → 启用新 writer/readers → 验证 projections → 删除 fallback/direct dispatch → 仅在已确认 published external read projection 或历史 import reader 下保留 legacy exports；无此责任则删除 legacy exports。`

保留同 section `:10064`/JSON `:12487` 的 marker-absence 规则：缺少新的 `DispatchStarted` 不是 no-start evidence；只有 positive no-callback evidence 才能 retirement；缺少 native/attempt identity 必须 `LegacyDispatchIdentityMissing/RecoveryRequired`，永不 native replay。

### 3.11 Coverage 与 Gap 术语

**当前证据**

- 主书已闭合 `Coverage = Complete | Partial | Unavailable`，并将 Gap 作为 stream continuity/recovery 语义（`docs/uta-capability-runtime-design.md:364-366,638-651,922-927`；`event-flows.md:62-78,331-335,535-539`）。
- `legacy-accommodation.md:4534`、`:5923`、`:9918` 已正确使用三值 Coverage。
- 但 `legacy-accommodation.md:4841` 写 `UnknownInstrument、UnsupportedLeaf、NoRefresh、Unavailable、Partial/Gap、OutputDecodeFailure...`，容易让 `Gap` 被解释为第四个全局 Coverage variant。

**精确 replacement**

> `UnknownInstrument、UnsupportedLeaf、NoRefresh、Unavailable、OutputDecodeFailure、ProviderError 与 authorization filter 分离；Kernel Coverage 仍只有 Complete|Partial|Unavailable。Gap 仅是带 partition/range/recovery policy 的 continuity evidence；它可使该 partition/result 保持 Partial 或 Unavailable，不能成为 global Coverage variant，也不能在 Gap 后自动 Completed。`

## 4. 不应改动的当前结论

为避免全面 compat 删词，以下已明确限定、属于语义 policy/历史 projection/Provider-local evidence，当前无需替换：

- `legacy-accommodation.md:94` 的 `[sub:...]` audit projection：只在 audit projection 里渲染，不是 runtime alias；若未来把它公开为协议，再按 published boundary 条件化即可。
- `:199` 的 source-compatible leaf schema、`:739`/`:741` 的纯 helper/确定性 normalization、`:789`/`:950` 的迁移后删除 compatibility barrel/shim、`:2848-2849`/`:3370` 的 atomic caller migration 后删除 shim。
- `:5177` 明确禁止 runtime compatibility view/shim；`:6351` 明确要求 explicit scope/capability proof 才保留 provider-local route；`:7009`、`:7709-7710`、`:8577`、`:8597`、`:9030`、`:9133`、`:9372`、`:9436`、`:9555` 已写 no speculative dual-read/shim 或 offline parity → single-authority cutover。
- `:9969` 已明确“without a shipped boundary”不添加 speculative dual-read/shim；`:10008` 的 current cutover 也已按同一方向限定。
- `CompatibilityUnknown`、schema compatibility、source-compatible schema、provider-local symbol matching 等若表达“具名 semantic policy/lookup evidence”，不是自动的 runtime compatibility parser；不要把这些词一律删除。
- `event-flows.md` 中 `Coverage`、Gap、terminal、MemberOutcome、ProjectionCheckpoint 的当前规则已经闭合，不需要在本轮改动；其 `ExternalFact → ObservationRecorded → projection` 与 `DispatchStarted → attempt/recovery` 语义应作为下节的消费依据。

## 5. 正面构造与事件消费者核实

本支线的调查不只是负面找茬。以下是已在主书、event flows、legacy accommodation/bindings 之间核实的正面设计，可以交给 Main 作为核心论证，不要被兼容清理覆盖。

### 5.1 数据组合：共同操作数产生所有消费者

主书 `docs/uta-capability-runtime-design.md:410-435` 给出一个闭合正面构造：

```text
D0 : Query<I,A,E0,R0,P0>
D1 : Query<J,B,E1,R1,P1>
M  : Adapter<I × A,J,Em>
```

同一声明关联同时供以下消费者使用：

| 消费者 | 从同一关联消费的内容 | 不能推出的内容 |
|---|---|---|
| parser/边界 | D0 的 I、D1 的 B、M 的 J；失败保留 E0/Em/E1、阶段和原槽位 | 不会自动把动态回调变成业务 schema |
| public descriptor | D0/D1/M 的 revision、binding、输入/结果/失败关系 | 不另建 CLI 参数表，也不靠 shape 证明业务正确 |
| interpreter closure | 先执行 D0，再以 `I×A` 运行 M，仅 M 成功后执行 D1 | 不能丢 A，也不能把 D1 的 B 当作全部业务证据 |
| service/permission | R0 与 R1 的联合；P0 与实际后继 P1 分别核验 | 服务存在不是 PermissionWitness；联合要求不是自动授权 |
| final pure function F | 若业务同时需要 A/B，F 明确消费原 I、A、B，保留 Ef | schema/digest 不能自动证明 F 正确或依赖完备 |

主书 `:429-435` 进一步要求同源 Instrument/Candle 共享 source instance/native identity namespace、WindowInput declaration 和后继 input 核对；同对象、同字段 shape、同 CapabilityId 都不是同源性证明。

事件层与此一致：`event-flows.md:62-78` 规定 item/failure/lifecycle slots 由同一 capability/recipe 派生，runtime binding 的 scope/revision/lineage/capture 由 envelope/policy 绑定；`event-flows.md:331-335` 规定 Gap、SnapshotEnd、ItemFailure 和唯一 terminal 的生命周期；`:430-464` 规定 child terminal 与 item failure 分离、`MemberOutcome`/`CompositeResult` 仅在显式 partial profile 下成立；`:535-539` 规定 gap/correction/watermark/merge terminal 的消费边界。

这形成一个可消费的 positive path：

1. 声明者给出 D0、D1、M/F 的 schemas、失败 slots、source/binding/revision。
2. parser/descriptor/closure/permission 都读取该同一关联，而非各自复制字段。
3. Pull 的 `Complete|Partial|Unavailable`、Push 的 Gap/Correction/SnapshotEnd/terminal 均随同一声明进入 operator。
4. Projection/merge 只在其 declared profile 下生成 `MemberOutcome`/`CompositeResult`；不把 child Failed 改写成 recoverable ItemFailure，不把 Gap 后的未完成 source 伪装成 Complete。

### 5.2 纯控制、组协调与 reservation 消费

主书 `docs/uta-capability-runtime-design.md:673-679` 定义 pure `decide/evolve`；`:873-887` 定义 group coordinator 消费 `ChildProgress` product、成员 criterion/resolution/exposure 和显式 policy，而非 `success: boolean`；Unknown exposure 非零；`:899-918` 定义 DeferredInvocation/guard 的控制边界。

已核实的正面控制链：

- `Prepare` 只能形成 candidate/evidence；不会获得 approval、reservation 或 dispatch grant。
- `RuleDeclaration` 的 evaluator 是 pure ADT，输入包含 immutable facts、before-image、scope、policy version、capability availability、explicit now。
- writer 在声明的 consumption touchpoint（当前 accommodation 选定为 Approve/queue）重新读取 local state、核验 read-set/version/freshness，并在同一 transaction 原子消费 reservation、job/outbox、control projection 和 receipt。
- `DispatchStarted` 写入并提交后，writer 才向 worker 发放 fresh one-use `DispatchGrant`；之后发生响应/进程丢失必须保留 `Unknown` 与 recovery owner，禁止从 marker 缺失或 pending marker absence 推断 no-start。
- group `AllOrCompensate` 在成员 B Unknown 时不能只因 A 已知成交就逆向下单；compensation 必须是新的 prepare/approve/start/observe 关联并消费未决 attempt/exposure responsibility。

Accommodation 的同源证据：

- `legacy-accommodation.md:7811-7843`：pure decision/evolution、Draft/PreparedPlan、CAS、reservation/job/receipt。
- `:7866-7896`：fresh one-use grant、DispatchStarted、Unknown/recovery、不能盲重试。
- `:7919-7948`：pure RuleDeclaration/evaluator、writer-owned reservation、typed rejection、commit failure rollback。

### 5.3 Deferred handoff、Alice 与事件消费者

主书 `docs/uta-capability-runtime-design.md:899-918`、`:1079-1097` 与 accommodation `:9388-9418`、`:9436-9439` 给出正面 handoff：

- `DeferredInvocation` 保存未发送 `IntentRevision`、activation owner、source set、pure predicate、checkpoint schema、future boundary、expiry、frozen disposition 和 decision channel。
- `advance` 只返回 `NoActivation | Candidate | Gap`；Candidate 必须进入 activation owner 的原子 checkpoint/event/outbox；Gap 表示 continuity damage，不能默认等同 Partial 或 Completed。
- `ReturnToAgent` 仅在配置的 disposition 下成立；UTA writer 拥有 decision/outbox/receipt，Alice 拥有 WorkspaceConversationControl、resume/headless/Inbox 投影，不拥有交易 approval/DispatchStarted/venue outcome。
- Alice bridge 先 durable-admit 稳定 `ReviewRequest`，再绑定 exact Workspace/Session/headless key；Inbox/Issue comment 只是 delivery evidence，不是 AI command authority。
- `legacy-bindings.md:6209-6219` 核实 EventLog 是 append-only/process-local history、Issue timing 不是 predicate dispatch、Workspace/headless identity 与 delivery failure 都已有独立语义；`:6225-6231` 核实 E01 的 callback-before-persistence 和 E02 的 cooldown side effect 被新控制关系替换，而非通过 retry/re-dispatch 修补。

### 5.4 事件消费者表

| 输入事件/结果 | 当前消费者 | 允许的后果 | 明确不允许的提升 |
|---|---|---|---|
| `ExternalFact` / provider observation | adapter codec → observation reducer/projection | 记录 source/native identity、scope、asOf、coverage、lineage；必要时 `ObservationRecorded` | 不自动授予 PermissionWitness、approval 或交易事实 |
| `PullResult` `Complete/Partial/Unavailable` | Query consumer / projection | 根据 declared policy 返回完整、部分或不可用；Partial 保留缺口 reason | 空数组/零/now 不能把缺失变 Complete |
| `Push` item/gap/correction/snapshot-end | resource/operator/subscriber/recovery | gap/correction 按 partition/revision 处理；SnapshotEnd 非终态；每 attachment 一个 terminal | Gap 后直接 Completed；ItemFailure 改写 child terminal |
| `ChildProgress` / `MemberOutcome` | group coordinator | 依 policy 计算 independent/all/quorum/compensation responsibility；Unknown exposure 非零 | success boolean、一个成员的已知进度不能清除另一个未知敞口 |
| `RuleDecision` / guard evidence | writer at declared approval/queue or Start touchpoint | fresh read-set + pure re-evaluation；原子 reservation/job/receipt | prepare candidate 自己占额度；rejection 推进 checkpoint/授权 |
| `DispatchStarted` | attempt/recovery writer | 固定 attempt identity；之后所有结果按 observation/recovery 消费 | ack 直接等 Fill/Cancelled；丢响应就新建意图或重发 |
| `Ack` | receipt/observation consumer | 只表示 provider response evidence；后续 Fill/Cancelled 仍需 observation criterion | Ack 的 `closed` 直接成为 terminal outcome |
| `Candidate` from deferred advance | activation owner | 原子写 checkpoint + domain event + outbox，产生一次 activation work | generic EventLog listener 自己取得 dispatch 权 |
| `ReturnToAgent` / `ReviewRequest` | UTA control/outbox → Alice durable admission | Alice 投影 stable workspace/session/headless delivery，delivery failure 进入 frozen policy | Inbox/Issue comment 充当 UTA command、approval 或 venue result |
| `Gap` / recovery evidence | resource manager/operator/recovery owner | resync/Pull/observation work；未解决时保持 Partial/Unavailable/RecoveryRequired | 把 Gap 当全局 Coverage variant，或以 timestamp/array position 补齐 |

## 6. Cooldown 结论：不是冲突，但需固定所选触点

主书 `docs/uta-capability-runtime-design.md:879-887`、`:912` 允许 cooldown 在 approval/queue 或 `DispatchStarted` 消费；accommodation `legacy-accommodation.md:7934` 已选择 `Approve/queue` 消费 cooldown/exposure reservation，并在同一 writer transaction 产生 job/receipt。结论：没有设计矛盾，只有“允许的 policy variant”与“本 section 的 selected policy”尚未在文字上完全分开。

建议在 `LTX-GUARDS` 当前字段补一句：

> `本 section 选定 approval/queue 作为 cooldown/exposure reservation 的 consumption touchpoint；Start-bound consumption 是其他 RuleDeclaration 可声明的独立 policy，不是本 section 的隐含默认。无论触点为何，release/expiry/retry 必须同一规则声明且与 receipt/job 原子提交。`

本支线不添加测试；现有文档中的未来测试步骤按用户要求保留为 future obligations，不在本轮删除或执行。

## 7. Remaining / blocker

### 已完成

- 已定位一个真正的硬冲突：P0 `MAP-7AF82C011B` parser（MD `:99-100`，JSON `:80-81`）。
- 已收敛全部本轮查实的同根因 current compatibility promises：provider/IBroker/pack、runtime/carrier、protocol index、projection/export/HTTP、zero AccountInfo、listing empty/null/omission、market static/DTO、controlled-effect shape、migration exports，以及 Coverage/Gap 术语。
- 已为每组给出最小、可直接替换的当前文字；原始材料不需要重写。
- 已核实正面数据组合、纯控制/组协调、Deferred handoff 和事件消费者关系；这些不是只有负面找茬的盖章。

### 不再扩大本支线的范围

- 不再继续全仓库搜所有 `compatibility` 单词；上节“不要改动”已经标出已具备迁移删除、provider-local、semantic-policy 或 explicit shipped-boundary 条件的安全条目。
- 不修改 `docs/uta-capability-runtime-design.md`、`event-flows.md` 或 repo 中任何文件；由 Main 决定是否把同一 replacement 同步进 MD/JSON current fields。
- 不将“未来可能是已发布外部协议”写成当前承诺。published protocol evidence 仍是未调查事实；若未来证实，新增 protocol-specific versioned projection，而不是恢复 generic parser/dual-read/shim。

### 当前阻塞判断

没有未决的抽象设计 blocker。剩余工作是 Main 选择并应用上述同源 current-field replacements；其中 provider-shipped compatibility evidence 的缺失不是暂停主机设计的理由，而是应在 current text 中明确为 evidence boundary。runtime、测试和真实 Provider conformance 未在本支线验证，且不属于本轮只读设计交付。
