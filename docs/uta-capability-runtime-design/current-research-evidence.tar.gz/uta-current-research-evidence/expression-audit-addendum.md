# 表达审核附录：持续读取、管理声明与未命中生命周期

## 复核对象与结论边界

本附录按 Main 的追加任务，对 `expression-audit.md` 的两个剩余构造问题及新增未命中截止消费者作独立回读与原反例推演，不重新签收整套目标，也不把文字加入本身当成成立证明。

直接回读：

- 主书快照 `#955E`：§3.2–3.3（269–283）；§5.4.3及相邻Controlled边界（459–503）；§7.1–7.4（595–653）；§11.1–11.2（919–956）。
- 事件流快照 `#E0B8`：EF05（547–649）；EF10（1176–1206）；EF12管理/配置（1541–1570）；EF13管理/模拟器（1681–1707）。
- 主书快照 `#95BB:930–947`：回读首次决定请求的origin分支，确认尚无请求的等待截止与已有请求升级分别构造。

无仓库修改、生产代码、项目验证或历史实验重跑。以下均为声明前提下的有限轨迹与消费关系分析。

**独立结论：** 持续读取回注与owner-scoped管理面的两条原缺口，在此次实际读到的正文中已经形成可推演的操作数—构造—解释—结果关系。未命中等待的Close/Suspend生命周期也有明确消费者，不再必须等待一个根本未创建的ReviewRequest过期。首次EscalateDecision按当前D/C及截止/渠道事实构造，只有已有请求的升级才引用前次请求；三种原反例的相应操作数与消费均已闭合。此结论不签收整套目标或运行时实现。

## 一、持续读取回注：原EUR/JPY反例不能再沿合法路径发生

### 1. 变化发生在构造关系，而非仅加标签

主书:482明确将读取工作与对外emissions分开。step可以返回声明的工作与等待状态；工作由已有§5.4.1/2的关系取得精确Query binding/input以及失败、R/P；解释器执行，并将关联成功或失败回注同一个operator。

因此三个此前空缺的消费位置已经可指出：

- **输入构造者：** 保存在关联中的固定/动态后继构造，不是FX回调临时从裸currency字段查一个自由handler。
- **IO解释者：** Query解释器按所选绑定和实际权限执行，不由纯step读网络。
- **结果消费者：** 原operator的纯step读取等待关系及请求依赖；decoder/schema通过不是推进当前输出的充分条件。

EF05:556及627–637把同一关系放进实际估值时序，区分当前匹配与旧请求/再次修订，不只列一个FxLookupRequested名称。

### 2. 使用原反例逐步推演

假定持续账户Feed、FX Query以及来源修订合法，operator仍存活：

1. 账户a1是EUR。M据a1的currency、scope、asOf和source policy构造EUR/USD读取q1；等待关系保留q1及其输入依赖。
2. q1未返回，可信账户修订a2将currency变为JPY。step使旧EUR估值匹配失效；同一关联产生JPY/USD读取q2与新等待关系。不要求重新读全部账户，也不自动更换projection owner。
3. EUR/USD结果r1晚到。它依q1的FX binding/slot解码仍合法，但不能满足q2的pair及输入依赖。因此原step不推进JPY结果。按业务声明，r1可以进入历史事实或诊断；不能被强制改成对q2的失败或丢弃仍有合法历史消费者的证据。
4. JPY/USD结果r2返回且q2仍与当前等待关系相容，step据原账户值和r2重建valuation，输出新的派生revision/lineage。
5. 若在r2返回前输入再次修订，或缺合法constructor、授权/FX证据，结果继续按相应构造/调用/业务失败处理，不能靠一个数值rate完成当前计算。

这里不要求所有revision字节必须相等：正文使用“仍与等待关系相容”，相容性由声明实际依赖决定。输入中不影响该读取的展示字段变动，不应因新增机械版本检查被误判为必须全量重算。

### 3. 终止与资源没有另起一套含义

§5.4.3:480与原§8/§16.5仍约束attachment和outer Terminal。读工作不会让已结束的invocation重新发帧。相应Scope的取消只释放自己持有的Query/原生引用，不解除另一个历史消费者的所有权；是否保留旧结果属于声明政策。

持久恢复另需保存checkpoint/工作接纳及同一因果关系，普通运行状态不被强制送入交易WAL。这是两种明确承诺，并非借非持久实现删除已声明的恢复义务。

**裁决：** 原审核§5的构造缺口已关闭。在Query/来源履约、等待相容性检查完整、owner/terminal规则被解释器执行的前提下，可推出旧EUR结果不能推进当前JPY估值。这不是Provider真实FX质量、持久恢复运行或任意switch算子全部正确的证明。

## 二、管理声明：没有把非金融写伪装成Query或交易Recipe

### 1. 分类范围和公开消费现在相互对应

§3.3:283将三分法限定为数据/金融业务调用协议，并指向管理面；§7.2:623给出明确manage/management-status协议入口；§7.4:639–651给出owner-scoped完整声明，而不是只改一个类别名称。

同一安装关联现在同时持有owner、协议/修订、scope、精确输入/成功/失败、R/P、版本条件、纯decide/evolve、工作及owner解释入口。构造器由它派生描述、帮助、parser、owner路由和结果消费者。host聚合完整管理描述，但不能因此取得管理写权或另维护action/callback表。

因此改变管理输入schema会影响其parser、发现说明和解释消费的同一关联；更换管理实现仍受版本/实现关联约束，不能保持描述不变另换一个自由handler。

### 2. Mock FillOrder的三分法反例有明确合法出口

假定simulator owner已安装声明且主体有fixture管理权限：

1. discover/describe返回明确标识管理面的完整关联，不返回虚假的read-only Query或交易Controlled。
2. 用户据同一输入schema构造FillOrder(qty=3)；manage入口重新核对binding、owner、fixture scope、expected revision及当前权限，发现成功本身不是许可。
3. 该owner保存的纯决定消费fixture state与合法stimulus，形成候选变化。
4. Mock fixture writer按自己的提交协议接纳，返回AdminReceipt，随后由Mock fact owner派生有causation的MockFillFact。
5. UTA观察者可以导入该事实，但没有由管理receipt产生UTA approval、reservation、DispatchStarted或grant。

未安装simulator管理声明时入口不存在；实际命令权限撤销时拒绝；不能由“有一个Mock连接”推导许可。EF13:1687与1698–1707已经沿此关系保留部分成交、累计数量及独立owner。

这同时拒绝原反例的三个错误出口：Query隐藏写、空Recipe强套交易语义、独立手填simulator命令表。它没有把Mock authority迁给host。

### 3. Capture和Config并未被统一成一个事务机

- **Capture：** §7.4:648与EF05:559、565–577明确由Observation owner声明。request接纳产生接纳receipt；保存的Query关系取得事实；该owner随后决定/提交selected evidence和最终capture结果。后续读取失败不会反向改变接纳历史，也不被接纳成功吞掉。普通Pull仍不会自动capture。
- **Config：** §7.4:649及EF12:1543–1567分别保留Alice配置revision与UTA生命周期apply。host目录只聚合各自的声明；ConfigSaved不是ConfigApplied。秘密解引用、打开连接和探测在可信解释边界，结果作为RuntimeBindingEvidence回到相应owner的决定/提交，不把网络搬进writer。

两个实例复用声明、纯决定与解释关联，却各自定义提交、等待、阶段失败和查询恢复。没有因为同为有限命令就强迫共享Order.Prepared/补偿/交易批准。

### 4. 新限制是合理范围，不是逃生口

§7.4:651明确不据这些已研究管理family声称任意未来Provider非金融写都已覆盖。普通Effect程序可显式组合管理入口，但Query组合不允许把它隐藏；公开组合保留管理协议身份、失败、权限和owner条件。

**裁决：** 原审核§8的声明/公开入口桥已关闭。当前已研究管理family具有同源构造；不是另起自由业务注册表，也不是新增万能事务机。未来新的协议承诺需要独立研究，具体管理协议的机械实现和跨进程可靠性仍未被本附录运行验证。

## 三、未命中等待：截止与首次请求的正面构造

### 1. CloseWithoutDispatch可在没有ReviewRequest时执行

主书:945–947、EF10:1184现在由同一个D保存激活有效期、可信终点判定及到期处置，构造独立生命周期消费者。其输入是声明的Clock或S完成/barrier事实与当前C/控制状态，不把生命周期结束伪装成普通advance的Candidate或Gap。

有限前提是“本交易时段截止前出现crossing，否则关闭等待”：

- 96、98只推进NoActivation及必要checkpoint，没有selected E或ReviewRequest。
- 截止事实到达，生命周期消费者读取当前D/C、epoch和not-started状态；writer提交owner退休、未发送意图处置和截止原因。
- 不生成虚假命中E，也无需等一个不存在的ReviewRequest过期。
- 若Start先提交，关闭不能再将它退休成未发送；保留attempt及相应观察/恢复责任。若截止先提交，则后继Start须消费被关闭状态。

FutureBoundary只定义epoch的未来起点；本地deadline可以支持停止等待政策，但没有完整来源barrier时不证明市场历史从未发生条件。某个子流Completed是否构成整个S结束仍由组合政策解释。

**裁决：** Close/Suspend的无命中生命周期关系成立，并保留了源完整性与本地等待政策的区别。不需要公共Partial ADT、自动最小支持闭包或全局规则ADT。

### 2. 第一次EscalateDecision与已有请求升级分别构造

主书快照`#95BB:939`将两个原因分支明确分开：尚无请求的等待截止或渠道升级引用当前C、截止/渠道事实及冻结政策；已有请求的升级另引用前次请求。非命中原因不伪造E，首次请求不伪造前次request。

用此前只有96、98且均NoActivation的轨迹：到期政策为EscalateDecision时，生命周期消费者不需要一个不存在的ReviewRequest。它消费D内冻结的责任渠道/政策、当前checkpoint及可信截止事实，生成以该原因说明的第一请求；随后按已有writer/outbox及Alice持久接纳关系交付。若后来针对这个真实请求再升级，新的请求才引用它作为前次request。

因此请求起点、原因材料与后继消费者已经闭合，不必把到期伪装成Candidate，也不要求通用公共Partial状态或自动最小支持闭包。schema只认证实际材料，D保存的原因构造决定如何消费它们；这仍不能证明任意业务终点判定函数的正确性。

## 四、此次复核可以交付什么

本附录确认两个原审核缺口已经通过新增的实际消费关系得到修补，且保留了各自的失败、权限、资源和owner边界。无命中截止的生命周期消费者解释了原来的空窗；第一次升级请求的origin也已经由同一D的真实材料构造。此次限定回读未留下需要以“实施时再决定”掩盖的同一断裂。

这是一项**限定的修复复核**：不是以“原反例不再发生”替代全书正面解释，更不是整套目标/旧承接/运行时的自动验收。原审核对已读范围、未读范围、实现义务与Provider证据的限定继续有效。