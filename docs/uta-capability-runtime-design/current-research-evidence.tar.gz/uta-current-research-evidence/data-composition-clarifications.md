# 数据组合研究：四项收窄的裁决回应

这是一份对 `local://uta-current-research/data-composition.md` 的补充裁决，不改原记录，不修改仓库。四项收窄均应采纳；它们削弱的是原报告中几处过强的实现/状态前提，不削弱 filter、window、join 或账户/FX 的正面构造。共同结果是：算子仍由声明的操作数、纯消费关系和解释边界组成，但存储、修订比较、时间输入及投影身份需要更精确地分层。

## 1. Filter 不必普遍保存所有被过滤 payload

### 裁决

原报告把“支持 correction”写成至少保存每个 source item 的最后 revision/lineage，容易被读成必须保存所有被过滤 payload。这一要求应收窄为：

> Filter 只需保留能履行其已声明 correction/coverage 契约的最小证据。是否需要旧 payload 取决于 correction 的形态、来源保证和 predicate/输出函数能否在新事实上重新判定；不具备条件时，显式宣告不支持、Partial、Unavailable 或 reconciliation，而不是强制全量缓存。

最小状态通常可以只有：

- source identity 与来源声明的修订关系；
- 已输出/未输出的 membership；
- 已输出项的 derived identity、当前 output revision 和 lineage；
- source position/coverage 所需的连续性证据。

不必因此保留旧的完整 Candle/News payload。具体分支如下：

| 来源修订条件 | Filter 所需证据 | 合法结果 |
|---|---|---|
| `Correction` 含同一 source identity 的**完整替换值**，predicate 对新值总定义 | 旧 membership、derived identity/lineage；无需旧 payload | `false→true` 发新 derived item；`true→true` 发 derived correction；`true→false` 发 derived retraction |
| `Correction` 只有 patch/delta | 需保存旧值，或由 adapter/新 Pull 先还原完整替换 | 有还原则同上；否则保留 Partial/Unknown/reconciliation，不执行不完整 predicate |
| Filter 从未观察到 target，且 correction 没有 baseline/来源存在性保证 | 无法知道 target 原来是否输出 | 不能直接发 `DerivedCorrection`；新 item 或 retraction 只有在来源/投影声明能判定 membership 时才合法，否则 reconciliation/new invocation |
| 来源没有 correction/retraction 关系 | 不存在可认证 replacement | 普通 Data 仍可消费；late 内容按 declared unsupported/unknown policy，不声称支持 correction |

因此“未命中项后来命中”要求的是**足以判定旧 membership 的证据**，不是旧 payload 的普遍保存。若 source correction 自带完整 replacement，filter 可用新值直接计算；若 filter 使用历史状态而非单值 predicate，则需另行声明状态依赖，不能继续称为简单 filter。

### 对 Candle 例子的影响

原有限时序仍然成立，但状态注释应改为：

- `c1@r1` 的 `close=99` 使 `q_close` 为 false，filter 记录 membership=false 与 source identity；不要求永久保存完整 `vwap`/OHLC；
- `Correction(c1@r2)` 若带完整 replacement `close=100`，即可由 predicate 得到 `false→true` 并发新 `ProjectedItem`；
- `Correction(c2@r2)` 若旧 membership=true 且新 replacement 不再满足，发 `DerivedRetraction`；旧值只在 patch 形态或业务函数需要时才必须保留；
- target 不在当前 invocation 的 membership/index 中时，不能凭空发 correction，按来源保证选择新 item、reconciliation 或失效。

这不改变 `close>=100` 与 `vwap>=100` 的非透明业务差异，也不改变 filter 的 source gap/terminal/owner 边界。它只把“支持修订”的前提从全量缓存改成“来源修订契约 + 最小 membership/lineage 证据”。

### 对 window/join 的区别

这个收窄主要适用于 filter，不能无条件下推到聚合和配对：

- Window 的 `sum/count` 若 correction 是完整 replacement，仍可能需要旧成员值才能修正 accumulator；除非 reducer 声明有 `replace(old,new)` 关系，或成员账/重放可提供旧值。`max/median` 等不可逆聚合更明显需要成员保留或 replay。
- Join 需要知道旧 pair/membership；如果 correction 完整替换一侧 value，旧 key/pair membership 仍须可判定。无法判定时不能随意发 correction/retraction。

所以共同最小关系是“保留足以满足声明契约的证据”，不是“所有 operator 必须保留所有输入”。

## 2. Revision 由来源声明关系决定；generation 不等于 revision

### 裁决

原报告中的“最高合法 revision”“revision 前进”“`r2 > r1`”不能被理解为内核默认的数值最大或全序。应改成：

> Source revision 是 provider/adapter 声明的 opaque identity/version relation。Operator 只按该关系判断 duplicate、replacement、conflict、concurrent 或 unknown；没有可验证关系时，不选“较大”的一方，也不将到达较晚当成新版本。

用关系记法表达即可，不需要新增 DSL：

```text
sourceChange(old, incoming)
  = Same
  | DeclaredReplacement
  | Conflict
  | ConcurrentOrAmbiguous
  | Unknown
```

这里的构造结果由 source binding 的声明和证据决定，不是核心自行发明的 ADT API。source 可能给出单调 revision，也可能给出版本向量、修订 token、effective interval 或只给有限的 identity/replacement 引用；operator 不应把它们统一压成整数最大值。

`generation` 只标识连接/资源代际：

- 旧 generation 的 frame 默认不能更新新 generation 的 current state；
- 若 source identity、slot、跨代连续性和 correction/replay 证据都认证，旧 generation 的事实可以作为 historical evidence 影响原 projection；
- generation 改变本身不表示 payload 被修订；revision 改变也不表示连接换代。

同一 source identity 的相同 revision 携带不同 payload，应走 Conflict，除非 source declaration 明确允许该关系。两个 revision 并发且没有选择政策时，保留冲突/Partial，不按 receivedAt 或本地 commit 顺序覆盖。

Derived revision 则由 operator/projection 自己的声明和写入边界产生。它可以在 writer 内部按自己的提交规则形成顺序，但不能反向宣称 source revision 有同样的顺序或语义。Derived identity 稳定并不代表 source replacement 已成立。

### 对 filter/window/join 的影响

- **Filter**：先调用 `sourceChange` 判断 correction 是否真是 replacement；若不是，不能重复执行 predicate。membership 的旧/新比较不依赖 numeric max。source generation 仍独立校验。
- **Window**：event-time window assignment、watermark 和 late policy 不由 revision 排序替代。revision 只决定成员 replacement/correction 能否应用；同一窗口的新 derived revision 是 operator/projection 版本，不是 source sequence 的复制。
- **Join**：pair 重新计算只有在两侧 source identity/revision 关系可解释时成立；并发/冲突版本不得任意选一侧。join key 的变化可造成旧 pair retraction 与新 pair item，但前提是 source replacement 关系已认证。
- **Account/FX**：`FX(EUR/USD)` 的 correction 是否替换前一观察由 FX source declaration 决定； valuation revision 可以由 projection owner 生成，但不能把它叫作 FX source revision。generation 变化需按 scope/rebind/跨代证据处理，不得用 `generation=2` 推断 `rate revision=2`。

## 3. Pure step 必须接收声明的边界/Clock 事实

### 裁决

原报告的

```text
step_O : State_O × DecodedChildFrame -> (State_O × Emission*) + OperatorFailure
```

对纯数据事件足够，但对 `WindowClosed`、processing deadline、freshness、as-of 和显式 barrier 不完整。应改为如下**推导记法**：

```text
step_O : State_O × StepInput_O
       -> (State_O × Emission*) + OperatorFailure

StepInput_O = declaration-authorized child frame
             | source/barrier/watermark fact
             | declared Clock/deadline fact
             | finite query boundary
```

这不是新造一个公共 DSL。它只说明：凡是会影响纯决定的时间或边界，必须先在解释边界被取得、认证并作为不可变事实传入；step 本身不读取全局 Clock、`Date.now()`、网络或 timer。具体 operator 可以不需要某些变体。

各场景的边界输入应这样理解：

| 算子/情形 | 声明的边界事实 | 不能隐藏的副作用 |
|---|---|---|
| Filter | invocation 的 request/as-of、source generation；若 predicate 依赖当前时间，则显式 Clock fact 与 `R` | 不能从全局 now 偷读时间；时间 predicate 也不再是无时间纯 filter |
| Window watermark close | source watermark、snapshot barrier 或 finite Pull completion | 不把 receivedAt/本地排序当 watermark |
| Window processing deadline | interpreter 取得的 `ClockObservation/DeadlineReached`，带 deadline policy/version | timer 只负责产生边界事实，不由 timer 回调直接改 projection |
| Join | caller as-of、两侧 observedAt/as-of 关系、必要的 finite boundary | 不按 frame 到达顺序或隐藏 current time 配对 |
| FX/valuation | capture/as-of boundary、FX observedAt/quality/freshness fact；stale 判断需要声明的 Clock fact | 不用本地 capture 时间伪造 source observedAt/Confirmed |
| child terminal | child 的 terminal/coverage/barrier 事实 | `SnapshotEnd` 不能被解释器暗中升级为 live Completed |

解释器可以负责读取 Clock、接收 provider watermark 或检测 deadline，但必须把结果编码成 O 声明可消费的 `StepInput_O`，并把 Clock/transport service 留在 `R`/effect 边界。这样时间仍是 effect，状态推进仍是纯函数。

### 对有限时序的影响

原 NewsGroup window 时序的 deadline 分支应明确为：

1. resource/interpreter 在声明的 `processingDeadline` 上取得 `ClockObservation`；
2. 把 `DeadlineReached` 送入 W 的纯 step；
3. W 产生 `WindowClosed(..., Partial, deadlineEvidence)`；
4. 外层 invocation 是否继续仍由 stream/terminal policy 决定。

这不把 deadline 变成 source watermark，也不改变 late item 在 outer invocation 尚未终止时可按声明修订的关系。若没有 Clock fact 或 deadline policy，step 不能自行关闭窗口。

## 4. Outer terminal 只结束 invocation；持久 projection 可沿稳定 identity 更新

### 裁决

原报告多处写成“late correction 必须新 projection identity”。应收窄为：

> Outer terminal 关闭的是本次 delivery invocation 及其 frame gate；它不自动终止仍合法存活的持久 projection processing owner，也不宣告持久 projection 的逻辑 identity 永远不可更新。该存活 owner 可以在新的处理/交付边界消费修订；若它已终止，则经 fencing/ownership 授权的新 owner 或 invocation 才可沿稳定 `projectionId`/`derivedId` 写入新的 projection revision。

需要同时保持四个区别：

1. **旧 delivery invocation 不复活**：已发 `Completed|Failed|Cancelled` 后，旧 subscriber 不再收到 Data/Correction/Retraction，也不再次发 Started/terminal。
2. **新处理 invocation 可以存在（不等于必须换 owner）**：迟到事实可由仍合法存活的持久 projection processing owner，或经 fencing 的新 owner，通过 `ProjectionRequested`、新 Pull/replay/resync 或另一个已认证 correction source 处理。
3. **projection identity 可稳定**：若 projection declaration 定义 stable identity、revision、owner fencing、checkpoint/replay 规则，存活 owner 的新处理边界或新 owner invocation 可以更新同一 `projectionId`/`derivedId`；输出是新 revision，不是旧 stream 的 frame。
4. **没有条件仍不可更新**：若 source identity/revision/replay/correction 证据不足，保持 reconciliation/Unavailable；稳定 identity 不是强行接受修订的许可。

因此，旧 delivery invocation 的 frame gate 必须关闭；若需继续处理，必须进入新的处理/交付边界，但该边界可以由合法存活的持久 projection owner 承担，也可以由经 fencing 的新 owner 承担。“新 projection identity”只是缺乏稳定投影延续契约时的一个可选处置，不是普遍要求。持久 projection row 可以保留稳定 derived identity 并追加 revision；旧 committed source event/旧 projection history 仍不可原地改写。

### 对各场景的影响

- **Filter**：旧流终止后，若 filter 的持久 projection owner 仍合法存活，可在同一持久 selection projection 中把 `d2` 更新到新 derived revision，或把原有 `d2` 撤回；这些更新不发给旧 subscriber。若 owner 已终止，则需经 fencing 的新处理边界；若只是 transient finite Pull，调用者必须重新 query。
- **Window**：同一 `windowId`/derived identity 可以由仍合法存活的 projection owner 在新的处理边界写入 `revision=2`；若 owner 已终止，则由经 fencing 的新 projection worker 处理，前提是成员状态/replay 或 correction source 可重建。`WindowClosed`/deadline 不等于整个 projection 永久不可修订；但 outer delivery terminal 后仍不允许旧 stream 发 revision frame。
- **Join/Account-FX**：同一 pair/valuation projection identity 可由仍合法存活的 projection owner，或取得 fencing/ownership 的新 owner，在取得新的 FX correction 后更新 valuation revision；若币种/key 改变，旧 pair 仍需 retraction，新 pair 使用其自己的 derived identity。稳定 valuation identity 不会让旧 `CaptureRequested` 或旧 immutable evidence row 被原地篡改。
- **Merge**：旧 outer stream terminal 后，若持久 merge projection owner 仍合法存活，可按声明从 child source/replay 处理相同 logical projection；若 owner 已终止，则由新 merge invocation 重建；child terminal 的旧 invocation 不会 resume。新的 child attachments 由当前合法 owner 获得，Shared native resource 是否复用由 resource manager 决定。

### 终止后路径的精确表述

`Correction` 在 outer terminal 后应按以下路径解释：

```mermaid
sequenceDiagram
    participant C as Correction source
    participant O as Old delivery invocation
    participant P as Lawful durable projection owner
    participant N as New processing or delivery invocation
    participant R as Projection store

    C->>O: correction after outer terminal
    O-->>C: terminal gate rejects; no old frame
    alt durable owner remains lawful
        C->>P: authenticated correction or replay fact
        P->>P: validate source revision and generation relation
        P->>R: append new derived revision to stable identity
    else owner or boundary ended
        C->>N: ProjectionRequested, replay, or resync
        N->>N: validate source revision and generation relation
        alt continuity is declared
            N->>R: append new derived revision to stable identity
        else continuity is absent
            N->>R: new projection identity or reconciliation
        end
    end
```

上面的路径是概念时序，不要求新增全局事件类型，也不假设必须更换 owner。若存活 projection owner 可直接消费 correction，其新的 processing/delivery boundary 由该 owner 负责；否则由新的 processing/delivery invocation 负责。若 invocation 只是一次查询，结果通过新 `QueryResult` 返回；若它是持久 projection，则 writer 以 stable identity + new revision 更新 projection，并保留旧历史。

## 5. 四项收窄是否影响原四种构造

| 构造 | 影响 | 收窄后的必要前提 | 未改变的结论 |
|---|---|---|---|
| Filter | 存储要求变小；revision 比较改为 source relation；step 显式接收 boundary；terminal 后可同 projection identity 更新 | predicate 总定义；membership/lineage 最小证据；source replacement/revision 关系；合法存活 processing owner 的连续性或新 owner/fencing | rich Candle 的业务 predicate 差异、Gap/coverage、旧 stream 不复活、资源 owner 仍成立 |
| Window | 不能用 revision max 维护窗口；deadline 必须传 Clock fact；window revision 可在稳定 projection identity 下推进 | 成员/可逆 reducer/replay 之一；watermark/barrier/deadline policy；late policy；window close≠outer terminal | deadline 不等 source finality；Gap/Partial 保留；关闭窗口仍可在 live invocation 内按 policy 修订 |
| Join | pair correction 依赖 source revision relation；as-of/time boundary 进入 step；合法存活 owner 或经 fencing 的新 owner 可更新稳定 pair/valuation identity | typed key、时间关系、缺侧政策、pair lineage、source replacement/conflict 证据 | 不按 display symbol/arrival time/zero 补值；FX 缺失不 Complete；跨币种单位仍需显式 FX |
| Account/FX | FX source revision 与 generation 分离；freshness/as-of Clock fact 显式化；valuation projection 可稳定 identity + 新 revision | currency/as-of relation；FX quality/coverage policy；账户/FX correction 可定位；capture evidence append-only | `F(A,B)` 纯消费、不产生 dispatch；缺 FX 保留 Partial/Unavailable；币种改变不沿用旧 rate |

## 6. 建议 Main 在整合时替换的措辞

不改原报告，只给整合替换点：

1. 将 filter 的“保留每个 source item 的最后 revision/lineage”改为“保留足以满足声明 correction/coverage 契约的 source identity、membership、lineage 和修订关系；是否保存 payload 由 replacement/patch 形态和 reducer/predicate 需要决定”。
2. 将所有“最高合法 revision”“revision 前进”“`r2` 新于 `r1`”改为“按 source declaration 的 revision/replacement/conflict 关系判断”；明确 `generation` 仅是连接/资源代际。
3. 将 `step_O(State_O, DecodedChildFrame)` 改为 `step_O(State_O, StepInput_O)`，并说明 `StepInput_O` 可包含声明的 source barrier、watermark、finite boundary、Clock/deadline fact；step 不直接读取 Clock。
4. 将“新 projection identity”改为“新的 processing/delivery invocation；持久 projection 若有 stable identity、revision、owner fencing 和 replay/correction 契约，可沿同一 identity 更新，否则新 identity 或 reconciliation”；不把“新 invocation”解释为必须新 owner，合法存活的 projection owner 也可承担新的处理边界。
5. EF04 的 `ProjectionCheckpoint` 说明应覆盖 operator 需要的最小 correction/replay evidence，不暗示保存所有未命中 payload；source revision/generation 字段按各自声明解释。
6. EF03/EF04 的 terminal 规则应同时写“旧 delivery invocation 不再发”和“持久 projection 可由合法存活的 owner 或经 fencing 的新 owner 更新 stable identity”，避免把 stream finality 与 projection-row finality混为一谈。

## 7. 最终 Main 裁决回应

四项收窄全部采纳。它们没有引入新的通用 DSL、算子或状态机；相反，它们把共同关系收敛为更小、更准确的三层：

- **纯业务 step**：只消费已解码 child/value 与声明的边界事实，按 source-declared revision relation 推进最小 operator state；
- **资源/时间解释**：取得 Clock、watermark、source barrier、owner/fencing 并转换为声明事实，不让纯 step 隐藏 IO；
- **持久 projection/交付**：旧 invocation terminal 后不再发 frame，但持久 projection 可由仍合法存活的 processing owner，或经 fencing 的新 owner，按 stable projection identity 和新 revision 更新 durable read model。

因此 filter 的构造仍然成立，只是 correction 支持不再要求全量被过滤值；window 的构造更明确区分成员重算证据、watermark/deadline 与 stream terminal；join/Account-FX 更明确区分 source revision、generation、as-of 和 projection revision；四者都仍需业务声明 predicate、window、key/time、missing-side、quality、late 和 terminal policy。原报告中所有把这些关系说成固定全序、全量缓存、隐式 Clock 或必须新 projection identity 的表述，以本补充为准。