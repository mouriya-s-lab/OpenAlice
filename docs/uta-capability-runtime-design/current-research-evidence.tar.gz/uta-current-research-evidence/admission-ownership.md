# EF11 Admission ownership：Alice 接纳之后的 worker、完成与恢复责任

## 范围与证据边界

本报告只审核主书 §11、事件流 EF11，以及 Alice 现有 owner guide / 当前 headless 实现对同一边界的说明。目标是澄清：**Alice 已经 `Admitted` 之后，谁对 worker 尚未启动、启动证据丢失、完成/回复和恢复负责；UTA 的 request/outbox 已送达或已过期时，哪些责任仍然存在。** 不改写 UTA 的总体架构，不把 Alice 改造成通用 workflow engine，也不承诺进程 exactly-once 或无条件自动重启同一任务。

EF11 自己声明所有目标类型是设计规格、源码锚点不表示目标协议已实现（`docs/uta-capability-runtime-design/event-flows.md:1-5`）。因此下文把三种证据分开：

1. **当前 Alice 契约/实现**：owner guide 和当前源码已经承诺的行为；
2. **当前目标文稿**：主书 §11 与 EF11 已表达的目标关系；
3. **最小补文**：只补足 post-admission 的责任关系、状态证据和恢复分支，不替换已有 admission、outbox 或 UTA CAS。

本次没有运行项目测试、build、lint 或 formatter，也没有修改仓库文件。
本报告不重复主书 §11.1.1 已补的 waiting expiry、普通 `advance` 与 FutureBoundary 的区别；这里只消费 EF11 已提交 request 的 `expiresAt`，并研究它在 Alice 已 `Admitted` 之后如何与 worker claim、completion、late reply 和 retention 分开。

## 1. 先核对已有规则：不能把已有关系误报成缺口

### 1.1 主书 §11 已经规定的 UTA 侧规则

| 规则 | 已有表达 | 责任边界 |
|---|---|---|
| 来源证据、epoch 与重复 | event identity/epoch 去重、checkpoint、意图状态和下一 outbox 在一个 writer transaction 中提交；同一意图版本只有一个 live activation owner（主书 §11.2，`docs/uta-capability-runtime-design.md:956-960`） | UTA activation owner；不是 Alice worker 去重 |
| request 身份 | 一个 committed decision revision/occasion 有稳定 request identity；correction/escalation 产生新 revision/request（EF11.2，`event-flows.md:1403-1405`） | 同一 request 不因重投变成新决定 |
| outbox 身份 | `outboxId`、`requestId`、`reviewId`、digest、`deliverySequence` 绑定在 `DecisionOutboxFrame`（`event-flows.md:1404`） | UTA outbox 负责交付同一 frame |
| 回复匹配 | 回复必须匹配 request、control version、intent revision、epoch、主体和有效期；迟到回复返回 stale/conflict（主书 §11.3，`uta-capability-runtime-design.md:978-980`） | UTA decision writer；不由 Alice 把旧回复改成新意图 |
| expiry 竞争 | request 到期与回复竞争同一控制版本 CAS；胜者原子保存结果和必要 outbox（主书 §11.3，`uta-capability-runtime-design.md:980-982`） | UTA expiry/reply 竞争；不是 Alice admission 的删除信号 |
| 时钟分离 | Keep 保留期、request 有效期、批准有效期和投递租约分别建模，不能互相代替（主书 §11.3，`uta-capability-runtime-design.md:982`） | 已明确不能用一个 TTL 代替所有生命周期；但 post-admission 的 Alice execution 记录尚未给出具体表达 |
| RequestSubmission | 对已接纳 intent 建立原意图的内部 control handle，不再次 SubmitIntent；Prepare/批准/Start 持续检查原依据（主书 §11.5，`uta-capability-runtime-design.md:1012-1016`；EF11 `event-flows.md:1395`） | Alice worker 的回复不是交易批准，也不直接下单 |

因此，不能再提出“EF11 没有 request identity / 没有 CAS / 没有 expiry 竞争”这样的结论。实际问题较窄：**UTA 已经有 request/outbox/reply 的身份和竞争；Alice `Admitted` 之后的 worker execution 生命周期没有与这些已有操作数形成同样清晰的正面关系。**

### 1.2 EF11 已经规定的 Alice admission 规则

EF11.1 已明确：

- EF10 writer 先原子提交 `DecisionRequested + DecisionOutboxFrame`；EF11 不重新计算 predicate；
- Alice 接收 frame 后，必须先在自己的 durable owner 中提交 admission，worker spawn 与 transport receipt 在该提交之后独立推进；
- UTA 拥有 request/outbox/review/expiry/CAS；Alice 拥有 workspace resolution、Session/Inbox admission、稳定 execution/task/session 引用、worker ownership、delivery receipt 和 agent reply transport（`event-flows.md:1390-1398`）。

EF11.2 的 `WorkspaceAdmission` 也不是空白：

```text
Pending{outboxId, reviewId}
Admitted{
  admissionId,
  executionRef{executionId, taskId, sessionId},
  workspaceId, resumeId, sessionRecordId,
  admissionRevision, resolution
}
Rejected{reason}
```

并且：`Admitted` 不使用可选 `taskId?`；重复 `outboxId` 返回原记录；Alice writer 在 `Admitted` commit 后才允许 spawn 与 receipt 分支（`event-flows.md:1406-1413`）。时序也已经给出 admission CAS、稳定 execution reference、AdmissionReceipt、AdmissionAck，以及重投前 query admission（`event-flows.md:1444-1455,1503-1515`）。

所以“重复 outbox 会创建多个 Alice worker”不是当前目标规则；已有规则已经禁止重复 admission。需要补的是：**同一已接纳 executionRef 如何 claim、确认启动、记录完成，以及在 crash/ack 丢失时怎样恢复。**

### 1.3 当前 Alice owner guide / 实现实际规定的规则

这些规则不能冒充 EF11 的目标实现，但必须用于区分当前和目标：

| 当前事实 | 证据 | 对本任务的意义 |
|---|---|---|
| Issue schedule marker 在 durable run record 被接受后才推进；之后启动失败/运行失败仍是该 occurrence 的单次尝试，使用 `Retry now`；没有创建 run 的 capacity/admission rejection 保持 due | `docs/workspace-issues-and-scheduling.md:277-288` | 当前 scheduler 已区分“没有接受 run”与“已接受但失败”，但这不是 UTA `DecisionOutbox` 的 admission key |
| 当前 health projection 有 `not_started/due/running/healthy/interrupted/failed/blocked/inactive`；它是读侧 projection，不创建新的 Issue workflow status | `docs/workspace-issues-and-scheduling.md:297-317` | 这些状态不能直接当作 EF11 的 durable `WorkspaceAdmission` 或 UTA status |
| `processStarted` 只有 OS child 发出 `spawn` 后才为 true；spawn failure 有 typed `launchErrorCode` | `docs/workspace-issues-and-scheduling.md:327-332`；`src/workspaces/headless-task.ts:89-117` | 这是可复用的启动证据形状，但当前没有绑定到 EF11 `admissionId/reviewId` |
| 当前 headless task status 只有 `running | done | failed | interrupted`；task 记录带 `taskId`、稳定 `resumeId`、`processStarted`、`agentSessionId` 等 | `src/workspaces/headless-task-registry.ts:25,87-142` | 当前有完成/失败观察面，但不是 post-admission worker claim ADT |
| 当前 v1 headless liveness 是进程内的；Alice 重启时 `reconcile()` 把遗留 `running` 标成 `interrupted`，明确说 durable/detached run 是后续升级 | `src/workspaces/headless-task-registry.ts:10-14,187-199` | 当前实现不证明目标能够在 crash 后自动恢复同一 worker；只能作为 `Interrupted` 观察输入 |
| 当前 dispatch 先创建 durable headless task/session 记录，随后 fire-and-forget 启动子进程；完成时才写 `processStarted`、exit、output 和 `done/failed` | `src/workspaces/service.ts:1898-1977,2050-2099` | 真实的 commit-before-spawn 类窗口已经存在；目标文稿应明确其不确定性，不能把 admission commit 当作 child 已启动 |
| 当前 runs/logs 按 guide 保留而非静默裁剪；当前 owner guide 没有为 EF11 admission/worker 写出一个统一 retention TTL | `docs/workspace-issues-and-scheduling.md:416-426`；`src/workspaces/headless-task-registry.ts:300-371` | “保留”是当前产品语义，不是已定义的 Alice post-admission retention clock |
| Workspace lifecycle transition 是 durable、启动时 idempotent recovery；retired/purged Session 保留 provenance，不静默换 successor | `docs/workspace-lifecycle.md:52-86,108-137`；`docs/conversation-provenance.md:244-289` | 可复用“恢复必须保留原身份”的原则，但不等于 worker claim recovery 已定义 |
| Product Activity journal 明确不是任务队列、不能调度 worker；当前 Alice event bus 已退役 | `docs/event-system.md:1-31,33-63`；`event-flows.md:1396` | 不应以 activity listener 补 worker authority |
| `Guardian` 对一个 AliceProject 持有 whole-home writer lease；takeover 是项目级恢复 | `docs/alice-project.md:143-157,176-185` | Guardian/project lease 不能充当 EF11 worker claim lease |
| Connector queue 有 bounded claim lease、ack/release、TTL 检查和 lease expiry 重见队列 | `docs/connector-service.md:239-248` | 这是另一个 queue owner 的先例，不是 EF11 已有规则；不能跨上下文直接复用或声称 EF11 已具备 |

当前 owner guide 的现有重试语义也很明确：`Retry now` 是显式额外 turn，不移动 schedule marker；它不是“同一进程继续”，也不是无条件自动重启（`docs/workspace-issues-and-scheduling.md:334-345`）。因此目标补文应保留这个保守姿态：**在 recovery 中允许 query、observe、显式 retry，但不能把 retry 当 exactly-once 或自动恢复保证。**

## 2. 真正的最小缺口

当前目标文稿已经有三种身份：

1. UTA 的 `DecisionRequested/DecisionOutboxFrame/ReviewRequest`；
2. Alice 的 `WorkspaceAdmission`；
3. UTA 的 `ReviewReply` 和 expiry/reply CAS。

但 admission 之后，EF11 只有“worker ownership”这一责任名词和一个 `WorkerNotSpawned` diagnostic，缺少能正面消费 `executionRef` 的最小生命周期关系：

- 哪个 durable record 表示 **已接纳但尚未 claim**；
- claim 是否在 spawn 前提交，claim 的 owner/lease/epoch 是什么；
- `processStarted`/worker start evidence 怎样与 `admissionId + executionRef` 绑定；
- 启动回执丢失时，什么证据区分 `not started`、`started`、`unknown`；
- worker completion 与 reply transport / UTA reply acceptance 怎样分开；
- Alice owner 重启后怎样 query/observe/recover，而不是把 admission 当作可以盲重启的指令；
- request expiry 和 Alice worker/response retention 的关系；
- retention 到期时怎样留下可查询的终态/tombstone 或明确的 recovery obligation。

这不是缺少新的通用 workflow。`WorkspaceAdmission` 仍是接纳边界；只需在它之后增加一个 Alice-owned execution evidence relation。

## 3. 正面构造：一个足够小的 Alice execution 关系

### 3.1 关系定义

可在 EF11.2 `WorkspaceAdmission` 后增加一个目标关系（名称可按实现约定调整）：

```text
WorkspaceExecution<C> =
  | Unclaimed {
      admissionId,
      executionRef,
      admissionRevision
    }
  | Claimed {
      admissionId,
      executionRef,
      claimId,
      ownerEpoch,
      claimLeaseUntil
    }
  | Started {
      admissionId,
      executionRef,
      claimId,
      startEvidence
    }
  | Terminal {
      admissionId,
      executionRef,
      outcome: Completed | Failed,
      completionEvidence,
      replyRef
    }
  | Unknown {
      admissionId,
      executionRef,
      reason: ClaimLost | StartUnconfirmed | CompletionUnconfirmed,
      recoveryRequired
    }
```

这不是要求固定全局 worker 状态列表，而是本关系所需的最小区分：

- `Unclaimed`：`WorkspaceAdmission.Admitted` 已提交，尚未将 worker claim 交给某个 Alice owner；允许合法 claim。
- `Claimed`：Alice 已为该 `executionRef` 提交一次 claim，`claimLeaseUntil` 只表示这次恢复/启动责任的暂时 owner。lease 到期**不证明进程没有启动**，也不授权盲目再 spawn。
- `Started`：有与该 `executionRef` 关联的 process/worker start evidence。当前系统的 `processStarted=true` 可作为一种具体证据；目标并不强迫所有 native CLI 提供相同的进程语义。
- `Terminal`：Alice 已持久化 worker 完成或明确失败及其 completion evidence。`replyRef` 只关联回复传输，不把 Alice completion 当成 UTA 接受。
- `Unknown`：现有证据不足以安全选择“未启动”或“已启动”；必须进入 query/observe/recovery，不得以超时或 lease expiry 猜测 no-start。

若需要表示 retention 到期，不要删除 `Terminal`/`Unknown` 的责任记录。可采用一个独立的 compacted evidence 形状：保留 `admissionId`、`executionRef`、terminal/unknown outcome、payload/reply digest、expiry/retention reason 和 archival pointer。这里的 `retentionUntil` 是 Alice execution evidence 的 retention boundary，不是 UTA `expiresAt`、claim lease 或 approval TTL。

### 3.2 最小责任分层

| 事实/操作 | 所属 owner | 可证明什么 | 不可推断什么 | 合法恢复 |
|---|---|---|---|---|
| `DecisionOutboxFrame` 已提交/重投 | UTA | 一个稳定 request/review/frame 可再次交付 | Alice 已接纳或 worker 已启动 | 用同一 `outboxId + digest` 重投；先 query Alice |
| `WorkspaceAdmission.Admitted` | Alice | UTA frame 已在 Alice durable owner 中接纳，并分配稳定 executionRef | worker 已 spawn、已回复、UTA 已接受回复 | 以 `outboxId/reviewId` query，返回原 admission |
| `AdmissionAck` / delivery receipt | Alice↔UTA transport | admission receipt 已在边界返回，或 transport 到达该阶段 | worker 已启动或完成 | transport uncertain 时按同一 key query/replay |
| `WorkerExecution.Claimed` | Alice | 某 owner 正在承担该 execution 的 claim/恢复责任 | child 一定已启动 | lease 内 observe；lease 过期先 probe/query，不能直接新 spawn |
| `Started` / `processStarted` | Alice worker owner | 有启动证据及执行引用 | worker 已完成、回复已被 UTA 接受 | 观察同一 execution，不创建第二个执行 |
| `Terminal` | Alice worker owner | worker 结果/失败已持久化 | UTA 已接受对应 `ReviewReply` | 重新发送同一 reply key，或把 UTA rejection 作为终态 transport evidence |
| UTA `ReviewReply` accepted | UTA | Keep/Rearm/Revise/Discard/RequestSubmission 已在 UTA 控制版本中提交 | Alice worker 已完成，provider 已 Ack | 读取 control receipt/status；EF06 另行 prepare/approve/start |
| UTA `ReviewExpired` / stale reply | UTA | expiry 胜出，旧 reply 不再改变控制状态 | Alice 之前未运行或责任已消失 | Alice 保留 completion/late-reply evidence；不得用旧 reply 重新提交 |
| `DispatchStarted` / `Ack` / `Unknown` | UTA effect owner | 交易控制是否进入外部 effect 及其观察责任 | Alice admission/worker completion | 按 EF06–EF08 observation/recovery，不能由 Alice receipt 结案 |

这个表把两个容易混淆的责任分开：

- **UTA outbox 已送达**只解决“frame 到 Alice admission boundary 的交接”；
- **UTA 等待决定/已过期**只解决“该 reply 是否还能改变 UTA 控制状态”；
- 二者都不替代 Alice 对已接纳 worker 的 claim、completion、unknown 和 retention 责任。

### 3.3 正面时序

```mermaid
sequenceDiagram
  participant UO as UTA Outbox Writer
  participant A as Alice Admission Writer
  participant C as Alice Worker-Claim Owner
  participant W as Workspace Worker
  participant AR as Alice Execution/Reply Store
  participant UD as UTA Decision Writer

  UO->>A: DecisionOutboxFrame(outboxId, reviewId, digest)
  A->>A: Resolve Exact/Reconstructed identity
  A->>A: CAS(outboxId, reviewId, digest)
  A->>A: COMMIT WorkspaceAdmission.Admitted(executionRef)
  par delivery receipt
    A-->>UO: AdmissionAck(admissionId, executionRef)
    UO->>UO: record transport receipt or keep retryable
  and worker branch
    C->>C: claim CAS(admissionId, executionRef, ownerEpoch, lease)
    C->>C: COMMIT Claimed before spawn
    C->>W: spawn/resume(executionRef)
    alt start evidence observed
      W-->>AR: Started(executionRef, startEvidence)
      AR->>AR: COMMIT Started
      W-->>AR: completion(replyRef, outcome)
      AR->>AR: COMMIT Terminal
      AR->>UD: ReplyCommand(replyCommandKey, digest)
    else spawn error before process exists
      C->>AR: COMMIT Terminal(Failed, launch evidence)
    else crash/ack uncertain
      C->>AR: COMMIT Unknown(StartUnconfirmed)
      AR->>AR: query/probe/recover; no blind duplicate spawn
    end
  end
  UD->>UD: CAS(reply key, expected state, expiresAt)
  alt reply wins before expiry
    UD-->>AR: ReplyReceipt(accepted)
  else expiry wins
    UD-->>AR: StaleReply(ReviewExpired)
    AR->>AR: retain late-reply/completion evidence; no new submission
  end
```

这里的 claim lease 只覆盖 Alice 的 worker-control/recovery owner，不是进程 lease，也不是 UTA approval。`COMMIT Claimed before spawn` 使 crash 窗口可被查询；它不能证明 spawn 一定发生。`Started`、`Terminal` 和 `ReviewReply` 是三个不同的持久事实。

## 4. 关键顺序推导与合法分支

### 4.1 commit-before-spawn crash

**轨迹：** Alice 已 commit `WorkspaceAdmission.Admitted`，随后在 claim 前、claim commit 后或调用 spawn 前崩溃。

1. UTA 重投同一 outbox 时，Alice 先按 `outboxId/reviewId/digest` query；已有 admission 返回原 `admissionId/executionRef`，不能新建第二个 execution。
2. 如果 Alice 没有 `Claimed` 记录，恢复 owner 可以从 `Unclaimed` 合法取得 claim。
3. 如果已有 `Claimed` 但无 `Started`，不能由“没有 start ack”推出 no-start。先读取 owner epoch/lease、Alice run record、process/session registry 和可用的 start evidence。
4. 若查询给出明确 launch failure 且无 child/process evidence，可把该 execution 置为 `Terminal(Failed)`，允许当前产品已有的显式 Retry now 产生新的 execution attempt；不要求重启同一 task。
5. 若查询仍不能区分，进入 `Unknown(StartUnconfirmed)`/`RecoveryRequired`。lease expiry 只能释放恢复 owner，不会把 execution 自动改成 `Unclaimed` 并盲目 spawn。

因此 admission commit 不会静默丢掉责任，也不被误报为 worker started。它只保证 Alice 已接纳并保存了后继 execution reference。

### 4.2 worker 已启动但启动回执丢失

**轨迹：** child 已经被创建，Alice/transport 没收到 `Started` 或 `AdmissionReceipt`，或者 activity journal append 失败。

1. Product Activity/Inbox/worker log 不能反向成为 authority；先 query Alice execution store。当前 owner guide 也明确 activity journal 不是 dispatch authority（`docs/workspace-issues-and-scheduling.md:12-23`；`event-system.md:40-46`）。
2. 若 `Started`/`processStarted` 或 native `agentSessionId` 已持久化，按同一 `executionRef/taskId/sessionId` 观察该 worker；不得重新 spawn。
3. 若 worker 进程可被探测但 start record 未写入，写入/补录 `Started` 的 recovery evidence；若不能原子补录，保持 `Unknown` 并继续观察，不能把它改成 no-start。
4. 若明确 child 未创建且 claim 仍可安全结束，记录 typed launch failure；再次执行只能是显式、带新 execution reference 的 retry，不能声称原执行 exactly-once。
5. Admission receipt/UTA outbox ack 丢失时，只重试 receipt 或 query admission；receipt 丢失不回滚 admission，也不创建新的 worker。

`AdmissionAck` 丢失与 `Started` 丢失是两个独立故障。前者只影响 UTA 是否知道 Alice 已接纳；后者影响 Alice 是否知道 worker 的状态；两者均不能由另一方代替。

### 4.3 UTA expiry 先于迟到 reply

**轨迹：** Alice worker 已启动或正在运行；`expiresAt` 到达，UTA expiry writer 先 CAS 提交 `ReviewExpired`；之后 reply 才到。

1. UTA 以现有 expiry/reply CAS 提交 `ReviewExpired + frozen disposition`；迟到 `ReviewReply` 返回 `StaleReply/Expired`，不建立新的 submission，不复活旧 binding/approval（EF11.4，`event-flows.md:1524-1529`）。
2. Alice 必须保留 worker 的 `Terminal` 或 `Unknown` evidence，并记录 UTA rejection 的 reason；不能因为 UTA request TTL 已到就删除 Alice admission/worker responsibility。
3. 如果 expiry 时 worker 尚未 claim，Alice 可在能够读取 UTA current state 时阻止新的 worker claim，记录 `ExpiredBeforeStart`；如果 UTA 状态暂时不可查询，保持 `Unknown`/recovery，而不是假定 expired 或假定仍可回复。
4. 如果 expiry 时已有 claim/worker，expiry 不会倒写成 no-start，也不会把 worker completion 伪装成 UTA accepted。worker 可按 Alice worker policy 完成或被显式停止；其迟到 reply 只能成为可查询的 stale evidence。
5. Alice 对 UTA 的 reply transport 若只是网络未知，应以同一 `replyCommandKey + payloadDigest` query/retry；一旦 UTA 明确返回 `ReviewExpired`，不能把同一 reply 无限重试成新决定。

这条推导把“reply 不能再改变 UTA”与“worker responsibility 仍需结案”同时保留，避免 TTL 变成静默丢任务。

### 4.4 UTA 或 Alice owner 恢复

**UTA 恢复：**

- 从 durable outbox/review state 重放；`Pending/Retryable` 使用同一 outbox identity 重投；`AdmissionAck` 不确定时 query Alice，而不是生成新 request。
- `ReviewExpired` 是已提交控制事实，不因 UTA 重启回到 waiting；迟到 reply 仍 stale。
- `DispatchStarted/Unknown` 继续 EF06–EF12 observation/recovery；不能用 Alice delivery receipt 或 worker reply 直接结案。

**Alice 恢复：**

- 从 `WorkspaceAdmission` 和 `WorkspaceExecution` 恢复，不从 Activity journal 推导 authority。
- `Unclaimed` 可以 claim；`Claimed`/`Started` 先读取 owner epoch、lease、process/session 和 run record。
- 进程仍在则 attach/observe；明确已退出则按完成/失败 evidence 收敛；不能证明是否启动则保持 `Unknown`。
- 当前实现把旧 `running` 标为 `interrupted`（`headless-task-registry.ts:187-199`），这可以成为 recovery evidence，但不是目标文稿中“自动重启”的承诺。
- 显式 `Retry now` 可以建立新的 task/execution，保留旧 execution 的 provenance；不得覆盖旧 execution，也不得把新 worker 伪装成原 worker。精确 Session 不可用时遵守现有 provenance 规则：报告 unavailable，或明确 `Reconstructed` 新 Session；不静默替换历史 owner（`conversation-provenance.md:244-289`）。

### 4.5 retention 到期

当前 owner guide 只规定 run/log 保留而不静默裁剪（`workspace-issues-and-scheduling.md:416-426`）；主书只说 Keep retention、request validity、approval validity、delivery lease 分开（`uta-capability-runtime-design.md:982`）。因此这里是**post-admission retention 的真实缺口**，不是可以凭报告声称已有一个固定 TTL。

最小规则应是：

1. Alice admission、execution、reply/recovery evidence 至少保留到 worker 已有 terminal evidence、UTA reply transport 已得到 accepted/stale/explicitly-unavailable 的结果，且没有待处理的 recovery responsibility。
2. UTA `expiresAt` 只结束 UTA reply 的有效期；不启动 Alice record 的删除倒计时。claim lease 只结束一次 claim ownership；也不等于 retention。
3. 到达 retention boundary 时，如果责任已经 terminal，可 compact 成带完整 identity/digest/outcome/reason/causation/archival pointer 的不可变 tombstone；查询仍能回答“接纳过什么、执行到哪一步、回复为何未被 UTA 接受”。
4. 到期时仍是 `Unknown`、未确认启动、未确认完成或 reply transport 未知，不能直接删除。应延长 retention、移入显式 recovery/archive owner，或提交 `RetentionExpired/RecoveryRequired` tombstone；该状态必须可查询且带原因。
5. 删除 raw log（若未来允许）不得删除 admission/execution responsibility 的最小证据。归档或 compact 是存储策略，不是把责任改写成“未发生”。

## 5. 建议的最小补文（不改架构）

下面是可直接放入主书/EF11 的补文草案；本报告没有写回它们。

### 5.1 主书 §11.4：在 Alice 持久交接段落后补入

> `WorkspaceAdmission.Admitted` 只证明 Alice 已在自己的 durable owner 中接纳该 `outboxId/reviewId/digest` 并分配稳定 `executionRef`；它不证明 worker 已启动、已完成或 UTA 已接受回复。Admission commit 后，Alice 为同一 `admissionId + executionRef` 维护一个 execution evidence relation：先提交可查询的 worker claim（必要时带 owner epoch 与有限 claim lease），再尝试 spawn/resume；`Started` 必须有绑定到该 execution 的启动证据，完成必须有独立 completion evidence。claim lease 到期只释放恢复责任，不证明进程没有启动；不能区分 no-start 与 possible-start 时保留 `Unknown/RecoveryRequired`，不得盲目创建第二个 worker。receipt、worker start、worker completion 和 UTA `ReviewReply` receipt 是不同事实。

### 5.2 主书 §11.3/§11.4：expiry 与 retention 补入

> Request `expiresAt`、Alice worker claim lease、Alice execution retention boundary 和批准有效期分别由各自 owner 消费。UTA expiry 胜出时，迟到 reply 只能得到 `StaleReply/ReviewExpired`，不复活旧 binding 或建立新 submission；Alice 仍须保留已接纳 execution 的 completion/unknown/late-reply evidence。未开始的 execution 可以在确认 UTA expired 后停止新的 claim；已 claim/已启动的 execution 不因 expiry 被伪装成未发生。retention 到期只能在责任已 terminal 且跨界 receipt/reply evidence 已结案后 compact；未决或 Unknown 责任必须延长或转交显式 recovery/archive owner，不得静默删除。

### 5.3 EF11.2：`WorkspaceAdmission` 后增加一行关系

```text
| `WorkspaceExecution<C>` | `WorkspaceAdmission.Admitted` 的 execution slot | `Unclaimed{admissionId,executionRef}`；`Claimed{claimId,ownerEpoch,claimLeaseUntil}`；`Started{startEvidence}`；`Terminal{outcome,completionEvidence,replyRef}`；`Unknown{reason,recoveryRequired}`。每个变体都带 `admissionId + executionRef`；claim lease 不证明 no-start；terminal/unknown 不因 UTA expiry 自动删除 | Alice execution writer：claim 在 spawn 前提交；start、terminal、unknown/recovery 分别持久提交；receipt/Activity 不替代 execution state |
```

同时把现有 `DecisionDeliveryDiagnostic` 的 `WorkerNotSpawned` 解释为该关系的 projection/diagnostic，而不是唯一状态；它必须能指向 `admissionId + executionRef`。

### 5.4 EF11.4：在现有 9 条规则后追加四条

> **10. Admission 后的执行责任。** `Admitted` 是 Alice 的 durable handoff，不是 worker start/completion。Alice 对同一 `admissionId + executionRef` 只建立一个可查询 execution relation；claim 可重试，worker spawn 不作 exactly-once 承诺。`Started`、`Terminal` 与 `Unknown` 必须携带相应 evidence。
>
> **11. crash 与启动回执。** commit-before-spawn crash 恢复时先 query admission、claim、process/session 和 run evidence。明确 no-start 才可结束该 claim；started/possible-start 保持观察或 `Unknown/RecoveryRequired`。receipt/ack 丢失只触发同 key query/replay，不回滚 admission，不盲重启。
>
> **12. 到期与迟到回复。** UTA expiry 与 reply 继续使用已有 CAS；expiry 胜出时 late reply 返回 `StaleReply/ReviewExpired`。Alice 保留 execution completion/unknown 和 late-reply evidence；未 claim 的工作可在确认 expiry 后不再启动，已 claim/started 的工作不得被改写为未发生。
>
> **13. owner recovery 与 retention。** UTA replay outbox、Alice replay admission/execution，分别使用各自 owner。retention boundary 不等于 request expiry 或 claim lease；terminal record 可有审计性 compact，未决/Unknown record 必须延长或转交显式 recovery/archive owner，不能静默丢弃责任。

这些补文只把已有 `WorkspaceAdmission`、`DecisionOutboxFrame`、reply CAS 和当前 Alice 的 process evidence 连接起来；没有引入通用 workflow graph、新的交易批准层或 Alice 对 Broker 的所有权。

## 6. 不可证明的活性前提

即使加入上述关系，以下仍不能由抽象本身证明，必须作为实现/部署前提单独核验：

1. Alice admission/execution writer 的 commit 是原子的、耐久的，恢复时不会把已 commit 记录静默丢掉；
2. 能按 `admissionId + executionRef` 查询同一执行，且 process/session registry 不会把旧身份误配给另一个 worker；
3. owner epoch/claim lease 有可接受的时钟和 fencing 语义；lease expiry 不能被解释成进程已死亡；
4. native CLI/OS 能提供足够的 start/exit/process evidence。若只能得到 transport timeout，必须停在 `Unknown`；
5. UTA 与 Alice 最终能通过重试或 operator query 交换 outbox/admission/reply 状态。网络永久断开时，设计只能保留 pending/unknown/recovery evidence，不能保证活性；
6. UTA expiry 的观察在 Alice claim gate 可用时，才能安全阻止未开始 worker；状态查询失败不是 expiry 或 non-expiry 的证明；
7. Workspace catalog、resume registry、headless run record 和 archive/retention owner 都能保留 provenance。reconstructed worker 必须被标识为新 Session，而不是原 Session 的隐式延续；
8. UTA native provider 的 transaction/dispatch semantics 仍由 EF06–EF12 单独提供。Alice 的 `Admitted`、`Started` 或 `Completed` 永远不证明 provider Ack、fill、finality 或交易完成。

## 结论

当前稿件已经正确表达了 UTA request/outbox 的稳定身份、Alice admission 的 CAS/idempotency、reply/expiry 的竞争，以及 Alice/UTA 的 owner 分离。真实未表达关系不是“再加一个 idempotency key”或“缺少通用 workflow”，而是 admission 之后的 **Alice execution evidence**：claim-before-spawn、start evidence、completion/unknown、owner recovery 和 retention 结案如何沿同一 `executionRef` 连接。

最小补文应守住四个结论：

- UTA outbox 已送达 ≠ Alice worker 已启动；
- Alice admission 已提交 ≠ worker completion 或 UTA reply 已接受；
- request expiry ≠ 删除 Alice worker responsibility；
- claim lease/retention 到期 ≠ 可以把 possible-start 或 Unknown 静默改成 no-start。

在这些关系下，commit-before-spawn crash、启动回执丢失、expiry 先于迟到 reply、owner 重启和 retention 到期都能落入 query、replay、observe、Unknown 或显式 retry 分支，而不强迫任何通用工作流引擎，也不许诺进程 exactly-once。
