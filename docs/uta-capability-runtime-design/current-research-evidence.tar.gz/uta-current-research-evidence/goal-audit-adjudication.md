# UTA 目标审核：独立裁决附录

> 本附录供主代理归档和整合使用，不改写 `goal-audit.md`。它只裁决本轮回读最新主书与事件流后，哪些原审核意见应撤回、哪些应保留为实现义务，以及一个有限的生命周期时序压力测试如何收窄。

## 证据基线与判定口径

本附录以当前候选主书和 EF10 最新正文为准：

- 主书 §6.4 明确区分 NewsGroup 的组级消费与逐成员消费，并说明 Partial 下“至少一个”和“所有成员”是不同的业务函数语义（`docs/uta-capability-runtime-design.md:581-585`）。
- 主书 §10.5 已规定规则的精确适用性、`Intent/ReadFacts` 投影、writer-owned local state、完整 read-set、消费触点、同一纯 evaluator/等价版本化 precondition、冲突后重算与 reservation 释放（`docs/uta-capability-runtime-design.md:904-916`）。
- 主书 §11.1.1 已把同一组操作数与初态、普通进展、支持选择、修订目标、后继消费者和历史重建关系连起来；§11.2 已给出普通 `advance` 的三值结果、Partial 保留、支持充分性不变式和保守覆盖规则（`docs/uta-capability-runtime-design.md:930-972`）。
- 主书 §11.3 将 `CloseWithoutDispatch` 列为 disposition，并区分它与 `RequestDecision`、`SeekAuthorizedExecution`（`docs/uta-capability-runtime-design.md:974-986`）。
- EF03 已给 Candle 同 bar key 更新的声明式分流：有认证 replacement/revision 才是 `Correction`，独立观测可用新 identity 交付 `Data`，同 identity 改 payload 进入 reconciliation/明确失败，不隐式采用最后到达值（`docs/uta-capability-runtime-design/event-flows.md:400-405`）。
- EF10 已明确把普通 source 输入和 deferred 生命周期分开，并给出终点、expiry、owner retirement 与 Start 竞争的控制路径（`docs/uta-capability-runtime-design/event-flows.md:1176-1205`, `:1218-1264`, `:1284-1292`）。

这里仍区分三层：主书是否能表达关系；具体声明/实现是否履行契约；真实 Provider 或运行时是否已有证据。没有把“有了关系”升级成“已实现或已生产验证”。

## 五项撤回裁决

### 1. 撤回“Partial 必须增加公共 predicate-result ADT”

这不再是核心抽象缺口。`advance` 已有 `NoActivation | Candidate<Evidence> | Gap`，而 checkpoint `C` 可以保存 `Partial`、成员积累或未定状态。主书还明确写出：`NoActivation` 只表示本步不提出激活，不等于谓词为 false；`Gap` 只表示声明所需连续性或证据关系受损，不是所有业务未知的总称（`docs/uta-capability-runtime-design.md:952-960`）。

因此，业务函数自己的判定/不确定性可以进入它声明的 `C/E`，不需要 host 再发明一个全局 `Satisfied | False | Undetermined` 五分或同形 ADT。NewsGroup 的“至少存在一个匹配”和“所有成员匹配”本来就可以在同一 Partial 输入上有不同决定，核心不应硬编码统一结果（`docs/uta-capability-runtime-design.md:581-585`）。

仍保留的义务是：每个 P 必须说明 Partial/未定如何保存在 C/E、何时足以给出 Candidate、何时确实是 Gap，以及 writer 如何避免把未定压成 false 或 Gap。这是业务声明和实现履约项，不是缺少公共 ADT 导致的 host 关系不能构造。

### 2. 撤回“必须由核心自动验证任意业务函数的 support closure”

这不再是设计完成的阻断条件。主书已经要求 P 提供支持选择和已认证来源引用，并给出可检验的不变式：只改变所声称支持集合之外的事实，不应改变承诺的判断、证据和后继控制资格；组合消费者的支持还要沿前序支持延伸到仍负责任的 request/submission/attempt（`docs/uta-capability-runtime-design.md:937-940`, `:964-972`）。

该契约不能由 schema 机械地自动分析任意业务函数。候选设计允许声明者给出业务推导、保守来源范围或更窄的修订保证；无法证明且无法保守覆盖时，不接纳“可修订”的关系，已有责任则进入失效/恢复。这样已经表达了 host 的安全边界，而不是把任意函数的证明自动化假定为核心能力。

仍保留的义务是：具体 P 的支持集合必须可持久化、可查找、足以覆盖其承诺；实现不得只保存最终值引用；失效后的冻结、重建、请求决定和 recovery owner 必须可执行。上述是声明/实现责任，不应再写成“缺少自动 support-closure analyzer”。

### 3. 撤回“规则缺少公共最小五分 ADT”

这不再是核心抽象缺口。§10.5 已给出可检验的 product 关系：规则声明适用性、精确输入投影、writer-owned state、显式时间、typed issue 和消费触点；消费时必须读取当前 local state，重跑同一 evaluator 或核验覆盖全部依赖的等价 precondition；冲突后重新读取和决定；消费、reservation、必要 work/outbox 与 receipt 原子提交（`docs/uta-capability-runtime-design.md:904-916`）。

已有“占用 40、两个候选各要求 60、上限 100”的有限构造，足以说明完整 read-set、共享 conflict scope 和冲突重算如何拒绝第二项 reservation（`:908-910`）。不需要把所有规则强行投影到公共 `Applicable | NotApplicable | EvidenceInsufficient | Rejected | Passed` union；规则可用自己的 typed issue 和证据结构表达这些变体。

仍保留的义务是：每个规则确实声明完整 read-set/touch、版本和时间来源；同一 writer authority 管理本地 reservation；失败不发新的 job/grant/成功 receipt；终止释放前证明没有敞口或移交给持久 recovery owner（`:912-916`）。这属于规则实例和 writer 实现契约，不是需要新增全局 ADT 的理由。

### 4. 撤回“独立 NewsGroup 的成员映射是通用关系缺口”

这不再是核心关系不足。§6.4 已明确两条合法路径：Provider 可以只提供组级事实，业务函数消费组级契约；若调用者要逐成员消费，则该 Provider 必须声明成员 identity、selection、revision、coverage，并提供到 News 单元的合法读取或投影关系（`docs/uta-capability-runtime-design.md:581-585`）。缺少后者时，逐成员消费者得到 `Unavailable`/不能接纳，是声明边界，不是 host 无法构造 NewsGroup。

仍保留的义务是：接入具体独立 Provider 时，给出所选路径的 declaration slot 和至少一个合法消费实例；不能仅凭 `groupId` 或分类标签让调用者逐成员套用 News 谓词。对只承诺组级能力的 Provider，不应额外要求它伪造成员关系。

### 5. 撤回“Candle 同 identity 无 revision 必须由 host 规定唯一 conflict policy”

这不再是核心抽象缺口。EF03 已穷尽 leaf 可声明的语义：同一 bar key 后续更新只有在 leaf 能认证 replacement/revision 时才成为 `Correction`；若 leaf 只承诺独立观测，可以用新的 observation identity 交付 `Data` 并明确不替代旧值；复制同一 event identity 却改变 payload 是非法的；相同 identity 冲突进入 reconciliation 或明确失败政策，未声明可恢复策略就使该流失败，不能隐式选最后到达（`docs/uta-capability-runtime-design/event-flows.md:400-405`）。

因此，host 不应替所有 provider 选择 Data、Correction 或 reconciliation 的单一默认。具体 leaf 的声明必须穷尽其 identity/revision/conflict 语义；不能声明时安全结果是失败或不可用。这是 provider/实现证据义务，不是通用 Candle 抽象不可构造。

## 收窄后的有限生命周期压力测试

### 测试场景

保留一个真正有用的有限反例作为语义验收场景，而不是把它误写成新的伪造 predicate outcome：

1. D 注册“本交易时段截止前出现 crossing，否则关闭等待”。
2. 来源事实依次给出 96、98，均未 crossing；intent 仍未开始，仍有一个 live activation owner。
3. 随后到达声明可信的 market-close/end/barrier 或注册的激活 lifetime 终点。
4. 业务要求是不发送 activation intent，而是以 `CloseWithoutDispatch` 退休这次等待，并保存截止原因。

若没有独立的生命周期消费者，普通 `advance` 只有 `NoActivation | Candidate | Gap`，会产生两种错误诱因：把“截止且未命中”伪造成 Candidate，或把可信终点误报成 Gap；若永远保留 `NoActivation`，则无法表达业务要求的终止。这个反例检验的是 deferred 生命周期和普通 source advance 的边界，不要求引入 `NoMatch` Candidate 或新的全局结果 ADT。

### 当前应采用的收窄语义

- `FutureBoundary` 是本 epoch 允许消费的未来起点，不是 market-close 终点，也不是 expiry 的别名。终点由 D/S 声明的 activation lifetime、显式 Clock 事实、source completion 或 barrier 关系提供；子流 `Completed` 本身不自动结束组合 S。
- 同一 D 另行消费 expiry/可信终点事实与当前 C、control state。持续未命中到达截止时，根据冻结 disposition 选择 `SuspendControl`、`CloseWithoutDispatch` 或 `EscalateDecision`；不把终点塞进普通 `advance` 的 Candidate/Gap。
- 选择 Close 时，writer 必须在同一控制决定域核验 not-started、当前 epoch/version 与 live owner，然后原子提交 owner retirement、截止原因和未发送 control 的释放。若 Start 先提交，则不能再退休成未发送；应保留已开始的 attempt 与观察/recovery 责任。
- 本地 deadline 停止继续等待，不等于证明整个市场历史从未命中。到期关闭与“负命中证据”必须分开；request/reply expiry、approval expiry 和未命中等待的 lifecycle expiry 也是不同 clocks，不应等不存在的 ReviewRequest 过期来结束等待。

主书已写入上述边界（`docs/uta-capability-runtime-design.md:945-947`），EF10 也给出了 source-vs-control 分离、终点分支、writer retirement 和 Start 竞争的事件路径（`docs/uta-capability-runtime-design/event-flows.md:1180-1186`, `:1218-1264`, `:1284-1292`）。因此，这个压力测试在当前稿中已从“抽象缺口”收窄为每个具体 D/S 必须声明并由 writer 实现验证的生命周期义务。

## 归档结论

1. 上述五项不应再作为主书尚未能表达的核心关系；其对应内容已在最新正文中给出，剩余工作分别是业务声明、Provider 证据或运行时实现。
2. 市场截止场景应保留为有限时序压力测试，要求实现证明：终点不是普通 `advance` 结果、Close 不伪造 Candidate/Gap、未开始检查与 Start 竞争同域、组合终点不被子流完成偷换。
3. 本附录没有运行项目测试、build、lint 或 formatter，也没有把文档关系升级为生产运行时证据。它只为 `GoalAudit` 对原报告的五项撤回和生命周期反例收窄提供独立裁决记录。
