# UTA 研究资料可读性核验报告

## 结论

本轮对指定的 7 份资料完成了实际 Markdown 解析、HTML 渲染、相对链接/锚点核对、表格结构核对，以及主书和事件流册中全部 Mermaid 代码块的真实 Mermaid parser 解析。

- Markdown：7/7 文件可由仓库已有 `marked` 解析并渲染。
- Mermaid：20/20 图解析通过；0 个语法失败。
- 本地相对链接/锚点：748 个通过；0 个失败。
- 外部链接：1 个按范围跳过（RFC 8785，不作网络可达性核验）。
- 归档生产者链接：1 个按约定延后，不计为通过，也不计为普通失败：`current-research.md` → `current-research-evidence.tar.gz`。核验时该归档尚未由 EvidencePack 生成，`present=false`；Main/EvidencePack 必须在归档生成后独立确认其可解包、内容和形式求解复现。本报告不宣称该文件存在。
- Markdown 表格：68 个表格全部被 parser 识别，所有数据行列数与表头一致；原始分隔行数与 parser 表格数逐文件完全匹配。

未编辑 repo 正文、未运行项目 build/lint/format/test，未启动产品、服务或 Broker。

## 核验输入与快照

输入文件：

1. `AGENTS.md`
2. `docs/README.md`
3. `docs/uta-capability-runtime-design.md`
4. `docs/uta-capability-runtime-design/event-flows.md`
5. `docs/uta-capability-runtime-design/current-research.md`
6. `docs/uta-capability-runtime-design/research-practice.md`
7. `plans/uta-core-design-research.md`

核验时 SHA-256（完整清单：`local://uta-current-research/input-hashes.stdout`）：

```text
3d0eeb93687274c87f84f9210dcfea9e4aea532498f7eeb7a320941f522d6814  AGENTS.md
f9d6adc31ec53b7a0472f486942f386366d01ce1c8142df8ba0a945373a9a968  docs/README.md
a755a95a158195f281c0aabf9e043a8be287e5363a9a38522c199c8c8eeebe66  docs/uta-capability-runtime-design.md
892293a3537314b791a252267f298e5e420a40344c94bef619355262b7eb28c0  docs/uta-capability-runtime-design/event-flows.md
f5473c30504dbd2fe35f41463b4c01f803f750b9c43440bfc9a3d895a2e27214  docs/uta-capability-runtime-design/current-research.md
16f2e24bda9b9ef0e963c40ded3099cf006da91ef73bfc32cd1a3fc0f0c4f88b  docs/uta-capability-runtime-design/research-practice.md
553b76857eafd792a041471fe57df5fa85ab55a9fc8ad5290d075a24e09e0cdb  plans/uta-core-design-research.md
```

## 工具来源与版本

### Markdown

- 仓库 UI 依赖声明：`ui/package.json` 声明 `marked: ^15.0.12`。
- 实际解析命令使用仓库当前已安装依赖：`marked 15.0.12`，Node `v26.8.1`。
- 解析/渲染输出：`local://uta-current-research/marked15.stdout`；stderr 为空：`local://uta-current-research/marked15.stderr`。
- 另一个综合核验 helper 使用已有研究资料处理环境中的 `marked 16.4.2`，仅用于 walk-token、链接/锚点、表格和渲染汇总；其版本和结果记录在 `readability-output-final-captured/readability-results.json`。两次 Markdown 解析均通过。

### Mermaid

- 发现并复用了已有研究资料处理环境，不安装依赖：`mermaid 11.17.2` + `jsdom`。
- 临时 parser helper：`local://uta-current-research/readability-check.mjs`。
- parser 使用 `mermaid.parse()`，不是代码块计数或正则近似；设置 `securityLevel: 'strict'`，以 JSDOM 提供 DOM 环境。
- 汇总 stdout：`local://uta-current-research/readability-command.stdout`；stderr 为空：`local://uta-current-research/readability-command.stderr`。
- 详细 JSON：`local://uta-current-research/readability-output-final-captured/readability-results.json`。

## 实际命令

### 综合 Markdown/Mermaid/链接/锚点/表格核验

以下是产生本报告结果的完整命令（`--tooling-root` 指向已存在的本地研究资料处理环境；没有 `npm install`）：

```sh
node /Users/mouriya/.omp/agent/sessions/-Ext-code-OpenAlice/2026-09-09T18-12-17-943Z_01a0875e-e397-7422-a544-66cff9c83d67/local/uta-current-research/readability-check.mjs \
  --tooling-root /Users/mouriya/.omp/agent/sessions/-Ext-code-OpenAlice/2026-09-07T06-52-53-135Z_01a07aa4-260f-77eb-b35f-f53e9f2d78ed/local/uta-construction-research/document-tooling \
  /Users/mouriya/Ext/code/OpenAlice \
  /Users/mouriya/.omp/agent/sessions/-Ext-code-OpenAlice/2026-09-09T18-12-17-943Z_01a0875e-e397-7422-a544-66cff9c83d67/local/uta-current-research/readability-output-final-captured \
  AGENTS.md docs/README.md docs/uta-capability-runtime-design.md \
  docs/uta-capability-runtime-design/event-flows.md \
  docs/uta-capability-runtime-design/current-research.md \
  docs/uta-capability-runtime-design/research-practice.md \
  plans/uta-core-design-research.md
```

当前会话实际调用的 helper 路径是 `local://uta-current-research/readability-check.mjs`（其绝对路径由 local workspace 映射）；上面命令中的 parser、输入和输出参数与实际调用相同。实际 stdout/stderr 已落盘，避免只保留聊天摘要。

### 仓库 declared Markdown parser 的独立复核

```sh
node /Users/mouriya/.omp/agent/sessions/-Ext-code-OpenAlice/2026-09-09T18-12-17-943Z_01a0875e-e397-7422-a544-66cff9c83d67/local/uta-current-research/marked15-check.mjs
```

实际执行使用其绝对 local workspace 路径，输出为 `local://uta-current-research/marked15.stdout`，stderr 为空。

### 原始表格分隔行复核

```sh
node /Users/mouriya/.omp/agent/sessions/-Ext-code-OpenAlice/2026-09-09T18-12-17-943Z_01a0875e-e397-7422-a544-66cff9c83d67/local/uta-current-research/table-structure-check.mjs
```

实际输出：`local://uta-current-research/table-structure.stdout`，stderr 为空：`local://uta-current-research/table-structure.stderr`。

## Mermaid 逐图结果

全部 20 个图均为 `passed`：

| 文件 | 行号 | parser 类型 | 结果 |
|---|---:|---|---|
| `docs/uta-capability-runtime-design.md` | 232 | `flowchart-v2` | passed |
| 同上 | 744 | `sequence` | passed |
| 同上 | 839 | `stateDiagram` | passed |
| 同上 | 1014 | `sequence` | passed |
| 同上 | 1389 | `flowchart-v2` | passed |
| `docs/uta-capability-runtime-design/event-flows.md` | 122 | `sequence` | passed |
| 同上 | 196 | `sequence` | passed |
| 同上 | 264 | `sequence` | passed |
| 同上 | 341 | `sequence` | passed |
| 同上 | 469 | `sequence` | passed |
| 同上 | 581 | `sequence` | passed |
| 同上 | 744 | `sequence` | passed |
| 同上 | 836 | `sequence` | passed |
| 同上 | 921 | `sequence` | passed |
| 同上 | 1044 | `sequence` | passed |
| 同上 | 1209 | `sequence` | passed |
| 同上 | 1422 | `sequence` | passed |
| 同上 | 1585 | `sequence` | passed |
| 同上 | 1725 | `sequence` | passed |
| 同上 | 1843 | `sequence` | passed |

按类型计数：`sequence` 17、`flowchart-v2` 2、`stateDiagram` 1。其余 5 份输入没有 Mermaid 代码块，未把“无图”误报为失败。

## 链接与锚点结果

综合 helper 采用以下规则：

- Markdown 链接由 `marked.lexer()`/`walkTokens()` 提取。
- `AGENTS.md` 和 `docs/README.md` 的 Obsidian wikilink 也被提取；它们按仓库根解析，而不是误按当前文件目录拼接。
- 相对目标先做 `access()`；片段优先匹配显式 HTML `id`，同时匹配 GitHub 风格 heading slug。
- 非 Markdown 目标的 `#Lx`/`#Lx-Ly` 片段按目标实际行数核对；普通 Markdown heading 片段按 heading slug/显式 id 核对。

| 文件 | 链接总数 | 通过 | 外部跳过 | 延后归档 | 失败 |
|---|---:|---:|---:|---:|---:|
| `AGENTS.md` | 17 | 17 | 0 | 0 | 0 |
| `docs/README.md` | 79 | 79 | 0 | 0 | 0 |
| `docs/uta-capability-runtime-design.md` | 31 | 30 | 1 | 0 | 0 |
| `docs/uta-capability-runtime-design/event-flows.md` | 597 | 597 | 0 | 0 | 0 |
| `docs/uta-capability-runtime-design/current-research.md` | 4 | 3 | 0 | 1 | 0 |
| `docs/uta-capability-runtime-design/research-practice.md` | 8 | 8 | 0 | 0 | 0 |
| `plans/uta-core-design-research.md` | 14 | 14 | 0 | 0 | 0 |
| **合计** | **750** | **748** | **1** | **1** | **0** |

非本地/延后项：

1. `docs/uta-capability-runtime-design.md` → `https://www.rfc-editor.org/rfc/rfc8785`：外部 RFC，按本地链接核验范围跳过；没有执行网络可达性或内容核验。
2. `docs/uta-capability-runtime-design/current-research.md` → `current-research-evidence.tar.gz`：这是 EvidencePack 约定在本报告之后生成的单一归档链接。核验时目标不存在（`present=false`），所以没有把它当作普通现存文件通过。Main/EvidencePack 需要在归档生成后独立执行解包、清单/内容核对及文中 `z3 -smt2 -T:60 obligations.smt2` 复现。

没有发现失败的本地相对路径、显式锚点、heading 锚点或非 Markdown 行号范围。

## 表格结果

`marked` 识别到 68 个表格；每个表格的每一行均与表头列数一致：

| 文件 | 表格数 | 数据行数 | 不齐列表格 |
|---|---:|---:|---:|
| `AGENTS.md` | 3 | 19 | 0 |
| `docs/README.md` | 1 | 30 | 0 |
| `docs/uta-capability-runtime-design.md` | 29 | 194 | 0 |
| `docs/uta-capability-runtime-design/event-flows.md` | 29 | 339 | 0 |
| `docs/uta-capability-runtime-design/current-research.md` | 2 | 19 | 0 |
| `docs/uta-capability-runtime-design/research-practice.md` | 2 | 7 | 0 |
| `plans/uta-core-design-research.md` | 2 | 15 | 0 |
| **合计** | **68** | **623** | **0** |

原始分隔行与 parser token 的逐文件复核输出（7 行均为 `MATCH`）在 `local://uta-current-research/table-structure.stdout`。这一步用于避免“parser 没识别出的疑似表格”被静默遗漏。

## HTML 渲染输出

仓库 `marked 15.0.12` 对 7 份输入均完成实际 `marked.parse()`；输出字节数见 `local://uta-current-research/marked15.stdout`。综合 helper 也写出了 HTML 快照到：

`local://uta-current-research/readability-output-final-captured/`

其中包含 7 个 `.html` 文件和 `readability-results.json`。HTML 生成仅证明 parser 可消费文本，不证明 GitHub/产品 CSS 下的视觉布局或 Mermaid 客户端渲染效果。

## 未验证与边界

- 未访问 RFC 8785 等外部 URL。
- `current-research-evidence.tar.gz` 在核验时按 EvidencePack 生产顺序尚不存在；本报告不把它标成通过。归档生成后必须由 Main/EvidencePack 完成独立验收。
- Mermaid 使用真实 parser 语法解析，不做浏览器视觉截图，也不证明图表达的业务语义正确。
- Markdown 检查覆盖 parser、HTML 生成、相对路径、显式 `id`、heading slug、wikilink 和表格列数；不替代 GitHub renderer、Obsidian renderer、项目产品渲染或架构/业务验收。
- 源码行号字符串、引用论断和归档内历史原文未被当作本轮设计正确性的证明；本报告只负责可消费性。
