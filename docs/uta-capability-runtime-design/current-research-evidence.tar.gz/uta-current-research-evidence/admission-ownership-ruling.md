# EF11 Admission ownership：裁决附录

> 本附录追加到 `admission-ownership.md` 之后，保留主报告原文身份，不回改历史报告。它记录 Main 对 post-admission responsibility 的三点收窄，并给出用于整合后的有限轨迹。它不重复主书 §11.1.1 的 waiting expiry / 普通 `advance` / FutureBoundary 关系，也不试图证明全局 liveness。

## A. 三项收窄裁决

### A.1 Worker state 与 ReplyState 是两个独立关系

主报告中的 `Terminal{..., replyRef}` 只能作为一种可能关联，不能作为公共必要字段。正确的最小关系是两个独立 owner-owned products：

```text
WorkerExecutionState<C> =
  | Unclaimed{admissionId, executionRef}
  | Claimed{admissionId, executionRef, claimId, launchOwnerEpoch, claimLeaseUntil}
  | Started{admissionId, executionRef, startEvidence}
  | Running{admissionId, executionRef, startEvidence}
  | Completed{admissionId, executionRef, completionEvidence}
  | Failed{admissionId, executionRef, failureEvidence}
  | Unknown{admissionId, executionRef, reason, recoveryRequired}

ReplyState<C> =
  | NotSent{requestId, reviewId, executionRef}
  | TransportPending{replyCommandKey, payloadDigest}
  | Accepted{replyCommandKey, receipt}
  | Stale{replyCommandKey, reason: ReviewExpired | RetiredReview | StaleRevision}
  | Rejected{replyCommandKey, reason}
  | TransportUnknown{replyCommandKey, recoveryRequired}
```

这只是本跨界关系所需的区分，不是要求全局统一 worker/status 枚举。

必须保留以下可达情况：

- `ReplyState=Accepted` 可以在 worker 仍为 `Running` 时发生：worker 已产生可提交的 reply frame，但进程尚未退出；reply acceptance 不等待 process exit。
- `WorkerExecutionState=Failed` 可以没有任何 reply：例如 spawn 明确失败、worker 在产生 reply 前退出，或 Alice 只取得 launch/exit failure evidence。
- `WorkerExecutionState=Completed` 不等于 `ReplyState=Accepted`：completion 只说明 Alice 对 worker lifecycle 的结案，reply 仍可能 pending、transport unknown、stale 或 rejected。
- `ReplyState=Stale` 不改写 Worker state；迟到 reply 因 UTA request expiry 被拒绝时，worker 仍可能 running、completed、failed 或 unknown。

因此，`completion before reply`、`reply before completion`、`failed without reply` 都是合法轨迹。Alice 的 worker completion、Alice→UTA reply transport、UTA decision CAS 不应串成一条必须按顺序闭合的成功链。

### A.2 Claim lease 到期转交 recovery owner，不释放责任

`claimLeaseUntil` 只限制当前 launch/recovery owner 的操作资格。lease 到期后的安全结论是：

1. 原 claim owner 不再拥有继续推进该 claim 的权威；
2. durable execution responsibility 仍存在；
3. responsibility 进入 `RecoveryRequired`，并由新的 `recoveryOwnerEpoch` / fenced recovery claim 承担；
4. 原 launch 可能尚未结束、可能已活着、也可能在迟到执行 spawn；lease 到期不等于进程死亡或 no-start。

因此不能把 lease expiration 描述为“释放责任、回到 `Unclaimed`”。旧 claim 的 launch invocation 必须被查询、停止或 fencing；在旧 owner 仍可能执行的情况下，新的 owner 不能并行盲目 spawn。同一个 execution responsibility 可以转移 owner，但不能被静默丢弃或复制成两个无关联 worker。

### A.3 重新启动必须同时满足 no-start 与 no-late-spawn

恢复 owner 只有在以下两个条件都得到当前可接受证据时，才可把未完成的 launch 重新推进为新的 claim/spawn：

- **positive no-start**：有正面证据证明该 launch 未创建 child/worker，或取得了明确的 pre-spawn launch failure；
- **no-late-spawn / fencing**：旧 launch invocation 已被取消，或由能阻止旧 OS/runtime 路径迟到 spawn 的 fencing 隔离；仅禁止旧 Alice owner 再写状态不足。

仅仅“当前进程列表里暂时没有看到 child”、`AdmissionReceipt` 丢失、`processStarted` 尚未写入或 claim lease 已到期，都不足以满足第二个条件。若 positive no-start 或 fencing 任一缺失，状态必须保持 `Unknown/RecoveryRequired`，由 recovery owner query/observe/显式处置；不能自动当作 no-start 重启。

这条前提仍不承诺进程 exactly-once。它只禁止在旧 launch 仍有迟到 spawn 可能时制造一个未被 fencing 的第二个 worker。

## B. 有限轨迹：用于检查顺序和责任，不是全局 liveness 证明

下列轨迹只覆盖有限反例类别。每条都给出 durable evidence、合法下一步和禁止的推断。

### B.1 Admission commit 后 crash，旧 launch 已 fencing，可安全重试

| 步骤 | durable/可验证事实 | 合法推进 | 禁止推断 |
|---|---|---|---|
| 1 | Alice CAS 后提交 `WorkspaceAdmission.Admitted{admissionId,executionRef}` | UTA 以 `outboxId/reviewId/digest` query/retry，复用原 admission | worker 已启动或 reply 已接受 |
| 2 | Alice 提交 `Claimed{claimId,launchOwnerEpoch}`，spawn 尚未开始；进程崩溃 | recovery owner 读取 claim、取得新 epoch，确认旧 launch owner 已取消/fenced | lease expiry 自动证明 no-start |
| 3 | 取得明确 pre-spawn failure/no-start 且旧 owner 已 fencing | 对原 execution responsibility 建立新的 recovery claim；可按实现选择同一 execution 的新 claim revision 或显式新 execution attempt，同时保留旧 claim | 进程 exactly-once；旧 attempt 可以被删除 |
| 4 | 新 worker 启动证据写入 `Started/Running` | 继续观察；reply 由独立 ReplyState 处理 | `Started` 等于完成或交易批准 |

### B.2 启动后 ack 丢失，lease 到期，worker 仍可观察

| 步骤 | durable/可验证事实 | 合法推进 | 禁止推断 |
|---|---|---|---|
| 1 | `Admitted` 与 `Claimed` 已提交；transport ack/`Started` 回执丢失 | UTA query admission；Alice recovery owner query executionRef/task/session/process evidence | 没有 ack 就等于 no-start |
| 2 | 旧 claim lease 到期；旧 worker/process 或 native session 可观察 | 把责任转给新 recovery owner epoch，补录/确认 `Started/Running`，不重新 spawn | lease expiry 释放执行责任 |
| 3 | worker 产生 reply，UTA CAS 成功；worker 仍未退出 | `ReplyState=Accepted`，`WorkerExecutionState=Running` 并存；继续等待独立 completion/failed evidence | reply accepted 等于 worker completed |
| 4 | worker 随后失败 | `WorkerExecutionState=Failed`，保留已 accepted reply；两条记录各自结案 | failed 必须抹掉已 accepted reply，或回滚 UTA decision |

### B.3 Worker failed before reply

| 步骤 | durable/可验证事实 | 合法推进 | 禁止推断 |
|---|---|---|---|
| 1 | claim 已提交，明确 child 启动后异常退出，未产生 reply frame | `WorkerExecutionState=Failed{failureEvidence}`；`ReplyState=NotSent` 或不建立 reply record | failed 需要伪造一个空 reply |
| 2 | 当前产品允许显式 Retry now，旧 launch owner 已结束/fenced | 新 execution attempt 使用新的 task/execution identity，保留旧失败记录与 provenance | 自动无限重启同一 task；旧失败被覆盖 |
| 3 | launch/exit 证据不完整，无法排除 possible-start | `Unknown/RecoveryRequired`，先 observe/query | 以 exit timeout 当 no-start |

### B.4 UTA expiry 先胜，迟到 reply 到达

| 步骤 | durable/可验证事实 | 合法推进 | 禁止推断 |
|---|---|---|---|
| 1 | Alice worker running；UTA expiry writer 以既有 CAS 提交 `ReviewExpired` | UTA 对迟到 `replyCommandKey/digest` 返回 `Stale/ReviewExpired` | 旧 reply 可以复活 request 或创建新 submission |
| 2 | Alice 收到 stale receipt；worker 可能仍 running | `ReplyState=Stale`；Worker state 继续 independent observe/complete/fail | stale reply 证明 worker 未运行 |
| 3 | worker 随后完成，或在产生 reply 后退出 | 保留 completion/failure evidence 与 late-reply relation；不把 worker 责任删除 | UTA expiry 删除 Alice admission/执行记录 |
| 4 | UTA reply transport 只是网络未知而非明确 stale | 以相同 `replyCommandKey + payloadDigest` query/retry；待 UTA 明确结论 | 网络 timeout 直接当 expiry |

### B.5 Claim lease 到期但旧 launch 未 fencing

| 步骤 | durable/可验证事实 | 合法推进 | 禁止推断 |
|---|---|---|---|
| 1 | `Claimed` lease 到期，进程列表暂时没有 child，旧 owner 的 spawn call 可能仍在网络/事件循环中 | 转 `RecoveryRequired`；先取消/隔离旧 owner，等待可证明的 fencing/no-late-spawn 边界 | 当前未看到 child 就是 no-start |
| 2 | fencing 或旧 owner termination 无法证明 | 继续 query/observe，责任由 recovery owner 保留；不可重新 spawn | lease expiry 自动清除 claim |
| 3 | 旧 owner 已 fencing，随后取得 positive no-start | 才允许新的 recovery claim/显式 retry；旧 claim 记录保留为历史证据 | 新 worker 可以无条件复用旧 task identity |

## C. 与Main整合后的核验结论

已回读 Main 整合后的主书 §11.4 与 EF11 post-admission 段落；下列含义已经在整合正文中成立：

1. `WorkspaceAdmission.Admitted` 只分配稳定 `executionRef`；不代表 worker start、completion 或 UTA reply acceptance。
2. Alice worker lifecycle 与 reply transport/UTA decision state 是两个独立 ADT/product；不得要求 `Terminal` 含 `replyRef`，不得要求 process exit 先于 reply。
3. `Claimed` 的 lease 到期把**操作资格**转移给 recovery owner；execution responsibility 仍然存在。旧 launch 仍可能活着或迟到 spawn，故 recovery owner 需要 owner epoch/fencing。
4. 重新 spawn 的安全前提同时是 positive no-start 与 no-late-spawn/fenced old owner；process list 暂无 child、ack 丢失、lease expiry 单独均不够。
5. UTA expiry 只裁决 reply 是否还能改变 UTA control state；它不裁决 Alice worker 是否曾启动，也不删除 Alice execution responsibility。
6. 有限轨迹只证明每个证据下的合法 query/observe/recovery/retry 分支；不证明所有 worker 最终活跃、最终完成、网络最终恢复或 native provider 最终可观测。

这些修正不增加新的全局 workflow engine，不把 Alice 变成 UTA authority，也不引入进程 exactly-once 承诺。它们只避免三类错误等价：`reply = completion`、`lease expiry = no-start`、`no child observed now = old launch fenced`。

## D. 本次回读位置与有限结论

- 主书 `docs/uta-capability-runtime-design.md:1004-1010`：已表达 execution evidence、claim-before-spawn、lease 到 recovery owner、不把 lease/marker/暂空进程列表当作 no-start、旧 launch 不能迟到启动、worker/reply 两条独立轴、expiry/retention 分离。
- EF11 `docs/uta-capability-runtime-design/event-flows.md:1413`：execution/reply table 不要求 Terminal 含 reply；`:1453-1472`：admission 后 claim、启动成功/失败/Unknown 及 worker 未退出即可发 reply；`:1526-1547`：owner 分离、重复/延迟、规则 10/11 的 no-start + no-late-spawn/fencing、显式 retry policy、expiry/retention 责任。
- 有限轨迹结论：B.1 只有在“正面 no-start + 旧 launch 已被实际 fencing、不能迟到 spawn”同时成立时才可重试；B.2 保留可能已启动的执行并把 claim 责任转给 recovery owner；B.3 允许 failed without reply；B.4 允许 reply accepted 与 worker running 并存，expiry 胜出后 late reply stale；B.5 在旧 launch 未被 fencing 时保持 Unknown/RecoveryRequired。

这些是对 post-admission 责任和安全分支的有限核验，不是 UTA 整体实现完成、跨 owner liveness 定理或 native provider 结果证明。
