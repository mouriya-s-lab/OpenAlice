import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
const requireUi = createRequire(resolve('ui/package.json'));
const { marked } = requireUi('marked');
const files = ['AGENTS.md','docs/README.md','docs/uta-capability-runtime-design.md','docs/uta-capability-runtime-design/event-flows.md','docs/uta-capability-runtime-design/current-research.md','docs/uta-capability-runtime-design/research-practice.md','plans/uta-core-design-research.md'];
for (const file of files) {
  const text = await readFile(file, 'utf8');
  const lines = text.split(/\n/);
  const raw = [];
  for (let index = 1; index < lines.length; index += 1) {
    if (/^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[index]) && lines[index - 1].trim()) raw.push(index + 1);
  }
  const tokenCount = marked.lexer(text).filter((token) => token.type === 'table').length;
  console.log(`${file}\trawDelimiterRows=${raw.length}\tmarkedTables=${tokenCount}\t${raw.length === tokenCount ? 'MATCH' : `MISMATCH\tlines=${raw.join(',')}`}`);
}
