# UTA 目标场景审核

## 审核范围与判定口径

本报告只读了 `AGENTS.md`、`plans/uta-core-design-research.md`、当前候选主书 `docs/uta-capability-runtime-design.md` 的目标/组合/控制/激活/事件语义章节，以及事件流册 `docs/uta-capability-runtime-design/event-flows.md`。在收到本轮新增禁令的通知后，追加回读了 `AGENTS.md:167-177` 与 `docs/uta-capability-runtime-design/current-research.md:54-79`，用于核对研究方法和证据边界。没有重做承接册的全量扫描，也没有运行 build、lint、项目测试或 formatter；仓库没有被改动。

本轮不把“类型能够承载”直接记为“业务承诺已经成立”。每项按三层区分：

- **设计表达**：候选模型是否能表达目标及其消费者、顺序、失败和身份关联。
- **尝试/实验解析**：归档中的独立 Node/Python/SQLite/NDJSON 样例实际执行了什么；它不是当前 UTA 运行时或真实 Provider 证据。
- **责任释放**：目标满足、尝试结果已解析、reservation/恢复责任已结清或已原子移交，三者是否都被保留；缺任何一项都不能把流程写成完成。

总体判断：候选主书和事件流册已经能正面表达列出的目标主干，且大多数危险捷径已有明确拒绝语义；但全目标验收尚未收敛。主要剩余问题不是再增加同义类型，而是若干跨组件关联尚未给出足够可检验的构造：异构补偿等级如何聚合、Partial 下纯规则的结果 ADT、外部组能力如何取得成员关系、共享规则状态的最小原子读写集、Alice admission 后 worker 不生效时的责任归属、修订支持闭包的完整性，以及真实 Provider 的 finality/identity/replay/atomicity 证据。
## 新增证据禁令是否阻挡本轮合法研究

`AGENTS.md:167-177` 的七条禁令约束的是论证方式和证据升级，不是暂停主线的门槛。本报告实际按以下方式执行：

1. 不用订单流程、模块或数据库清单替换抽象；每个目标都追踪操作数、构造关系、事件消费者、时间/失败和责任释放。
2. 没有把预先分组当答案。虽然用户明确给出了目标维度，本报告仍分别找正面构造和反例；没有把报告完成状态或意见数量当结论。
3. 没有把静态目录/事件表当动态语义；各节均检查消费顺序、修订、Gap、终态、重启和 owner。
4. 没有使用 14 条 EF 流、99 个 legacy section 或样例次数作验收计数；这些只作为定位材料和证据范围。
5. 没有以归档样例、阶段检查点或“未发现反例”结束全目标研究；报告明确列出仍需收敛的设计关系。
6. 没有按章节、行数、图数判断契约完整；缺口判断针对被遗漏的前提、失败或责任后果。
7. 没有把历史任务自动升级为当前授权，也没有重做历史待办；本轮只按当前用户目标审核候选主书和事件流。历史归档仅用于区分其原始执行范围。

这些禁令**没有阻挡任何本轮合法研究或必要可行性验证**。`AGENTS.md:171-177` 明确仍允许业务实例、候选修改、不同模型思考、并行研究、旧映射和必要的抽象验证；它们只禁止把这些材料误升为抽象完成、生产证据或新的授权。当前 `current-research.md:57-79` 也把本轮继续的完整表达链、目标/业务时间审核和形式验证并列为主线，并明确原生 Provider 取证与实现义务不能反过来掩盖 host 关系缺口。本报告未启动代码测试，因此不需要为禁令另行添加规则测试，也没有因历史支线完成而暂停主线。

## 1. Provider 与订单差异

### 正面构造与事件消费

主书把扩展单位定义为绑定 schema、成功/失败、资源、权限、交付和解释实现的完整 capability association，而不是动作字符串或 `unknown` 函数（`docs/uta-capability-runtime-design.md:188-209`）。Provider 业务词汇开放，内核控制选择闭合；因此新增 `postOnly`、原生保护条款或独有条款不要求改全局 action union（`:269-283`）。Order 的 quantity/notional、pricing、session/TIF、OCA/bracket 等由积、和及 Provider extension 组合，原生 SDK 对象留在解释器边界（`:550-559`）。

实际消费链是：声明/证书先进入 catalog（`event-flows.md:97-118`），动态定义只能以完整 `BoundDocument + slot certification + provider/capability/revision/schema digest` 进入可调用目录；受控路径再由 EF06 的 `IntentAccepted → PrepareWork → PlanPrepared → Approve → ReservationHeld → DispatchPlanned` 消费同一个 Recipe 的槽位（`event-flows.md:692-724`），EF07 以同一个 binding、plan、attempt 和历史解释身份进入 Start/observe/recovery（`event-flows.md:795-816`）。这确实能容纳“外观相同但订单语义不同”的 Provider，而不会把每个 Provider 塞进核心 switch。

### 关键前提与失效边界

1. 每个受控叶子必须同时声明 intent、prepared、ack、observation、failure、recovery、compensation、criterion 和 native lookup 的关联；只有输入 schema 而没有尝试解析/观察槽位的 Provider 不能被安全地提升成完整受控能力。
2. 动态后继还必须有适用于所选定义的输入构造关系，不能只认证输出 schema（主书 `:439-459`）。
3. Provider 的原生幂等、订单完整查询、finality、撤单/替换、组原子性和补偿等级不是 host 类型推导的结果；主书明确要求按 Provider、版本、账户环境取证（`:1163-1167`）。
4. 以两个 Provider 接受同形输入为例：A 的 `postOnly + extended` 组合可能在其契约中拒绝，B 可能合法接受；若仅共享一个 order DTO/ack，就会丢失拒绝阶段和原生条款。当前候选通过各自 Recipe 槽位保留差异，故表达上可分叉；但尚没有一个真实异构 A/B 的完整受控执行证据。
5. 没有稳定 provider order/execution identity 的来源只能停在 unresolved/unknown/reconciliation，不能合成 fill 或把 `Ack` 当成交（`event-flows.md:545-575`）。这是正确的保守边界，不是待补的默认值。

### 真实缺口与实现义务

- **证据缺口（Provider/实现义务）**：候选关系没有证明任意 Provider 都能满足完整 Recipe。要进入实现验收，必须对至少一个订单参数差异明显的真实 Provider 证明声明加载、动态输入构造、私有 grant、native observation、失败和历史恢复闭环；没有证据时应暴露 `Unavailable/RecoveryRequired`，不能扩展 host 特判。
- **边界已定位而非新核心缺口**：旧 `IBroker` 宽接口、旧 dispatcher 和无关联执行回调的事实已被主书标为迁移输入（`:217-245`）；不应把“尚未迁移”改写成模型已完成或要求把旧 facade 继续当权威。

## 2. 统一 Candle 扩展的 Pull/Push

### 正面构造与事件消费

Candle 的共同语义保留来源、InstrumentRef、interval、时间范围、OHLC、volume 单位、session/timezone/adjustment、finality 和 revision；`vwap`、tradeCount、原生时间戳和 native event identity 作为声明的精确 extension，不塞进任意 metadata（主书 `:561-565`）。`richCandle.schema` 同时进入 Pull 页的 `items` 与 Push 帧的 `value`，Pull/Push 仅在 coverage/lifecycle/resource 语义上分层（`:1062-1077`）。

EF02 的有限 Pull 以 selected binding、scope、as-of、window、limit/cursor 和 coverage 交付；EF03 的 Push 以同一 item schema 交付 `Started/Data/Correction/Retraction/Gap/SnapshotEnd/ItemFailure` 及唯一 attachment terminal（`event-flows.md:168-191`, `:302-337`）。因此 IBKR 的 `historicalDataEnd` 可成为 `SnapshotEnd`，但 `keepUpToDate=true` 时不能成为持续订阅的 `Completed`；后续 `historicalDataUpdate` 只有在 leaf 声明 correction/revision 语义时才能成为 `Correction`（`:400-405`）。EF04 再以 operator binding/lineage 投影到过滤、窗口或 join，不将富扩展值投影成不带 coverage/finality 的裸 Candle（`:420-539`）。

### 关键前提与失效边界

1. Provider 必须声明 extension、item/failure/lifecycle、source identity、generation、coverage 和 revision；扩展字段的存在不能自动产生 correction、replay 或 finality。
2. Pull 的 `Complete` 只在声明的有限范围/barrier 完成时成立；空数组、无 cursor 或收到 `SnapshotEnd` 都不是充分证据。
3. Push 的共享资源必须声明 Shared/Exclusive、attachment owner、cancel/release 和 reconnect/gap 政策。一个订阅者取消不能关闭其他订阅者仍拥有的共享连接（`event-flows.md:306-337`, `:407-414`）。
4. 无 provider native sequence/replay 时只能保留 adapter-local transport evidence；断连产生 Gap/Partial/Unavailable，不能由 timestamp 或 receivedAt 补出顺序。
5. 欲声称 1:1 透明投影，除了值的总投影，还需保持 control-kind、顺序、coverage、finality、终态、修订目标、资源释放和来源 lineage；主书明确说值投影本身不足（`:1332-1355`）。

### 真实缺口与实现义务

- **设计缺口**：同一 bar identity 的后续更新在没有声明 correction/revision 时被写成“新的 `Data`/unknown conflict”（`event-flows.md:400-405`），但当前候选没有给出这个冲突的穷尽 ADT/选择政策：是允许同 identity 多版本 Data、转 `ReconciliationRequired`，还是直接结束该 leaf。该处必须在 lifecycle/declaration 中选择可观察政策，否则不同实现会产生不同的下游修订语义。
- **证据缺口（实现/Provider 义务）**：样例只证明进程内 scoped stream 和有限扩展；主书明确未证明 foreign Push、credit/replay、buffer overflow、共享释放及完整 filter/window/join（`:1218-1224`, `:1442-1451`）。IBKR callback 证据也不等于目标 UTA 已暴露 history/news leaf；CCXT 当前只有有限 Pull（`event-flows.md:400-405`）。

## 3. NewsGroup 与数据组合

### 正面构造与事件消费

News 保留 source、publication/observation time、内容引用、event identity、correction/retraction（主书 `:573-575`）；NewsGroup 是有身份、成员/选择语义、as-of/revision/coverage 的集合，可由多个 News Query 组合，也可由独立 Provider 提供，但不能由 group membership 推出交易原子性（`:576-585`）。

EF04 以显式 operator binding 构造 merge/window/join：输入 binding、scope、key、failure/coverage/terminal/late policy 和 operator revision 均保留，源事件不被覆盖，派生事件有独立 identity/lineage（`event-flows.md:420-465`）。两个新闻源的一个失败可在声明的 partial profile 中成为失败成员，另一个继续；processing deadline 只能形成带缺口的 Partial，不能伪造 source finality；窗口仍开放时 late/correction 形成新 revision，invocation 终止后不再向该 invocation 发修订（`event-flows.md:444-452`）。`dedupKey` 只在 source/feed 内去重；不同 feed 的相同标题/正文不自动合并，`seq` 也不是 publication-time 全序（`:525-539`）。

这组构造还明确能消费不完全数据：例如两取三判据已有两个可信匹配时可 Candidate；只有一个匹配而其余未到达时应保留 Partial/未定，而不是假定 Gap、false 或 Complete（主书 `:920-939`）。一个“至少一个匹配”函数和“所有成员匹配”函数在同一 Partial 输入上的结果可以不同，这是业务函数语义，不由核心硬编码。

### 关键前提与失效边界

1. 每个 child 必须有 source/member identity、coverage、terminal 和失败分类；未声明可恢复的 child terminal `Failed` 不能偷换成 `ItemFailure` 或默认最佳努力（`event-flows.md:426-442`, `:532-539`）。
2. Window 必须声明 watermark/barrier 或明确的 processing deadline；receivedAt、本地 now、数组位置和 chunk 顺序都不能证明完整性。
3. Cross-source canonicalization、News member 选择、时间关系和修订传播必须是 operator 的显式 binding；文本相同或 groupId 相同不是身份映射。
4. correction target 缺失时只能 reconciliation/unavailable；不能原地修改旧 projection 或伪造从未发出的 DerivedCorrection。
5. 如果独立 Provider 只承诺组级事实，调用者只能消费组级契约；逐成员谓词需要额外的成员身份/选择、revision、coverage 和合法 News 投影关系（主书 `:581`）。

### 真实缺口与实现义务

- **设计缺口**：NewsGroup 的 Partial 消费有正面语义，但没有一个明确的 predicate-result ADT 把“已决定为满足/不满足”“证据不足仍未定”“来源 Gap/Unavailable”分开。当前 `NoActivation` 已被定义为“不提出激活，不等于 predicate false”（主书 `:927`），但普通数据组合的纯函数输出及其进入 deferred checkpoint 的承接仍主要是散文。建议后续设计固定一个与业务函数绑定的判定结果/不确定性关联，不把所有未决压成 `NoActivation` 或 `Gap`。
- **关系缺口（独立 Provider）**：`groupId → members` 的合法投影、成员修订和缺成员策略只被列为必要前提，没有正面实例或可认证的 declaration slot。若目标只消费 group-level fact，这不是问题；若目标要逐条 News 谓词，则该 Provider 必须补成员关系证据，否则只能提供组级能力。
- **证据缺口（旧 RSS）**：现有 RSS 是 timer/poll + JSONL ingest，单 feed 失败继续且重复 GUID/link 内容变化不产生 correction；主书已经正确把它限制为 Partial/非可靠 correction，不应把旧 collector 的 callback 当 Push/replay 证据（主书 `:575-585`；`event-flows.md:400-405`）。

## 4. 纯规则与共享本地状态

### 正面构造与事件消费

主书保留纯 `decide(state, command, facts, now)` 与 `evolve(state, event)`：纯决定只能返回候选事件/工作或拒绝，不能读 SDK、全局时钟、Promise 或修改共享 guard；时间、价格、余额、权限和原生观察先在边界形成带来源事实（主书 `:669-679`）。同一原子决定以 `evolve` 产生推测状态，再由单一 writer 复核版本、授权和失效条件，原子提交事件、投影、reservation、outbox 与 receipt。

旧 `CooldownGuard` 在 check 中修改 Map、后续 guard 拒绝仍泄漏状态的行为被用作反例；候选要求把规则适用性、精确 read-facts 投影、writer-owned local state、显式时间、typed issue 和消费触点绑在同一业务关联（`:677`, `:877-881`）。EF06 的 PrepareWorker 在 writer 外读 Provider facts 并运行纯 compiler/guards，writer 在 Approval 时按当前 local state 重算 guard 或完整等价 read-set，再原子消费共享 reservation；guard reject 不创建新 reservation/job（`event-flows.md:696-724`, `:782-791`）。EF10 的 predicate 同样以纯 `advance(Checkpoint, SourceFact, FutureBoundary)` 推进有界状态，非命中也可持久化，防止“只保存命中”破坏边沿语义（主书 `:920-939`；`event-flows.md:1158-1272`）。

### 关键前提与失效边界

1. 规则的全部可变本地状态必须成为 writer 可读、可比较、可原子消费的持久产品；不能藏在闭包、全局 Map 或进程内 Layer。
2. 规则的消费时机是业务政策：批准时消费与 `DispatchStarted` 时消费都可合法，但保留窗口、释放、重启和失败行为必须分别声明。
3. 通过证据不是已占额度；共享额度的 reservation 必须和决定在同一控制写入域中提交。并发订单不能各自读到同一余额后重复占用。
4. 远端事实仍在 writer 外取得，writer 只能复核声明的来源、freshness、generation、版本和失效条件；本地 CAS 不承诺远端原子性。
5. 前一规则的候选状态必须只在最终 writer commit 后成为权威；后续规则拒绝不能留下前一规则的隐藏消费。

### 真实缺口与实现义务

- **设计缺口**：文稿规定“typed issue”“适用性”“通过证据”和消费触点，但还没有给出规则最小关联的可检验 ADT/product，例如 `Applicable | NotApplicable | EvidenceInsufficient | Rejected | Passed` 如何携带 state delta、read-set、消费点和 release policy。若只按文字实现，很容易恢复旧 mutable guard 或把缺事实当“不适用”。
- **实现义务**：跨账户/共享额度的锁范围、锁顺序、SQLite isolation/CAS 冲突和重启恢复需要具体 writer 规范；主书只规定“明确范围与一致锁顺序”（`:877-881`），尚不足以证明死锁、重复 reservation 和 crash 后责任释放均已处理。
- **时间责任**：`now`、deadline、approval expiry、worker lease、watermark 和 history retention 已被区分，但每个时钟的 owner、可信来源和提交失败动作需要实现阶段固定；不得用一个本地时间值替代全部时钟。

## 5. 事务控制与异构补偿

### 正面构造与事件消费

受控效果通过私有 `RecipeAssociation` 进入 `withTransaction`，公开能力只提供意图接纳、receipt/control status，不暴露 native start；prepare、start、observe、criterion、resolution、compensation 各有精确槽位和失败（主书 `:482-509`, `:770-812`）。单一 writer 在一个事务中验证 command key/版本/授权/reservation、运行纯决定、追加事件/投影/work/outbox 并在 commit 后返回 receipt（`:717-760`）。

批次不是 `JoinedOrder` 或通用 workflow：每个 child 保留自己的 binding、prepared、ack、observation、criterion、resolution、attempt、exposure 和 recovery owner，coordinator 只消费 `ChildProgress` product。`IndependentBatch`、`AllOrCompensate`、`VenueNativeAtomic` 是不同政策；后者无 exact Provider/账户/操作 conformance 时返回 `ConformanceRequired/Unavailable`，而不是把“同一批 request”当原子（`:855-875`；`event-flows.md:999-1024`）。补偿是新 Recipe，有自己的 approval、DispatchStarted、Unknown、observation 和 reservation release；`Exact/StateRestoring/Economic/None` 不互换，原成交与费用不被抹掉。

EF09 的事件消费把成员的 criterion、attempt resolution、ExposureEvidence、reservation disposition 和 recovery responsibility 组成多轴 `ChildProgress`，再由纯 `advanceGroup` 产生 group 控制候选（`event-flows.md:1011-1024`）。A 部分成交而 B started Unknown 时，B 不是零，AllOrCompensate 必须保留恢复责任，不能直接反向下单；只有实际敞口、政策允许等级和充分证据共同满足时才建立补偿 work（`:1146-1154`）。

### 关键前提与失效边界

1. 每个成员的业务目标、尝试解析、敞口和责任必须分开；criterion 满足不能替代 attempt resolution。
2. AllOrCompensate 必须在接纳时冻结成员集合、失败条件、允许补偿等级和释放责任；`None` 在要求自动补偿时拒绝。
3. 组协调只保证本地控制顺序和政策，不保证跨 Provider 远端 ACID；VenueNativeAtomic 需要 exact native evidence。
4. compensation plan 只能消费已观察敞口和未决尝试，且补偿本身可能拒绝、失败或 Unknown；确认前不得释放原 exposure lock。
5. known rejection 与 Unknown 不同；前者可按政策继续，后者只能 observe/recovery，不能 catch continuation 偷换成“无效果”。

### 真实缺口与实现义务

- **设计缺口（本轮最重要之一）**：异构成员的补偿等级如何聚合没有形式化。主书/EF09 通常用一个 group `compensation grade`（主书 `:857-865`；`event-flows.md:1005-1009`），但没有规定成员向量如 `A=Exact, B=Economic` 对 `AllOrCompensate(StateRestoring)` 的 admissibility、组结案和残余风险如何判定。不能由最弱等级、最强等级或字符串比较猜出业务承诺；需要 per-member grade、group acceptance predicate、未决敞口产品和释放规则的显式关联。
- **责任缺口**：`CompensationProgress`/`GroupSatisfied` 已区分状态，但没有足够精确地定义“补偿完成后原 child attempt 的 reservation、exposure lock 与 recovery owner 何时分别释放”。建议继续保持多轴结果，并为每个 grade 指定不可逆历史、经济残余和责任移交条件。
- **Provider 证据义务**：真实 native atomicity、订单/成交 finality、组请求去重、补偿逆操作和费用/滑点只能由具体 Provider 取证；样例和 host writer 不得替代这些证据（主书 `:1218-1224`, `:1442-1451`）。

## 6. 外部延后激活 → Alice 交接 → 原意图执行

### 正面构造与事件消费

`DeferredInvocation` 绑定尚未 `DispatchStarted` 的 `IntentRevision`、唯一 activation owner、source set、纯 predicate、checkpoint/evidence、future boundary、expiry、frozen disposition 和 decision channel（主书 `:895-918`）。`advance` 的结果严格区分 `NoActivation`、`Candidate<Evidence>` 和 `Gap`；初始化/未足够 quorum 不等于 false，Gap 不能自动命中（`:920-939`）。

命中后，UTA writer 原子提交 checkpoint、选中 evidence、`DecisionRequested`、`ReviewRequest` 与稳定 outbox；EF11 从已提交请求开始，不重算 predicate，不创建 dispatch。Alice 用 `Exact` 或带来源的 `Reconstructed` 解析 Workspace/Session，先提交自己的 `WorkspaceAdmission.Admitted`，再独立 spawn worker/返回 transport receipt；无法解析则保留 outbox，不生成 worker（`event-flows.md:1368-1395`, `:1398-1501`）。

Agent 的 `Keep/Rearm/Revise/Discard/RequestSubmission` 由 UTA writer 以 request、revision、epoch、principal、expiry CAS 消费。`RequestSubmission` 只建立原意图的内部 control handle，随后 EF06 重新取得真实准备事实、检查当前 approver/plan/依据，再按普通 approval/Start；不再次 `SubmitIntent`，不把激活事实或回复文字当价格、余额、权限或批准（主书 `:941-1000`；`event-flows.md:1503-1513`）。

### 关键前提与失效边界

1. 原意图 revision 必须仍是未开始且只拥有一个 live activation owner；rearm retirement、新 epoch、new future boundary 和 checkpoint 初始化应同一 writer 事务完成。
2. predicate 必须声明每命中、false→true、持续窗口等算法，并声明足够支持修订目标的证据关系；有限 checkpoint 不能丢弃仍被历史 submission/attempt 引用的支持。
3. UTA outbox 与 Alice admission 是两个 durable owner，没有跨边界事务；每一侧只能依赖稳定 identity/digest/idempotency，不得以 UI/transport 顺序作授权。
4. `Keep` 保留可查询 suspended handle，不取消原生工作或隐式持有账户锁；`Rearm` 不重消费旧命中；`Discard` 只适用于未发送意图；已 Started/Unknown 只能 observe/recovery。
5. 发送前的 Start 必须在同一控制域检查仍有效的 activation basis；Start commit 后即使 correction 到达也不能承诺物理 native call 已被撤回。

### 真实缺口与实现义务

- **跨上下文责任缺口**：Alice 已 `Admitted`、但 worker 未 spawn、spawn 后 transport receipt 丢失，或 UTA review 随后 expiry 的情况下，文稿有 `WorkerNotSpawned`/Pending/Retryable 诊断，却没有穷尽“谁继续负责 admission、何时重试/退休、已 admission 但未有 worker 时是否可重新交付”的 liveness/retention 规则（`event-flows.md:1391-1395`, `:1503-1513`）。这不影响“先 durable admission 后 spawn”的安全顺序，但影响责任是否真正结案；需要 Alice owner 与 UTA outbox owner 的交接/超时协议。
- **实现缺口**：主书明确当前代码没有 review outbox→Alice durable admission、deferred checkpoint writer、predicate schema、correction lineage、response CAS（`event-flows.md:1287-1291`）。这些不是可留给“以后再决定”的新业务语义，而是已经决定的实现义务。
- **证据边界**：独立控制样例只验证有限 deferred-control 规律，不包含真实 Alice 会话交付（主书 `:1181-1195`）。不能把样例中 Keep/Rearm/RequestSubmission 的成功解析当成产品交接已实现。

## 7. 身份、权限、目录修订与恢复

### 正面构造与事件消费

主书把 ProviderDefinition/Instance、SourceBinding/ConnectionGeneration、AccountScope/SubAccount、InstrumentRef、Principal/Authorizer/Recipient、IntentRevision/CommandKey/AttemptId、SourceEvent/EvidenceRevision 分开，禁止因编码均为字符串而互换（主书 `:251-267`）。能力声明、当前可用和调用授权也是三件事；目录 revision 只影响新调用，已 Started 的历史观察按完整旧 binding/解释器身份恢复（`:329-333`）。

EF01 先验证 pack/slot/digest，再原子发布完整 catalog snapshot；EF02 先 scope discovery，再独立取得 permission witness，再按 exact binding/generation 发起 Pull，连接可读不自动生成交易权限（`event-flows.md:97-161`, `:168-250`）。EF12 将 Alice config revision、SecretRef、UTA apply、connection generation、catalog revision、policy revision 和 Guardian process owner 分开；secret 在 writer 外解引用，writer 只提交 typed `RuntimeBindingEvidence`，旧 generation 只能做 provenance，历史观察使用新授权连接和旧 codec/lookup（`:1519-1653`）。EF14 在迁移前 fence old writer，损坏/缺 identity/缺 dispatch evidence 的旧记录 quarantine，不因缺 `DispatchStarted` 就推断 no-start（`:1772-1915`）。

### 关键前提与失效边界

1. Permission witness 必须绑定 principal、capability、scope、catalog/policy revision 并在实际叶子边界复核；`provide` 消解服务依赖但不改变 P（主书 `:368-379`）。
2. catalog/generation/config revision 只在各自 owner 的提交点生效；transport connected、HTTP 200、health probe 或 Mock init 不能升级为 catalog ready、交易可写或历史恢复证明。
3. source/provider 没有原生 ID 时，只能标记 adapter-assigned identity；本地 identity 不证明远端去重或没有漏发。历史 binding 找不到时应 `RecoveryRequired`，不能用当前 catalog/compiler/salt 重建旧请求。
4. Instrument 搜索命中、公共数据来源、账户 Scope 和可交易权限互不替代；来源消失时不能从 UTA fallback 到 vendor，不能由显示 symbol 拼成跨源身份（主书 `:226-230`, `:567-571`）。
5. 双 owner/restore clone/old writer 未 fence 时必须 `RestoreQuarantine/CutoverBlocked`，不能复制 UUID/seq 后直接 Ready（`event-flows.md:1902-1915`）。

### 真实缺口与实现义务

- **设计/业务关系缺口**：跨 Provider Instrument identity mapping 只被要求“显式且有证据”，没有规定 mapping 的证据类型、版本、冲突/撤销和对后继 Order/Candle join 的最小契约（主书 `:569-571`）。若目标涉及跨源合并或交易，该关系必须独立设计；不能让统一 symbol 代替它。
- **恢复证据义务**：历史 resolver 何时可用新 generation 观察旧 attempt、何时只能 `RecoveryRequired`，依赖 provider native lookup、scope continuity、identity 和账户环境证据。主机已规定“不能重发/不能悄悄 reprepare”，但不能代替 Provider 证明完整 absence、跨重连身份和 finality（主书 `:1163-1167`）。
- **实现缺口**：目标 config/secret owner、catalog、generation 和 migration 都是规格，EF12/EF14 明确当前只读对照和时序，尚未成为运行中的 owner/commit protocol（`event-flows.md:1519-1653`, `:1772-1900`）。

## 8. correction、Keep/rearm 与 Start 异常顺序

### 已表达的顺序与责任分离

主书 11.5 给出了四个决定性的 commit 顺序：

1. correction 先于 reply：旧 request 依据失效，reply stale/conflict，不建立 submission；
2. reply 先于 correction、prepare 未提交：handle 继承原依据，但修订 fence 后迟到 `RecordPrepared` 不可执行；
3. prepare/approval 先于 correction、Start 未提交：Start 在同一域拒绝旧 job，不发 grant；
4. Start 先于 correction：attempt 已存在，修订只能追加失效因果与观察/恢复责任，不能退回未开始，也不能承诺物理 send 已被撤回（主书 `:993-1000`；事件流 `event-flows.md:1274-1285`）。

同样的区分覆盖金融异常：fill 先于 ack 时先记录 observation，late ack 只补事实；criterion 已满足但 channel loss 时保留目标结果并继续 attempt recovery；Start commit 后 grant 丢失只能 observe/recover，查询记录不能生成第二 grant（主书 `:847-853`；`event-flows.md:795-880`）。EF08/EF09 又规定 cancel 的 `NoFurtherWorking` 不等于 flat exposure，部分成交、费用、原始 quantity 和未知敞口均保留（`event-flows.md:884-995`）。

Keep/Rearm/Revise/Discard/RequestSubmission 也已分开：Keep 是 suspended handle；Rearm 是新 epoch/boundary；Revise 是新 intent revision/reprepare；Discard 只退休未发送意图；RequestSubmission 是原意图内部控制后继，均不能由 UI 文本或 receipt 互换（主书 `:941-957`）。reservation 只有 conclusive no-effect、合法 terminal 或 recovery-owner handoff 才能释放（`event-flows.md:672-679`）。

### 失效边界与有区分力的反例

- `false@10 → Gap → true@12` 不证明跨越阈值；首个高值最多重建 baseline，不能自动产生 crossing。若把它当 Candidate，模型会把传输缺口错误地升级为授权。
- 96、98、101 的 crossing 若选中证据包含 98/101 与连续性；事后将 98 correction 为 101，当前 checkpoint 仍可能只有 101，但历史 crossing 的控制依据已经失效。若持久存储只留最后值，无法知道是否应 fence 已产生的 request/submission。
- Start 前已满足目标状态不等于该 attempt 已产生效果；Start 后满足目标也不等于 attempt 已解析。两项必须同时留在状态 product 中。
- Alice admission 已提交但 reply/transport 丢失时，重新 delivery 应 query admission，而不是启动第二个 agent；反之 admission 已提交而 UTA request expiry 胜出，迟到 reply 只能 stale，不能复活旧批准。

### 真实缺口与实现义务

- **设计/实现缺口（本轮最关键之一）**：P “支持选择”要求覆盖所有会改变承诺的依据，且可保守多冻结，但没有规定如何验证 support closure 的完备性；主书也承认类型和摘要不能证明业务函数的支持充分性（`:935-939`）。需要显式支持图/依赖记录、修订影响分类和缺失证据的 fail-closed policy，否则 correction 可能漏 fence 某个旧后继。
- **责任/liveness 缺口**：Keep retention、request expiry、approval expiry、delivery lease、worker lease、history retention 已被正确分成不同 clocks，但每个到期的失败方、保留期限耗尽后的责任接收者和 outbox/admission 清理顺序仍未穷尽（主书 `:955-957`；事件流 `:1264-1272`）。不能用任意一个 timeout 释放其他责任。
- **跨 writer 限制**：UTA correction/response CAS 与 Alice admission 各自可原子，但二者不构成一个跨进程事务；因此可证明的是“每个边界不重复、迟到响应不复活旧 revision”，不能证明端到端零丢失或 exactly-once worker。该限制必须进入实现验收和用户可见状态，不应被“稳定 requestKey”扩大解释。

## 实验身份、历史执行与停止条件检查

主书第15章把验证归档明确标为独立、非生产的从属证据：Node/Python/SQLite 样例证明受限 schema、foreign Pull、writer commit-before-grant、no-blind-resend 和有限 deferred control；同一章明确未验证完整 Controlled、真实签名/密封存储、补偿/成交/敞口恢复、并发、真实权限、foreign Push、Alice 持久接纳（`docs/uta-capability-runtime-design.md:1171-1224`）。第16章同样把事件流归档限定为有限 NDJSON/merge 和声明派生反例，并在 `:1442-1451` 明说 EF01–EF14 仍是目标动态语义，当前没有真实安装、native Push、真实 FX/账户账、完整批准/补偿/激活、Alice admission、config/secret apply 或 migration 实现。

因此，本轮文字**没有把这些归档执行直接冒称为当前 UTA/Provider 生产执行**；“实际结果”应解析为隔离样例的 attempt evidence，而不是目标系统 runtime evidence。仍需防止两个误读：

- 事件流册拥有 EF01–EF14、旧承接 99 section 的关联以及多次“完整时序”标题，只说明设计覆盖和查漏，不能作为目标完整实现的计数证明；
- 计划把小范围研究标为已完成，但总体验收、方法整合和停止条件仍未勾完（`plans/uta-core-design-research.md:25-45`, `:63-79`）。计划本身还明令阶段总结、提交推送和局部负面评审不能停手（`:67`, `:79`）。本报告发现的上述关系缺口和责任缺口足以说明不能以本轮局部样例或阶段检查点收口。

## 尚未调查范围

1. 未重做 `legacy-accommodation.md`/`legacy-bindings.md` 的承接册逐项扫描；本轮只使用主书和事件册已经给出的旧行为锚点。
2. 未对任一真实 Provider、账户、版本或权限环境取证；因此没有结论可升级为 native idempotency、complete absence、cross-reconnect identity、finality、replay、native group atomicity 或 compensation grade。
3. 未检查目标新接口的实际 TypeScript/SQLite/foreign-process 实现，因为本轮授权是抽象设计研究，且计划明确当前目标接口尚未迁移。
4. 未验证 Alice 的真实 Workspace admission、exact/reconstructed resume、worker-not-spawned recovery、delivery lease 与跨进程 retry；这正是第6节列出的交接责任缺口。
5. 未验证真实 FX/账户快照、order sync、Mock/live evidence、配置/SecretRef apply、migration cutover 和恢复后的 presentation projection。

## 结论

当前候选设计可以继续作为主书候选：它已经把 Provider 差异、同一 Candle 值的 Pull/Push 双生命周期、NewsGroup/数据组合、纯规则与 writer 状态、受控交易与补偿、延后激活/Alice 交接、身份/权限/目录/恢复以及 correction/Keep/rearm/Start 的主要边界表达出来。不能作出的更强结论是“全部目标已经完成”或“归档样例已证明生产可交易”。在 Main 继续整合前，至少应先收敛本报告标出的七个关系：Partial 纯规则结果、独立 group 成员映射、Candle identity conflict policy、规则状态最小 ADT、异构 compensation grade 聚合、Alice admission 后 orphan responsibility、correction support closure；其余真实 Provider 与运行时证据则应单列为实现/环境验收，不用它们掩盖 host 设计关系尚未定义的部分。
