# UTA 当前候选设计连接调查

## 调查边界

本报告只读核对当前候选稿 `docs/uta-capability-runtime-design.md` 的 §§8–13、§16，以及同目录 `event-flows.md` 中 EF06–EF12 与数据激活、Agent 决策、受控发送/恢复有关的章节。没有读取初版 `uta-effect-runtime-architecture.md`，没有编辑仓库，也没有运行 build、lint、formatter、test 或样例。

`docs/uta-capability-runtime-design/research-practice.md:83-99` 将本轮范围限定为：共同声明、值消费、Close 的局部构造已经存在，下一步沿真实消费关系连接数据激活、Agent 决策与受控恢复；局部未发现矛盾不能宣称全书完成。

下文区分：

- **观察**：候选稿或事件流册明确写出的函数、事件、状态、owner 与提交条件。
- **正面推导**：在文档已给前提下能直接推出的关系。
- **尚待构造**：已有关系之间还没有用一个有限轨迹或函数构造把跨边界竞态完整推出；这不是把“尚未实现”改写成“契约不存在”。

## 1. 已有函数与静态/动态关系

### 1.1 数据与交付

Pull 返回有限 data、范围、as-of、coverage 和 continuation；`Complete` 只针对声明范围成立，空数组不是无仓位/无订单证据。Push 的数据帧可复用 Unit，但控制帧区分 `Started | Data | Correction | Retraction | Gap | SnapshotEnd | ItemFailure` 与 `Completed | Failed | Cancelled`。订阅 owner 负责 Scope 与释放；普通行情不写交易 WAL，只为持久控制保存选中的证据和必要 checkpoint（候选稿:592-623）。

### 1.2 纯决定、状态演进与持久边界

`decide(state, command, facts, now)` 返回 `Rejected` 或 `Accepted` 的候选事件与外部工作描述；`evolve(state, event)` 产生下一状态。Accepted 不是持久 receipt，纯函数不启动 Promise、不调用 SDK、不读全局时钟、不改共享 guard。writer 复核版本和失效条件，将事件、投影、工作/outbox、receipt 原子提交后才产生权威状态（候选稿:627-639）。

持久受控叶子明确分离 `Intent / Prepared / Dispatch / Ack / Observation / Recovery / Compensation` 槽位。计划至少保存 intent revision、Provider/binding/scope、解释器和 codec 身份、精确输入和转换、criterion/resolution、授权、原生 lookup、reservation、attempt、decision/outbox 关联；`DispatchStarted` 或 `Unknown` 后恢复必须沿旧 binding/解释身份观察，不能用当前编译器重新准备或重发（候选稿:641-673, §9.4–9.5）。

### 1.3 Recipe 输入输出与受控状态

同一 Recipe association `A` 派生以下阶段：

```text
prepare(A.Intent, A.ReadFacts)
  -> Result<A.Prepared, A.PrepareFailure>
start(A.Prepared, DispatchGrant<A.Binding,A.Plan,A.Attempt>)
  -> Effect<A.AckOrUnknown, A.DispatchFailure, A.DispatchServices>
observe(A.Prepared, A.AttemptEvidence)
  -> Effect<A.Observation, A.ObserveFailure, A.ObserveServices>
decideCriterion(A.Prepared, A.ObservationHistory)
  -> A.CriterionDecision
decideResolution(A.Prepared, A.AttemptEvidence, A.ObservationHistory)
  -> A.ResolutionDecision
planCompensation(A.Prepared, A.ExposureEvidence, A.Policy)
  -> Result<A.CompensationPlan, A.CompensationFailure>
```

来源：候选稿:728-749。`withTransaction(A, policy, admission)` 用同一个 A 构造提交、receipt、计划编码、阶段失败、观察和恢复消费者，不接受任意 action/payload map；重启后按完整 binding、实现身份和槽位重新绑定（候选稿:753-770）。

状态代数为 `Draft -> Prepared -> Ready -> DispatchStarted -> Observing`，随后按 criterion、attempt resolution、未决工作、reservation 与恢复责任进入 `Satisfied / ConclusivelyRejected / Recovering / Compensating`。文档明确区分“业务目标满足”和“本次尝试已解析”：前者成立时后者仍可 Unknown（候选稿:772-801）。

### 1.4 Deferred activation

```text
advance(Checkpoint, SourceFact, FutureBoundary)
  -> { checkpoint, outcome: NoActivation | Candidate<Evidence> | Gap }
```

`DeferredInvocation` 关联一个尚未发送的 `IntentRevision`、live activation owner、source bindings、纯 predicate、checkpoint schema、future boundary、expiry、冻结 disposition 和 decision channel（候选稿:841-858）。

Source/Data owner 产生 `ExternalFact`；deferred writer 校验 source identity/generation/cursor 后调用纯 `advance`。NoActivation 也可以提交必要 `CheckpointAdvanced`；Candidate 才能提交 `ActivationCandidate`；Gap 不能自动算作命中。event identity、epoch 去重、checkpoint、意图状态和下一 outbox 在同一 writer transaction 中提交；一个 intent revision 只有一个 live owner。Correction/Retraction 通过 selected-evidence lineage 定位依赖：未发送工作被 fence 并请求新决定，已发送/Unknown 保留（候选稿:849-862；`event-flows.md`:1149-1169,1183-1229,1231-1257）。

## 2. 已有事件消费、状态和所有权

### 2.1 EF06：接纳、准备与批准

`SubmitIntent` 输入 `commandId`、principal、scope、intent revision、expected aggregate revision、精确 recipe input 和 policy reference；不接受 caller 自填的余额、行情、position、permission 或 source identity。writer 提交 `IntentAccepted + receipt + PrepareWork`；trusted Read Interpreter 在 writer 外读取带来源的 ExternalFact 并运行纯编译/guards；`RecordPrepared` 由 writer 做 binding/slot/digest/CAS。`RequestSubmission` 只能进入资格/批准路径；只有真实 approver/delegated witness 才能提交 `ApprovalBound` 和 `ReservationHeld`（`event-flows.md`:682-714,730-779）。

### 2.2 EF07/EF08：受控发送、Close 与恢复

EF07 中 `Start` 不是公开入口。scheduler/private worker 先向 writer 请求；fresh CAS 成功后 writer 提交 `DispatchStarted`，再发 process-bound、one-use `DispatchGrant`。raw Ack/Observation 只能回到 writer，产生 `AckRecorded`/`ObservationRecorded`；ack 不代表 fill/cancel/finality。writer 分别消费 criterion 与 resolution，并保留 attempt identity（`event-flows.md`:783-804）。

运输丢失、crash、timeout 或 lease expiry 时，writer 先读已有 observations/criterion/attempt：证据充分则保留已知状态，仅追加 transport-loss；否则提交 `OutcomeUnknown + RecoveryCase + HistoryResolveWork` 并保留 reservation。resolver 的 `Found / AbsentWithEvidence / Partial|Unavailable / Ambiguous / Malformed` 不压成一个 not-found；Unknown 不得 blind resend、reprepare 或创建第二 attempt（`event-flows.md`:817-868）。

EF08 将 Cancel、Replace、Close 建模为不同 Recipe。Close 的 `All` 和 `QuantityTarget` 是不同语义；Close criterion、Cancel 的 `NoFurtherWorking` 与 exposure criterion 不互换。部分成交后的 cancel 不抹去既有 fills/exposure；未知、position gap 或未解析敞口继续保留 recovery owner（`event-flows.md`:872-983）。

当前源码只作为文档引用的旧行为锚点：`UnifiedTradingAccount._assertCloseQuantityWithinPosition` 在 dispatch 前重读 broker positions，缺仓或 qty 超过 available 即拒绝（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:565-595`）；`stageClosePosition` 解析 qty、解析 contract/subaccount 后只加入 staged operation（同文件:742-766）。旧 `TradingGit.push` 先执行 external operations，再 snapshot、append commit、`onCommit`（`services/uta/src/domain/trading/git/TradingGit.ts:119-185`），所以旧 marker 缺失不能推导 no-start。旧 guard pipeline 是 `Operation -> Promise<unknown>` 的宽组合并顺序调用 mutable guards（`services/uta/src/domain/trading/guards/guard-pipeline.ts:13-36`）。这些是迁移输入，不是候选 Controlled 已实现的证据。

### 2.3 EF10：激活、决定请求与修订

EF10 明确区分 source/channel 输入和 UTA committed event：Source/Data owner 产生 `ExternalFact`；UTA writer 才产生 `CheckpointAdvanced`、`ActivationCandidate`、`CorrectionApplied`、`ReviewRequestCreated`、`DecisionApplied` 等 DomainEvent。`ApplyDecision` 是 Alice/Agent channel 发给 writer 的 command；writer 以 request、control revision、intent revision、epoch、principal 和 expiry CAS 唯一结果。`RequestSubmission` 进入普通 EF06，而不是直接 dispatch（`event-flows.md`:1149-1169）。

对 Gap，冻结 disposition 分支为 RequestDecision、CloseWithoutDispatch 或 Suspend/RebuildBaseline；对 Candidate，分支为 SeekAuthorizedExecution→EF06、RequestDecision→ReviewRequest/outbox 或 CloseWithoutDispatch（`event-flows.md`:1171-1229）。Correction/Retraction 在未 DispatchStarted 时 fence 未发送工作并创建新 review/boundary；已 DispatchStarted 或 Unknown 时只追加 lineage 与 recovery owner（`event-flows.md`:1231-1244）。

EF10 的当前实现声明明确说 review outbox→Alice durable admission、deferred checkpoint writer、predicate schema、correction lineage、response CAS 尚未运行（`event-flows.md`:1259-1263）。这只是实现状态，不否定前述目标关系。

### 2.4 EF11：UTA→Alice→Agent

EF11 从已提交 `DecisionRequested + DecisionOutboxFrame` 开始，不重算 predicate。UTA 拥有 outbox 交接、未发送 intent、review revision、expiry、outbox 以及 Keep/Rearm/Revise/Discard/RequestSubmission 的 CAS；Alice 拥有 `WorkspaceResolution`、Session/Inbox admission、稳定 execution/task/session 引用、worker 与 delivery receipt，Alice 不拥有交易批准（`event-flows.md`:1342-1352）。

目标类型已明确关联：

- `ActivationEvidence<C>` 来自 ExternalFact，只带可验证 source identity/value/freshness/position/binding。
- `DecisionRequested<C>` 带 `requestId`、`decisionRevision`、`activationEpoch`、`intentRevision`、`evidenceRefs`、`checkpointRef`、`expiresAt`、`currentExpectedState`。
- `DecisionOutboxFrame<C>` 与 DecisionRequested 同一提交，带 outbox/review/digest/delivery identity，不带 secret/native dispatch。
- `ReviewRequest<C>` 保留同一 request/review/revision/epoch/intent/evidence/checkpoint/expected state。
- `WorkspaceAdmission` 用 `Pending | Admitted{admissionId,executionRef,...} | Rejected`；重复 outbox 返回原记录。
- `ReviewReply<C>` 带 request/review/epoch/reply key/digest/principal/expected intent/state 和 `KeepSuspended | Rearm | Revise | Discard | RequestSubmission`。
- `SubmissionControlReceipt<C>` 只表示 EF06 control admission，带 control handle、review、intent revision、EF06 admission revision；不带 provider Ack/Unknown，不等 approval。

来源：`event-flows.md`:1354-1367。

时序已给出：Alice 解析 Exact/Reconstructed/Unresolved；Exact/Reconstructed 时先用 outbox/review 做 admission CAS，再 spawn/resume 和返回 receipt；Agent reply 回到 UTA writer 做 request/review/epoch/key/digest/expected-state/expiry CAS。RequestSubmission 只提交 control handle，EF06 随后读取当前 plan/recipe、valid approver、currentExpectedState；通过后 scheduler 返回 fresh start，effect writer 先 commit `DispatchStarted` 再给 one-use grant，native raw facts 经 interpreter 回 writer（`event-flows.md`:1387-1473）。

## 3. 正面推导（不制造问题）

1. **数据命中不等于授权。** `ExternalFact`→`advance`→selected evidence/checkpoint→`DecisionRequested` 是 UTA 激活控制的输入；source 事实本身不能产生 `ActivationCandidate`、Approval 或 dispatch。
2. **Agent 决策不等于交易批准。** Alice 的 durable admission 只保证一个稳定 workspace execution；Agent 只能提交声明的 response ADT。`RequestSubmission` 只得到 EF06 control handle，之后仍需当前 plan/approval/state 校验与 `DispatchStarted` CAS。
3. **本地主机可在不预设 Provider 保证的情况下保持恢复边界。** `DispatchStarted` 是本地发送许可线；其后 raw Ack/Observation/Unknown 都沿原 attempt 回 writer。Criterion 满足可与 Unknown 并存；恢复 owner、reservation 和 lineage 不能被状态投影或 Agent 文字抹去。
4. **Close 的局部构造已经正面成立。** `Close` 叶子从同一 A 产生 prepared/observation/criterion/resolution；重启后通过旧 binding/codec/lookup 重绑，不重算数量或重发。目标仓位满足和本次执行归因可同时存在（候选稿:1003-1011；research-practice.md:93-99）。

## 4. 尚待构造的单一连接

以下结论需限缩表达：不能说候选稿没有保持 evidence/checkpoint/revision/receipt 关联，也不能说没有 CAS。EF11:1351、1359-1365、1477、1484 已明确这些关联和后续读取 current plan/approval/state。

**尚待构造的是跨已有关系的显式组合与竞态推导。** 当前稿分别规定了：

- EF10 correction/retraction 如何按 evidence lineage fence 未发送或转 recovery；
- EF11 `ReviewReply(RequestSubmission)` 如何以已给的 request/review/epoch/expected-state/CAS 形成 EF06 control handle；
- EF06/EF07 如何读取 current plan/approval/state，并在 `DispatchStarted` 前后分流；
- EF07/EF08 如何处理 started/Unknown、criterion、exposure 与 recovery owner。

但目前没有一个小型纯 transition 或有限轨迹，把这些**已有**关系在同一个中间窗口串起来：Candidate 已提交、Agent 已回复 `RequestSubmission`、EF06 control handle 已接纳但尚未完成 `DispatchStarted`，此时 selected evidence 的 Correction/Retraction 到达。尚待推导的是控制 revision/epoch/lineage 如何在线性化点上让旧 pending handle 变 stale 或被 fence，以及它如何与后续 Start/Recovery 分支唯一衔接；不是声称字段或 CAS 不存在。

## 5. 下一轮最有信息量的小研究问题

给定以下前提：

- 同一 `intentRevision=r`、`activationEpoch=e` 的 Candle→Order Candidate 已由 EF10 writer 提交；`DecisionRequested + outbox` 已提交。
- Alice 已用同一 outbox/review identity durable-admit；初始没有 `DispatchStarted` 或 Unknown。
- Agent 的 `RequestSubmission` 通过 request/review/epoch/principal/currentExpectedState CAS，形成 EF06 control handle。
- 同一 selected evidence 的 Correction/Retraction 与 EF06 的 `DispatchStarted` 可能竞态；只使用 UTA 的提交顺序和状态，不假设 Provider 原生幂等、完整查询或 finality。

**研究问题：** 能否构造一个最小 writer transition/有限轨迹，使两种线性化顺序都唯一且保持既有关系？

1. **Correction 先赢：** fence 未发送 candidate/pending submission handle；旧 reply/start 变 stale 或 no-dispatch；保留原 source lineage，并按 EF10 的规则创建新 ReviewRequest 或可信边界。
2. **DispatchStarted 先赢：** correction 只能提交 `CorrectionApplied + lineage + recovery owner`，不能撤销 attempt；迟到旧 review reply 不能逆转；后续按 EF07 的 observation/OutcomeUnknown/RecoveryRequired 继续。

两种顺序都应明确：不重算 predicate、不替换 intent revision/plan、不丢 checkpoint/evidenceRefs、不产生第二 attempt。若推导成功，这是数据激活→Agent→受控恢复的正面组合律；若推导失败，应精确指出缺的是 pending control-handle 的 invalidation/lineage 连接，而不是把 Provider 原生未知误报成核心阻塞。

## 6. 关键行号

- `docs/uta-capability-runtime-design.md:592-623`：§8 Pull/Push、coverage、resource owner、deferred evidence。
- `docs/uta-capability-runtime-design.md:627-724`：§9 `decide/evolve`、持久槽位、writer、rebind/recovery。
- `docs/uta-capability-runtime-design.md:728-837`：§10 Recipe 函数、状态代数、criterion/resolution、Unknown、Close/exposure。
- `docs/uta-capability-runtime-design.md:841-904`：§11 `DeferredInvocation`、`advance`、disposition、UTA/Alice/Agent。
- `docs/uta-capability-runtime-design.md:908-930`：§12 目标模块 owner 与依赖方向。
- `docs/uta-capability-runtime-design.md:934-1025`：§13 Order/Candle activation、Close 重启消费、账户/FX read-only 构造。
- `docs/uta-capability-runtime-design.md:1134-1232`：§16 消息种类、上下文 owner、slot 派生、identity/causation/time。
- `docs/uta-capability-runtime-design.md:1236-1294`：§16 extension/composition laws 与异常时序。
- `docs/uta-capability-runtime-design.md:1296-1353`：事件样例的证明边界，EF10/EF11 尚未声称生产实现。
- `docs/uta-capability-runtime-design/event-flows.md:682-804`：EF06/EF07 接纳、准备、批准、Start 与事件消费。
- `docs/uta-capability-runtime-design/event-flows.md:806-868`：EF07 先到观察、transport loss、Unknown、history recovery。
- `docs/uta-capability-runtime-design/event-flows.md:872-983`：EF08 mutation/Close/partial exposure/recovery。
- `docs/uta-capability-runtime-design/event-flows.md:1145-1263`：EF10 activation、correction/rearm、outbox 与 Agent response。
- `docs/uta-capability-runtime-design/event-flows.md:1342-1485`：EF11 UTA→Alice→Agent admission/reply/expiry、RequestSubmission、EF06/07 continuation。
- `docs/uta-capability-runtime-design/event-flows.md:1491-1625`：EF12 config/generation/shutdown/recovery classification。
- `docs/uta-capability-runtime-design/research-practice.md:79-99`：当前研究边界、Close/criterion-resolution 的既有局部结论。
