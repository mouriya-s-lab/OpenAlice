# 数据组合研究：filter/window/join 的正面构造

状态：候选核心设计的局部研究，不是整体设计验收，也不是生产实现完成证明。本报告只补数据组合与流消费关系；不重做已经存在的 `Unit/Query/Feed` 关联、固定/动态后继、投影条件律或受控控制归纳。依据是当前主书 §§3–8、§§13.1/13.2/13.5、§16.5、事件流册 EF01–EF05，以及下列少量旧源码锚点。未编写或运行代码、测试、样例、实验程序；所有时序均为有限输入下的设计推导。

## 1. 先给结论

当前设计已经有足够的静态骨架，但流算子的**正面消费构造还没有写到可逐步推演的程度**。

已经成立的部分是：

- `Unit`、`Query`、`Feed` 保留值、失败、服务要求和权限要求的关联；声明槽位是 parser、描述、事件 payload 的共同来源。
- `adaptInput`、`projectOutput`、`flatMap`、`combine` 已说明值/失败/服务/权限怎样组合；固定后继和动态后继已经区分“构造输入”与“认证输出”。
- §16.5 已给出已接纳轨迹上的透明投影条件律，要求来源、状态、身份、修订、覆盖、终态和观察面共同相容，而不是只比较 payload。
- EF03 已给出 Push 的 `Started + nonterminal frames + exactly one terminal`、共享资源、attachment ownership 和 `SnapshotEnd` 非终态。
- EF04 已给出 operator binding、derived lineage、`ProjectedItem`、`WindowedItem`、`DerivedCorrection/Retraction`、`CompositeGap`、`MemberOutcome` 和 child terminal 的基本边界。
- EF05/§13.5 已把账户值、FX 和估值放进只读数据消费，明确不产生 approval、reservation 或 dispatch。

尚需补齐的不是更多算子名字，而是每个算子的真实操作数与消费者：

1. `filter` 必须有一个声明的纯 predicate、版本/配置、输出选择和修订策略；当前只在 §16.5 表中出现，EF04 的 `ProjectionRequested` 尚未把 predicate/filter binding 放入操作数。
2. `window` 必须有窗口归属、边界、时间语义、聚合/成员函数、关闭证据和 late policy；当前字段表列出了这些词，但没有说明有限状态怎样从 Data、Correction、Gap 和 barrier 产生输出。
3. `join` 必须有两侧输入、typed join key、时间关系、选择基数、缺侧/Partial 政策和修订策略；不能只说 `Joined<A,B>` 或“用 key”。
4. `merge` 需要把 child terminal 先折进 operator state，再依据 declared outer policy 终止；不能只用到达顺序或把左 child 的 Completed 复制成 outer Completed。
5. 所有算子都需要一个稳定的 derived identity/revision 关系，以及“已输出成员如何在修订后变为 correction/retraction/新 item”的分支。
6. 流结束后收到的 correction 不属于旧流的继续输入。它必须被旧 invocation 拒绝且不产生旧流输出；只有显式的新 `ProjectionRequested`/新 Pull 或 replay/resync invocation 才能消费。

这正是父代理新增的 §5.7 尚未完全覆盖的细节：§5.7 已有构造归纳框架，但“读取积与流组合消费自己的政策”仍不足以决定具体 state、emission、owner 和 late-after-terminal 路由。

## 2. 最小共享构造：一个纯 step，加一个资源解释边界

下面只是设计推导所需的共同关系，不是要新造一个通用 DSL 或公共 `Operator` 接口。每一种算子仍由自己的声明提供业务函数和政策。

### 2.1 每种算子必须声明的操作数

对一个数据算子 O，必须能从声明中取得以下操作数：

| 操作数 | 作用 | 核心可以派生什么 | 不能由核心猜什么 |
|---|---|---|---|
| 一个或多个 child binding/slot | 指定输入 Query/Feed、scope、generation、schema revision | 输入 decoder、source lineage、R/P 关联 | provider 是否真的完整、可 replay 或 final |
| 输出 Unit/schema 与 operator binding | 指定派生值和输出 codec | 输出 parser、`ProjectedItem`/`WindowedItem` 等 envelope 关联 | 业务值是否真表达目标含义 |
| 纯值关系 | filter predicate、window assignment/reducer、join key/match 等 | 版本化实现身份、输入/输出失败槽位 | predicate、key 等业务函数的正确性 |
| derived identity/revision 关系 | 从 lineage 形成输出身份并处理同一输出的后续修订 | 稳定的 derived envelope 和 revision 校验 | 跨源 canonicalization 或“同名就是同一对象” |
| coverage/failure/terminal policy | 规定 Gap、ItemFailure、child Failed/Cancelled 与 Complete 的消费 | 合法的 ADT 分支和拒绝条件 | “最佳努力”是否符合业务承诺 |
| late/correction policy | 规定窗口关闭、已输出成员或已终止 invocation 之后怎样处理 | correction/retraction/reconciliation 的形状 | 是否要改写历史、是否允许估算或迟到修订 |
| resource attachment policy | 指定 operator 对每个 child attachment 的拥有权及 Shared/Exclusive 关系 | 解释器的 attach/release 边界 | provider native handle 是否可取消、是否能续传 |

`P` 可以在组合声明中表现为 child 要求的集合并，但每个 child 仍须在自己的 binding/scope 上复核 witness；`P1 ∪ P2` 不是授权 witness。`R` 是静态服务要求的联合；若 window 使用处理时钟或 join 需要目录读取，这项服务必须显式进入 O 的要求，不能偷偷读取全局时间或网络。

### 2.2 共享的最小纯 step

对每个具体 O，使用如下关系来推演即可：

```text
step_O : State_O × DecodedChildFrame
       -> (State_O × Emission*) + OperatorFailure
```

这不是强迫实现同一个运行时类型，而是最小纯关系：

- `DecodedChildFrame` 已经由 child binding/schema 解码，不能把未经认证的 JSON 交给 predicate、join key 或 reducer。
- `State_O` 至少包含：每个 child 的 `Open | terminal` 状态；已见 source identity 的最高合法 revision/lineage；已经产生过的 derived identity 与当前 revision/成员状态；算子专属的待配对、窗口或聚合状态；Gap/coverage；外层 `Open | terminal` 状态。
- 资源句柄、subscriber、timer、writer 不放进纯状态。它们由 `interpret_O` 管理；纯 step 不打开连接、不发网络、不写 Journal、不改变共享对象。
- `Emission` 只能是 O 声明的输出槽位及 EF04 已有的派生事件形状，例如 `ProjectedItem`、`WindowedItem`、`DerivedCorrection`、`DerivedRetraction`、`CompositeGap`、声明的 `MemberOutcome` 或唯一 outer terminal。无输出是合法的空 emission（例如普通 filter 丢弃一条不匹配的 item），但不能抹掉 source position、coverage 或修订依赖。
- 在调用 `step_O` 前，解释器先核对 child binding、slot、scope、generation 和 operator revision；若 O 已进入 outer terminal，任何后来的 child Data/Correction 都不得进入 `step_O`。

解释边界可写成：

```mermaid
flowchart LR
    A["decode(childBinding, wireFrame)"] -->|decoded child frame| B["step_O(state, frame)"]
    B -->|next state + derived emissions| C["interpret_O(emissions, owner)"]
    C --> D["transient delivery"]
    C --> E["atomically persist selected projection/checkpoint"]
    C --> F["release owned attachments on terminal/cancel"]
```

对 finite Pull，解释器把有限 emissions 汇总为有边界的 `PullResult`；对 Push，逐项变成具有 O binding/lineage 的 delivery frame。普通 data frame 不因经过 O 就自动写交易 WAL；只有 EF05 的显式 capture 或选中的 projection 才进入相应 writer。算子也不获得 financial dispatch 权限。

### 2.3 算子各自的实际操作数与消费

| 算子 | 最小输入操作数 | 纯业务函数/状态消费 | 必须由声明给出的动态政策 |
|---|---|---|---|
| `filter` | 一个 child `Feed/Query<C>`；predicate 及配置/版本；输出选择与 identity 关系 | 对每个合法 C 计算 `keep/drop`；保留 source identity、旧 membership、revision 和 coverage 依赖 | predicate 是否读 extension、缺值处理、是否输出每次命中、invalid item 处理、late correction 的 drop/revise/reconcile |
| `window` | 一个 child（可为 source 或已声明的 merge）；window key、事件时间字段、边界/时区；aggregate/member reducer | 把 item 放入确定窗口，更新窗口成员/accumulator；修订时按成员重算或使用声明的可逆状态；保存 window revision/closure | inclusive/exclusive、event-time 与 processing-time、watermark/barrier/deadline、输出更新频率、late item/correction、聚合的缺项/Partial 语义 |
| `join` | 两个 child binding；两侧 key 关系；时间/`asOf` 关系；输出配对 identity | 维护各侧候选和已选配对；item 到达、修订、撤回会重新计算受影响 pair | key 的语义和 mapping 证据、one-to-one/one-to-many、缺侧、等待边界、Partial、late/correction、冲突选择 |
| `merge` | 有序声明的 child binding 集合；来源 tag/partition；每成员 item/terminal 输出关联 | Data 变成带 source binding 的和；child terminal 折进状态；按 all/partial/quorum 等外层政策决定终态 | dedup/排序、child Failure/Cancelled、partial-result、何时释放各 child、是否输出 MemberOutcome |

`filter`、`window` 和 `join` 都不是透明 1:1 extension：它们改变选择、输出结构或观察时机，必须带自己的 operator binding、revision、失败和终态策略。`merge` 也不是把几个 payload 的字段拼接成一个对象；其输出是带来源归属的和。

## 3. Filter 的正面构造与有限状态

### 3.1 构造条件

令 C 是已认证的 rich Candle，F 是一个 Pull/Push child，声明：

- `predicate_q(C, config)` 为纯、版本化的业务函数；例如 `close >= 100`。若它需要账户、时钟或另一行情源，则它不再是单纯 filter，必须显式组合一个 Query/Join/decision 输入。
- 输出保留 C 的全部声明字段，或使用另一个已声明的总值投影；不因“过滤”而丢掉 source identity、finality、coverage 或 revision。
- `derivedId = id(filterBinding, sourceIdentity)` 的稳定性以及 `derivedRevision` 的推进规则已声明。
- O 保留至少每个 source item 的最后 revision、旧 membership 和必要 lineage；没有这些状态就不能声称支持 correction。只保留已命中的 item 时，未命中 item 后来进入选择集的转移将无法构造。
- source Gap 不是 predicate=false。有限 source 已有完整 barrier 时，结果可表示“该范围内满足 q 的完整选择”；无 barrier 的 live 流只能保持 Open/Partial。

### 3.2 有限 Candle 时序

记 `c1@r1` 的 close=99、vwap=101，`c2@r1` 的 close=101；`g1` 是 source generation。初始状态为 `child=Open(g1), seen=∅, output=∅, coverage=Open, owner=O`，其中 O 拥有 F 的一个 child attachment，外部 subscriber 拥有 O 的输出 attachment。

| 输入 | 纯状态变化 | O 的输出/解释 |
|---|---|---|
| `Started(g1)` | 记录 child binding/generation；仍 Open | 发 O 自己的 Started；不把 source Started 当数据 |
| `Data(c1@r1)`，q=`close>=100` 为 false | `seen[c1]=r1, member=false`；source position 已消费 | 无 `ProjectedItem`。缺少输出不等于 Gap，也不能丢掉 c1 的位置 |
| `Data(c2@r1)`，q 为 true | `seen[c2]=r1, member=true, output[d2]=r1` | `ProjectedItem(d2@r1,lineage=[c2@r1])` |
| `Correction(c1@r2)`，close 改为100 | `seen[c1]=r2, false→true` | 以前没有 d1，所以产生带 correction cause 的新 `ProjectedItem(d1@r1)`；不能伪造“修订了一个从未输出的 d1” |
| `Correction(c2@r2)`，close 改为99 | `seen[c2]=r2, true→false` | `DerivedRetraction(target=d2,newRevision=r2)`；旧 d2 不原地改写，后续查询可见其撤回关系 |
| child `Completed` 且 source coverage 完整 | child terminal；filter outer policy 可闭合 | 唯一 `Completed`，覆盖说明是“已完成 source 范围内的 q 选择”，不是源 item 数目；释放 O 对 F 的 attachment |
| child 已有 Gap 且未恢复 | `coverage=Partial/Gap`，仍 Open 或按 policy Failed | 不可把 Gap 后缺失 item 当作 false，也不能发 Complete |
| `Correction(c2@r3)` 在 O 已发 `Completed` 后到达 | 旧 O 状态不变 | 旧 invocation 拒绝 late-after-terminal；不向旧 subscriber 发任何 Data/Correction/Retraction。若允许修订，新的 owner 必须发 `ProjectionRequested`，用新 Pull/replay/resync invocation 建立新投影；不能让旧流复活 |

如果同一个 source identity 在相同 revision 下携带不同 payload，应走 source conflict/reconciliation，而不是再次执行 predicate。若 source correction target 不在 O 的历史索引中，也不能直接发 `DerivedCorrection`；应保留 reconciliation/unavailable，或由新 invocation 从可信 source barrier 重建。

Candle 的 rich 字段构成一个有区分力的业务挑战：同一 `c1` 的 close=99、vwap=101，`q_close` 丢弃它，`q_vwap` 保留它。两者都可以是合法声明，但不能声称 structural projection 后行为透明；若基础投影已经丢弃 vwap，就没有总的 `q_vwap` 输入，必须显式失败/保持动态结果，不能拿 close 代替。

### 3.3 Filter 的资源边界

O 是 F 的 attachment owner，不是 provider native handle 的任意关闭者。O 取消或终止时只释放自己拥有的 attachment；若 F 的资源是 Shared，其他 subscriber 仍持有时，resource manager 不得调用 native cancel。O 的 outer terminal 一旦提交，`step_O` 的输入闸门关闭；资源 cleanup 的 pending diagnostic 不改变已经发出的 terminal。这个关系把“过滤后没有更多输出”与“provider 连接被关闭”分开。

## 4. Window 的正面构造与有限状态

### 4.1 构造条件

一个 window 声明至少要给出：

- `windowKey` 与 event-time 字段（例如 News 的 `pubTs`），窗口边界、时区和 inclusive/exclusive 规则；
- 成员/聚合函数及其输出 schema、单位和 revision 规则；若收到 correction 后不能由 accumulator 纯重算，声明必须保留成员观察或可验证 replay；否则只能返回不支持/未知，不能继续声称可修订；
- 关闭证据：source watermark、finite Pull completion、snapshot barrier，或显式的 processing deadline。deadline 是本地策略，不是 source finality；使用 Clock 就属于 O 的 R；
- late item/correction policy；窗口关闭不是 outer stream terminal，二者必须分开；
- source Gap、child terminal、Partial 的影响。无 watermark/barrier 时，窗口保持 Open/Partial，不用 `receivedAt`、数组位置或本地 now 制造完整性。

### 4.2 NewsGroup 组合的有限时序

取两个已声明的 News Feed `F1`、`F2`，先以 `Merge` M 保留来源 tag，再由 Window W 对 M 的 `pubTs` 做 `[10:00,11:00)` 窗口计数。M 采用明确的 partial-result profile；W 声明 processing deadline=11:00、late policy=`ReviseWhileInvocationOpen`，仅作为一个挑战场景，不表示该政策是全局默认。

初始状态：

```text
M: child F1=Open(g1), F2=Open(g1), member outcomes=none
W: child M=Open, window[10,11)=Open, members=∅, revision=0, coverage=Open
owners: M owns F1/F2 attachments; W owns M attachment; subscriber owns W output
```

| 输入 | M 的状态/输出 | W 的状态/输出 |
|---|---|---|
| `F1.Data(n1@r1,pubTs=10:05,seq=1)` | `MergedItem(m1,lineage=[F1:n1])`；seq 只作为 F1/store 的位置证据 | 将 n1 放入窗口，计数=1，发 `WindowedItem(w@r1,lineage=[F1:n1])` |
| `F2.Failed(f2)` | 记录 `MemberOutcome{F2,Failed,f2}`；因 M 有 partial profile，M 不把 F1 关闭，也不把 f2 改名 ItemFailure | W coverage 变为 Partial；按声明可以保持窗口 Open，不能把 Partial 提升 Complete |
| processing deadline 到达但没有 source watermark | `M` 仍 Open；W 可发 `WindowClosed(w,deadline,Partial)`，但窗口关闭不结束 M/W 的 live invocation | W 保存 window closed + Partial；没有 source finality 断言，仍可按 late policy 接收窗口修订 |
| `F1.Data(n2@r1,pubTs=10:30,seq=2)`，本地收到时间已晚于11:00 | M 发 m2；`seq=2` 的 ingest 顺序不阻止其按 pubTs 归入旧窗口 | 若 W invocation 仍 Open，重算 count=2，发 `WindowedItem(w@r2)` 或 `DerivedCorrection(w,r2)`；若 late policy=drop，则不发数据但要保留 declared late/coverage 诊断，不能假装没有 n2 |
| `F1.Completed`，此时 F2 已 Failed | M 消费两个 child terminal，按 partial profile 产生唯一 outer `Completed`，覆盖仍 Partial | W 消费 M terminal；有完整 finite barrier 的部分关闭窗口，发 outer `Completed` 一次，但结果 coverage 仍 Partial，不是 Complete |
| `Correction(F1:n1@r2)` 在 W outer Completed 后到达 | 该 frame 不再属于旧 M/W invocation | 旧 W 拒绝且不再向旧 subscriber 发 correction；若业务需要修订，新的 `ProjectionRequested`/新 projection owner 读取可回放的 F1/F2，形成新投影 revision。旧流不复活 |

如果 F2 采用默认 strict policy，则其 `Failed` 直接使 M/W outer `Failed`；后来的 n2 或 correction 都不能进入已经终止的 output。这个分支与 partial profile 的差异是业务承诺，不是算子核心自动选择的默认。

News 的旧实现只能支持较窄的声明：`NewsRecord.seq` 是本地 ingest 序号，`pubTs` 是发布时间，RSS collector 对单 feed 失败告警并继续其他 feed，已见 GUID/link 的后续内容被去重丢弃（`src/domain/news/collector/rss.ts:77–139`、`src/domain/news/store.ts:161–180,227–255`）。因此旧路径可以作为有限 Pull/本地投影输入，却不能被声明为可靠 correction/retraction Push 或 publication-time 完整 watermark。不同 feed 的同标题/同内容也不能凭文本去重；跨源 canonicalization 必须成为 M 的业务声明并保留两个 lineage。

### 4.3 Window 的聚合修订边界

若窗口只保存 count 和总和，收到一条影响最大值、分位数或成员删除的 correction 时，旧 accumulator 可能不足以纯重算。正面构造的前提必须二选一：

- 保存每个成员的已认证 identity/revision/value，修订后纯重算；或
- 有声明且可验证的 reducer/replay 关系，能从 checkpoint 后的 source history 重建窗口。

两者都没有时，输出应变为 declared `Partial/Unavailable/ReconciliationRequired`；不能用新 arrival order 覆盖旧窗口 row。`WindowClosed` 只表示该窗口的本地投影关闭动作；只要外层 invocation 尚未终止，late policy 仍可产生该窗口的新 revision。outer terminal 后则必须走新 invocation。

## 5. Join 的正面构造与有限状态

### 5.1 构造条件

令 L、R 是两个 child。Join 必须由声明提供：

- `keyL`、`keyR` 的 typed 关系及跨源 identity mapping 证据；`display symbol`、文本标题或裸字符串不够；
- 时间关系，例如同一 `asOf` 桶、`r.observedAt <= l.asOf` 或有限迟延区间；不能按“谁先收到”配对；
- one-to-one、one-to-many 或确定选择规则；
- 缺侧政策：等待、inner omission、显式 unmatched、Partial 或 Unavailable；不能以 zero 填补缺失金额/数量；
- pair identity/revision、correction/retraction 和 child terminal policy；
- 输出 schema 保留两侧 source binding、scope、as-of/observedAt、coverage 和完整 lineage。

### 5.2 Account/FX 的有限时序

这是对现有 §13.5 构造的具体化，不改变其“D0 账户值、M 构造 FX 请求、D1 FX、纯 F”关系。目标币种 USD，scope 内有：

```text
A1@r1 = 100 USD, AccountScope=S, asOf=t1
A2@r1 = 80 EUR,  AccountScope=S, asOf=t1
FX key = (EUR, USD, asOf policy)
join policy = all-required-for-Complete; missing FX -> Partial/Unavailable, never zero
```

Join state 初始为 `left=Open, right=Open, candidates={A1,A2}, pairs={EUR unresolved}, output=none`，J 拥有账户和 FX 两个 child query/resource 的 attachment。

| 输入 | Join state | 输出/解释 |
|---|---|---|
| `A1@r1,A2@r1`，账户 Pull Complete | 记录两个 account facts；EUR pair 待匹配，A child 可进入 Completed | 若声明允许增量观察，可发 `AccountValuation(Partial,missing EUR/USD)`；否则保持待定。不得返回“100 USD”冒充总值 |
| FX 不可用/只收到 Partial | EUR pair 未完成；coverage 保持 Partial/Unavailable | `F` 不进行零填充；普通 Query 可返回结构化缺口，不能变成 Complete |
| `FX(EUR/USD)@r1=1.10,Confirmed` | pair 成立；纯 F 计算 80×1.10=88，100+88=188 | 发 `AccountValuation(v@r1=188 USD,lineage=[A1,A2,FX@r1])`；具体是否 Complete 仍需双方 coverage 和时间政策满足 |
| `FX@r2=1.12` correction | 同一 pair 的 source revision 前进，输出 revision 前进 | 发 `DerivedCorrection(v,r2=189.6)`；保留旧 valuation 与 FX lineage，不原地改历史 |
| `A2@r2` 将 currency 改为 JPY | 旧 EUR/USD pair 不再适用；A2 与旧 v 脱离 | 对旧 v 发 `DerivedRetraction` 或按 output schema 变为 unresolved；M 显式构造 JPY/USD 的新请求。旧 EUR rate 数值可相乘不代表单位相容 |
| A child Completed，FX child 仍 Open | 仅说明不再有新的 A row；J 仍等待 FX barrier/late policy | 不能因为一侧结束就给全量 Complete；FX 仍可在 invocation 内补 pair |
| J outer Completed 后收到 FX correction | 旧 J 已关闭 | correction 不得向旧 valuation subscriber 继续发；新 capture/projection invocation 重新绑定 FX revision 后产生新 projection。若这是已持久 capture，修订属于新的 evidence/projection revision，不回写旧 capture |

这里的 `Confirmed`、`Estimated`、`Stale`、`UnknownFx`、`Unavailable` 仍是 FX/估值声明中的业务质量，不由 join 自动压成一个数。允许 Estimated 进入展示，或要求 Confirmed/Identity 才能成为某个业务结果，都是不同程序承诺。

旧代码只支持更窄的现实边界：`UnifiedTradingAccount.getAccount` 在 account read 后再读 positions，只有所有 position currency 与 account base currency 相同才汇总 PnL，否则保留 broker 值（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:1005–1023`）；Alpaca 并行读取账户和持仓并汇总美元 PnL（`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:417–437`）；CCXT 则按钱包和 ticker 的 provider policy 聚合 USD equity（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:932–1027`）。这些事实不能证明 `Promise.all` 是同一时点快照，也不能被提升成一个通用 FX join 的原生保证。目标构造必须把 scope、currency、as-of、FX evidence 和 coverage 保留下来。

### 5.3 Join 的缺侧与修订

一个 missing side 在 side 尚未达到声明边界时是“尚未观察”，达到完整 barrier 后才可能成为“确认缺失”。两者不能共用一个 empty/zero 状态。若 inner join 选择不输出 unmatched，Complete 也必须依赖两侧完整性；若业务需要保留 unmatched，输出 Unit 必须声明该 variant。若一侧 child `Failed`：strict join outer `Failed`；partial-result join 才能保留带 source binding 的 `MemberOutcome` 并继续，不能把 child terminal 改成 per-item failure。

Join correction 需要以 source identity/revision 找到所有受影响 pair：

- 未有旧 pair、修订后首次满足匹配：新 `JoinedItem`；
- 已有 pair、值仍匹配：`DerivedCorrection` 新 revision；
- 已有 pair、key 或时间关系不再满足：`DerivedRetraction`，必要时构造另一个 pair；
- 没有旧 source target 或候选选择不具确定性：reconciliation/Partial，不静默选择最近到达的一侧。

## 6. Merge 与 child terminal/resource 的正面消费

`Merge` 的最小纯 state 是每个 child 的 `Open | Completed | Failed | Cancelled`、各 child 的 source position/coverage、输出 source tag/lineage 和 outer status。其 Data step 产生带 child binding 的和，不产生跨源全序；terminal step 只更新 child outcome，是否继续由 partial policy 决定。

条件推演如下：

1. 左 child `Completed` 后，右 child 仍 Open，M 仍 Open；右 Data 可以继续输出，不能把左终态复制给 outer。
2. 默认 strict policy 下，任一 child `Failed` 使 M outer `Failed`，并释放 M 拥有的其他 child attachments；不补 `Completed`。
3. declared partial-result 下，Failed child 进入 `MemberOutcome`，仍开放的 child 可继续；全部 child terminal 后可发 outer `Completed`，但 `CompositeResult` coverage 仍 Partial。
4. `ItemFailure` 只有 child capability 明确允许逐项恢复时才不关 child；source `Failed` 不能改名 `ItemFailure`。
5. M outer terminal 之后，所有 child frame（包括 correction）均为 late-after-terminal，不能重新打开 M。若业务需要历史修订，必须由新 M invocation 以新 projection identity 和 replay/resync 读取。

资源 owner 链是：M 拥有对各 child 的 attachment，W/J 等上层 operator 拥有 M/J 的 attachment，最终 subscriber 拥有最外层 output attachment。上层取消只释放自己拥有的下层 attachment；一个 child terminal 不自动关闭其他仍开放 child；只有 operator outer terminal/cancel 后才释放其全部 child ownership。Provider resource manager 根据 Shared/Exclusive 引用计数决定 native handle 是否关闭。纯 step 不做这项释放决定。

## 7. 条件性保证与业务承诺变化

### 7.1 在哪些前提下组合保持关联

对任一 finite trace，可给出以下局部保证：

- 初态携带经过认证的 child binding、operator binding、output schema 和 owner attachment。
- 每一步只接受匹配 child slot/scope/generation/revision 的 decoded frame；纯 step 的每个 emission 都由同一 O 声明编码，并带 source lineage、operator revision 和适用的 derived identity。
- correction 只更新已识别的 source identity；有旧 derived target 才发 correction/retraction，没有 target 就走 reconciliation。derived output 旧 row 不被原地改写。
- child terminal 先折入 operator state；只有 terminal policy 与 coverage 证据满足时才产生 outer terminal；outer terminal 之后不再调用 step 或发布 output。
- interpreter 只释放当前 invocation 拥有的 attachments；共享 native resource 的关闭由 resource manager 的剩余 owner 决定。

由此可归纳得到的是：**关联、来源、修订、覆盖、终态和资源边界在给定声明前提下被保持**。这不是 predicate、FX rate、canonicalization、watermark 或 Provider 原生保证正确的证明。

### 7.2 相容组合与业务承诺变化

| 变化 | 判断 | 原因 |
|---|---|---|
| Rich Candle 通过总 structural projection 保留 close、source、coverage、finality、revision，且沿用同一业务函数 | 可在 §16.5 条件下声称局部透明 | 值、状态、identity、control-kind 和观察面均保持；新 derived binding 仍需可见 |
| 同一 Candle 从 `close>=100` 换成 `vwap>=100` | 业务承诺变化 | predicate/观察面变化；同一输入可产生不同命中，不是透明投影 |
| 两个 source merge，保留 source tag/lineage，并使用原已声明的 child/outer policy | 相容的结构组合 | 组合新增来源关系，但不伪造共同全序或 child atomicity |
| Merge 从 strict child failure 改成 partial-result | 业务承诺变化 | `Failed` 的 outer 可见性、coverage 和继续范围变化 |
| Window 使用 source watermark/finite barrier；只重算受影响窗口并带 revision | 在该 source evidence 下成立 | closure 和 correction 有明确前提 |
| Window 从 watermark 改为 processing deadline，并把结果视为 Complete/final | 业务承诺变化且不合法升级 | deadline 只能是本地 Partial policy，不能证明 source finality |
| Join 用带证据的 `InstrumentId`/`AccountScope` 与 as-of 关系配对 | 可组合 | key、时间关系和缺侧语义明确 |
| Join 按 display symbol、缺 FX 填 0、把 unmatched 变成空成功 | 不合法/承诺变化 | identity、单位和 coverage 被擦除 |
| 允许 carry-forward 旧账户值，或允许 Estimated FX 进入 Complete | 业务承诺变化 | 时间/新鲜度/质量政策改变，须更新 operator/consumer declaration |
| source correction 在 outer terminal 后继续推送给旧 subscriber | 不合法 | 违反已终止 invocation 的 ownership/finality；必须新 invocation |

## 8. 终止后的 late correction：唯一合法路径

必须明确三层状态，避免把“窗口关闭”与“流终止”混为一谈：

1. **child terminal**：该 child invocation 不再接受其后 frame；operator 可消费 terminal，并按自身 policy 决定是否继续消费其他 child。
2. **per-window closed**：该窗口由 watermark/barrier/deadline 关闭；若外层 invocation 仍 Open，声明的 late policy 可以产生窗口的新 revision，或保留 late/Partial 结果。
3. **outer terminal**：整个 operator output 已选择 `Completed | Failed | Cancelled`。旧 invocation 的 frame gate 永久关闭，任何 late correction 只产生旧 invocation 的 reject/diagnostic/reconciliation，不产生旧 output。

外部 correction 到达 outer terminal 后：

- 若来源声明可 replay/resync，数据 owner 或 projection owner 发起一个带新 invocation/projection identity 的 `ProjectionRequested`，精确重绑定 operator revision、source generation 和 late policy，再从 source Pull/replay 重建；新投影可以产生自己的 Data/Correction/Retraction。
- 若来源没有可靠 identity、target、replay 或 correction 证据，保留 reconciliation/unavailable；不能把 correction 贴到旧 output，也不能凭 receivedAt 生成新顺序。
- 若是显式 capture 后的修订，产生新的 selected evidence/projection revision；不能回写旧 capture 的历史 row，也不能让已结束的 delivery stream 复活。
- 旧 operator 不重新获取资源、不重新发 Started、不重新发 terminal；新 invocation 才有新的 owner/attachment。若新 invocation 需要复用 Shared resource，资源管理器只增加新 attachment，不侵入旧终态。

这条路径同样适用于 filter 已经 Completed、window aggregate 已经 outer Completed、join valuation query 已经返回终值以及 merge 已经 Failed 的情况。

## 9. 对主书的精确修改建议

以下是给 Main 的整合建议，不是本报告直接修改 repo。

### §3.2 / §3.3

在 `Definition/Binding/Program` 后补一句：公开数据组合产生自己的 operator binding 和 output association；它保留 child bindings/lineage，但不继承 provider native 全序、finality、replay 或交易权限。说明 operator binding 不是新的公共 DSL，也不是把 predicate/window/join 变成核心内置业务枚举。

### §5.2 / §5.4

在 `projectOutput` 后、受控效果前增加一个“算子声明与纯消费关系”小节，内容至少包括：

- `step_O : State_O × DecodedChildFrame -> State_O × Emission* | OperatorFailure` 作为推导记法；强调纯 step 不持有资源，不写 Journal。
- 操作数表：child binding/slot、output Unit、纯函数、derived identity/revision、coverage/failure/terminal/late policy、resource attachment policy。
- 分别列出 filter、window、join、merge 的最小操作数，不只列 ordering/buffer/replay。
- 明确 filter 不是 transparent projection；window close 不是 outer terminal；join 的缺侧不能被 zero/empty 静默替代；merge 先消费 child terminal。
- 明确 `R` 是服务要求联合、`P` 是要求关系而非授权 witness；每个 child 仍单独复核 scope/permission。

父代理新增 §5.7 可保留作为归纳总则；上述小节应作为它的具体 state/emission 实例，而不是再写第二套形式体系。

### §6.2 / §6.4

Candle 段增加“rich extension 被 filter/window/join 消费时，predicate、window assignment、join key 属于业务声明；同一字段集合不证明行为透明”。NewsGroup 段增加：跨 feed merge 保留 source tag/lineage；`seq` 不等于 publication watermark；GUID 内容变化只有来源声明 correction 时才可产生 correction。

### §8.1–§8.3

在已有 Push frame 与资源 ownership 后补三条：

1. source/child terminal、per-window closed、outer terminal 是不同状态；`SnapshotEnd` 和 `WindowClosed` 都不是 outer terminal。
2. outer terminal 后旧 invocation 不接受任何 late Data/Correction/Retraction；late correction 只能走新 projection/invocation 的 Pull/replay/resync。
3. operator 只释放自身 attachment；共享资源由 resource manager 按剩余 owner 决定 native cleanup，cleanup diagnostic 不改变已经提交的 terminal。

### §13.2

在 rich Candle 两种交付例子后加入上面的有限 filter trace（至少 `close=99,vwap=101`、`close=101`、命中项 correction/retraction、source Completed 和 terminal 后 late correction）。明确 `q_close` 与 `q_vwap` 是两个合法但不透明的业务消费者。

### §13.5

保留现有 D0/M/D1/F 构造，再补 join state：AccountScope + currency/as-of key、FX missing、FX revision、账户 currency revision、双方 terminal。强调 188 USD 的计算只在声明的 FX quality/coverage policy 下成立；不能从 account+FX 两个数自动推出同一时点快照、Complete 或 financial authority。

### §16.5

保留透明投影的条件律；在表格后补：

- filter 的 membership state 和三种修订转移（false→true 新 item、true→false retraction、true→true correction）；
- window 的 member/accumulator/revision state 以及 watermark/deadline 分支；
- join 的 candidate/pair state、缺侧和 key/time correction；
- outer terminal 后 late correction 的新 invocation 路由。

该处应明确“算子 output schema 可由声明派生”不等于“业务函数、watermark、canonicalization 或 aggregate reducer 可由 schema 自动推出”。

## 10. 对 EF01–EF05 的精确修改建议

### EF01 / 共用约定

现有 EF01 已规定 capability leaf 的 item/failure/lifecycle slot。补充：EF04 operator binding 是由 child binding、operator revision/digest、output schema 和业务 policy 组成的**派生 binding**；它不能被当作 provider native leaf，也不能覆盖进行中的 child generation 或旧 output revision。

### EF02

保留 finite Pull 与 `Partial/Unavailable`。在“前段结果怎样成为后继计算”后补：当后继是 filter/window/join 时，后继构造必须保留真实输入 Unit、source identity、scope、as-of 和 coverage；后继 predicate/key/window 不得从裸字段或 display symbol 猜出。普通 Pull 返回后，迟到修订只能被新 query/projection 消费，不改变已返回 finite result。

### EF03

在终止规则后补：

- child/resource terminal 后的 late frame 不是旧 stream 的新 nonterminal frame；按 binding/generation/terminal gate 拒绝或转 reconciliation。
- `SnapshotEnd` 只结束历史段；window close 只结束一个窗口；二者都不释放仍被 live invocation 持有的 operator child attachment。
- 需要修订时由新 subscription/projection 按 data leaf 允许的 replay/resync policy 重新 attach；不能让旧 attachment 重新发 Started 或补发一个第二 terminal。

### EF04

这是本轮最重要的补齐：

1. `ProjectionRequested` payload 增加 `operatorKind`（仍可作为声明标签而不是全局业务 union）、`predicate/filter binding`（若为 filter）、`window assignment/reducer/closure policy`（若为 window）、`join key/time/missing/cardinality policy`（若为 join）；只在对应 operator 需要时出现，不能变成 optional-field soup。
2. 新增一个“每 operator 的 pure step/state”小节，引用主书 §5.4 新小节：输入 child frame 先按 binding 解码，step 更新成员 revision/output index/child lifecycle/gap/window/pair state，再由 interpreter delivery/persistence。此处不需发明新事件类型。
3. `ProjectedItem` 明确可承载 filter 的首次命中；`DerivedCorrection` 只适用于已有 derived target；source correction 使未命中项首次命中时用新的 derived item；命中变不命中用 `DerivedRetraction`。
4. `WindowClosed` 明确是 per-window derived control，不是 outer terminal；deadline close 的 coverage 必须为 declared Partial/deadline reason；窗口仍处于 live outer invocation 时，late policy 才能发新 revision。
5. `Join` 说明 pair identity、两侧 lineage、key/time/coverage；缺侧只能按声明输出待定/Partial/unmatched/Unavailable，不能 zero-fill。
6. `CompositePartial/OperatorFailed` 保留 child `MemberOutcome` 与 outer policy；终态后输入被拒绝，不能重启 closed member。
7. `ProjectionCheckpoint` 至少覆盖每个 child position/generation、operator revision、output commit position，以及 correction 所需 member/pair/window state 或 replay 证据；否则不要声称修订可重建。
8. 在 EF04 时序末尾增加一个有限 late-after-terminal 分支：旧 operator gate 拒绝 correction；新 `ProjectionRequested` 创建新 owner/invocation 后才可 replay/resync。`

### EF05

保留现有 FX/valuation/order sync 不产生 dispatch 的边界。在 `ValuationProjected` 关系后明确它是 EF04 join 的一个业务实例：账户值、FX observation、currency/as-of relation、quality/coverage 和 output revision 必须进入 lineage。FX correction 或账户 currency correction 只修订/撤回 valuation projection，不创建新的 Order/Dispatch；outer valuation query 已终止时由新 capture/projection 消费。

## 11. 旧承接与实现/原生义务

### 已有旧行为可承接的部分

- Bars 旧路径在单一 source 上执行 provider-specific window sizing、upper-bound post-filter 和 tail finalize，并在结果 metadata 保留 source/barId/capability（`src/domain/market-data/bars/bar-service.ts:193–234,237–274`；`src/domain/market-data/bars/types.ts:56–123`）。可承接为有限 Pull + source policy；不能从它推出 Push correction、provider watermark 或跨源 join。
- RSS 旧路径逐 feed 隔离失败并以 GUID/link/hash 去重，store 用本地 monotonic seq 写入、按 `pubTs` 查询排序。可承接为有限 News source/merge 输入；不能把 seq 当 publication 全序，也不能把同 GUID 内容变更当 correction。
- 账户/FX 旧路径已明确相同 base currency 才直接汇总；混合币种保留 broker 值或由 provider 自己以 USD 估值。可承接为 provider-specific policy/Partial，而不是通用 join 完整性。
- 旧 order-history 通过 orderId/Git commit 对齐 fill，并按 commit timestamp 排序（`services/uta/src/domain/trading/order-history.ts:134–251`）；这证明旧 projection 有 join-like 行为，但没有稳定 provider execution identity、correction 或跨重启的 source lineage。迁移到 EF05 的 typed observations 仍是实现义务。

### 尚未由设计或旧源码证明的实现义务

1. 每个 provider 是否有稳定 source identity、revision、replay/cursor、watermark、finality、correction/retraction；必须按 provider/version/account 实测，不能由函数名或 capability 名称猜。
2. Push resource 的真实 Shared/Exclusive、credit、overflow、native cancel、重连 generation 和 cleanup 语义；EF03 的关系仍是目标设计。
3. Filter/window/join 的持久 state、projection checkpoint、输出 identity 冲突和 correction 重算实现；特别是不可逆 aggregate 的成员保留/replay。
4. 真实账户/FX snapshot 的 as-of 一致性、币种/乘数/质量证据和 provider Partial 行为；`Promise.all` 或本地 capture 时间不能替代原生证据。
5. EF05 writer 对 selected observation/projection 的原子提交与重启恢复；普通 live frame 仍不能全部写入交易 WAL。
6. 真实跨进程 late correction、新 projection identity 和旧 invocation fencing；没有这条实现验证，不能声称“终止后不继续发”已经落地。

## 12. 给 Main 的最终裁决边界

本轮可以采纳的正面结论是：在 operator 声明给出 child binding、纯业务函数、identity/revision、coverage/terminal/late policy 和 resource attachment 前提时，单一纯 `step` 加资源解释边界足以构造 filter/window/join/merge 的有限消费关系；它能保持来源、失败、修订、覆盖、终态和资源 owner 的关联，而不需要新增通用工作流语言或 Provider 特判。

不能采纳的更强结论包括：

- “EF04 已列出 operator 名称，所以 filter/window/join 已经有完整构造”；
- “输入字段/输出 schema 相同，所以 filter/window/join 可任意交换或透明”；
- “两个异步读取一起返回就是同一时点快照”；
- “窗口 deadline、无 FX、缺 join side、空数组或 child terminal 可以由最佳努力策略自动转成 Complete”；
- “outer terminal 后 correction 可以继续投递给旧流”；
- “Provider capability 或 digest 自动证明 predicate、canonicalization、watermark、finality、replay 或业务函数正确”。

因此这份报告只完成数据组合支线的必要正面构造与修改定位；它不整体宣称当前 UTA 设计完成。