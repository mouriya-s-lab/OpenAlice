import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { readFile } from 'node:fs/promises';
const requireUi = createRequire(resolve('ui/package.json'));
const { marked } = requireUi('marked');
const files = ['AGENTS.md','docs/README.md','docs/uta-capability-runtime-design.md','docs/uta-capability-runtime-design/event-flows.md','docs/uta-capability-runtime-design/current-research.md','docs/uta-capability-runtime-design/research-practice.md','plans/uta-core-design-research.md'];
console.log(JSON.stringify({node: process.version, marked: requireUi('marked/package.json').version, documents: files.length}));
for (const file of files) {
  const text = await readFile(file, 'utf8');
  const tokens = marked.lexer(text);
  const html = await marked.parse(text);
  console.log(JSON.stringify({file, tokens: tokens.length, tables: tokens.filter((token) => token.type === 'table').length, htmlBytes: Buffer.byteLength(html)}));
}
