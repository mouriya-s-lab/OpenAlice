; UTA activation/control relation, not an implementation or a test.
; One already committed request for one fixed intent revision and basis token.
; All definitions are assertion-free. Invariants are checked by external obligations.
; Int is mathematical/unbounded. No transition-depth or revision bound is imposed.
(set-option :produce-models true)
(set-option :timeout 30000)

(declare-const origin Int)
(declare-datatypes ()
  ((Control Waiting
            (Handling (handleBasis Int))
            (Prepared (preparedBasis Int))
            (Approved (approvedBasis Int))
            (Started (attemptBasis Int) (startTime Int)))
   (Invalidation Uncorrected (Invalidated (invalidationTime Int)))
   (Receipt NoReceipt AcceptedReceipt)
   (Grant Empty Held Consumed Lost)
   (Recovery Normal Observe)
   (Output NoOutput HandleReceiptOutput FreshGrantOutput AlreadyStartedOutput
           StaleOutput NativeOutput ObserveOutput)
   (State (state (clock Int) (reviewRevision Int) (jobRevision Int)
                 (control Control) (receipt Receipt) (invalidation Invalidation)
                 (grant Grant) (issued Int) (nativeCalls Int)
                 (recovery Recovery) (output Output)))))

; Basis is copied from the committed request, then from the previous control.
; The Waiting branch is only a total-function value, not an existing handle.
(define-fun basis ((c Control)) Int
  (ite ((_ is Handling) c) (handleBasis c)
  (ite ((_ is Prepared) c) (preparedBasis c)
  (ite ((_ is Approved) c) (approvedBasis c)
  (ite ((_ is Started) c) (attemptBasis c) origin)))))

; Current eligibility is a projection of the SAME authoritative state.
; It is not the historical receipt, nor an independently cached job revision.
(define-fun eligible ((s State)) Bool
  (and (not (= (control s) Waiting))
       (= (basis (control s)) (reviewRevision s))))

(define-fun Init ((s State)) Bool
  (= s (state 0 origin 0 Waiting NoReceipt Uncorrected Empty 0 0 Normal NoOutput)))

; Reply is schema/identity validated before this abstraction. It reads origin
; from the committed request, never from caller-supplied business data.
(define-fun Reply ((s State) (t State)) Bool
  (and (= (control s) Waiting) (= (reviewRevision s) origin)
       (= t (state (+ (clock s) 1) (reviewRevision s) (+ (jobRevision s) 1)
                   (Handling origin) AcceptedReceipt (invalidation s)
                   (grant s) (issued s) (nativeCalls s) (recovery s)
                   HandleReceiptOutput))))

; Off-writer preparation reads are abstracted away. This is result ADMISSION,
; not the external read itself. A late result still has to consume the basis.
(define-fun RecordPrepared ((s State) (t State)) Bool
  (and ((_ is Handling) (control s)) (eligible s)
       (= t (state (+ (clock s) 1) (reviewRevision s) (+ (jobRevision s) 1)
                   (Prepared (basis (control s))) (receipt s) (invalidation s)
                   (grant s) (issued s) (nativeCalls s) (recovery s) NoOutput))))

; All other approval/reservation/plan conditions are an abstract admission
; precondition. They are NOT proved by this relation.
(define-fun ApproveSchedule ((s State) (t State)) Bool
  (and ((_ is Prepared) (control s)) (eligible s)
       (= t (state (+ (clock s) 1) (reviewRevision s) (+ (jobRevision s) 1)
                   (Approved (basis (control s))) (receipt s) (invalidation s)
                   (grant s) (issued s) (nativeCalls s) (recovery s) NoOutput))))

; Atomic invalidation: changing this authority changes ALL derived eligibility
; in this same step. Existing historical control/receipt records are retained.
; A committed attempt never reverts, and an already issued live grant survives.
(define-fun Correction ((s State) (t State)) Bool
  (= t (state (+ (clock s) 1) (+ (reviewRevision s) 1) (jobRevision s)
              (control s) (receipt s)
              (ite (= (invalidation s) Uncorrected)
                   (Invalidated (+ (clock s) 1)) (invalidation s))
              (grant s) (issued s) (nativeCalls s)
              (ite ((_ is Started) (control s)) Observe (recovery s)) NoOutput)))

; Only this transition both commits Started and returns a fresh private grant.
; The independent job CAS is necessary here but explicitly NOT sufficient.
; issued is a ghost event counter: it is INCREMENTED, not assigned the target 1.
(define-fun FreshStart ((s State) (t State) (expectedJob Int)) Bool
  (and ((_ is Approved) (control s)) (= expectedJob (jobRevision s)) (eligible s)
       (= t (state (+ (clock s) 1) (reviewRevision s) (+ (jobRevision s) 1)
                   (Started (basis (control s)) (+ (clock s) 1))
                   (receipt s) (invalidation s) Held (+ (issued s) 1)
                   (nativeCalls s) (recovery s) FreshGrantOutput))))

; No fresh output on replay. An old sender's existing Held token may still
; exist; preserving it is NOT returning it to this duplicate caller.
(define-fun RepeatStart ((s State) (t State)) Bool
  (and ((_ is Started) (control s))
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) (grant s)
                   (issued s) (nativeCalls s) (recovery s) AlreadyStartedOutput))))

; Generic idempotent receipt replay returns only the historical handle receipt.
(define-fun RepeatReply ((s State) (t State)) Bool
  (and (= (receipt s) AcceptedReceipt)
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) (grant s)
                   (issued s) (nativeCalls s) (recovery s) HandleReceiptOutput))))

(define-fun RejectReply ((s State) (t State)) Bool
  (and (= (control s) Waiting) (not (= (reviewRevision s) origin))
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) (grant s)
                   (issued s) (nativeCalls s) (recovery s) StaleOutput))))

(define-fun RejectPrepared ((s State) (t State)) Bool
  (and ((_ is Handling) (control s)) (not (eligible s))
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) (grant s)
                   (issued s) (nativeCalls s) (recovery s) StaleOutput))))

(define-fun RejectStart ((s State) (t State) (expectedJob Int)) Bool
  (and ((_ is Approved) (control s))
       (or (not (eligible s)) (not (= expectedJob (jobRevision s))))
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) (grant s)
                   (issued s) (nativeCalls s) (recovery s) StaleOutput))))

; Actual process loss destroys a live process-local grant. It does NOT erase
; DispatchStarted or conclude that native transmission definitely did not occur.
(define-fun ProcessLoss ((s State) (t State)) Bool
  (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
              (control s) (receipt s) (invalidation s)
              (ite (= (grant s) Held) Lost (grant s))
              (issued s) (nativeCalls s)
              (ite ((_ is Started) (control s)) Observe (recovery s)) NoOutput)))

; A scheduling lease expiry is NOT process death: the old sender can continue.
(define-fun LeaseExpiry ((s State) (t State)) Bool
  (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
              (control s) (receipt s) (invalidation s) (grant s)
              (issued s) (nativeCalls s)
              (ite ((_ is Started) (control s)) Observe (recovery s)) NoOutput)))

; Recovery is conservative without stronger provider evidence authorizing resend.
; Before Start it preserves pending work; after Start it schedules observation.
(define-fun Recover ((s State) (t State)) Bool
  (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
              (control s) (receipt s) (invalidation s) (grant s)
              (issued s) (nativeCalls s)
              (ite ((_ is Started) (control s)) Observe (recovery s)) ObserveOutput)))

; Symbolic physical-call event only; this file performs NO provider IO.
; No eligibility recheck is assumed here. Hence native execution can follow a
; correction if Start committed first. The token is consumed exactly once.
(define-fun NativeCall ((s State) (t State)) Bool
  (and ((_ is Started) (control s)) (= (grant s) Held)
       (= t (state (+ (clock s) 1) (reviewRevision s) (jobRevision s)
                   (control s) (receipt s) (invalidation s) Consumed
                   (issued s) (+ (nativeCalls s) 1) (recovery s) NativeOutput))))

(define-fun Step ((s State) (t State) (expectedJob Int)) Bool
  (or (Reply s t) (RecordPrepared s t) (ApproveSchedule s t) (Correction s t)
      (FreshStart s t expectedJob) (RepeatStart s t) (RepeatReply s t)
      (RejectReply s t) (RejectPrepared s t) (RejectStart s t expectedJob)
      (ProcessLoss s t) (LeaseExpiry s t) (Recover s t) (NativeCall s t)))

; Candidate inductive strengthening, NOT a transition guard or global assertion.
; Each clause must hold initially and be preserved by EACH independently defined
; transition. In particular, Start/correction chronology is proved, not assumed
; as a precondition of Correction or FreshStart.
(define-fun Inv ((s State)) Bool
  (and (>= (clock s) 0) (>= (jobRevision s) 0)
       (>= (reviewRevision s) origin)
       (= (= (invalidation s) Uncorrected) (= (reviewRevision s) origin))
       (=> ((_ is Invalidated) (invalidation s))
           (and (> (invalidationTime (invalidation s)) 0)
                (<= (invalidationTime (invalidation s)) (clock s))))
       (=> (not (= (control s) Waiting)) (= (basis (control s)) origin))
       (= (= (receipt s) NoReceipt) (= (control s) Waiting))
       (ite ((_ is Started) (control s))
            (and (= (issued s) 1) (not (= (grant s) Empty))
                 (> (startTime (control s)) 0)
                 (<= (startTime (control s)) (clock s)))
            (and (= (issued s) 0) (= (grant s) Empty)
                 (= (nativeCalls s) 0) (= (recovery s) Normal)))
       (= (nativeCalls s) (ite (= (grant s) Consumed) 1 0))
       (=> (and ((_ is Started) (control s))
                ((_ is Invalidated) (invalidation s)))
           (< (startTime (control s)) (invalidationTime (invalidation s))))
       (=> (= (output s) FreshGrantOutput)
           (and ((_ is Started) (control s)) (= (grant s) Held)))))

; DELIBERATELY WRONG ALTERNATIVE: a valid independent job CAS, but no
; consumption of the inherited activation basis. All other updates are IDENTICAL
; to FreshStart. Correction changes reviewRevision, not this independent job CAS.
(define-fun BadFreshStart ((s State) (t State) (expectedJob Int)) Bool
  (and ((_ is Approved) (control s)) (= expectedJob (jobRevision s))
       (= t (state (+ (clock s) 1) (reviewRevision s) (+ (jobRevision s) 1)
                   (Started (basis (control s)) (+ (clock s) 1))
                   (receipt s) (invalidation s) Held (+ (issued s) 1)
                   (nativeCalls s) (recovery s) FreshGrantOutput))))
