"""Emit SMT proof obligations and run installed Z3; no UTA code or IO is loaded."""
from dataclasses import dataclass
from enum import StrEnum
from hashlib import sha256
from pathlib import Path
import platform
import shutil
import subprocess
import sys


class Result(StrEnum):
    SAT = "sat"
    UNSAT = "unsat"


@dataclass(frozen=True)
class Obligation:
    name: str
    formula: str
    expected: Result
    declarations: tuple[str, ...] = ()
    values: tuple[str, ...] = ()


TRANSITIONS = (
    "Reply", "RecordPrepared", "ApproveSchedule", "Correction", "FreshStart",
    "RepeatStart", "RepeatReply", "RejectReply", "RejectPrepared", "RejectStart",
    "ProcessLoss", "LeaseExpiry", "Recover", "NativeCall",
)


def relation(name: str, before: str = "s", after: str = "t") -> str:
    match name:
        case "FreshStart" | "RejectStart" | "BadFreshStart":
            return f"({name} {before} {after} expectedJob)"
        case _:
            return f"({name} {before} {after})"


def trace(name: str, actions: tuple[str, ...], conclusion: str) -> Obligation:
    states = tuple(f"q{i}" for i in range(len(actions) + 1))
    edges = tuple(
        relation(action, states[i], states[i + 1])
        for i, action in enumerate(actions)
    )
    formula = "(and (= origin 0) (Init q0) " + " ".join(edges) + " " + conclusion + ")"
    return Obligation(
        name, formula, Result.SAT,
        tuple(f"(declare-const {state} State)" for state in states),
        states + ("expectedJob",),
    )


def obligations() -> tuple[Obligation, ...]:
    result = [Obligation("init_implies_inv", "(and (Init s) (not (Inv s)))", Result.UNSAT)]
    result.extend(
        Obligation(
            f"preservation_{name}",
            f"(and (Inv s) {relation(name)} (not (Inv t)))",
            Result.UNSAT,
        )
        for name in TRANSITIONS
    )
    # These satisfiability obligations reject vacuous, impossible transitions.
    # They are not the induction argument and are not bounded model checking.
    result.extend(
        Obligation(f"enabled_{name}", f"(and (Inv s) {relation(name)})", Result.SAT)
        for name in TRANSITIONS
    )
    result.extend((
        Obligation(
            "invalidated_implies_no_current_eligibility",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (eligible s))",
            Result.UNSAT,
        ),
        Obligation(
            "invalidated_cannot_admit_reply",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (Reply s t))",
            Result.UNSAT,
        ),
        Obligation(
            "invalidated_cannot_admit_prepared",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (RecordPrepared s t))",
            Result.UNSAT,
        ),
        Obligation(
            "invalidated_cannot_fresh_start",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (FreshStart s t expectedJob))",
            Result.UNSAT,
        ),
        Obligation(
            "invalidated_cannot_gain_any_new_grant",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (Step s t expectedJob) (> (issued t) (issued s)))",
            Result.UNSAT,
        ),
        Obligation(
            "at_most_one_grant_per_fixed_intent_revision",
            "(and (Inv s) (or (< (issued s) 0) (> (issued s) 1)))",
            Result.UNSAT,
        ),
        Obligation(
            "grant_history_never_decreases",
            "(and (Inv s) (Step s t expectedJob) (< (issued t) (issued s)))",
            Result.UNSAT,
        ),
        Obligation(
            "recovery_and_replay_never_issue_grant",
            "(and (Inv s) (or (ProcessLoss s t) (LeaseExpiry s t) (Recover s t) (RepeatStart s t) (RepeatReply s t)) (or (not (= (issued t) (issued s))) (= (output t) FreshGrantOutput)))",
            Result.UNSAT,
        ),
        Obligation(
            "historical_receipt_is_retained",
            "(and (Inv s) (= (receipt s) AcceptedReceipt) (Step s t expectedJob) (not (= (receipt t) AcceptedReceipt)))",
            Result.UNSAT,
        ),
        Obligation(
            "started_attempt_never_reverts_or_changes_identity",
            "(and (Inv s) ((_ is Started) (control s)) (Step s t expectedJob) (not (= (control t) (control s))))",
            Result.UNSAT,
        ),
        Obligation(
            "native_event_has_preexisting_committed_start",
            "(and (Inv s) (NativeCall s t) (or (not ((_ is Started) (control s))) (>= (startTime (control s)) (clock t))))",
            Result.UNSAT,
        ),
        Obligation(
            "correction_of_started_work_requires_observation",
            "(and (Inv s) ((_ is Started) (control s)) (Correction s t) (not (= (recovery t) Observe)))",
            Result.UNSAT,
        ),
        Obligation(
            "bad_independent_job_cas_breaks_induction",
            "(and (Inv s) ((_ is Invalidated) (invalidation s)) (BadFreshStart s t expectedJob) (not (Inv t)))",
            Result.SAT, values=("origin", "s", "t", "expectedJob"),
        ),
    ))
    result.extend((
        trace(
            "witness_valid_start_then_native",
            ("Reply", "RecordPrepared", "ApproveSchedule", "FreshStart", "NativeCall"),
            "(and (= (issued q5) 1) (= (nativeCalls q5) 1))",
        ),
        trace(
            "witness_correction_before_reply",
            ("Correction", "RejectReply"),
            "(and (= (control q2) Waiting) (= (receipt q2) NoReceipt) (= (issued q2) 0))",
        ),
        trace(
            "witness_late_prepare_rejected_historical_receipt_replayed",
            ("Reply", "Correction", "RejectPrepared", "RepeatReply"),
            "(and ((_ is Handling) (control q4)) (= (receipt q4) AcceptedReceipt) (not (eligible q4)) (= (issued q4) 0))",
        ),
        trace(
            "witness_correction_before_start",
            ("Reply", "RecordPrepared", "ApproveSchedule", "Correction", "RejectStart", "RepeatReply"),
            "(and (= expectedJob (jobRevision q4)) (= (receipt q6) AcceptedReceipt) (not (eligible q6)) (= (issued q6) 0))",
        ),
        trace(
            "witness_native_after_committed_correction",
            ("Reply", "RecordPrepared", "ApproveSchedule", "FreshStart", "Correction", "NativeCall"),
            "(and (= (nativeCalls q4) 0) (= (nativeCalls q5) 0) (= (nativeCalls q6) 1) (= (issued q6) 1) (= (recovery q6) Observe))",
        ),
        trace(
            "witness_lost_grant_recovery_repeat_start",
            ("Reply", "RecordPrepared", "ApproveSchedule", "FreshStart", "ProcessLoss", "Recover", "RepeatStart"),
            "(and (= (grant q7) Lost) (= (issued q7) 1) (= (nativeCalls q7) 0) (= (output q7) AlreadyStartedOutput) (= (recovery q7) Observe))",
        ),
        trace(
            "witness_expired_lease_old_sender_can_continue",
            ("Reply", "RecordPrepared", "ApproveSchedule", "FreshStart", "LeaseExpiry", "Recover", "NativeCall", "RepeatStart"),
            "(and (= (grant q6) Held) (= (issued q8) 1) (= (nativeCalls q8) 1) (= (output q8) AlreadyStartedOutput))",
        ),
        trace(
            "counterexample_review_only_correction_independent_job_start",
            ("Reply", "RecordPrepared", "ApproveSchedule", "Correction", "BadFreshStart"),
            "(and (Inv q4) (not (Inv q5)) (= expectedJob (jobRevision q4)) (> (startTime (control q5)) (invalidationTime (invalidation q5))) (= (issued q5) 1))",
        ),
    ))
    return tuple(result)


def main() -> int:
    directory = Path(__file__).resolve().parent
    model_path = directory / "control-model.smt2"
    solver = shutil.which("z3")
    if solver is None:
        raise RuntimeError("Installed z3 is unavailable; no proof claim is possible")
    problems = obligations()
    sections = [model_path.read_text(), "(declare-const s State)", "(declare-const t State)", "(declare-const expectedJob Int)"]
    for problem in problems:
        sections.extend((f'(echo "OBLIGATION {problem.name} EXPECT {problem.expected}")', "(push 1)"))
        sections.extend(problem.declarations)
        sections.extend((f"(assert {problem.formula})", "(check-sat)"))
        if problem.values:
            sections.append("(get-value (" + " ".join(problem.values) + "))")
        sections.append("(pop 1)")
    query_path = directory / "obligations.smt2"
    query_path.write_text("\n".join(sections) + "\n")
    version = subprocess.run([solver, "-version"], capture_output=True, text=True, check=True)
    command = [solver, "-smt2", "-T:60", str(query_path)]
    completed = subprocess.run(command, capture_output=True, text=True, timeout=70, check=False)
    (directory / "solver-stdout.txt").write_text(completed.stdout)
    (directory / "solver-stderr.txt").write_text(completed.stderr)
    observed = tuple(line.strip() for line in completed.stdout.splitlines() if line.strip() in ("sat", "unsat", "unknown"))
    matched = len(observed) == len(problems) and all(
        status == problem.expected for status, problem in zip(observed, problems)
    )
    successful = completed.returncode == 0 and "(error " not in completed.stdout and matched
    record = [
        "PURPOSE: symbolic induction and satisfiability obligations, not product tests",
        "SOLVER: " + version.stdout.strip(),
        "PYTHON: " + platform.python_version(),
        "DRIVER: " + str(Path(__file__).resolve()),
        "COMMAND: " + " ".join(command),
        "EXIT: " + str(completed.returncode),
        "OBLIGATIONS: " + str(len(problems)),
        "OBSERVED: " + str(len(observed)),
        "UNSAT: " + str(observed.count("unsat")),
        "SAT: " + str(observed.count("sat")),
        "UNKNOWN: " + str(observed.count("unknown")),
        "ALL EXPECTED RESULTS: " + str(successful),
    ]
    record.extend(
        f"{problem.name}: expected={problem.expected}; observed={status}"
        for problem, status in zip(problems, observed)
    )
    record.extend(
        "SHA256 " + path.name + " " + sha256(path.read_bytes()).hexdigest()
        for path in (model_path, Path(__file__).resolve(), query_path)
    )
    record.append("STDERR: " + ("empty" if not completed.stderr else "see solver-stderr.txt"))
    (directory / "execution.txt").write_text("\n".join(record) + "\n")
    print("\n".join(record))
    return 0 if successful else 1


if __name__ == "__main__":
    sys.exit(main())
