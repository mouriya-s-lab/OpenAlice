# UTA 激活依据与 Start 的形式核对

## 结论及证据范围

使用本机实际安装的 **Z3 5.1.0（64 bit）**，对一个固定 IntentRevision、一个已提交请求所继承依据、一个 writer 原子提交域建立 SMT-LIB 状态关系。实际执行 **50 项求解义务：27 unsat、23 sat、0 unknown**，进程退出码 0，stderr 为空。完整结果与逐项状态见 `execution.txt:1-66`；未经摘录的 solver stdout 见 `solver-stdout.txt:1-473`。

在这个明确抽象中，初态及全部 14 种转移保持归纳不变量；由此得到：

- 已提交的依据失效不能再接纳旧回复、旧准备结果或新的 FreshStart。
- 历史接纳 receipt 不等于当前推进资格。
- 没有更强重发证据的恢复、租约到期及重复 Start，不会为同一固定意图修订颁发第二个 grant。
- Started 记录不能被恢复退回未开始；grant 已颁发不表示 native call 已发生。
- Correction 不撤回既有 live grant。求解器给出了 **Start 已提交、Correction 随后提交、native call 再发生** 的合法模型。

删除 Start 对共同依据的消费、只保留独立 job CAS 的对照模型，实际得到 Correction 在先、旧 job FreshStart 在后的反例。

这些结果不宣布 UTA 整体设计完成，不证明实现符合规格，不代替业务契约、依赖充分性或原生保证。

## 文件与复现

全部文件位于 `local://uta-current-research/formal/`，没有修改仓库，没有运行产品样例、项目 build/lint/formatter 或测试，没有连接 Broker、读取凭据或使用 Docker。

| 文件 | 用途 |
|---|---|
| `control-model.smt2` | 196 行可独立审阅的状态类型、14 种转移、候选不变量、错误替代 |
| `prove_control.py` | 仅使用 Python 标准库，拼接证明义务并调用实际 Z3，不导入 UTA |
| `obligations.smt2` | 驱动生成的完整独立 SMT-LIB 输入；内含原规格，不依赖 include 或 Python 库 |
| `solver-stdout.txt` | 全部原始 Z3 输出，包括每项 sat/unsat 及完整状态赋值 |
| `solver-stderr.txt` | 完整 stderr，此次为空 |
| `main-solver-stdout.txt`、`main-solver-stderr.txt` | Main 直接运行已生成义务的完整独立复跑输出；stdout 经其 `cmp` 核对与原输出逐字节一致，stderr 为空 |
| `execution.txt` | 实际版本、绝对执行命令、退出码、逐项判定和输入 SHA-256 |
| `sources.txt` | 设计来源、实际工具版本和官方工具文档 URL；归档保留 |

### 可移植的归档复现

解压后进入归档内的 `formal/` 目录，以下命令都在该目录运行。**不需要原工作站路径、OpenAlice checkout、网络连接、Context7、Python 第三方库或凭据。** 仅求解现有义务需要 PATH 中实际可用的 `z3`；重新生成义务另需提供标准库 `StrEnum` 的 Python，本次实际验证版本为 3.14.7。原机器绝对路径仅作为历史执行记录保留在 `execution.txt`，不是输入中的依赖。

首选直接复跑归档内完整 SMT 输入，并将新输出另存，保留原始证据：

```sh
z3 -version
z3 -smt2 -T:60 obligations.smt2 > replay-solver-stdout.txt 2> replay-solver-stderr.txt
```

需重新生成全部义务并自动核对每项预期结果时，在归档的工作副本内运行：

```sh
python3 prove_control.py
```

驱动从自身文件所在目录读取 `control-model.smt2`，重新生成 `obligations.smt2`，调用 PATH 中的 Z3，并重新写入 `execution.txt`、`solver-stdout.txt`、`solver-stderr.txt`。预期为 50 项：27 unsat、23 sat、0 unknown，`ALL EXPECTED RESULTS: True`，退出码 0。任何 unknown、少项、错误或判定不符都不算复现成功。

原求解使用 Z3 5.1.0（64 bit）、Python 3.14.7；SMT 输入为每个 check-sat 设置 30000ms timeout，CLI 总超时为 60 秒。求解器版本不同可能改变 sat 的具体赋值和打印格式，不能把跨版本 stdout 字节不同直接当作性质被推翻；需要核对每项义务的判定及模型所满足的公式。没有实际复核其他版本的行为。

### Main 的独立复跑记录

Main 阅读 196 行规格及全部 obligation 查询后，使用同一实际版本 Z3 5.1.0（64 bit）直接执行 `z3 -smt2 -T:60 obligations.smt2`，没有通过 Python 驱动包装求解。其完整输出保存为 `main-solver-stdout.txt` 和 `main-solver-stderr.txt`。Main 运行 `cmp` 得到两份 stdout 逐字节相同，stderr 为空。

这项记录证明既有完整 SMT 输入可独立执行并复现原结果；它是同一求解器的独立复跑，不是第二套证明算法、产品代码测试、业务证据或新增证明范围。

### 最小归档集合

保留规格、驱动、完整 SMT 输入、两次运行的 stdout/stderr、`execution.txt`、`report.md` 和 `sources.txt`，即可保留形式论证与可复现证据。`context7-z3.json` 和 `z3-basiccommands.html` 只是研究时取得的工具文档副本，不被规格、驱动或输入读取，可以从归档排除；必要官方出处已在 `sources.txt` 保留。

## 状态抽象

`State` 是**持久控制、进程内资源及证明观察量的数学乘积**，不是拟议数据库 schema，也不表示其中每项都应序列化。

| 数学对象 | 解释与边界 |
|---|---|
| `origin` | 固定请求的已提交依据 token。连同单一 IntentRevision、A、epoch、checkpoint/证据的身份关系被抽象成这个不可变标签；不是从回复输入取值 |
| `reviewRevision` | 此依据在 UTA 权威域中的当前有效版本，不是 Alice UI 或独立 review 缓存版本 |
| `jobRevision` | 工作自己的 CAS 版本。Reply、RecordPrepared、批准/排程、FreshStart 递增；Correction 不靠递增这个独立版本来实现安全 |
| `Control` | ADT：Waiting、Handling(basis)、Prepared(basis)、Approved(basis)、Started(basis,startTime)。后四种保留继承的依据；Started 是持久开始记录 |
| `receipt` | 接纳的历史事实，建立后不因 Correction 删除；它不携带执行授权 |
| `eligible(s)` | 当前继承依据是否仍被共同权威接受。它不是全部业务授权，也不单独表示可以 FreshStart；后者另需 Approved 与匹配 job CAS |
| `invalidation` | 记录第一次使旧依据失效的转移位置。首次位置服务于证明，后续 Correction 不重置它 |
| `grant` | 原执行拥有者的进程内线性资源：Empty、Held、Consumed、Lost。持久 Started 与它是不同维度；Recover 不从持久记录重建 Held |
| `output` | 最近一步向该次调用者产生的抽象输出标签，不是持久 receipt 内容。FreshGrantOutput 与 AlreadyStartedOutput 明确不同 |
| `issued` | 颁发事件的无界整数 ghost counter，初态 0，FreshStart 执行 `issued + 1`，其他转移不增加 |
| `nativeCalls` | 数学观察者看到的私有 dispatcher 调用次数。不是恢复拥有者可用的“可信未发送证明”，转移不以它批准重发 |
| `clock` | 全局关系步号，包含 native/恢复/拒绝等步；不是物理时钟、lease 时钟或数据库版本 |
| `recovery` | Normal/Observe，表示开始后的保守观察责任；不证明观察工作最终送达或完成 |

初态是请求**已经提交但尚未回复**。不包含建立请求之前的数据判据或 Alice admission。Correction 可发生在任意阶段，也可重复发生；它递增权威依据版本，不把同一个旧依据重新变为有效。新的业务输入、Revise、计划退休/新修订和有更强证据的 resend 均不在这个固定修订模型中。

## 与当前主书规则的逐项对应

来源再次核对为 `[docs/uta-capability-runtime-design.md#91EF]`：§9.4 在 717–760 行，§10.3 在 847–853 行，§11.5 在 983–1000 行。后续主书插入段落会移动行号，节标题和 `activation-control-consumption` anchor 才是稳定定位。

| 主书规则 | 形式对应 | 规格位置 |
|---|---|---|
| §11.5 从已提交请求取回原依据，不相信回复复制事实 | Reply 只能从 Waiting 接纳；使用固定 `origin` 构造 Handling，不存在 caller-supplied basis 参数 | `control-model.smt2:43-50` |
| 同一决定建立 handle、工作与历史 receipt | Reply 的单个后态同时成为 Handling 并产生 AcceptedReceipt；Handling 隐含一项尚待 Prepare 的工作义务，不模拟 outbox 投递 | `:45-50` |
| Prepare 在 writer 外读取当前事实，迟到结果仍须接纳检查 | 只模型化 RecordPrepared 的提交，要求 Handling 且当前 basis 有效；外部读取可任意延迟，不赋予推进权 | `:52-58` |
| RecordPrepared、批准/排程、Start 不得丢失依据 | 三种转移复制上阶段 basis，并各自消费共同 `eligible` | `:54-87` |
| §9.4、§11.5 同一 writer 原子决定，失效和 Start 不得成为两个互不相关的 CAS | 每个转移是一个不可分割的前后态关系；Correction 改变 reviewRevision；Start 在同一前态读取继承 basis、reviewRevision 和 job CAS | `:68-87` |
| 未开始工作须同一权威写集失去资格 | 资格是共同权威状态的纯投影，Correction 同步使所有旧 basis 的资格变假。历史阶段标签可保留，不是仍可执行；没有最终一致资格缓存 | `:34-38,68-77` |
| 修订先于回复 | RejectReply；无新 handle、receipt 或 grant | `:104-108` |
| 回复后修订，准备尚未提交 | RejectPrepared；原 receipt 可 RepeatReply 返回，但仍不能 RecordPrepared | `:98-114` |
| 准备/批准后修订，Start 尚未提交 | RejectStart；即使 job CAS 正确仍因 basis 失效被拒绝 | `:116-121` |
| §9.4 Start 成功提交后只有本次拥有者取得私有 grant | FreshStart 同步建立 Started、颁发 Held、输出 FreshGrantOutput；只有这一步增加 issued | `:79-87` |
| 重复 Start 不能以历史 receipt 重放 grant | RepeatStart 输出 AlreadyStartedOutput；RepeatReply 输出 HandleReceiptOutput；均不增加 issued、不重建 Held | `:89-102` |
| §10.3 commit 不等于包已发送；lease 不等于发送许可 | NativeCall 为独立转移；ProcessLoss、LeaseExpiry、Recover 不回退 Started。lease 到期保留旧拥有者的 Held | `:123-154` |
| Start 先于修订，已获 grant 不能保证物理撤回 | Correction 保留 grant 与 Started，追加 Observe；NativeCall 不再假定 basis 有效，因此可在 Correction 后发生 | `:71-77,150-154` |
| Alice admission 独立 | 完全不放入 UTA 的原子关系，不声称跨系统 exactly-once 或事务一致性 | 模型范围 |

这里把“同一写集使工作失效”表示为当前资格的同步派生，而非强制某种 `Fenced` 存储列。具体实现可以原子更新物化状态，也可以在权威事务内消费相同有效性关系；本模型不批准从独立、可能过时的 job 字段推导资格。**共享存储/单 writer 本身仍不充分，正确的读依赖必须被实际消费。**

## 证明义务及非循环性

令 `I` 为 `Inv`，`T_k` 为 14 个独立定义的转移。实际提交给 Z3 的反例查询包括：

1. `Init(s) ∧ ¬I(s)`。
2. 对每个 k 分别查询 `I(s) ∧ T_k(s,t) ∧ ¬I(t)`。
3. 从已归纳的不变量推出各项安全结论，或排除包含错误事件的单步关系。

上述 1、2 的 15 项查询全为 unsat。自由常量 `s、t、origin、expectedJob` 不受有限枚举范围限制；反例不存在表示对应全称公式成立。由初态和逐转移归纳，结论适用于该抽象中**任意有限长度执行前缀**，也就是无限执行的安全前缀性质；不是“跑到深度 N 未见错误”。

`Inv` 的重要强化项是：

- 非 Waiting 控制始终携带 `origin`。
- 尚未 Correction 当且仅当当前依据版本等于 `origin`；Correction 后版本严格大于它。
- 接纳 receipt 与历史控制建立关系一致。
- 未 Started 时 `issued=0`；Started 后 `issued=1`，Started 身份保持。
- 若 Started 与 Invalidated 同时存在，`startTime < firstInvalidationTime`。
- native 观察计数与进程内 token 消费状态一致。

**没有把结论当作系统公理。** `control-model.smt2` 的全部转移定义不调用 `Inv`，没有全局 `(assert (Inv ...))`；FreshStart 不把 issued 硬赋为 1，而是无条件对先前事件计数加 1；Correction 不检查“没有晚于修订的 Start”才允许发生。不变量仅作为需要分别证明初态与保持性的候选强化，归纳步使用 `I(s)` 是数学归纳假设，不是跳过证明。历史先后条件自身也包含在被否定的后态不变量中接受反例搜索。

此外，各转移都有一项 `I(s) ∧ T_k(s,t)` 得到 sat，排除把某个转移写成不可发生而空泛证明安全的做法。这些启用性义务不代替归纳证明；下节另外提供由 Init 出发的实际可满足轨迹。

| 义务组 | 数量 | 实际结果 | 输出位置 |
|---|---:|---|---|
| 初态蕴涵不变量 | 1 | unsat | `solver-stdout.txt:1-2` |
| 14 种转移分别保持 | 14 | 全 unsat | `:3-30` |
| 14 种转移非空 | 14 | 全 sat | `:31-58` |
| 无新接纳/新 grant、receipt 保留、开始身份、物理先后、观察责任等推论 | 12 | 全 unsat | `:59-82` |
| 错误 Start 的归纳反例 | 1 | sat | `:83-108` |
| 七条正确关系边界轨迹 | 7 | 全 sat | `:109-434` |
| 错误模型从 Init 出发的五步反例 | 1 | sat | `:435-473` |

这是信任 Z3 实现的 SMT 判定支持的归纳论证；未另行导出并由独立 proof-assistant 内核检查证明证书。

## 实际反例：只检查独立 job revision

错误关系 `BadFreshStart`（规格 188–196 行）与正确 FreshStart 的后态更新完全相同；唯一删除的是 `(eligible s)`。它仍检查阶段为 Approved、`expectedJob = jobRevision`，因此不是省略全部准入条件的稻草人。

求解器给出的可达赋值如下（完整输出 `solver-stdout.txt:435-473`）：

| 步 | 转移 | reviewRevision | jobRevision | 历史控制 | 当前依据有效 | issued |
|---:|---|---:|---:|---|---|---:|
| 0 | Init，原请求已提交 | 0 | 0 | Waiting | 请求依据有效 | 0 |
| 1 | Reply | 0 | 1 | Handling(0) | 是 | 0 |
| 2 | RecordPrepared | 0 | 2 | Prepared(0) | 是 | 0 |
| 3 | ApproveSchedule | 0 | 3 | Approved(0) | 是 | 0 |
| 4 | Correction commit | 1 | 3 | Approved(0) | 否 | 0 |
| 5 | BadFreshStart，expectedJob=3 | 1 | 4 | Started(0,5) | 否 | 1 |

第一次失效位置为 4，开始位置为 5；旧 plan 的 basis 仍为 0，job CAS 却正确匹配 3。状态 q4 满足 `Inv`；错误转移产生 q5 不满足 `Inv`。这不是仅从不可达任意状态造出的反例，而是从 Init 出发、逐个正确 Reply/Prepare/Approve/Correction 后只替换 Start 的轨迹。正确模型在相同 q4 上只能拒绝这个 FreshStart。

## 必须保留的物理与恢复边界

### Correction 后仍然可以发生原 native call

实际 sat 轨迹 `witness_native_after_committed_correction`（输出 252–301 行）：

| 步 | 事件 | 开始记录 | grant | issued | nativeCalls | recovery |
|---:|---|---|---|---:|---:|---|
| 4 | FreshStart commit | Started(0,4) | Held | 1 | 0 | Normal |
| 5 | Correction commit | 同一 Started(0,4) | Held | 1 | 0 | Observe |
| 6 | NativeCall | 同一 Started(0,4) | Consumed | 1 | 1 | Observe |

因此机械结果证明的是不能**新取得 Start**，不是 Correction commit 后物理世界没有写入。`nativeCalls` 在这个论证中只是全知数学观察量，UTA 恢复者不能因此声称拿到了未发送证明。

### 恢复不新增 grant，不等于原 grant 消失

- `witness_lost_grant_recovery_repeat_start`（302–362 行）：Start 在第 4 步提交，第 5 步实际 ProcessLoss 使 Held 成为 Lost；Recover 和 RepeatStart 后 issued 仍为 1、输出 AlreadyStartedOutput，没有重建发送权。此轨迹的 nativeCalls 为 0，系统仍保留 Observe，不能盲目重发。
- `witness_expired_lease_old_sender_can_continue`（363–434 行）：Start 后 LeaseExpiry、Recover 均保留原 sender 的 Held；随后旧 sender 可以 NativeCall，最后 RepeatStart 不增加 grant。不能用 lease 到期或恢复者存在推出旧进程死亡。
- 重复 Start 时后态可能仍有旧 sender 的 Held，但该次输出明确为 AlreadyStartedOutput。这一区别阻止把“没有创建新 token”误说成“把现有 token 再返回了一遍”。

## 不能由此证明的事项与精化前提

1. **依赖充分性是前提。** 模型假定 `origin` 覆盖所有真正相关的激活依据，任何使它失效的已接纳 Correction 都改变这个共同权威版本。它不能识别漏列的行情修订、其他账户事实、策略依赖或 shared-risk 完整 readset；§10.5 新增内容没有纳入本任务。
2. **Provider truth 与及时性是前提外的业务事实。** 没有证明输入证据真实、final、完整、及时、同一时间切片，或 UTA 尚未收到的原生 Correction 已被消费。
3. **writer/storage 原子性是模型前提。** SMT 的单步关系不能证明 SQLite 实际隔离级别、事务写集、持久化、唯一约束、崩溃一致性、outbox 送达、投影未丢失依赖或客户端拿不到未提交成功。
4. **单修订、单激活拥有者、同一请求身份是范围条件。** 未建模恶意 key/binding 伪造、JCS/SHA 实现、去重清理、多个独立 admission 路径以及多个 IntentRevision 的联合性质。Reply 的解析/身份认证被视为边界已完成，不从本结果证明它们。
5. **私有 grant 的线性消费是规定的转移语义。** 没有检验实际语言/进程内资源能否被复制、串用 plan/attempt 或从公开查询泄漏。`State` 中出现 grant 不意味着允许把 grant 写进存储。
6. **Start commit 与 grant 交付间隙被安全抽象。** FreshStart 合并“已提交后向获胜拥有者交付”；紧随其后的 ProcessLoss 覆盖 commit 后响应/grant 丢失的保守情况。它不证明精确 crash point 的实现。
7. **NativeCall 不是真实 Broker 实验。** 没有发送请求、查询订单或证明 SDK/网络/Provider 恰好一次执行。模型仅约束该抽象 dispatcher 对一个线性 grant 的调用；远端重复、ack、fill、Unknown 的业务消解不在其中。
8. **更强证据下的合法 resend 不在转移集。** §10.3 允许有充分证据后更精确的重试；这里的“最多一个 grant”仅指固定修订在尚无该证据、只有普通恢复/重复 Start 的关系。不能据此禁止所有合法的新修订或把以后新增的 resend 转移视为已经证明。
9. **没有活性、业务批准、风险、计划内容或 Alice 跨域证明。** ApproveSchedule 抽象允许其他前提已经满足，不证明余额、价格、权限、批准、reservation、digest、不变计划的实际内容正确。没有证明最终执行、最终观察、公平调度、Alice admission 或跨系统原子性。

精确可采用的结论是：**在显式共同依据消费、单一原子 writer 及上述状态抽象成立时，模型的全部转移保持“失效后不能 fresh Start、普通恢复不新发 grant”；互不关联的 job CAS 不满足这项关系。**
