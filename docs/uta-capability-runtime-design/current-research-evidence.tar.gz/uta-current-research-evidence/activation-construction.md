# Deferred 声明怎样构造数据到控制的消费关系

## 结论与证据强度

本轮保留 `deferUntil`，不建立工作流语言，不增加 Candle/NewsGroup 核心分支。现有 `advance` 的三个结果可以保留，但只能承担**普通来源进展与连续性判断**；不能把它单独当作整个 deferred 控制机。必须从同一声明另行构造依赖修订消费者、决定请求构造器和回复/后继消费者。这些不是新增业务状态机，而是使 §§11.2–11.3 已承诺的 correction、rearm 和决定交接具有实际计算来源。

关键判断分开：

- **结构可成立：** 同一 `A/S/P/continuation` 关联能产生 source parser、checkpoint/evidence codec、依赖索引、请求/回复 parser 与持久后继；有限控制机不需要知道 close、vwap、标题或情绪的含义。
- **业务正确性有前提：** 声明者必须准确给出触发算法、状态初始化、支持证据与边界语义。schema、摘要和单一 writer 都不能证明某条 Candle 真能证明 crossing，也不能发现任意纯函数遗漏的证据依赖。
- **现稿不是空白：** §5.5 已给构造操作数；§11 已给主要控制承诺；§16.3 已给槽位派生原则；EF11 已明确继续一个已接纳 intent。需要补的是这些操作数怎样构成消费者以及跨阶段失效如何被实际消费，不是再列一批字段。

只读调查，未改仓库，未写代码/测试，未运行 validation。以下是形式构造与有限事件轨迹，不声称已经实现或运行。

## 1. 当前材料已经给了什么

主书均指 `docs/uta-capability-runtime-design.md`；EF 指 `docs/uta-capability-runtime-design/event-flows.md`。

| 已有前提 | 精确位置 | 本论证如何使用 |
|---|---|---|
| `deferUntil` 的共同操作数为未开始意图、source、predicate、continuation；一个意图版本只有一个 live owner | 主书 §5.5:466–475 | 不从来源事实重新构造另一个意图，不注册多个可各自激活的等待者 |
| predicate 版本/配置/单位/来源/checkpoint 版本冻结；非命中 checkpoint 也可能持久化 | 主书 §11.2:852–860；EF10:1251–1252 | 恢复需要原函数及其状态，而不是仅保存命中布尔值 |
| correction/retraction 按依赖处理，不要求当前再次命中；未开始栅栏，已开始/Unknown 保留 | 主书 §11.2:862；EF10:1231–1245、1253 | 修订消费不等于普通筛选或重新运行谓词 |
| RequestDecision 不批准；响应含 Keep/Rearm/Revise/Discard/RequestSubmission，受 request/版本/主体/期限约束 | 主书 §11.3:866–880 | 决定响应是受控命令，不是原生执行函数 |
| 同一声明派生事件 parser/codec/类型；历史读取使用原 binding/slot/实现身份 | 主书 §16.3:1178–1209 | `checkpoint` 与 `evidence` 的业务载荷不能在事件层手写另一份 DTO |
| 不保存函数；单一 writer 原子保存事件、决定性投影、工作/outbox 和 receipt | 主书 §9.1:631–637、§9.3:663–673、§9.4:679、§9.5:722–724 | 构造时可捕获函数，重启时必须重绑；依赖状态不能仅放最终一致缓存 |
| EF11 只消费已提交 request；RequestSubmission 是已接纳 intent 的控制请求 | EF11:1346–1351、1359–1365、1427–1434 | 恢复与回复都不重算原 predicate，不重做 SubmitIntent |

具体错接点：EF10:1216 写“进入 SubmitIntent/Prepare/Approval/guard/reservation”，与 EF11:1351、1428–1430 的 `SubmissionAdmitted` / `PrepareSubmission` 冲突。EF06:686 将 SubmitIntent 定义为外部意图接纳；这里已有精确 intent revision，应继续它的内部控制路径，而不是再次接纳另一意图。EF10:1168–1169 的“开启 EF06 接纳/重新走 EF06”也应明确是控制接纳，不是重交意图。

## 2. 可直接纳入主书的正面构造论证

### 2.1 作者提供的是计算关系，不是一组独立 schema

令 D 表示本次 deferred 声明关联的说明记号，不提议新增公共 API。其来源仍是 §5.5 的同一组操作数：

1. **A 与原意图。** 一个由原受控能力接纳、且当前未 DispatchStarted 的精确 IntentRevision，连同它的 A binding、输入与 scope。该引用只证明已接纳身份；调用时仍要复核“未开始”和当前控制拥有者，不能把一个曾经有效的值永久当成 NotStarted。
2. **S 来源计算。** 精确 source binding 及读取输入、单位、范围、generation/continuity/revision 契约；多个来源由一个已声明组合产生带来源的和/积，不靠裸 payload 合并。source 所需权限、资源及失败仍由来源解释层负责。
3. **P 谓词关联。** C checkpoint 与 E selected-evidence 的声明、纯进展函数、初始/重新武装状态构造，以及支持证据的选择关系。P 的算法、配置、实现及 schema 身份一起冻结。新增的候选明确化是：**不能只给 C 的 schema 就声称已经有初态或依赖关系**。作者要提供如何从已给配置和可信边界构造 C，以及 C/E 各自由哪些已认证来源事实支持；构造失败必须在接纳边界显式返回。
4. **continuation。** 冻结 disposition、责任渠道、允许的响应及各分支参数、无回复/到期/不可交付政策。响应中的新意图输入来自 A 的真实输入关联；rearm 所需新边界来自 S 的真实边界契约。自然语言解释可以随附，但不能充当控制解码器。

P 的初态、支持关系和响应所需配置不是从任意回调反射出来的性质。它们属于同一个 P/continuation 的声明与实现，不允许分别注册一个“看起来对应”的 checkpoint codec、依赖提取器和恢复函数。此要求沿用主书 §4.1:309–311 对结构派生与语义实现的区分。

### 2.2 构造器实际派生什么

| 共同操作数的投影 | 生成的实际消费者 | 对关系的约束 |
|---|---|---|
| S 的 item/control/revision 槽位与精确 binding | source 边界 parser 和分流消费者 | provider 只能给 ExternalFact；不存在的 correction/retraction 能力不能由内核补造 |
| P 的 C/E schema、初始化与 advance | 初次注册/rearm 的状态构造、普通进展闭包、C/E 编码器 | 消费 S 解码的值；生成的函数调用保存的 P，而不是根据业务字段选另一个 handler |
| P 的支持关系，加已认证 source refs、组合 lineage | checkpoint/evidence 持久依赖及修订目标消费者 | ref 必须解析到本声明允许的真实来源/历史节点；source identity 不因只是字符串相同而可互换 |
| D、C/E 的已提交引用和此次控制原因 | DecisionRequested 与 outbox 的构造器 | 请求从本次 writer 决定产生；不是 source 直接给出，更不从当前行情重新解释旧请求 |
| A 与 continuation 的有限响应声明 | Reply parser、分支消费者、receipt/status | Revise 的输入仍归 A；RequestSubmission 只能产生原 intent 的控制接纳；无分支能取出 native dispatch |
| 同一个 D 的完整 binding、实现身份、slot 与编码值 | 历史解码与消费者重建 | 恢复调用原 P/continuation；当前同形 schema 不替代旧语义 |

**数据到控制的切点**不是 `Candidate` 构造成功。纯函数提出 C′ 与 E 后，writer 同时保存 consumed-source identity、C′、选中证据及依赖、当前控制变化和必要 request/outbox，才得到 committed event。普通订阅者仍可只消费 S，不调用 deferUntil，不因此进入控制 journal。

### 2.3 依赖不是装饰字段：它从哪里来，怎样消费

采用一个最小可行候选：P 为自身的 C/E 声明**有限可表示、允许保守覆盖的支持证据选择**。函数可选择当前事实和保留的 checkpoint 支持，也可声明自己消费的整段来源输入范围；构造器验证引用/范围的身份、归属及可解析性，并保存关系，而不分析 close/vwap/NewsGroup 的业务内容。这里不要求支持集是语义依赖的最小精确集。范围表示必须能依据真实 source/partition/generation/position 契约判断修订目标是否落入，不能把接收时间区间冒充来源范围。

数学上，令 `support(x)` 为某个已保存 checkpoint 或 evidence 节点的直接支持集。若 x 保存了前一 checkpoint 的结果，支持关系可以指向那一 checkpoint，但不能在截断历史时把其尚有用的传递支持丢掉。决定 request 依赖此次 checkpoint/evidence；从该决定形成的 submission control 又依赖该决定依据。令 `depends*(x,t)` 表示沿这些已保存边可到达被修订事实 t。

对 correction/retraction r，先解析它认证的修订目标 `target(r)`，再求仍负有控制责任的受影响集合：

\[
Affected(r)=\{x\mid depends^*(x,target(r))\land x\text{仍有相关控制责任}\}.
\]

这里存在两个不同操作：

- **普通消费：** 用新来源进展和当前 C 判断是否构成一次新触发；未来边界、epoch 去重与当前 live owner 限制它。
- **依赖消费：** 找出旧已选依据受到什么修订，再对引用它的 checkpoint、request、未开始的工作或恢复责任演进。它不以新值仍满足 predicate 为前提，也不把“目标早于当前 future boundary”当作无关证据。

例如 crossing 选择 false 基线 b 和 true 事实 h。E 可以显示 h，但其充分依据还包含 b 与两者间所依赖的连续性。若修订 b 后变成 true，h 仍为 true，当前阈值谓词仍命中，却已不能证明原 false→true；只保存 h 的引用会漏失效。这说明支持集必须覆盖判断所用依据，不只是 UI 展示项。

类型能限制引用的出处并让 C/E/slot 不串绑；**不能证明作者声明的支持集覆盖了函数的全部语义依赖**。P 必须满足支持充分性：没有改变其支持依据、配置及已声明时间/连续性事实的替换，不能改变所承诺的判断与后继状态。实际语义依赖只需包含于声明支持；保守多报会触发额外冻结/重新决定，不会漏掉真正失效，但这项可用性代价必须是该政策允许的。任一声明支持变化进入修订消费范围，不等于其结果在业务上必然改变。这是一项业务/函数契约，不由“返回一个 refs 数组”、通过 codec 或绑定摘要自动成立；任意纯业务函数没有可假设存在的机械依赖提取器。

bounded checkpoint 也有真实边界：它必须保留仍影响未来判断的充分状态，以及仍被 live 控制/恢复责任引用的证据可解析性。不能以固定长度缓存丢弃仍被 request 或 submission 使用的支持。若某算法需要不可界定的历史才能证明自己，不能把它未经额外归档/界限契约塞入当前“有界 C”的承诺。

依赖留存还分两层：**当前 checkpoint 的未来计算支持**与**历史 selected evidence/decision 的后继责任支持**。Rearm 可以初始化新的 C 并不再沿用旧基线，却不能因此删除旧 request 已派生 submission/attempt 的证据关系。旧证据即使不再影响当前 P，也可能仍支持一个待开始控制或已开始尝试；其修订必须能查到相应旧责任拥有者。新 epoch 的普通数据 admission 栅栏不屏蔽这种历史目标查询；依赖消费只影响有实际或保守支持关联的节点，不把整个新 epoch 无条件作废。

### 2.4 三个 advance 结果的精确地位

保留主书 §11.2 的 NoActivation / Candidate(E) / Gap，条件如下：

- NoActivation 表示本步不提出激活，**不证明业务谓词为 False**，仍可带来 C′ 和去重位置的持久推进。初始化尚无基线、持续窗口尚未完成、quorum 的正常成员积累等，都可由具体 P 在 C 中表达并返回 NoActivation；不能把这些情况一律升级为 Gap 或强迫增加全局业务 variant。
- Candidate(E) 只是普通进展的候选，不是批准，不直接发请求；后续 writer 按冻结 disposition 构造持久结果。
- Gap 表示**声明所需连续性或证据关系出现缺口/受损，不能沿用相应判断依据**，不是所有业务未知或暂未满足条件的统称，也不允许伪装 Candidate。它的原因必须能由已认证输入、C′ 的相应状态及 P 的声明解释；如果这种解释还需要额外业务值，必须由同一 P 声明和产生，不能在 decision 层凭空编造。

这三个结果**足够表达普通进展，但不足以单独表达整个 deferred 生命周期**：返回类型中没有“失效某个旧已选依据/已创建 request/未开始 submission”的关系；强行把 correction 当 Gap 会丢掉修订目标，将其当 NoActivation 会漏 fence，将其当 Candidate 会伪造再次命中。

不必因此给 advance 再加一个业务枚举。可由 deferUntil 从同一 P 的支持关系生成依赖修订消费者，先消费 correction/retraction 的目标，再按现有控制状态和冻结政策形成写集。没有 replay、反函数或足够历史时，合法处理是把受影响状态判为失效、冻结未开始工作并等待新可信边界重建，而不是强求自动重算旧结果；有真实重算依据时才按已声明算法重算。必要时之后才在明确的重建政策下让新值参与普通进展。EF10:1183–1185 的图应明确这种分流，而不是先把 Data/Correction/Retraction/Gap 全部送入一个仅有三结果的函数，再在 opt 块补修订。

决定请求也不能假设每次都有 Candidate(E)。EF10:1194 明确允许 Gap 请求，1235 允许 correction 请求，主书 §11.3:880 允许 escalation。可使用这些**已有控制原因**形成有限选择：命中原因引用 E；连续性不足原因引用相应 source/control 事实和 C；修订原因引用 correction/retraction 及受影响旧依据；escalation 引用前一 request 与冻结政策。共同请求部分始终从 D 与原 intent 构造。这样既不假造 Gap 的 E，也不要求业务作者写一份与 P 脱离的 decision payload。

### 2.5 恢复不是重新创建这组关系

持久记录保存 D 的绑定、配置、C/E 编码、支持引用、epoch/future boundary、控制状态、request/outbox 和 receipts；不保存函数。重启分为两件事：

1. 用原 D 的 codec/evolve 读取已提交记录，重建已成立的控制关系；已有 request/outbox 继续原身份交付，不再调用 predicate 生成一次“同样的命中”。
2. 按原 D 的实现身份重建初态/进展/依赖/回复消费者，用于后续新输入。恢复订阅还必须重新取得真实 source 接纳与连续性证据；原 checkpoint 存在不证明重连无 gap。

缺原 P/continuation 时可以保留原 bytes、控制身份与已提交交付责任，但不能用当前函数继续判断。尚未开始的控制保持冻结或经显式新修订重建；已开始/Unknown 继续原尝试的恢复责任。旧函数仍存在也不自动授予当前数据权限，更不重新开放旧版发送。

## 3. RequestSubmission 怎样消费原决定，而不是重交意图

这里采用当前主书 §9.4 的同一 UTA 权威存储和单一 writer；EF10 activation、EF11 decision 与 EF06 effect 是语义职责，不假定它们各有互不协调的权威数据库。Alice admission 仍在另一持久边界，不需要被放入 UTA 事务。

把以下称为“决定依据”只是关系记号，不是新批准令牌：原 D、request/decision revision、IntentRevision、epoch、checkpoint/evidence 引用，以及这些依据当前是否被失效。

RequestSubmission 回复的消费过程是：

1. 按请求所属 D 的 reply slot 解析；查询已提交 DecisionRequested，核对主体/责任渠道、request/intent/epoch/expected state、期限和幂等键。不得相信回复复制过来的 evidence/plan 字段是事实来源。
2. 以请求解析回**已经接纳的原 IntentRevision 与 A**。验证其仍未开始、该决定仍是当前可消费决定，并验证被引用的激活依据未被失效。
3. 在同一 writer 决定中消费本次 response、建立原 intent 的 submission control handle，并把原 request 的依据关系延续到该 handle；保存必要 PrepareSubmission 工作与 reply receipt。新工作以 committed control handle 为因果，不以 AI 文本为批准。
4. EF06 消费此工作，从 handle 解析原 intent/A/控制关联。它按当前准入与真实事实需求执行 prepare 或复核有效准备结果，而不是调用 SubmitIntent 新建另一个 intent。激活证据证明“为什么进入此控制”，**不自动等于 A.ReadFacts，也不自动满足当前行情、余额、权限或风险检查**。
5. prepare worker 的结果只能提交到其所消费的原 intent revision 和仍有效的控制依据上。重新 prepare 不得悄悄改写精确意图；若业务修改 input，则由 Revise 创建新 IntentRevision，旧意图的批准与可写权不继承。若仅为未批准原意图重新取得事实/形成计划，则新准备结果仍明确归原 intent；若已有 immutable prepared 被替换，则按主书 §9.3:669 的显式新修订边界处理，而不是让同一个 plan digest 漂移。
6. 批准仍独立绑定实际新计划及其 scope/policy/expiry。原 request 的关联不因 prepare 成功或有人批准新计划而自动消失；只要当前 continuation 承诺 correction 栅栏未开始工作，后续 RecordPrepared、批准/排程和 Start 都要消费这项仍有效的控制依据。receipt 的历史成功不等于以后仍可开始。

这一继承不是因为几个字段值相同。它来自**只有 writer 可从已提交 request 构造 submission handle，并把同一依据关系接到该 handle 的后继**。普通外部 RequestSubmission 没有 deferred 来源时，不需要假造一个 deferred slot；这是带真实因果依据的已有控制路径实例，不是 Candle/News 的特殊入口。

## 4. correction、reply、prepare 与 Start 的双向次序推导

设 q 是尚可回复的原请求，h 是消费 q 后产生的 submission handle，t 是 q 所依赖的来源事实。r 是已认证、目标为 t 的 correction。以下只承诺 **UTA 已接纳事实和 writer 提交边界**；来源实际早已修订但 UTA 尚未收到，不能由本地类型或 CAS 提前阻止。

### 情形 A：correction 先于 reply 提交

1. writer 按 `Affected(r)` 找到 q 与它的依据，原子保存修订事实关系、失效状态及必要新 request；旧 q 的当前可回复权同时关闭。
2. 旧 q 的 RequestSubmission 随后到达。即使输入仍符合同一 reply schema，版本/依据状态检查失败，返回 stale/conflict 与当前 handle。
3. 不产生 h，不开启 prepare，更没有批准或 Start。新请求描述“旧依据被修订”这个 occasion，不是假造一次新 Candidate。

### 情形 B：reply 先提交，correction 先于 Prepare 提交

1. 回复通过，writer 形成 h、消费 receipt 与 PrepareSubmission；h 继承 q 的依据。此时仅是控制接纳。
2. r 随后提交。依赖消费不仅找到已经 consumed 的 q，也找到仍负有未开始责任的 h；原子 fence h 的可推进状态并构造规定的新决定/冻结结果。q 的历史 reply receipt 不被改成“从未接纳”。
3. 尚未开工的 PrepareSubmission 不再启动；已在 writer 外读取/计算的 prepare 不能被物理撤回，但返回的 RecordPrepared 在 writer 边界对原 h 的有效状态检查失败。结果可以保留为可追溯的过时事实，不能成为可批准/可 Start 的当前计划。

### 情形 C：Prepare/approval 已提交，correction 先于 Start 提交

1. h 已关联准备计划，甚至已有真实批准或排程；这些记录不证明激活依据永不变化。
2. r 的提交使仍未开始的 h/相关工作失去继续资格，并按政策移交新决定。此时不能只提高 EF10 的 review revision，却保持 EF06 job 的 expected state 仍可通过。
3. Start 的同一 writer 决定必须检查它消费的 h/决定依据仍有效，或消费 correction 已原子推进的同一效果控制版本；检查与 DispatchStarted 提交不可分开。故旧 job 被拒绝，未开始资源按控制规则释放/保留，不发 grant。

### 情形 D：Start 先于 correction 提交

1. Start 已按当时有效控制与实际批准原子提交 DispatchStarted。
2. r 随后命中其依赖，但 now-state 已属于 started/Unknown 分支。writer 保留原 attempt 与修订因果，追加恢复/观察责任，不能把已开始事实退回未开始，也不能依赖“adapter 还没返回”宣称未发。即使 r 的 commit 落在 DispatchStarted commit 之后、native 调用之前，已取得的 grant 仍可能继续执行；当前契约没有提供将它原子撤销的保证。
3. 是否存在业务上的 cancel/replace/close 只能由该能力自己的受控 recipe 与真实证据决定；本论证不推测 Broker 的撤销或幂等行为。

**为何以上成立：** 对所有能推进 h 的 writer 提交，依据有效性是实际消费条件；对 correction 提交，受影响未开始控制的失效是同一权威写集。两种决定在同一提交域中只能有一个先成立。仅仅各自有 CAS、或者消息都带相同 intentRevision，并不能推出这一结论：若 CAS 只触及不相关的 review/job revisions，仍可出现 correction 已提交而旧 job 可 Start 的轨迹。

本论证能证明的是“已失效依据不能取得新的 Start”，不是“修订提交后物理世界不再发生写入”。DispatchStarted 是本地线性化边界，native 实际调用有自己的时间；不得为加强表述而补造取消 grant、撤回网络调用或 Broker 条件写保证。

## 5. 有限业务轨迹：命中、修订、rearm、重启与迟到回复

以下数值及有限时序是本轮候选实例，不是 Provider 运行证据。目标已有前提为 §13.3 的精确未开始 Order intent、Candle 来源、版本化 crossing、RequestDecision/ReturnToAgent、单 owner 和新 epoch。新增实例前提为阈值 100、来源明确证明 b 与 h 连续、当前 P 的 C 保存基线及其支持、源允许认证修订、rearm 采用清空旧基线并等待新可信样本的政策。

1. 注册原意图 i 的 epoch 0。可信未来边界为 F0；P 的初始构造产生“尚无可用基线”的 C0。注册接纳不产生 Candidate 或发送工作。
2. 来源 b 为 close=99。它在 F0 之后，P 返回 C1 和 NoActivation；writer 保存 b 的必要引用、C1、连续性/位置与去重事实。这个非命中写入有业务意义。
3. 来源 h 为 close=101，且来源契约证明它延续 b。P 返回 C2 与 Candidate(E)。E 的论据包含 b、h 及所需连续性；writer 原子保存依据并生成 q0/outbox。RequestDecision 路径至此没有金融 dispatch。
4. 进程在 commit 后、Alice receipt 返回前重启。恢复解析原 D/C2/q0，重投同一个 outbox；Alice 已接纳则复用原 admission。不会重跑 h 再生成 q1，也不因断连重建批准。重新接来源无法证明续传时，进入声明的 gap 处理。
5. correction r 把 b 修订为 close=100.5。当前 h 仍大于阈值，但原 crossing 的 false 基线已不存在。依赖消费失效 q0，按 RequestDecision 政策生成新的修订 occasion q1；它不要求 r 再次命中，也不伪称出现新的 crossing。q0 的迟到 Keep/RequestSubmission 不能作用到 q1。
6. q1 的有效 Rearm 回复与旧 owner retirement 在同一 writer 事务中创建 epoch 1/F1，P 的 rearm 构造不继承失效基线。旧 h 的重投不成为新命中。来源恢复后第一个 101 仅建立当前 true 基线，不能证明 false→true；以后出现新的 99、再出现连续 101 才有候选 q2。
7. 另一个迟到 correction 若只指向旧 epoch 的旧依据，仍可记入原决定/恢复历史，但不能仅因到达较晚而覆盖 epoch 1 的无关 C。若当前 C/未开始控制确实通过合法引用继续依赖该旧事实，则依赖消费必须影响它；“target 属于旧 epoch”不是免疫条件。携旧 worker ownership 的直接状态写被拒绝，与真实 source correction 经当前权威按目标关联接纳，是不同事情。
8. q2 的 reply 与 expiry 竞争当前 request/control revision，胜者生效，败者得到明确 stale/expired。相同 reply key/digest 的重试重取既有 receipt，不生成第二个新 epoch 或 submission handle；同 key 不同语义是冲突。

这条轨迹使用 §11/EF10/EF11 已有状态结果，只补齐它们各自消费什么。普通事件的 future-boundary 去重，与 correction 的依赖目标解析不能合成一个“旧事件全丢弃”入口。

## 6. 合法业务特化与另一个可行构造

### 推荐构造：直接在 P 中承载业务计算

Candle crossing 的 C 可保存阈值侧与基线；NewsGroup 的 P 可消费已声明的分组、成员、窗口边界，按自己的纯算法形成 C/E。后二者无需与 crossing 有相同业务判断或相同 C。只要它们满足来源认证、状态与支持充分性、有限结果、确定性和恢复绑定，公共 writer 用同一种构造保存依赖并解释 continuation，不增加 `if Candle` / `if NewsGroup`。

这不是声称 Candle 与 NewsGroup 可透明互换。新增 vwap 判断、新闻分组算法或持续窗口可以合法改变触发含义；其版本和依据也随之改变。schema 自动携带字段不证明业务判断相同。

### 可比较构造：在来源侧显式组成带修订的派生信号

业务作者也可以先用已有 projection/window/aggregate 关系构造一个数据能力：它输出有身份、成员证据、quality/revision 的派生事实，内部完成 crossing 或新闻分组计算；deferred 的 P 再选择这些派生事实并使用同一 RequestDecision 控制。公共内核仍不认识业务字段，且普通数据消费者可以独立复用该能力。

它的边界是：

- 不是只发“true”并丢弃 false/gap/correction；派生算子必须消费基线、窗口与子流控制，向已输出依据传播修订/撤回，保存可解析 lineage。
- 它把必要状态与修订义务移到来源组合拥有者，**没有消灭依赖问题**。控制侧仍须引用选中派生证据，并在派生 correction/retraction 时 fence 相应未开始工作。
- 派生绑定与事件身份重新建立，不能宣称是原 Provider 原生事实；新服务/权限/失败/留存要求必须进入组合契约。
- 若目标只需一个 deferred predicate，直接 P 更轻；若已有真实可复用数据投影，来源侧构造可以减少重复计算。不能只为绕过 deferred 的修订消费而增加中间层。

### 组合保持的前提

依据主书 §16.5:1249–1259、1263–1270，若声称把同一基础 predicate 沿透明投影提升仍保持决定，至少要给出：

1. 基础/富状态的初态关系，来源与修订目标/lineage 的对应；
2. P 的初始、普通进展、rearm 和支持选择均保持该关系；富端每个已接纳步骤有合法对应的基础步骤；
3. 命中、gap、依赖失效、决定 occasion 与允许响应的基础可见观察相同，不只比较 value；
4. source position、continuity、控制次序与必要 coverage/quality 保持；去重若被消去，零步等价属于明确观察契约；
5. 共同 continuation 消费对应 C/E/依据，且 writer 接纳与权限边界未被削弱。

逐步保持再按有限轨迹归纳，才得到该条件域中的决定观察保持。仅有值投影或相同字段不能推出它；入口替换的接纳/拒绝/冲突保持仍是 §16.5:1255 的另一项义务。富 P 改读 vwap 或新新闻特征是合法特化，但不在“同一基础判断保持”的保证内。

## 7. 最小必要修改与停止边界

建议本轮只修改四个紧邻关系，不扩写全书：

1. **§5.5/§11 增补一个与 §10.1.1 同粒度的构造小节。** 从现有操作数说明 source 消费、P 的初态/advance/支持关系、C/E 编码、决定请求/响应与历史消费者如何被一次构造。明确这些纯业务函数和配置由作者提供；schema 不会生成其含义。
2. **§11.2 与 EF10 分开普通进展和依赖修订入口。** 保留 advance 三结果；补全 P 支持的构造/消费以及 Gap/correction 请求原因的来源，防止只加 dependency 字段而无人消费。future boundary 只挡旧触发，不统一挡住对当前依据有影响的旧目标修订。
3. **修正 EF10 的 SubmitIntent 错接，并把 EF11 PrepareSubmission 落成原 intent 的控制后继。** 从已提交 request 构造内部 handle，延续原激活依据；明确 prepare/新 plan 与原 intent 的关联、新 input 必须 Revise，以及激活依据不等于 A.ReadFacts 或批准。
4. **EF10/EF11→EF06/Start 明确同一依据的失效消费。** 用上述双向次序作为解释；单一 writer 的原子边界必须实际覆盖依据失效及未开始工作的推进条件。不是让 Alice admission 与 UTA 做一个事务，也不是新建跨系统工作流协调器。

可以在本轮论证成立的范围：当前有限 deferred 场景可以由开放的纯业务计算和有限控制协议构造，并在声明支持/连续性/历史解释/原子提交前提下保持关联。不能据此宣称任意未来 predicate 都有有界充分状态、任意函数可自动追踪依赖、跨语言函数等价、Provider 必有 correction/replay/finality，或已完成产品实现。
