# UTA deferred relation：activation counterview

## 范围与结论

本报告只核对主书 §5.5、§11、§13.3、§16.3、§16.5，以及 `event-flows.md` 的 EF10/EF11。它不以当前接口尚未实现为设计缺口；只检查这些关系在给定业务函数、明确输入和明确 source 证据时，是否足以唯一追踪消费结果。

结论分两层：

1. **共同控制机制已经足够构造**：`deferUntil` 的关联对象、`advance` 的三分结果、单一 activation owner、source identity/generation/epoch 栅栏、checkpoint/evidence/outbox 的同事务提交、correction/retraction 的 lineage 入口、以及 Rearm 的旧 owner 退休和新 epoch 注册，均已有明确的 owner 与控制方向。
2. **业务消费仍有一个决定性前提**：每个 predicate 必须声明 checkpoint 的充分状态、证据依赖闭包、partial/coverage 的判定、correction 的重算起点和 Rearm 的 future boundary/baseline 规则。当前文字要求“通过证据依赖找到已选证据和 checkpoint”，但没有把这个依赖关系本身构造成可计算的声明。因此，哪些 checkpoint 会被修订、何时仍是 Candidate、何时只能 Gap，不能只由共同关系推出。

下面用一个数值 crossing 和一个允许部分成员的 NewsGroup predicate 展开。
## 0. 对初稿推演的两处限定（保留修订痕迹）

初稿中有两处把业务选择写成了共同规则，现明确收窄而不隐藏：

1. `NewsGroup` 中 `A=.90、B/C 缺失` 不自动意味着 `Gap`。只要来源连续性本身没有 Gap，业务函数可以返回 `NoActivation`，同时在 checkpoint 中保留 `C` 未定/缺失；这里的 `NoActivation` 只表示这一步没有激活，不等于谓词已证明为 false。也可以由业务函数声明“未定即 Gap”，但那不是共同机制的默认。
2. crossing 的 correction `98 -> 101` 只由共同机制推出原 `p42 -> p43` 证据关系失效、旧工作必须受栅栏约束；“candidate 移到 p42”只有在该 predicate 明确允许历史重算/重新激活时才成立。若策略选择失效重建或等可信新边界，则不得自动生成新 Candidate。

因此后面的两个轨迹分别标出：共同机制必然保证的部分、业务函数允许选择的部分，以及保守 fence/rebuild 与历史 replay 两种合法分支。


## 1. 共同关系与权威所有者

主书 §5.5（`uta-capability-runtime-design.md:461-500`）把关系构造成：

- `withTransaction(...)` 先由 `Association` 派生受控效果；
- `deferUntil(NotStartedIntentRevision, SourceBinding, Predicate, ContinuationPolicy)` 关联未开始的 intent revision、source、纯 predicate 和延续策略；
- 一个 intent revision 只有一个 live activation owner；多个来源在该 owner 内组合，不注册多个可重复消费同一意图的等待者。

主书 §11.1-11.2（`:841-860`）进一步给出：

```text
advance(Checkpoint, SourceFact, FutureBoundary)
  -> { checkpoint: Checkpoint, outcome: NoActivation | Candidate<Evidence> | Gap }
```

predicate 自己声明触发语义（每个命中、false→true 边沿、持续窗口等），并冻结实现身份、配置、单位、来源和 checkpoint 版本。`NoActivation` 也可能要提交 checkpoint；`Gap` 不能凭当前值补造 crossing。

EF10.1-10.3（`event-flows.md:1147-1169,1171-1247,1249-1257`）将消费责任具体化：

- Source/Data owner 只产生 `ExternalFact`，包括 data、correction、retraction、gap；它不直接产生 activation 或授权。
- UTA activation owner/writer 校验 source binding、event identity、generation、current intent revision 和 future boundary，调用纯 predicate，并负责提交 `CheckpointAdvanced`、`ActivationCandidate`、`ActivationGap`、`CorrectionApplied`/`RetractionApplied`、`ReviewRequestCreated` 及 outbox。
- `NoActivation` 时仍可提交 checkpoint 与 consumed source identity；Candidate 时 checkpoint、selected evidence、candidate 和后续 request 在同一 writer transaction 中提交；Gap 时 checkpoint 被标 invalid，按已冻结 disposition 进入请求决定、冻结重建或未发送退休。
- Correction/retraction 不能直接写 UTA DomainEvent；writer 依据 source/evidence lineage 找影响并 fence 未发送工作。
- Rearm 不是继续使用旧 owner：旧 owner 退休、旧 epoch 可写权关闭、新 epoch/future boundary 注册必须在同一个 CAS/事务中完成；按一个 `intentRevision` 同时只允许一个 live owner。
- `DispatchStarted` 或 `Unknown` 之后只进入 observation/recovery，不能因 source correction 重绑已发生的外部事实。

EF11.1-11.2（`event-flows.md:1344-1367`）的边界也足够明确：已提交的 `DecisionRequested`/outbox 才交给 EF11；EF11 不重算 predicate。`DecisionRequested` 和 `ReviewRequest` 带 `intentRevision`、`activationEpoch`、`evidenceRefs`、`checkpointRef`、decision revision 和 expected state；correction/escalation 要由新 revision/request 表达。UTA 拥有 deferred control、request、outbox、expiry 和响应 CAS；Alice 只拥有 Workspace/Session admission、delivery 和 reply transport。

因此，本报告把“source 事实 → 纯 predicate → UTA writer checkpoint/control 提交”作为唯一消费链，不把 Agent、Alice 或 source 当作 checkpoint 权威。

## 2. Crossing：T = 100 的逐步轨迹

### 2.1 业务函数前提

设：

- `intentRevision = r17`，`activationEpoch = e0`，controlled intent 尚未 `DispatchStarted`；
- Candle source binding `B_C` 固定 instrument `X`、1-minute interval、generation `g1`，并能证明同一 generation 内的 source position 顺序、event identity 和 correction target；
- disposition 是 `RequestDecision(ReturnToAgent)`；
- predicate 是严格声明的 `crossUp100`：在同一 generation 且无 Gap 时，若上一个可信 close `< 100` 且当前 close `>= 100`，返回 Candidate；第一个可信值只初始化 baseline，返回 NoActivation；非 crossing 值推进 baseline 并返回 NoActivation；Gap 使 baseline 无效；
- checkpoint 只保存足以重放的有界状态：`C = {lastClose, sourcePosition, generation, validity}`；
- **业务函数额外声明**：Candidate 的证据依赖是 baseline 事实和触发事实，而不是只保存当前触发 candle。也就是说，`Candidate@p43` 的 evidence refs 至少为 `{p42, p43}`，并保留对应 checkpoint lineage。

上述 baseline/evidence 选择不是 §11 的共同默认值，而是 crossing 函数声明；共同机制只要求它能重放 predicate 并把选中证据带进 control journal。

### 2.2 无 Gap 的 crossing

| 步骤 | 输入（source identity） | 纯函数状态与输出 | UTA writer 的提交/权威 |
|---|---|---|---|
| 注册 | `B_C@g1`, future boundary `>p40` | `C0={last=⊥,pos=40,g1,valid}` | UTA writer 注册 `r17/e0` 的唯一 owner，保存 predicate/checkpoint/future/disposition 完整 binding |
| 1 | `p41@v1, close=96` | 首个值只建立 baseline：`C1={96,p41,g1,valid}`；`NoActivation` | `CheckpointAdvanced(C0→C1)` + consumed source identity；不产生 candidate/request |
| 2 | `p42@v1, close=98` | `98<100`，无 crossing：`C2={98,p42,g1,valid}`；`NoActivation` | 再次提交 `CheckpointAdvanced(C1→C2)`；非命中仍被持久化，因为它改变了未来判定所需 baseline |
| 3 | `p43@v1, close=101` | `98<100<=101`：`Candidate<E={p42,p43}>`；`C3={101,p43,g1,valid}` | 同一事务提交 checkpoint、`ActivationCandidate`、selected evidence；`RequestDecision` 分支再提交稳定 `DecisionRequested/ReviewRequestCreated` 和 outbox。来源事件本身没有授权，也没有 dispatch |

这里的数值轨迹使 `Candidate` 的证据依赖可见：当前 101 单独并不能证明 crossing，必须同时知道上一可信 baseline 98 和它的来源位置/代际。

### 2.3 Gap 分支

从步骤 2 的 `C2={last=98,p42,g1,valid}` 分叉，假设 source 在 `p43..p44` 之间报告 `Gap(g1,[43,44])`。这不是一个 close 值，不能交给 crossing 函数假装“当前价格”。

- `advance(C2, Gap, futureBoundary)` 返回 `Gap`，checkpoint 变为 `C_gap={last=⊥, gap=[43,44], prior=p42, g1, invalid}`；
- UTA writer 提交 `ActivationGap + CheckpointInvalidated`，然后按冻结 disposition：`
  - RequestDecision：提交 gap evidence 与新的 review request/outbox；
  - Suspend/RebuildBaseline：提交 `GapFrozen + AwaitTrustedBoundary`；
  - CloseWithoutDispatch：仅对未发送 intent 退休。
- 随后即使收到新 generation `g2` 的 `p50=101`，crossing 函数也只能把它当作新的第一可信值：`NoActivation`, `C={last=101,p50,g2,valid}`；不能从旧的 98 推出跨越。若 `p51=99`，仍 `NoActivation`；若 `p52=102`，才得到新的 `Candidate<E={p51,p52}>`。

`Gap` 的结果由共同机制确定为“不得补造 Candidate”；`p50` 是 baseline 还是可直接命中，则由 crossing 函数的首样本规则确定。这里采用首样本初始化，因此结果是唯一的。

### 2.4 选中 evidence 的 correction

回到无 Gap 的步骤 3。此时尚未 `DispatchStarted`，`q1` 的 request 尚在 review/未发送控制状态。source 发送：

```text
Correction(target = p42@v1, replacement = p42@v2, close: 98 -> 101)
```

假设 binding 明确支持 correction，并且 correction target identity/revision 可验证。

1. `p42@v1` 是 `Candidate@p43` 的 baseline 依赖；因此 correction 影响的不只是 old evidence row，还影响 `C3` 及 Candidate 的 truth。
2. writer 保留旧 `p42@v1`，追加 correction/replacement lineage；不原地改写历史 source event。`q1` 的 selected evidence/checkpoint 仍可审计，但被 fence，不再是 current request。
3. 按同一个 `crossUp100`、从最近未受影响的可信前缀 `p41=96` 重放：
   - `p42@v2=101` 已满足 `96<100<=101`，在 `p42` 产生新的 crossing candidate；
   - 后续 `p43=101` 不再是 false→true 边沿，故不产生第二个 candidate。
4. 结果应是新的 checkpoint `C3'={101,p43,g1,valid}`，但 selected evidence 改为 `{p41@v1,p42@v2}`，而不是 `{p42@v1,p43@v1}`。未开始、请求决定路径下，writer 提交 correction lineage、fence old review、更新 checkpoint，并以新的 decision revision/request 表达 replacement；旧 `q1` 的迟到回复只能 stale/conflict。

这个轨迹是一个区分力很强的反例：如果只记录当前触发证据 `p43`，而没有把 baseline `p42` 放进 evidence dependency/impact relation，就无法从 correction target 推出应修订 `C3`，更无法知道 Candidate 应移到 `p42`。所以“selected evidence”必须由业务函数给出依赖闭包，不是一个只含 trigger row 的列表。

### 2.5 Rearm 后的可重绑范围

假设新 request `q2`（对应 correction 后的新 decision revision）收到合法 `Rearm`：

- UTA writer 以 `requestId/controlRevision/intentRevision=r17/epoch=e0` 做 CAS；
- 同事务提交 `DecisionApplied(Rearm)`，退休 `e0` owner，注册 `e1` 与明确 future boundary `>p43`；
- `e1` 不重消费旧的 `p42/p43`，也不继承被 correction 影响的 baseline。这里的首样本规则由业务函数声明为“新 boundary 后第一 candle 仅初始化 baseline”。

例如 `p44=101` → `NoActivation`，建立 `e1` baseline；`p45=99` → `NoActivation`；`p46=102` → `Candidate`，evidence 为 `{p45,p46}`。旧 epoch 的 source event/reply 只能得到 stale/rejected diagnostic，不能覆盖 `e1`。

可重绑边界因此是：

- 未发送的 `NoActivation`/checkpoint：若 correction 触及依赖，可在同一 `intentRevision`、同一 epoch 内按业务重算；不必自动 Rearm，但必须更新 lineage/checkpoint。
- 未 `DispatchStarted` 的 Candidate/review：可以 fence 后在同一 intent revision 生成新的 decision revision/request，或经合法 Rearm 改换 epoch；不能复用旧 request identity。
- `Revise`：新 `IntentRevision`，重新 prepare/approval；不原地修改旧 plan。
- `Prepared` 或 `ApprovalBound + ReservationHeld` 但尚未 start：不可原地编辑 plan；至少要退休/重新 prepare 新 revision（具体 disposition 由该受控 leaf 声明）。
- `DispatchStarted` 或 `Unknown`：不重绑原 intent/attempt，不以 correction 撤销 remote reality；只追加 correction lineage 并转 observation/recovery。

## 3. NewsGroup：Partial 不自动等于拒绝

### 3.1 业务函数前提

设：

- `intentRevision = r22`，`activationEpoch=e0`，source binding 是一个有身份的 group，期望成员 `{A,B,C}`，每个成员有稳定 member identity、member revision 和 source generation；
- group predicate 是 `quorum2of3`：成员 score `>=0.8` 算 match；达到至少两个 match 就 Candidate；
- 该业务明确声明 **allow partial when quorum is already proven**：Partial group 如果已有两个可信 match，可以 Candidate；若 Partial 尚未达到 quorum，且缺失成员仍可能改变结果，则返回 Gap；只有 Complete 且少于两个 match 才返回 NoActivation；
- checkpoint 是有界成员表：`G={groupRevision, member(A/B/C -> value, revision, match), observedSet, missingSet, coverage, predicateVersion}`；
- Candidate evidence 至少包含形成 quorum 的成员引用；Gap evidence 包含已观察成员、缺失成员和 coverage/gap 依据；NoActivation evidence/Checkpoint 必须包含完整 coverage 或等价的 group barrier。

这套 partial policy 是 NewsGroup 函数的声明，不是 `advance` 或 EF10 的全局规则。

### 3.2 逐步轨迹

| 步骤 | 输入 | 纯函数状态与输出 | UTA writer 的提交/权威 |
|---|---|---|---|
| 1 | `A@v1 score=.90`；B/C 尚缺 | 1 个 match，Partial，第二个 match 仍可能来自 B/C：`Gap`；`G1` 保存 A、missing `{B,C}` | `ActivationGap + CheckpointInvalidated/GapFrozen`（按 disposition）；不把 Partial 变成 Candidate，也不把缺失当 non-match |
| 2 | `B@v1 score=.85`；C 仍缺 | 已有 2 个 match，Partial 但 quorum 已确定：`Candidate<E={A@v1,B@v1}>` | 同事务提交成员 checkpoint、selected evidence、`ActivationCandidate`、`DecisionRequested/ReviewRequestCreated`；C 缺失继续出现在 coverage 中 |
| 3（独立 NoActivation 轨迹） | 新 group revision `g6`：A=.30、B=.40、C=.70，三者均已观察 | Complete，0 个 match：`NoActivation`；`G6` 保存三个 member refs 和 complete coverage | `CheckpointAdvanced`；没有 Candidate/request。NoActivation 依赖完整 coverage，不是“当前已知成员暂时都不 match” |
| 4 | correction `A@v1 .90 -> A@v2 .20`，B=.85，C 仍缺 | correction 触及已选 quorum member；重算后只有 1 match 且 Partial，结果是 `Gap` | 保留 A@v1，追加 A@v2 lineage；fence 原 candidate/review；提交 correction + 新 checkpoint + Gap/review replacement（按 disposition）。旧 request 不被原地改写 |
| 5 | 新事实 `C@v1 score=.90` | B/C 达到 quorum：新的 `Candidate<E={B@v1,C@v1}>`；A@v2 仍在 group checkpoint 中但不再是 selected quorum evidence | 新 decision revision/request；旧 candidate evidence 仍可追溯，不能删除 |

步骤 2 证明 Partial 可以是 Candidate；步骤 1 证明 Partial 也可以是 Gap；步骤 3 证明 NoActivation 需要该业务声明的 Complete barrier。若业务函数改成 `all3match`，同一个 Partial 输入就可能永远不能 Candidate；那是业务函数差异，不是共同 deferred 状态机差异。

### 3.3 NewsGroup 的 Rearm

假设步骤 5 的 request 收到合法 `Rearm`，且函数将 future boundary 定义为“只接受 group revision 大于 g1 的成员”。UTA writer 原子退休 `e0`、注册 `e1`、保存新 boundary；不把 g1 的 A/B/C 成员表自动带入 e1。

新 epoch 中，`A@g2=.90`、B/C 缺失先得 `Gap`；B@g2=.88 到达后才得 Partial `Candidate<E={A@g2,B@g2}>`。旧 group revision 的 match、coverage 和 review reply 都不能重消费或改变 e1。

这里“新 epoch 是否清空全部成员、是否允许复用某个外部 group snapshot 作为新 baseline、future boundary 是 group revision 还是窗口边界”均必须由 `quorum2of3` 声明。共同机制只保证旧 epoch 不写入新 owner。

## 4. 旧证据追溯、修订影响和状态重绑

### 已由共同关系确定的部分

- §16.3（主书 `:1176-1209`）把 `CorrectionFrame` 构造成 `CorrectionRef(B) × Event(B, Correction, item)`；Deferred activation 的事件族从 source schema、predicate checkpoint/evidence schema 和 continuation response schema 派生。Correction 不是覆盖旧 source row 的就地 mutation。
- §16.5（`:1236-1259`）要求新派生 binding/event identity 保存源引用；状态关系 `S` 和 lineage 对应关系 `I` 必须保留会影响未来观察的去重历史、sequence、phase、修订目标；不能用“值相同”省略修订关系。
- EF10 要求旧 source identity/position 去重、CorrectionApplied 携带 source/evidence lineage、未发送工作被 fence；EF11 的 request/reply identity、intent revision、epoch 和 expected state 使旧 request/reply 在修订或 Rearm 后 stale。
- 因此，旧 evidence 应作为不可变历史保留，replacement 以新 source revision/derived revision 引用它；旧 candidate/review 仍可审计，但不是 current authority。具体存储介质不由这些章节指定。

### 必须由业务函数声明、当前没有唯一答案的部分

1. **checkpoint 的充分字段**：crossing 至少需要上一个可信值、位置、generation、validity；NewsGroup 需要成员 identity/revision、coverage/missing 和 group revision。抽象 `Checkpoint` 不自动包含这些字段。
2. **evidence dependency closure**：crossing Candidate 依赖 baseline+trigger；NewsGroup quorum Candidate 依赖形成 quorum 的成员，NoActivation 依赖完整 coverage，Gap 依赖 missing/continuity 证据。共同机制没有规定证据是一个 row 还是一组 refs。
3. **correction 的影响集合/重算起点**：必须知道 correction 影响哪些 checkpoint components，以及从哪个可信前缀或 group revision 重放。只说“通过依赖找到 checkpoint”还没有给出这个查找/重放关系。
4. **Partial 的可判定性**：Partial 是 coverage 状态，不是固定 control outcome。`quorum2of3` 可以 Partial→Candidate；未达到 quorum 可 Partial→Gap；Complete 且不满足才 NoActivation。另一个函数可以选择不同策略。
5. **Rearm 的 future boundary 和首样本规则**：共同机制要求新 epoch、新 boundary、不重消费旧匹配/不继承失效 baseline；边界究竟是 source position、generation、group revision 或窗口，以及新 epoch 第一事实如何初始化 checkpoint，必须是业务声明。

## 5. 最小修改建议

不新增通用 workflow 语言；只补强每个 deferred predicate 的业务声明：

> 对每个 predicate 版本，除 `advance` 外声明一个有限、可重放的 dependency/impact certificate：给定当前 checkpoint、source fact 或 correction target，列出受影响的 checkpoint components、全部 source/evidence refs、coverage obligations，以及从哪个可信 source position/group revision 开始重算；同时声明 Partial/Complete 的判定和 Rearm future-boundary/首样本规则。

可用关系记为：

```text
Impact_P(C, correctionTarget, boundary)
  = { affectedCheckpointParts,
      dependencyRefs,
      coverageObligations,
      replayStart,
      revisedOutcome }
```

这不是要求全局实现一个新工作流；它只是把 §11.2/EF10 已经依赖的“证据依赖关系”从断言变成 predicate 自己必须提供的可追溯构造。对两个示例：

- `crossUp100` 给出 `{previousBaseline,currentTrigger}` 和 earliest replay position；
- `quorum2of3` 给出 Candidate 的 quorum refs、NoActivation 的 complete-member barrier、Gap 的 missing members，以及 member correction 到 group checkpoint 的映射。

在这些前提下，有限轨迹的结果是可确定的：旧证据不可变保留，replacement 有新 revision/lineage，未 start 的 current control 可 fence/rebind，Rearm 只建立新 epoch；已 start/Unknown 不重绑。若要证明任意 predicate 的 correction replay 与 Rearm 在所有交错轨迹下都满足 §16.5 的已接纳轨迹律，需要先固定 source reorder/late correction、checkpoint equivalence 和观察面，属于超出本次普通限定推演的复杂证明，交 Main 决定，不在此猜测。

## 6. 精确定位汇总

- 主书 §5.5：`docs/uta-capability-runtime-design.md:461-500`，`deferUntil` 的构造签名、未开始 intent、唯一 activation owner 与控制边界。
- 主书 §11.1-11.3：`:841-880`，Deferred relation、`advance` 三分结果、baseline/Gap、Correction/Retraction、Keep/Rearm/Revise/Discard 和 CAS。
- 主书 §13.3：`:983-1001`，Candle crossing 的具体业务实例：版本化 crossing、baseline、Gap 后首高值只重建 baseline、Rearm 换 epoch。
- 主书 §16.3：`:1176-1209`，slot-derived payload、CorrectionRef、Deferred activation 的 source/predicate/checkpoint/evidence/continuation 槽位。
- 主书 §16.5：`:1236-1259`，状态关系/lineage、修订目标、行为保持与组合限制。
- EF10.1-10.3：`docs/uta-capability-runtime-design/event-flows.md:1147-1169,1171-1247,1249-1257`，producer/consumer、原子提交、Gap/Candidate/Correction/Rearm 和 owner 规则。
- EF10.4/状态矩阵：`:1259-1278`，说明目标接口未实现不等于关系未定义，并列出 Deferred Candidate 与 Deferred Gap/Correction 的允许后继。
- EF11.1-11.2：`:1344-1367`，已提交 request 的消费边界、evidence/checkpoint refs、UTA/Alice authority；EF11 不重算 predicate。

此报告没有运行代码、测试、build、lint 或 formatter，也没有修改仓库文件；只写入被 Main 明确要求的 `local://uta-current-research/activation-counterview.md` 报告工件。

## 证据附录 A：Main 裁决与对初稿的限缩（追加，不改写上文历史）

本附录记录 Main 在复核后给出的三个限定；上文保留初稿轨迹与原始判断，以下限定优先于其中过强的措辞。

### A.1 Partial 成员缺失不自动推出 Gap

`A=.90` 而 `B/C` 尚未到达时，若 source continuity 本身没有 `Gap`，不能把 `Gap` 当作共同控制机制的必然结果。一个合法的 NewsGroup predicate 可以返回：

```text
NoActivation
checkpoint = {A matched, B/C unresolved, coverage=Partial}
```

这里 `NoActivation` 是“当前输入没有激活”，不是“整个 group predicate 已证明为 false”。当 B 或 C 后续到达时，checkpoint 仍可产生 Candidate。只有 source 明确给出 continuity gap，或该业务函数另外声明“coverage 未满足即进入 Gap”，才进入 `Gap`；后者是 leaf policy，不是 deferred 协议默认。原报告第 3.1/3.2 的 `A=.90、B/C 缺失 -> Gap` 只能作为一种额外 policy 分支，不能写成必然消费结果。

### A.2 Correction 影响 selected evidence，不必然改变当前 checkpoint

crossing 中 correction `p42: 98 -> 101` 必然能证明旧的 `p42 -> p43` **selected evidence 关系失效或需要重新评估**，因为 p42 是声明的 baseline dependency。它不必然证明当前 checkpoint `C3={last=101, sourcePosition=p43, generation=g1, valid}` 的 `last` 数值或全部状态字段受影响：当前 checkpoint 的 `last=101` 可能在修订前后相同，影响首先落在历史 selected evidence、candidate truth/lineage 和 checkpoint validity/revision 关系上，而非数值字段一定变化。

因此必须区分：

- **current checkpoint support**：当前 checkpoint 的有界状态字段是否仍可作为继续消费的支持；
- **historical selected-evidence support**：已提交 Candidate/ReviewRequest 所引用的 p42/p43 证据关系是否仍成立。

共同机制只要求 writer 通过 source/evidence lineage 找到受影响的关系并 fence 未发送工作；它不默认历史重算，更不默认“把 crossing 自动移到 p42”。若 business predicate 明确允许 historical replay/re-activation，并声明从 p41 重放，则在本数值例中可推导出 p42 新 Candidate；若策略是保守失效重建，则合法结果是保留旧证据与 correction lineage、使旧 Candidate/request stale，并等待新可信边界或 Rearm，不生成替代 Candidate。原报告第 2.4 中“应移到 p42”的表述只应读作前一种显式 replay policy 下的条件轨迹，不是共同机制结论。

### A.3 Dependency 需要可追溯但不要求最小闭包

“dependency/impact relation”不应被理解成必须计算精确、最小的依赖集合。业务函数可以给出保守的有限超集（例如保存整个有界窗口、全部已观测 group 成员和 coverage barrier）；只要它足以支持修订影响判断、旧 evidence lineage 和安全重放/失效重建即可。若不能证明精确影响，可以直接把相关 checkpoint 标为 invalid、fence 未发送工作并从可信边界重建；这仍满足共同控制关系。

同理，NoActivation 不需要每次输出精确最小 evidence 集。它可以持久化一个保守 bounded checkpoint，并显式保留未定成员/coverage；要求是不能把未定伪装成 false 或 Complete，也不能丢掉未来决定所需的状态。

### A.4 对最小修改建议的相应收窄

因此，原报告第 5 节的 `Impact_P` 应解释为一个**可追溯影响证明或保守失效/重建策略**，而非强制精确闭包或强制历史 replay：

```text
Impact_P(C, correctionTarget, boundary)
  = precise impact + replayStart
    | conservative invalidation + rebuildBoundary
```

需要业务函数声明的最小内容是：哪些依赖/coverage 关系受 correction 触及、旧 evidence 如何 lineage、何时允许 replay/re-activation、何时采用 fence/rebuild，以及 Rearm 的新 boundary/首样本规则。共同机制不替业务函数选择其中哪条恢复策略。
