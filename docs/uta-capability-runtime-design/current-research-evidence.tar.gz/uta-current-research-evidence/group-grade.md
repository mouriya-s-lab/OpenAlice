# 异构补偿等级进入组政策：定向研究

## 0. 范围与结论

本报告只研究当前主书 §10.4 与 EF09 中，异构成员的 `Exact / StateRestoring / Economic / None` 如何进入同一个组政策。它不重做受控效果、`DispatchStarted`、Unknown、Alice 或全部 reservation 控制研究；这些关系只在补偿等级的消费点需要时引用。依据是当前主书 `docs/uta-capability-runtime-design.md:876-900`、`docs/uta-capability-runtime-design.md:902-916`，事件流册 `docs/uta-capability-runtime-design/event-flows.md:1013-1170`，以及目标审核 `local://uta-current-research/goal-audit.md:116-138`。

结论：**补偿等级不是一个可对成员做字符串 `min`/`max` 的标量。** 它是带目标、残余、证据范围和输入构造的成员级保证声明。组政策必须冻结每个成员的实际保证/证据和该成员所需的目标关系，再用显式的组接受函数消费成员向量。`Exact`、`StateRestoring`、`Economic` 作用于不同语义对象，不能因为名称看起来像强弱级别就建立全序；`None` 是“没有自动补偿保证”，不是所有政策中的最低可接受级别。

对相同成员向量 `A=Exact, B=Economic`：

- 如果组政策要求**每个成员均有 `StateRestoring` 对其指定状态目标的证据**，则应在 `GroupPolicyBound` 前拒绝；原因是 B 的 Economic 证据不能满足 B 的状态目标，而不是因为某个通用字符串排序得出“较小”。
- 如果组政策的真实目标是**组级经济敞口在明确容差内恢复**，且 A、B 的单位、范围、时点、暴露和残余证据足以让组函数计算该目标，则同一向量可以合法接纳。此时 B 没有状态恢复保证，组也不能把这个较窄的经济目标改写成 `StateRestoring`。

已表达的成员 `criterion / resolution / exposure / responsibility` product、补偿目标的固定/动态输入构造、Unknown 不等于无效果、补偿确认前不释放敞口锁、以及已开始后不临时降级，均不需要另造一套控制模型。本轮真正需要补的是它们与**成员级补偿声明、组目标、证据和结案释放**之间的桥。

---

## 1. 当前构造已经表达了什么

### 1.1 每个成员不是 JoinedOrder

主书已经规定每个 `Aᵢ` 有自己的 `Prepared`、`Ack`、`Observation`、`criterion`、`resolution`、`ExposureEvidence`、`attempt` 和恢复责任；`ChildProgress` 是这些结果与证据引用的 product，协调器不把异构 Observation 压成一个成功布尔值（`docs/uta-capability-runtime-design.md:898-900`）。EF09 的 `Control<Batch, ChildProgress>` 也已经列出 `criterion`、`attempt resolution`、带 coverage/uncertainty 的 `ExposureEvidence`、reservation disposition 和 recovery responsibility（`event-flows.md:1032-1033`）。这是异构等级研究的正确输入，不应重写为一个通用子订单类型。

### 1.2 补偿是新 Recipe，不是旧 inverse

主书已经规定 `A.CompensationPlan` 只能按照固定或动态目标构造精确的 `C.Intent`，随后由 C 自己取得 `ReadFacts`、prepare、批准、criterion、resolution 与恢复消费者；C 不继承 A 的批准、Prepared 或 grant（`docs/uta-capability-runtime-design.md:888-890`）。EF09 对 `CompensationCandidate<A,C>` 和 `CompensationProgress` 已保存同一关系（`event-flows.md:1035-1037`）。因此，本报告的组级消费应把原成员和补偿成员分别保留，不把 C 的结果写回覆盖 A。

### 1.3 失败、未知和责任释放已经有安全边界

当前规则已经表达：

- `A` 部分成交而 `B` 在开始后 Unknown 时，B 是未知敞口，不是零；没有允许不确定性下补偿的政策和充分证据时先恢复（`docs/uta-capability-runtime-design.md:894-900`；`event-flows.md:1169-1170`）。
- 补偿未确认前，原敞口 lock 不释放；未开始且有 conclusive no-effect 的 child 才能按责任规则释放，started/unknown 由观察或恢复 owner 持有（`event-flows.md:1165-1168`）。
- `GroupSatisfied` 只有在组目标满足且成员责任结清或原子移交时成立（`event-flows.md:1038`, `1142-1144`）。
- 组策略在接纳时冻结成员、失败策略、允许等级和释放责任；不能失败后把原先承诺的 Exact 临时降成 Economic（`docs/uta-capability-runtime-design.md:884-890`；`event-flows.md:1164-1166`）。

这些约束已经足够作为本研究的控制边界，不需要再重复整段交易状态机。

---

## 2. 为什么等级不能做字符串 `min`/`max`

### 2.1 四个名称修饰的是不同的目标关系

当前主书给出的最小语义是：

| 等级 | 实际修饰的保证 | 不能从名称自动推出的内容 |
|---|---|---|
| `Exact` | 对声明的尝试、身份、条款或数量提供确切逆操作的证据承诺 | 不自动证明组级状态已恢复、费用消失、历史未发生或远端原子性 |
| `StateRestoring` | 将声明的状态投影恢复到指定目标/等价关系 | 不自动证明原尝试因果被撤销，也不自动消除手续费、滑点或历史记录 |
| `Economic` | 将声明的经济敞口恢复到指定容差/风险目标 | 不自动恢复原生订单身份、队列、状态字段或非经济历史 |
| `None` | 不声明自动补偿保证 | 不是所有策略中的“最低可用值”；只有不需要该保证的政策分支才可接受 |

`Exact` 的“确切”针对逆操作/身份关系，`StateRestoring` 的“恢复”针对状态投影，`Economic` 的“恢复”针对经济暴露。核心不能跨越目标、证据域或判据条件，把下列关系当作全局等级蕴含：

- `Exact ⇒ StateRestoring` 不是标签本身推出的关系；但在相同的目标投影、作用域、证据域和判据条件下，具体 Provider/Recipe 可以证明并冻结这项蕴含，作为该成员的 target-specific claim。
- `StateRestoring ⇒ Economic` 不是通用关系；恢复的状态投影可能不包含费用、融资、滑点或估值时点。
- `Economic ⇒ StateRestoring` 不是通用关系；经济上抵消可以使用另一条订单/另一 venue，而不改变原成员状态。
- `None` 不是上述三者的数值下界；它表示没有自动补偿保证，能否接受取决于组政策是否声明该保证。

同一目标/证据域内的具体蕴含仍须由对应证据支持；它不能被提升成跨目标、跨成员或跨 Provider 的全局排序。

若某成员的具体证据确实证明 `Exact` 操作同时恢复某个指定状态，或者某个 `Economic` 计划也有状态恢复性质，这个蕴含应作为该成员的目标化 claim/evidence 关系记录；不能从标签自动推断。

### 2.2 任意一个标量排序都会丢失政策信息

即使作者人为定义 `None < Economic < StateRestoring < Exact`，也只能得到一个粗略筛选，不能成为组语义：

1. **按最弱等级拒绝会过严。** `A=Exact, B=Economic` 对“组经济敞口不超过 ε”的政策可能完全合法；将它们压成 `Economic` 后再拿去与 `StateRestoring` 比较，会错误拒绝这个较窄目标。
2. **按最强等级接纳会过松。** `A=Exact, B=Economic` 不能因为 A 的 Exact 就满足“每个成员状态恢复”的政策；max 会把 B 的缺证据藏掉。
3. **同一等级向量在不同目标下结果不同。** `StateRestoring` 可满足一个只看 position quantity 的目标，却不能自动满足包含费用的经济目标；`Economic` 可满足经济容差，却不能满足原生 order identity 恢复。
4. **`None` 没有同一坐标。** `IndependentBatch` 不承诺组回滚时，某成员 `None` 可以合法表达“本成员没有补偿”；自动补偿的 `AllOrCompensate` 则必须在接纳时拒绝会暴露的 `None`。两者不是同一排序上的相邻数字。
5. **证据不是等级文字。** `Exact` 但缺稳定 native identity、缺完整 lookup 或 scope 不匹配时，实际可用保证仍是 `Insufficient`；不能把标签当作证据。

因此组协调器不能实现为 `min(member.grade)`、`max(member.grade)` 或按字符串排序后比较。它要实现的是带目标和证据的 `suffices` 关系。

---

## 3. 最小成员级构造：保证、目标、证据和残余必须绑定

不要求核心预先枚举所有业务目标；作者只需为本组涉及的成员提供必要构造。对每个 required member `i`，组政策应绑定一个成员补偿要求和该成员实际可用的 claim：

```text
MemberCompensationRequirement<i> =
  target_i                 // 该成员需要恢复的状态/经济/逆操作关系
  acceptedClaimRelations_i // 对 target_i 可接受的一组具体保证关系
  uncertaintyPolicy_i      // Unknown、Partial、coverage 缺口如何处理
  residualPolicy_i         // 费用、滑点、历史、非目标状态等允许或必须移交的残余
  releasePolicy_i          // reservation、exposure、recovery responsibility 的释放/移交条件

MemberCompensationClaim<i> =
  grade_i                  // Exact | StateRestoring | Economic | None
  targetClaim_i            // 该 grade 实际声称的目标关系，不是标签 alone
  evidence_i                // 该 scope/Provider/operation/identity 的证据引用和 coverage
  residual_i                // 该 claim 明确不覆盖的残余
  inputConstruction_i       // 能否由 A 的 Prepared/Exposure/Policy 构造精确 C.Intent
```
`MemberCompensationClaim` 是组准入时的**实际可用保证/证据**，不是事后从 `grade_i` 推断出来的说明。一个 policy 可以声明多个可接受 claim，同一声明也可能提供多个彼此相容、共同被组目标消费的 claim；writer 在 `GroupPolicyBound` 中冻结本次实际消费的 claim/evidence 关系集合及其 digest，而不是强制每个成员压成一个 claim。以后要换一组 claim，应是新的 policy/revision，不是运行时取更强或更弱的字符串替代。


`evidence_i` 的最小范围必须至少能回答：

- Provider、账户/作用域、capability binding/revision 和 operation 是否与该 child 相同；
- target 所需的 native/order/execution identity、scope、source revision、as-of/coverage 和不确定性是否足够；
- claim 的输入构造是否存在，能否仅消费原 A 的 Prepared、实际 ExposureEvidence、Policy 和显式配置构造 C.Intent；
- residual policy 所承认的费用、滑点、历史和非目标状态是否被识别；
- 若 group target 跨成员合并，单位、币种、时间/来源关系和暴露身份是否有合法投影，不能只因数字可加就合并。
没有这些证据时，结果是 `EvidenceInsufficient`/`Unavailable`/`RecoveryRequired` 的相应分支，不是把 claim 降成一个“较低等级”继续发送。这里的绑定证据是能力、保证/conformance 和条件式构造证据，不要求未来发送前已经有实际 exposure；实际 exposure 在补偿触发后取得，并按冻结关系重新核验。
---

## 4. 组政策和接受函数

### 4.1 组政策不是一个 scalar grade

`AllOrCompensate` 的 `GroupPolicyBound` 至少应冻结以下关系：

```text
GroupPolicy =
  requiredMembers
  memberRequirement_i       // 每个 i 一条，不是一条 group grade
  memberClaimRelations_i    // 本次实际消费的一个或多个相容 claim/evidence 关系
  groupTarget               // 组级目标；可只观察某个成员，也可组合成员目标
  uncertaintyPolicy
  releaseAndHandoffPolicy
  policyRevision
```

`memberRequirement_i` 是该成员的保证要求；`groupTarget` 是组的业务目标。两者不能互相替代：逐成员 StateRestoring 不能自动推出组级 Economic target，组级 Economic target 也不能回写成逐成员 StateRestoring。

### 4.2 绑定时的最小接受规律

设 `claimRelations_i` 是本次选定、由组目标实际消费的成员 claim/evidence 关系集合，`supports_i(requirement_i, claimRelations_i)` 是带目标和证据的适用关系，而不是等级比较。组绑定可以写成如下纯判定：

```text
bindGroupPolicy(P, members, claimRelations) =
  Accept(GroupPolicyBound(P, frozenClaimRelations, evidenceRefs))
    iff
      requiredMembers(P) == members
      and every member has a frozen claim/evidence relation set
          sufficient for its requirement
      and supports_i(P.memberRequirement_i, claimRelations_i) for every i
      and groupInputsConstructible(P.groupTarget, claimRelations, members)
      and every admitted failure/uncertainty branch has a declared consumer
      and release/handoff rules cover original and compensation responsibilities
  otherwise
    Reject(MissingMember | ClaimMismatch | EvidenceInsufficient
           | GroupTargetUnconstructible | UncertaintyNotAdmitted
           | CompensationUnavailable)
```

这里的 `supports_i` 不是：

```text
ordinal(claimRelations_i) >= ordinal(requirement_i)
```

它要同时匹配 `target_i`、证据范围、coverage/uncertainty、残余政策和输入构造。一个声明可以提供多个相容 claim；绑定时冻结本次组目标实际消费的关系集合，不要求把它们压成一个 claim。`groupInputsConstructible` 也不是保证远端原子性；它只确认本地可以合法地形成组目标所需的成员投影和依赖关系。跨 Provider 的 native atomicity 仍按现有 `VenueNativeAtomic` 证据边界处理。

`None` 的准入规则应明确为：

- `IndependentBatch` 可以接受 `None`，因为它没有为该成员或全组声明自动回滚；成员仍独立进入自己的 criterion/resolution/recovery。
- `AllOrCompensate` 若对某 required member 的可能敞口声明自动补偿，`None` 在 `GroupPolicyBound` 前拒绝。已知未开始且有充分 no-effect 证据的结果可以使某一实际分支不需要补偿，但这是一条**结果分支**，不是把 `None` 变成满足自动补偿保证的等级。
- 若组政策只允许不涉及该成员的分支，必须把这个不发送/不暴露的前提写成冻结的 policy/evidence；不能运行到 started/unknown 后才用 `None` 解释“其实不用补偿”。

### 4.3 失败后和补偿中的组函数

现有 `ChildProgress` 已经有正确的多轴材料。需要补齐的是它如何与 `GroupPolicy` 和补偿 progress 组合，而不是新建一个成功布尔值。可以把组推进关系明确为：

```text
advanceGroup(
  boundPolicy,
  originalChildProgress_i,
  compensationChildProgress_i?
) =
  GroupControlCandidate
```

对每个成员，组函数消费：

- 原 child 的业务 `criterion_i`；
- 原 child 的 `attempt resolution_i`；
- 原 child 的 `ExposureEvidence_i`（包含 coverage/uncertainty）；
- 如已产生 C，则 C 自己的 `criterion_C`、`resolution_C`、`ExposureEvidence_C`；
- 原 child 与 C 的 reservation disposition、exposure lock 和 recovery responsibility。

它不得用 `compensation grade` 单字段取代这些结果。补偿 capability/conformance 和条件式输入构造在绑定时验证；绑定不要求发送前已经存在未来的实际 `ExposureEvidence`。补偿触发后，planner 才取得实际敞口、coverage 和 uncertainty，并按冻结的 claim/target 重新核验，核验失败进入恢复或不可用，而不是降级。

最小条件规律是：

1. **需要补偿**：失败条件/成员 criterion 表明当前组目标不能满足，且已观察到实际敞口或政策明确允许处理的不确定敞口与责任；只有在取得实际 `ExposureEvidence` 后，受影响成员的 `CompensationPlan` 仍能按冻结 claim 构造时，才产生 `BatchCompensationRequired`/C work。没有实际敞口不能伪造补偿；未知敞口不能伪造成零。
2. **补偿目标满足**：`groupTarget` 必须消费各成员的目标化 criterion/exposure，不把 C 的 ack、HTTP 成功或一个反向命令当作目标满足。Economic C 要按 economic target/tolerance 评价，StateRestoring C 要按声明的 state target 评价，Exact C 要按 exact claim 的 identity/terms 评价。
3. **尝试解析仍独立**：C 的 criterion 已满足时，C 的 attempt 仍可能 Unknown；原 A 的 criterion 已满足时，A 的 attempt 也仍可能未解析。目标满足不等于责任结案。
4. **结案**：只有 `groupTarget` 满足，且原 child 与所有 compensation child 的 attempt 已按各自要求解析，或者其未决责任已由明确持久 owner 原子移交，同时最终 exposure/residual 符合 `residualPolicy_i`，才产生 `GroupSatisfied`。
5. **恢复**：目标已满足但任一 attempt/exposure/responsibility 未解决时，结果是保留目标并进入 `RecoveryRequired`，不报告组成功；补偿 candidate 不可构造、证据不足或 C Unknown 时也保留责任，不把失败改写成“降级后完成”。

这条规则允许一个较窄而合法的组目标，同时阻止组摘要掩盖成员缺证据。它也解释了为什么 `GroupSatisfied` 现有的“责任结清或原子移交”句子必须保留，并需要绑定到实际 claim 的残余政策。

---

## 5. 有限实例与条件规律

### 实例 A：A=`Exact`、B=`Economic`，组要求 `StateRestoring`

前提：A 的 provider evidence 证明其 exact compensation 可以针对 A 的指定状态目标；B 只能证明一个经济抵消计划，保留手续费/滑点且不改变 B 的原生 order/position state。

- 若 `StateRestoring` 是对每个 required member 的要求（例如 A、B 均须把各自指定 position projection 恢复到 baseline），`bindGroupPolicy` 拒绝 B：`ClaimMismatch` 或 `EvidenceInsufficient`。不能用 A 的 Exact 代表 B，也不能以 group max 通过。
- 这个拒绝并不证明 Economic 是“比 StateRestoring 数值更小”。它证明 B 的 `targetClaim_B` 与 `target_B` 不相容，或证据没有覆盖该 state target。
- 如果 B 的 provider 另有证据证明其 Economic plan 同时满足一个**明确指定的 state projection**，那不是核心从字符串推导出的 `Economic ⇒ StateRestoring`；应记录为 B 的附加 target claim，重新对该 claim 做 `supports_B`。

### 实例 B：同一成员，合法的更窄组目标

仍为 A=`Exact`、B=`Economic`，但政策目标改为：`groupTarget = 组合经济敞口在明确币种/时点/容差 ε 内不超过上界`；政策明确允许历史、手续费和滑点按 residual budget 留存，并有 A/B 的单位、FX、scope、coverage 与 exposure lineage 证据。

- A 的 Exact claim 和 B 的 Economic claim 均可通过各自 `supports_i`；组接受。
- B 的原生状态没有恢复，B 的费用/滑点仍由 exposure/accounting 记录；`GroupSatisfied` 只在经济 criterion、尝试解析和责任释放条件都成立时产生。
- 文档必须称其为较窄的 group economic target，不能把组结果命名成 `StateRestoring` 或声称时间倒流/原成交撤销。

这同一向量在实例 A 被拒、在实例 B 被接受，正是标量 `min` 无法表达的关系。

### 实例 C：StateRestoring 与 Economic 的目标交叉

- 一个 `StateRestoring` compensation 将 position quantity 恢复到 baseline，但政策允许保留费用；它可以满足“状态 projection 恢复”的成员目标，却不能自动满足“含费用的经济净值误差 ≤ ε”目标。
- 一个 `Economic` compensation 将另一 venue 的经济敞口抵消到 ε 内，但原 venue 的 order identity、queue state 或历史记录不变；它可以满足经济目标，却不能满足逐成员原生状态恢复目标。

因此即使不涉及 Exact，也不存在跨所有业务目标的 `StateRestoring > Economic` 全序。目标和残余政策决定可接受关系。

### 实例 D：`None` 的两种政策结果

- `IndependentBatch` 中，A=`None`、B=`Economic` 可以绑定：政策没有声明全组自动补偿；A 的失败、Unknown、exposure 和 recovery owner 仍独立可见，B 也不能回滚 A。
- `AllOrCompensate` 若要求 A 的可能敞口必须自动补偿，则同一个 A=`None` 在接纳时拒绝；不应先派发 A、失败后才把 policy 的要求改成 Economic 或把 A 解释为不需要恢复。

### 实例 E：已开始后企图降级

假设 `GroupPolicyBound` 冻结的每成员要求是 `StateRestoring`，A/B 至少一个已 `DispatchStarted`，之后 provider 只给出 Economic 计划或原先 StateRestoring 的证据失效。

- 不能修改原 policy revision，把 required claim 从 StateRestoring 降成 Economic；不能生成一个同一 `GroupSatisfied` 来掩盖原承诺。
- 原 A/B attempt、实际/未知 exposure、reservation 和 recovery owner 必须继续保留。结果可为 `RecoveryRequired`、`CompensationUnavailable` 或等待新的有授权 recovery decision。
- 若在任何 child `DispatchStarted` 前发现不匹配，可以退休未开始的旧计划并用新 revision 重新构造、批准和接纳；这是新 policy，不是运行中降级。
- started 之后若业务确实选择一个更窄的 Economic recovery target，它也只能是新的受控 C/recovery policy，显式消费旧责任并保留原 `StateRestoring` 承诺未满足的事实；不能回写原 group policy 或释放仍由原责任覆盖的锁。

---

## 6. 当前文稿的真实桥接缺口

### 6.1 设计关系缺口

1. **`GroupPolicyBound` 仍是单数 grade 的表达。** 主书表格称“允许的 compensation grade”（`docs/uta-capability-runtime-design.md:876-886`），EF09 的事件槽位也只列一个 `compensation grade`（`event-flows.md:1030-1034`）。这没有表达 `member_i → actual claim/evidence/target` 向量。
2. **没有 grade 与目标/证据的适用函数。** 当前文字定义了四个标签，但没有规定何时某个 claim 满足某个成员目标、何时证据不足、何时 group target 只能选择较窄目标。需要增加 `supports_i` 与相应拒绝分支，不需要增加固定全局业务目标枚举。
3. **`advanceGroup` 的输入没有显式携带补偿 claim 和 target contract。** `ChildProgress` 已有 criterion/resolution/exposure/responsibility，但组函数如何知道这些轴要满足哪一个成员目标、允许哪些残余、是否能处理 Unknown，尚未写出。
4. **补偿后的多轴消费没有 grade-specific 结案条件。** EF09 已说 `CompensationProgress` 和 `GroupSatisfied/RecoveryRequired`，但没有明确 C criterion、C resolution、C exposure 和原 A responsibility 在各等级下如何同时消费；尤其没有写出 StateRestoring 成功仍可保留费用、Economic 成功仍可保留 state/history 的情况。
5. **reservation/exposure/recovery 的释放仍是宽泛规则。** “补偿未确认前不释放”已正确，但需要把确认定义为目标化 criterion + attempt resolution + residual policy + release/handoff，而不是一条通用 `CompensationSucceeded` 布尔值。
6. **已开始后的 policy revision 栅栏未落到组函数。** 主书散文明确“不能失败后临时降级”，但 EF09 尚未把冻结的 per-member claim/evidence digest、`DispatchStarted` 后禁止修改和新 recovery policy 的边界写成 `advanceGroup` 的拒绝/恢复分支。
7. **`None` 的合法范围没有被精确分开。** EF09 只说自动补偿要求下 `None` 接纳时拒绝；需要同时说明 IndependentBatch 的合法 `None` 和“已知 no-effect 使某实际分支不需要补偿”不等于把 `None` 当作较低等级。

### 6.2 已经定位、但不应伪装成主机设计缺口的证据义务

下列问题仍属于具体 Provider、版本、账户/作用域和真实运行环境取证，不应由主书用一个全序或额外核心特判填空：

- native inverse/close/replace 是否真的存在、是否具有所声明的 identity 和 scope；
- provider 的完整 lookup、absence、finality、幂等 horizon、跨重连 identity 和组原子性；
- StateRestoring 对哪个状态投影成立，Economic 对哪个单位/时间/容差成立；费用、滑点、融资和外部并发的残余；
- 组合成员之间能否合法做单位、FX、scope、as-of 和 exposure lineage 投影；
- compensation input constructor 所需新增字段是否能由 A 的 Prepared、ExposureEvidence、Policy 和显式配置构造。

主书已经将这些列为 provider/account acceptance evidence，而不是 host writer 能推导的性质（`docs/uta-capability-runtime-design.md:1192-1196`, `1409-1421`, `1471-1480`）。缺证据的具体 claim 应不可用/恢复，不应把“未知”当作某个等级。

---

## 7. 具体主书修订文本建议（不在本报告中修改主书）

以下是可直接整合到主书 §10.4 的最小文本；它替换/扩展现有标量表述，不重复已有的 Recipe、Unknown 和通用 writer 说明。

### 7.1 替换等级段落（接在策略表后）

> 补偿等级不是跨所有业务目标的全序，也不能按字符串或固定 `min/max` 聚合。`Exact`、`StateRestoring`、`Economic` 分别描述带目标的逆操作/身份关系、指定状态投影和经济敞口关系；`None` 表示没有自动补偿保证。某个等级是否满足某个成员要求，必须同时检查该成员的 target、允许的 residual、uncertainty policy、输入构造和作用域化证据。只有具体 Provider/Recipe 的证据明确给出额外蕴含时，才可在该成员的 claim 中记录例如“该 Exact 也恢复此 state target”；核心不得把这种蕴含写成全局等级排序。
>
> 因而同一向量 `A=Exact, B=Economic` 可以被要求 StateRestoring 的逐成员组拒绝，也可以被只要求经济敞口容差的较窄组接受。前者的理由是 B 的 target/evidence 不满足状态要求，后者的理由是每个成员的 claim 与组目标匹配；两者都不能由一个 group `min` 得出。`None` 只在政策没有为该成员声明自动补偿、或已由冻结证据证明该实际分支不需要补偿时有效；它不是所有政策中的最低保证。

### 7.2 在“补偿目标和输入的构造”之后加入成员 claim 与组准入

> **成员 claim 与组准入。** `AllOrCompensate` 不绑定一个 scalar compensation grade，而是为每个 required member `Aᵢ` 冻结 `MemberCompensationRequirementᵢ` 与本次实际消费的一组 `MemberCompensationClaimᵢ` 关系。前者至少包含该成员的补偿 target、允许的 residual、uncertainty policy 和 reservation/exposure/recovery release policy；后者包含各 claim 的 `gradeᵢ`、实际声称的 target relation、scope/provider/binding/operation evidence、coverage/uncertainty、residual evidence 和构造 `C.Intent` 的条件式关联。同一声明可以提供多个相容 claim；`GroupPolicyBound` 保存组目标实际消费的 claim/evidence 关系及其 digest、成员集合、组级 target、失败条件和 policy revision。
>
> `bindGroupPolicy` 只有在以下条件同时成立时才接受：required members 与 child 集合完全匹配；每个成员的 claim/evidence 关系集合与其 target、scope、residual 和 uncertainty 相容；组级 target 所需的成员投影、单位/时间/来源关系、能力/保证/conformance 证据和条件式补偿输入构造可证明；所有被政策接纳的 known rejection 与 uncertainty 分支都有明确的处理/恢复 owner；原成员与可能的 compensation member 都有合法的 reservation/release 或原子 handoff 规则。绑定不要求未来发送前已经存在实际 exposure；补偿触发时必须取得实际 `ExposureEvidence` 并重新核验冻结 claim。缺任一条件返回 typed `ClaimMismatch`、`EvidenceInsufficient`、`GroupTargetUnconstructible`、`UncertaintyNotAdmitted` 或 `CompensationUnavailable`，不把 claim 降级后继续派发。
>
> `None` 在 `IndependentBatch` 中可以表示该成员没有组级自动补偿承诺；在要求自动补偿的 `AllOrCompensate` 中，对可能暴露敞口的 required member 必须在绑定时拒绝。某一次 child 后来被充分证实为未开始且无效果，只说明该实际分支不需要创建 compensation work，不改变已绑定的 `None`/非 `None` 语义。

### 7.3 扩展“成员到 coordinator 的构造”与组结案

> `advanceGroup` 消费 `GroupPolicyBound` 的成员 claim/evidence 关系集合，以及每个原 child 的 `criterionᵢ`、`resolutionᵢ`、`ExposureEvidenceᵢ`、reservation disposition 和 recovery responsibility；若已创建 C，则同时消费 C 自身的 criterion、resolution、ExposureEvidence 和责任。它不通过 `min/max(gradeᵢ)` 产生组结果。
>
> 组失败只有在冻结的 failure condition 被成员事实触发，且实际/政策允许处理的敞口和责任存在时，才产生 `BatchCompensationRequired`。补偿 planner 在该时点取得实际 exposure/coverage/uncertainty，并重新核验成员 claim 的 target-specific construction；核验失败走恢复/不可用。C 的目标由成员 claim 的 target-specific criterion 判定：StateRestoring 不等于 Economic，Economic 不等于原 native state 恢复，Exact 也只有在其 exact target/evidence 成立时才满足。C 的 ack 或反向命令不能替代 criterion/resolution/exposure。
>
> `GroupSatisfied` 需要组级 target 满足、原 child 与 compensation child 的尝试均已解析或由持久 owner 原子移交，并且各成员最终 exposure/residual 符合冻结的 residual policy；目标已满足但 attempt、Unknown、敞口或责任仍未结清时只能保留 target 并进入 `RecoveryRequired`。`DispatchStarted` 之后不得把已冻结的 StateRestoring/Exact claim 原地改为 Economic；新的较窄 recovery target 若被允许，也必须是新受控关联并保留原 policy 未满足的事实。

### 7.4 EF09 的最小表格替换

将 `event-flows.md:1030-1038` 中的相关行改为以下语义（字段名可按实现命名，但不能退回 scalar grade）：

| 事件/工作说明 | 需要表达的最小内容 |
|---|---|
| `Control<Batch, GroupPolicyBound>` | required members、failure condition、`memberRequirementᵢ`、本次实际消费的一个或多个 `memberClaimᵢ` 关系与 evidence digest、group target、uncertainty policy、release/handoff policy、policy revision；`None` 只按该 policy 的自动补偿承诺判断。 |
| `Control<Batch, ChildProgress>` | 原 child 的 criterion、attempt resolution、ExposureEvidence、reservation disposition、recovery owner，以及引用的 member claim/target。 |
| `Control<Batch, BatchCompensationRequired>` | 被触发的 failure condition、实际/允许处理的成员敞口、责任引用和仍满足冻结 claim 的 compensation construction；实际 exposure 到此时才取得并重新核验；不携一个可重新解释原 policy 的 scalar grade。 |
| `CompensationCandidate<A,C>` | 原 A 的 claim/target/evidence 引用、C.binding、C.Intent、原敞口与责任引用；C 继续独立 prepare/approve/start/observe/recover。 |
| `Control<Batch, CompensationProgress>` | C 的 target-specific criterion、attempt resolution、ExposureEvidence、reservation disposition、recovery owner 和原 A/C 责任关联；不要用 `CompensationSucceeded` 布尔值替换这些轴。 |
| `Control<Batch, GroupSatisfied/RecoveryRequired>` | group target 结果、每成员原/补偿 criterion 与 resolution、残余 exposure、reservation release 或原子 handoff 证据；started/unknown/未结责任不能被摘要吞掉。 |

在 EF09 `9.3` 不变量后增加：

> **成员 claim 不能降级。** `GroupPolicyBound` 冻结每个成员实际消费的 target、claim relation(s)、evidence scope、residual 和 uncertainty policy；同一声明可有多个相容 claim，但 `DispatchStarted` 后不得替换这些关系。证据不足或原 claim 失效进入 `RecoveryRequired/CompensationUnavailable`，不能把原组要求改成较低等级。未开始的整组可通过新 policy revision 退休并重建；已开始的成员必须保留原 attempt、exposure 和责任。新 recovery target 是新的受控关联，不改写原组承诺。
>
> **组目标不是等级折叠。** `GroupSatisfied` 由 group target 与成员多轴 progress 的函数产生。一个 `Economic` claim 可以满足明确的经济组目标而不满足状态组目标；一个 `StateRestoring` claim 可以满足明确的状态投影而仍留下经济 residual。`None` 只在没有相应自动补偿承诺的政策/分支中成立。

这些修订足以把当前已经存在的 `ChildProgress`、CompensationCandidate 和 release/handoff 关系接到 group grade；不需要另加全局业务状态枚举、通用 workflow 或新的权限类型。

---

## 8. 证据范围与剩余边界

### 本报告实际核对的设计证据

- 主书 §9.1–§9.5：纯决定、准备值、attempt/reservation、writer 提交和责任结案的总体约束（`docs/uta-capability-runtime-design.md:690-787`）。
- 主书 §10.1–§10.4：Recipe 槽位、criterion/resolution、四种补偿等级、固定/动态补偿输入构造、成员 `ChildProgress` 与有限反例（`docs/uta-capability-runtime-design.md:791-900`）。
- 主书 §10.5：未知敞口、责任移交和终止释放边界（`docs/uta-capability-runtime-design.md:902-916`）。
- EF09 的策略 ADT、事件槽位、组合时序及不变量（`event-flows.md:1013-1170`）。
- 当前目标审核对该问题的定位（`local://uta-current-research/goal-audit.md:116-138`）。

### 这份报告证明什么、不能证明什么

本报告是对当前候选设计的条件推导和有限实例，不是生产实现、真实 Broker 或 provider conformance 证据；未运行 build、lint、项目测试、Broker、账户或权限环境。本研究产物自身未修改主书和 EF09；Main 后续整合后的回读见附录。它证明的是：若采用成员目标/claim/evidence 绑定和显式 group acceptance/terminal consumption，`Exact/StateRestoring/Economic/None` 的异构语义能够进入现有 `ChildProgress`/新 Recipe/责任释放结构，并能区分过强要求与合法较窄目标。

它不证明任一具体 Provider 的 Exact、StateRestoring 或 Economic 逆操作真的存在；不证明 native finality、lookup、幂等、跨 venue 原子性、费用/滑点上界、跨重连 identity 或 compensation dispatch 的成功。主书已经把这些作为按 Provider/版本/账户取证的边界（`docs/uta-capability-runtime-design.md:1192-1196`, `1471-1480`）。实现阶段若缺这些证据，必须保留 `Unavailable/RecoveryRequired`，不能用字符串等级、Mock 计数、host writer 顺序或 group summary 补足。

整合前需要收敛的不是“选哪一个等级排序”，而是每次 `GroupPolicyBound` 是否保存了：**每个成员的真实 target、实际 claim、证据范围、可接受残余、组目标、Unknown 处理和 release/handoff 责任**。这就是本报告定位的最小桥接；当前正文的整合回读见附录 §10。

---

## 9. Main 复核后的收窄说明

Main 回读本报告后保留“禁止跨目标按标签 `min/max` 聚合”的核心推理，并对两处表达作如下收窄；这不是撤回前述反例，而是避免把局部条件写成更强的普遍禁令：

1. 本报告原先用“核心不能假设 `Exact ⇒ StateRestoring`”作反例说明。准确边界是：**不能仅凭标签、跨目标或跨证据域假设该蕴含**；在相同 target projection、scope、evidence domain 和 criterion 条件内，Provider/Recipe 可以用充分证据证明 `Exact ⇒ StateRestoring`，并把它冻结为该成员的 target-specific claim。相同方式适用于其他等级之间的具体蕴含；它们不能因此升级为全局全序。
2. 本报告原先在伪代码中写“每个成员恰好一个 claim”。准确构造是每个成员冻结一组本次政策实际消费的 claim/evidence 关系；同一声明可以暴露多个相容保证，组目标可能同时消费它们。桥接要求是冻结实际选择/关系与 digest，而不是强制一个 claim 或让运行时重新挑选等级。
3. `GroupPolicyBound` 的前置证明是成员能力/保证/conformance、作用域化 evidence、组目标投影和**条件式**输入构造可用；它不需要在发送前预见未来的实际敞口。补偿被触发后，planner 才读取实际 `ExposureEvidence`，按冻结的 claim/target/residual/uncertainty 重新核验，再决定是否能构造 C.Intent。核验失败进入恢复或不可用，不得静默降级。

因此本报告的最终桥接仍是：先冻结成员的 claim/evidence 关系，按组目标完成准入，补偿触发后重验实际敞口，最后依据 criterion、resolution、exposure 和 responsibility 的多轴结果结案；被收窄的是蕴含和 claim cardinality 的表述，不是该消费链的结论。

---

## 10. Main 整合后的双目标轨迹回读

Main 将本报告的桥接关系整合进主书 §10.4 与 EF09 后，本报告重新读取当前正文，不再扩大研究范围。当前主书 `docs/uta-capability-runtime-design.md:892-906` 与 EF09 `docs/uta-capability-runtime-design/event-flows.md:1024-1040`, `1099-1146` 的关系与本报告的有限轨迹一致：

1. `A=Exact, B=Economic` 且政策要求逐成员 `StateRestoring` 时，在 B 的 target/证据域拒绝；A 的 Exact 不替代 B 的保证。
2. 同一成员组合改用明确的组级经济目标、单位/范围/时间/容差与对应证据时可以接纳；结果不能称为原状态恢复。
3. `GroupPolicyBound` 的前置证据证明能力/保证/conformance 和条件式输入构造，不伪造未来 exposure；补偿触发后读取实际 `ExposureEvidence` 并重验冻结关系。
4. 同目标/证据域内有充分证据时，具体 `Exact ⇒ StateRestoring` 等蕴含可以作为成员 claim；正文只禁止跨目标、跨成员或跨 Provider 按标签 `min/max`。
5. 成员 claim/evidence 是实际消费的关系集合，不强制每成员恰好一个 claim；`CompensationProgress` 与 `GroupSatisfied/RecoveryRequired` 继续消费 criterion、resolution、exposure、责任和 residual。

因此第 6 节列出的“桥接缺口”是整合前的研究定位；当前正文已补上这些关系，本报告附录只记录回读和 Main 的收窄，不提出新的控制或证据范围。