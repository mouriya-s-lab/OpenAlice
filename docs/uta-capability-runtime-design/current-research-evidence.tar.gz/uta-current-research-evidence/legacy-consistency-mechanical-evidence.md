# Legacy accommodation consistency — mechanical evidence

## Deliverables

- Research report: `local://uta-current-research/legacy-consistency.md`
- Repository files edited: `docs/uta-capability-runtime-design/legacy-accommodation.md` and `docs/uta-capability-runtime-design/legacy-accommodation.json`.
- Repository files deliberately not edited: the main design book, `event-flows.md`, `legacy-bindings.md`, and the original solution/audit material.

## Exact edit boundary

The approved current design fields changed only where the approved consistency corrections applied:

- `abstractExpression`
- `effectAndStateOwnership`
- `migrationCutover`
- `preservedContract`
- `selectedChanges`

The JSON changed-value counts were: `abstractExpression` 23, `effectAndStateOwnership` 5, `migrationCutover` 20, `preservedContract` 26, `selectedChanges` 22, and `failuresAndRecovery` 1 (97 changed values total). All changes are within these six approved current design fields; no other JSON keys changed.

The Markdown had 10,445 lines before and after the edit. It has 97 distinct changed lines. The JSON had 53,506 lines before and after the edit. It has 97 distinct changed lines. Both changed-line sets are the exact approved correction plus mirror-sync set; no unrelated line changed.

Final Markdown changed-line ranges:

`100, 1303-1305, 1326, 1328, 1331, 1351, 1353, 1355, 1468, 1470, 1472, 2749, 3626, 3668, 3762-3763, 3765-3766, 3770, 3781, 3784, 3788, 3790, 3798, 3812, 3814, 3818, 3820, 3828, 3972, 3974, 3978, 3980, 3988, 4517, 4793, 4805, 4841, 5527, 5534, 5544, 5560, 5588, 5757, 5785-5789, 5797, 5799, 5801, 5804, 5811, 5813, 5815, 5817, 5819, 5823, 5825, 5827, 5829, 5831, 5890, 5892, 5894, 5896, 5898, 5927-5928, 5932, 5946, 5949, 5961, 5980, 5988, 6139, 6147, 7211, 7357, 7798, 7934, 8043, 8046-8047, 8051, 8059, 8064, 8074, 8076, 8088, 8108, 8148, 8386, 10062`

Final JSON changed-line ranges:

`81, 1566-1568, 1588, 1590, 1593, 1612, 1614, 1616, 1725, 1727, 1729, 3582, 4451, 4502, 4643-4644, 4646-4647, 4651, 4661, 4664, 4668, 4670, 4678, 4691, 4693, 4697, 4699, 4707, 4847, 4849, 4853, 4855, 4863, 5595, 5949, 5960, 5981, 6862, 6869, 6878, 6894, 6921, 7086, 7133-7137, 7144, 7146, 7148, 7151, 7157, 7159, 7161, 7163, 7165, 7168, 7170, 7172, 7174, 7176, 7232, 7234, 7236, 7238, 7240, 7312-7313, 7317, 7330, 7333, 7345, 7363, 7371, 7518, 7526, 8819, 9167, 9584, 9731, 9920, 9923-9924, 9928, 9936, 9940, 9950, 9952, 9964, 9984, 10023, 10257, 12485`

For every target line, the old target fragment is absent and the approved replacement fragment is present in context.

## Preservation checks

A persistent Python document check performed after writing observed:

- Both files retain their original line counts.
- The JSON parses successfully as a dictionary both before and after the edit.
- `currentBehavior`: 99 values before and after; all values equal.
- `sourceReferences`: 1,562 values before and after; all values equal.
- All JSON data outside the six approved current design fields listed above is structurally equal before and after.
- For each targeted replacement, the old target fragment is absent and the approved replacement fragment is present in context.

## Markdown/JSON mirror check

A field-aware document parser compared the 99 JSON sections with the 99 Markdown sections across eight mirrored fields (`currentBehavior`, `abstractExpression`, `preservedContract`, `selectedChanges`, `effectAndStateOwnership`, `failuresAndRecovery`, `empiricalEvidenceBoundary`, and `migrationCutover`), for 792 section-field pairs. Markdown HTML entities were decoded before comparison.

- The 97 changed approved-field values compare equal across Markdown and JSON: `abstractExpression` 23, `effectAndStateOwnership` 5, `migrationCutover` 20, `preservedContract` 26, `selectedChanges` 22, and `failuresAndRecovery` 1. The direct changed-value mismatch count is zero.
- The full document comparison has 16 pre-existing mismatches both before and after this work; the mismatch signature is unchanged, so this edit introduced zero new mirror drift. Those retained signatures are `LSURFACE-ALICE-TRANSPORT`, `LSURFACE-ALICE-DATA`, `LSURFACE-ALICE-AUDIT`, `LSURFACE-ALICE-CONTROL`, `LSURFACE-ALICE-LIFECYCLE`, `LSURFACE-HTTP-DATA`, `LSURFACE-HTTP-CONTROL`, `LSURFACE-HTTP-SIMULATOR`, `LSURFACE-SUPP-DATA`, `LSURFACE-SUPP-PROVIDER`, `LSURFACE-SUPP-TRIGGER`, `LSURFACE-LIVE-DISCOVERY`, `LSURFACE-LIVE-EFFECTS`, `LSURFACE-LIVE-EVIDENCE`, `LSURFACE-LIVE-SIMULATION`, and `LSURFACE-LIVE-ACCEPTANCE`, each at `effectAndStateOwnership[0]`. Their retained structural difference is that JSON stores a role-map object while Markdown renders role-prefixed lines; this evidence does not claim whole-document equality.
- The added coverage item is a section-level (no MAP label) `LCORE-DATA-CATALOG` `failuresAndRecovery[0]` mirror: Markdown `legacy-accommodation.md:4841` and JSON `legacy-accommodation.json:5981`. Before: `UnknownInstrument、UnsupportedLeaf、NoRefresh、Unavailable、Partial/Gap、OutputDecodeFailure、ProviderError 和 authorization filter 分离；public query 不应生成 AccountScope 或 mutation job。` After: `UnknownInstrument、UnsupportedLeaf、NoRefresh、Unavailable、OutputDecodeFailure、ProviderError 和 authorization filter 分离；Kernel Coverage 仍只有 Complete|Partial|Unavailable。Gap 仅是带 partition/range/recovery policy 的 continuity evidence，可使该 partition/result 保持 Partial 或 Unavailable，不能在 Gap 后自动 Completed；public query 不应生成 AccountScope 或 mutation job。`
- The guard consumption-policy sentence is an exact Markdown/JSON mirror at `legacy-accommodation.md:7934` and `legacy-accommodation.json:9731`: `本节选择approval/queue消费cooldown/exposure；其他RuleDeclaration可以显式选择DispatchStarted消费，不以本节示例作为公共默认。`

The edit did not touch the original solution files, the main design book, event-flow material, or `legacy-bindings.md`; no production code or project-wide tests/build/lint/formatter were run. Ephemeral Python document processing and structural checks were used for the approved document edits; the parallel Readability review owns parser validation.

## Modification themes represented

- Legacy parser and aliases are restricted to offline import/provider-local lookup; runtime callers cut over to branded codecs and `InstrumentResolver`.
- IBroker/DTO, pack, route, health-carrier, connection, HTTP, observation, projection, and Git export compatibility is one-way, versioned, read-only, and conditional on a specifically confirmed published external protocol; absent that responsibility, internal callers cut over and the legacy path is deleted.
- Listing omission, nullable/empty/`[]`, zero values, zero `AccountInfo`, static arrays, historical bars, and DTO shapes cannot enter core authority or turn transport failure into absence.
- `Gap` remains continuity evidence and cannot imply completion; ordinary `Cancelled` remains valid after confirmed observation and is not made conditional on a published protocol.
- Promise/lifecycle and config projections remain outer representations only; they never claim remote effect success or create a dual runtime path.

## Sensitive material

No credentials, tokens, private keys, connection strings, or other sensitive material were introduced, copied, or found in the edited prose or this evidence file.

## Verification boundary

This was an explicitly design/document-only change. Runtime execution was not applicable. The field-aware Markdown/JSON parser and preservation checks above are the completed mechanical validation for this subtask; no project-wide validation was run here.
