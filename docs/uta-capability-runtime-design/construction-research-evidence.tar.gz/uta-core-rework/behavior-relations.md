# BehaviorRelations：原始 UTA 核心行为关系草稿

> 这是一份供 Main 回查、试用的核心表达草稿，不是 EF/Provider 章节清单，也不是把旧契约重新命名。研究输入限定为：原始用户场景、原始 Effect/Decision 材料、旧 guard/TradingGit 实现，以及只读行情 `bar-service`。按本轮约束，现有 `event-flows`、主书第 16 章及其派生的 deferred/source/checkpoint 协议时序不作为设计依据。

## 1. 先固定可组合的关系，而不是固定业务对象槽位

原始 Effect/Decision 材料给出的最小语义是：

```ts
type UtaEffect<Success, Failure, Requirements> =
  Effect.Effect<Success, Failure, Requirements>

interface Decision<State, Command, Event, ExternalEffect, Failure> {
  readonly decide: (
    state: State,
    command: Command,
  ) => Either<{
    readonly events: NonEmptyReadonlyArray<Event>
    readonly effects: ReadonlyArray<ExternalEffect>
  }, Failure>
}

interface Evolution<State, Event> {
  readonly evolve: (state: State, event: Event) => State
}
```

见 `docs/uta-effect-runtime-architecture.zh-CN.md:202-254`。这里的关键不是把所有能力塞进 `Decision`，而是分开三件事：

1. **边界效果**：适配器、HTTP、SDK/gateway、订阅和文件/队列等外部工作，先返回可校验的值或显式失败。
2. **业务决定**：纯函数根据当前状态和请求/观察作出接受或拒绝，并列出被接受的事实和需要解释执行的外部工作。
3. **演化**：只由已接受的事实推进业务状态；不能把一个外部调用的 `success` 偷换成“业务已经完成”。

因此本稿使用一个很小的关系记号：

- 一次 pull 的计算形态沿原始 Effect 记号表达为 `Effect<A, E, R>`。
- 实时 push 的计算形态沿原始 Stream 记号表达为 `Stream<X, E, R>`；失败属于该效果/流的错误通道，不把失败伪装成 `X`。
- `decide : (State, Command) -> Either<AcceptedFacts + ExternalWork, Failure>`：业务决定；`ExternalWork` 还没有被解释执行。
- `evolve : (State, AcceptedFact) -> State`：纯状态演化。

这四个关系是行为方向，不是要求每个业务都声明同一组字段。下面用真实契约检验它们能共用到哪里、在哪里断裂。

## 2. 各材料的真实行为

### 2.1 Candle、Pull、Push：值相同不代表交付关系相同

原始用户明确要求：Candle 是统一基本 K 线加提供商自定义 schema 扩展；实时与非实时是两种完全不同的通讯，前者 push、后者 pull，但抽象应能平衡差异（`local://uta-original-user-inputs.txt:78-90`）。

原始材料只给出两个核心要求：

- Candle 的统一值由一个基本 K 线和提供商自定义 schema 扩展组成。
- 实时数据与非实时数据分别通过 push 与 pull 交付；push 的结果形态类似 UTA 向 stdout 输出，pull 是标准调用返回。

原始用户没有规定 push frame、sequence、终止控制或运行时 schema。由此能确定的是：同一领域值可以被不同 delivery relation 交给消费者；不能从这两句话继续推导一套固定的流协议。

旧行情 successor 是一个明确的 pull 实例，而不是 push 的伪装：

- `BarService.getBars(ref, opts)` 对 `{symbol, assetClass}` 路由 vendor；对显式 `barId` 路由 UTA 或 vendor（`src/domain/market-data/bars/bar-service.ts:371-387`）。
- vendor 分支调用一个历史数据 client，过滤缺失 OHLC、按时间整理并截断后返回 `BarsResult`（`src/domain/market-data/bars/bar-service.ts:193-235`）；UTA 分支检查历史能力，调用 `acct.getHistorical`，转换 wire `Bar` 后返回 `BarsResult`（`src/domain/market-data/bars/bar-service.ts:238-274`）。
- UTA 的真实 broker 契约只有 `getHistorical?(contract, params): Promise<Bar[]>`，`Bar` 只有 timestamp/OHLCV，没有 source identity、sequence、closed/finality、correction/retraction 或 replay boundary（`packages/uta-protocol/src/types/broker.ts:349-364,589-595`）。
- `calc-v2`、`simulate`、`snapshot` 都直接消费 `{bars, meta}`；例如 `src/domain/analysis/calc-v2/evaluator.ts:107-111`、`src/domain/analysis/simulate.ts:85-98`、`src/domain/analysis/snapshot.ts:105-115`。它们计算指标、选择 entry 或生成 stale warning，不改变订单状态。

因此 `BarsResult` 可作为 pull 的输出，但不能直接充当“已经发生的实时订阅事件”：当前真实 broker `Bar` 只有 timestamp/OHLCV，`meta.asOf` 只是一次读请求的时间锚点。未来 push 如何表示重复、终止或最终性，原始材料没有给出，必须留在后续真实提供商/消费者关系中推导。

### 2.2 数据触发等待订单：原始场景与当前代码边界

原始用户只预设了这一行为：等待提交的订单可能由特定 K 线订阅事件触发；默认设置如果是“返回 agent”，就给 AI 生成警告，询问这条订单是否还需要保留、如何保留（`local://uta-original-user-inputs.txt:93-96`）。

和现有函数逐步对照，可以确定：

1. 只读行情的现有消费是 `getBars(ref, opts)` 返回有限 `BarsResult`，随后由 `evaluator.fetchBars`、`simulate` 或 `getSnapshot` 计算/展示；这些函数没有把读取结果变成订单提交（`src/domain/market-data/bars/bar-service.ts:371-387`；`src/domain/analysis/calc-v2/evaluator.ts:107-111`；`src/domain/analysis/simulate.ts:85-98`；`src/domain/analysis/snapshot.ts:105-115`）。
2. 用户场景另要求一种尚不存在的消费：某个等待中的订单意图接收特定 Candle 订阅结果，判断是否达到触发条件；达到后按配置向 AI 提问，或进入某个尚未定义的后续行为。
3. 当前 `IBroker` 只有 `getQuote`、`getMarketClock` 和可选 `getHistorical`，没有订阅函数；当前 broker `Bar` 也没有事件身份或流游标（`packages/uta-protocol/src/types/broker.ts:349-364,553-595`）。所以不能用现有 `getBars` 函数冒充这条触发消费路径。

触发场景仍需由真实函数和消费者共同补足，当前不能预先命名或固定：

- 等待订单如何保存订阅与触发条件；
- 订阅结果由谁、以什么证据交给等待订单；
- “返回 agent”警告的实际交付函数和 AI 回复如何回到订单意图；
- 非 `return-agent` 配置是否存在，以及它如何进入正常下单路径。

### 2.3 旧 guard-pipeline/CooldownGuard：准入检查本身已经含有副作用

真实签名是：

```ts
createGuardPipeline(
  dispatcher: (op: Operation) => Promise<unknown>,
  account: IBroker,
  guards: OperationGuard[],
): (op: Operation) => Promise<unknown>
```

见 `services/uta/src/domain/trading/guards/guard-pipeline.ts:13-35`。非空 guards 时，一次调用先并发执行 `account.getPositions()` 与 `account.getAccount()`，逐个 `guard.check(ctx)`；首个字符串结果立即返回 `{success:false,error}`，全通过才调用 dispatcher。空 guards 直接返回 dispatcher。guard 自身只承诺 `null` 或字符串（`guards/types.ts:4-20`）。

`CooldownGuard` 对 `placeOrder` 以 `getOperationSymbol(op)` 和 `Date.now()` 查询进程内 `Map<string, number>`；通过后立即写入 `lastTradeTime`，再让管线继续（`cooldown.ts:6-32`）。旧 helper 对 modify/cancel/sync 没有 symbol，返回 literal `unknown`（`packages/uta-protocol/src/types/git.ts:310-321`）。这不是一个纯 `check : Context -> Decision`：它同时读取账户、占用时间窗口，并且占用发生在 dispatcher 之前。

因此旧管线能表达的是一个**准入 continuation**：

```ts
admit : Operation -> Effect<DispatchResult | GuardRejection, AccountRequirements>
```

但当前实现把 reservation 隐藏在 `check` 中。已有故障注入记录了可重复的结果：`[Cooldown, later rejecting guard]` 第一次由后续 guard 拒绝，第二次却被 cooldown 拒绝，而执行器调用次数仍为零（`docs/uta-effect-runtime-design/solutions/source-experiments.md:61-72`）。这正是“检查结果”和“已消费的状态”不能由一个布尔/字符串结果代替的断点。

### 2.4 TradingGit：远端调用成功、订单状态成立、日志提交成功是三件事

旧 `TradingGit.push(expectedPendingHash)` 的输入是调用者提供的 pending hash；它检查 prepared/CAS 后，逐个调用 `config.executeOperation(op)`，再读 `getGitState()`，追加内存 commit，调用 `onCommit`，最后清空 staging（`services/uta/src/domain/trading/git/TradingGit.ts:119-185`）。`UnifiedTradingAccount` 在构造时把 `guardedDispatcher` 赋给 `gitConfig.executeOperation`（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:179-205`），所以真实调用顺序是：

```mermaid
sequenceDiagram
    participant Caller
    participant UTA as UnifiedTradingAccount
    participant Git as TradingGit
    participant Guarded as guardedDispatcher
    participant Account as Broker reads
    participant Guards as Guard chain
    participant Broker as Broker mutation
    participant Snapshot as getGitState
    participant Persist as onCommit

    Caller->>UTA: push(expectedPendingHash)
    UTA->>Git: git.push(hash)
    Git->>Guarded: executeOperation(op)
    Guarded->>Account: getPositions + getAccount
    Account-->>Guarded: positions + account
    Guarded->>Guards: check(ctx)
    alt guard rejects
        Guards-->>Guarded: rejection string
        Guarded-->>Git: {success:false,error}
    else all guards pass
        Guarded->>Broker: dispatcher(op)
        Broker-->>Guarded: raw broker result
        Guarded-->>Git: raw result
    end
    Git->>Git: parse result for each operation
    Git->>Snapshot: read state after execution
    Snapshot-->>Git: GitState
    Git->>Git: append commit and advance head
    Git->>Persist: exportState()
    Persist-->>Git: callback result
    Git-->>UTA: PushResult(submitted, rejected)
    UTA-->>Caller: PushResult
```

`parseOperationResult` 只把 `rawObj.success === true` 当作成功；status 由 `OrderState.status` 映射，缺少或未知状态默认 `'submitted'`（`TradingGit.ts:929-976`）。所以：

- `success: true` 不是 filled，也不是最终业务期待已成立；`submitted` 只是当前观测状态。
- `getGitState` 或 `onCommit` 在远端动作后失败时，pending 仍可保留；已有 E01 实验观察到同一 pending hash 重试会再次调用 executor，导致重复远端动作（`source-experiments.md:7-24`）。
- 旧实现的 `executeOperation` 是外部效果解释器，但它在本地 accepted/persisted fact 之前执行；这与原始 `Decision` 中“Event 是已接受并持久化的事实、ExternalEffect 是待跨边界执行的工作”的语义不同（Effect/Decision 原文：`docs/uta-effect-runtime-architecture.zh-CN.md:230-254`）。

这不是要求把 TradingGit 继续扩成新核心，而是一个反例：核心关系必须能表示“外部结果未知/已提交但本地保存失败”，不能用一个成功布尔值覆盖远端、业务状态和持久化三个观察点。

### 2.5 `bar-service`：数据读取、来源选择、消费投影，不是订单事务

`bar-service` 的输入是 `BarSourceRef` 与 `GetBarsOpts`。`barId` 明确是 `sourceId|nativeSymbol`，不同来源不做跨源归一化（`src/domain/market-data/bars/types.ts:1-17,31-45`）。输出是 `BarsResult = { bars: OhlcvBar[]; meta: BarMeta }`（`src/domain/market-data/bars/types.ts:56-109`），其中 `meta` 记录来源、barId、能力和 freshness；每根 `OhlcvBar` 是 read-only OHLCV 数值。

它的副作用是读取 vendor/UTA 外部数据并在本地规范化：过滤不完整 OHLC、按时间排序、限制 5000 根、计算 `asOf/isLatestActual/staleTradingDays`（`src/domain/market-data/bars/bar-service.ts:193-274`）。如果 UTA 没有声明历史能力，服务在调用 `getHistorical` 前显式拒绝（`src/domain/market-data/bars/bar-service.ts:244-249`）。消费者把该值用于量化、回测、快照和 stale warning，而不是提交订单或写交易 WAL。

这给出一个很窄但稳定的共同关系：**来源适配器返回有边界的观察值，消费者再决定是否计算、显示或进入另一条业务决定路径**。但 `BarsResult` 本身不产生交易事实；若未来要让行情触发订单，订阅结果到等待订单之间仍需由真实函数和消费者定义关系，不能把 `getBars` 的返回值直接当作已发生的订阅事件。

## 3. 共同关系的交叉检验与断点

### R1：IO 结果可以进入续接，解析只是局部实现

可复用的计算关系是结果续接，而不是一个共同的业务结果类型：

```ts
flatMap : Effect<A> × (A -> Effect<B>) -> Effect<B>
consume : Stream<A> × (A -> Effect<B>) -> Effect<Consumption>
```

这里的 `A`、`B` 由具体能力决定。`barService.getBars` 的 `BarsResult` 被 evaluator/simulate/snapshot 继续计算；`TradingGit` 的 executor 返回值被 `parseOperationResult` 继续转成提交结果；guard 读取账户结果后继续运行 guard chain 和 dispatcher。它们都证明“IO 结果可以成为下一步函数的输入”，但并不证明结果拥有相同的持久化或业务含义。

解析、规范化是各边界的局部实现：bar-service 将 raw/wire bars 变成 `BarsResult`，TradingGit 将 raw response 变成 `OperationResult`，guard 将账户读取组装为 `GuardContext`。Candle 触发消费当前没有对应的真实函数。

交叉测试立即出现断点：

- `BarsResult` 缺少 `OperationResult` 所需 action/status，不能作为订单结果。
- `OperationResult` 含订单动作和提交状态，不能作为 Candle 数据值。
- guard 的字符串拒绝没有 provider error 的 ADT，也没有与有限数据读取相同的结果拓扑；把它们统一成 `{success, error}` 会丢失错误来源和已消费状态。

**结论**：共同点支持 IO 结果的续接和组合计算；解析/normalize 只是其中的边界步骤，不是核心唯一的统一物。Output、Error、State 仍由能力和消费者精确化。

### R2：Pull 与 Push 是同一值契约的两种交付关系；旧 `TradingGit.push` 不属于这个 Push

Candle 场景只明确：实时数据通过 push、非实时数据通过 pull；前者类似向 stdout 输出，后者是标准调用返回。它没有进一步规定流项、终止或重放的固定形状。

交叉测试：

- 把 `BarsResult` 当作实时订阅事件，当前 `Bar` 没有事件身份，而且现有 `getHistorical` 是有限 Promise 读取；无法据此构造等待订单的订阅消费。
- `TradingGit.push` 虽然同名，但签名是 `Promise<PushResult>`，并且执行 broker mutation；它是写操作提交，不是用户所说的实时数据 push。名称相同不能推导同一关系。

**结论**：核心可以让同一领域值通过 pull 或 push 进入后续计算；写入/读取的业务效果和未决的流消费语义必须另行解释，不能用一个同名高阶函数掩盖两者。

### R3：观察、决定、外部工作可串接，但不能互换

普通数据消费和持久业务决定都能继续消费 IO 结果，但提交顺序不同，不能写成一条字符流程：

```mermaid
sequenceDiagram
    participant Source
    participant Read as Read consumer
    participant Caller
    participant Committer as Decision committer
    participant Decision
    participant Store
    participant Work
    participant External

    alt ordinary data consumption
        Source->>Read: pull result or stream item
        Read->>Read: pure calculation / projection
        Read-->>Caller: derived result
    else durable business decision
        Source->>Committer: observation as command input
        Committer->>Decision: state + command
        Decision-->>Committer: accepted facts + external work
        Committer->>Store: persist accepted facts and work
        Store-->>Work: committed work
        Work->>External: interpret work
        External-->>Work: effect result
        Work->>Committer: result becomes next command
        Committer->>Decision: next state + command
    end
```

实例验证：

- `bar-service -> quant/snapshot/simulate` 在末端是计算/展示投影，没有 broker effect。
- 原始 Candle 等待场景只保证：特定订阅结果触发后，若配置为 return-agent，则给 AI 生成询问订单是否/如何保留的警告；警告的实际交付函数、AI 回复和后续行为尚未由现有代码定义。
- `guard -> dispatcher` 是旧代码中的串接，但 Cooldown reservation 藏在 guard 内，故不能当作纯决定。
- `TradingGit -> broker` 是外部效果，但旧顺序先 remote mutation 后 commit，不能假定它已经符合 `Decision` 的 accepted-fact 语义。

交叉测试：把 bar read 强行登记为订单事件，会让普通分析读取获得交易事务语义；把尚未定义的 trigger 警告当成 broker `OperationResult`，会错误地声称 AI 尚未决定的订单已提交；把 guard rejection 当成所有决策失败，则掩盖账户读取失败和 cooldown 已写入的事实。

**结论**：核心需要保留“效果被解释”和“决定/演化”的方向关系，不需要一个覆盖 data、guard、order、AI review 的万能 pipeline。

### R4：重复、顺序、最终性的身份属于关系边界，不存在一个全局 ID

真实材料中的身份用途不同：

- `barId = sourceId|nativeSymbol` 是选择读取来源的操作身份，不是某一根事件的身份（`src/domain/market-data/bars/types.ts:1-17,31-45`）。
- 当前 broker `Bar` 只有 timestamp/OHLCV，没有事件身份、来源游标或最终性字段（`packages/uta-protocol/src/types/broker.ts:349-364`）；等待订单的订阅事件身份仍未定义。
- Cooldown 以 symbol 加进程内时间 map 做准入窗口，且某些 operation 只能得到 `unknown`（`services/uta/src/domain/trading/guards/cooldown.ts:15-31`; `packages/uta-protocol/src/types/git.ts:310-321`）。
- TradingGit 的 pending hash/commit hash 是本地 staging/CAS/提交链身份，orderId 是券商订单身份（`packages/uta-protocol/src/types/git.ts:13-16,60-77,119-125`）。

交叉测试：

- 用 bar 日期或 barId 充当 Candle event id，无法区分多来源同时间、修订和重复帧。
- 用 TradingGit commit hash 当未来 provider stream cursor，hash 绑定 message/operations/parent，不表示未定义来源事件的顺序。
- 用 symbol cooldown map 作为触发器去重，无法区分同一标的上的不同等待意图。

**结论**：核心不能在最外层发明一个全局 `id` 槽位替代这些语义；每条关系需要的身份和证据必须由真实提供者、消费者和持久边界共同确定。

### R5：`success`、`submitted`、空结果不是同一个终态

- 一次 pull 返回与实时 push 观察不是同一种终止语义；原始用户没有规定 push 的终止形状。
- `BarsResult.bars = []` 是一次有限窗口读取没有合格数据；它不是“没有发生过 Candle 事件”。
- `OperationResult.success = true` 可能只得到 `status: 'submitted'`；未知状态也默认 submitted（`services/uta/src/domain/trading/git/TradingGit.ts:942-976`）。
- guard 的 `{success:false,error}` 是一次准入拒绝，但可能已经改变 Cooldown 内存状态；它不是 broker rejection。
- 原始场景的 return-agent 分支产生的是给 AI 的警告/询问，而不是 order submitted；警告的后续状态尚未定义。

交叉测试显示，所有结果都压成布尔值会破坏消费者状态演化。应由各关系的消费者读取自己的精确结果，再调用后续计算/决定；不能从 `success` 猜测持久化、补偿或完成条件。

## 4. 对核心抽象的可执行边界

本轮材料支持的最小核心不是“所有业务都有同一套 slots”，而是下面四条可组合约束：

1. **Schema/product 组合（候选）**：基于“基本 Candle + 提供商扩展”，可提出不覆盖基础字段的积构造 `Base × Extension -> Combined`；基础投影保持不变，扩展冲突如何报告仍需在候选构造中明确。
2. **Delivery 分离**：同一输出值可以有 pull 或 push 交付；push 的具体消费和生命周期契约必须由真实提供商/消费者关系继续推导，不能从 pull 或旧 `TradingGit.push` 反推。
3. **Effect/Decision 分离**：外部读取/订阅/券商调用属于可解释效果；业务决定产生 accepted facts 与待执行 effects；`evolve` 只处理 accepted facts。
4. **关系内身份与结果**：来源、流、订单准入、提交链各自定义 identity/evidence/outcome；任何跨关系转换都必须是显式函数，不能靠同名字段或 `success` 猜测。

这份草稿当前只交付真实材料已经支撑的关系：IO 结果可以进入后续续接，pull/push 是不同交付关系，普通数据消费与持久业务决定不能互换，且旧 guard/TradingGit/bar 源码暴露了身份、结果与提交顺序的具体断点。等待订单由 Candle 订阅触发仍缺少真实 subscription/consumer 函数；原始用户的 return-agent 询问只能保留为场景约束，不能声称已被本稿解释。