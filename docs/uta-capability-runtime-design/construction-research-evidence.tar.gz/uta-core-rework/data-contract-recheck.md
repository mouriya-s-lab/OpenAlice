# UTA core recheck: data contracts, valuation, snapshots, polling, guards, protocol models, identity

> **只读调查材料。** 本文件不是设计结论、不是旧方案的恢复，也没有修改仓库。它把六个原始组的 `questions`、`analyses`、`entries` 与当前源码重新对接，提供给 Main 修正当前核心及承接册。

## 0. 方法、边界和证据等级

本轮先读了 `docs/uta-capability-runtime-design/current-research.md:56-127`。该记录明确：旧 event-flow、旧 EF/槽位、旧实验和上一轮 targetModel 不能为当前设计作证；当前核心必须先独立推导抽象，业务只能在各自实例中检验。`current-research.md:129-194` 还明确，形式求解不证明 provider、持久化原子性、outbox 活性、授权、真实 grant、Alice launcher 或运行时履约。

当前源码事实均回到 checkout 中的文件与行号；原始调查内容不改，原始问题表及来源表见本文件 §6–§7。标记含义：

- **[S]** 当前源码直接可见的事实，或原始 `entries/analyses/questions` 的逐项记录；
- **[R]** 原始调查中的 disposition/开放问题，保留作追溯，不等于本轮采纳设计；
- **[I]** 由 [S] 连接得到的最小反例/缺口，需由 Main 在核心或业务实例中裁决；
- **[U]** 当前来源未证明的 provider、生产数据或运行时保证；本轮不补猜。

没有运行 build、lint、tests、formatter 或 runtime；没有改仓库文件。下文的反例是静态路径推导，不冒称已执行。

## 1. 给 Main 的短结论

### 1.1 核心构造可以描述关系，但当前 consumer 还没有可用的“边界履约件”

当前核心 §3.2 要求：实际 `h` 形成 `F(A,E,R)`，后继只消费本次产生的 `a`，连续消费要明确逐项顺序/状态推进；§3.3 要求同一 Definition 同时给出输入解析、结果编码、描述和调用；§3.4–§3.5 又要求决定/演化、可保存操作数、工作身份与保存结果消费保持真实关联（`docs/uta-capability-runtime-design.md:245-253,357-385,430-506`）。

六组回查得到的不是“再加六个槽位”，而是五个共性边界仍未闭合：

1. **有限读取**已有 `F` 形状的候选值（bars、目录、账户读），但异常、范围、完整性、身份和 provider 覆盖被压成 `[]`、fallback 或字符串异常；调用方不能消费一个带来源/状态的结果。[S: `src/domain/market-data/bars/bar-service.ts:41-45,221-233,255-274,277-388`; `services/uta/src/domain/trading/contract-search.ts:27-64`; `src/domain/market-data/aggregate-search.ts:77-165`]
2. **估值/货币的当前实现**已有 Decimal 算术，但单位、FX 对、观测时间、stale/default/unknown 和 broker-vs-derived authority 没有变成必须处理的结果分支；未知货币可以得到 1:1。当前核心 §13.4 已独立补出‘保留本次账户结果 a→纯 pairs→实际 FX 后继 b→纯 value’的关系；本轮检查的是旧实现是否履约该关系，不要求核心新增通用 Account/Coverage 模型。[S: `services/uta/src/domain/trading/fx-service.ts:146-220`; `position-math.ts:35-64`; `uta-manager.ts:230-259`; core `docs/uta-capability-runtime-design.md:1504-1527`]
3. **快照**已有 builder→store→HTTP query 路径，却把同步失败、读取失败、schema/存储损坏和“无数据”压成 `null`/`[]`；append 与 index 保存不是同一文件原子边界，读后写可观察结果没有 receipt/checkpoint。[S: `snapshot/builder.ts:20-84`; `snapshot/service.ts:45-110`; `snapshot/store.ts:43-86,127-168`; `routes-trading.ts:611-693`]
4. **连续轮询**只有进程内 timer、tickCount、pending Git 扫描和日志；并发 tick 可静默丢弃，restart 丢失相位/退避，stop 不等待在途 broker work，也没有 durable job/observation identity。[S: `order-sync-poller.ts:53-104`; `UnifiedTradingAccount.ts:844-950`]
5. **Guard/身份/协议**仍以 native SDK、裸字符串和 untyped options 为公共边界；unknown symbol/新持仓可 fail-open，zero-guard 直接放行 dispatcher，`schemas/index.ts` 仍为空，`BrokerError` 仍主要是文本分类。[S: `guards/*.ts`; `packages/uta-protocol/src/types/broker.ts:1-79`; `packages/uta-protocol/src/schemas/index.ts:1-10`; `UnifiedTradingAccount.ts:509-545`]

因此，当前核心若要真正构造 consumer，最小必要检查不是“某字段是否存在”，而是：每个实际叶子必须给出**输入解析、成功结果、预期失败、来源/范围证据、身份关联和消费时点**；持续/可恢复叶子还要给出**每次发生的工作身份、重启找回路径和未知窗口处理**；coverage/quality/partial 这样的差异仍由各业务叶子表达，不要求核心增加一个统一业务模型。上述缺项不能由 `F`/`S` 的类型名自动补上。

### 1.2 同形不等价；相同关系集中论证，业务实例分开

本轮可共享的关系只有下列几类：

- **有限 read→result consumer**：bars 与 contract/catalog search 都是有限读取并需要边界解析、结果覆盖和失败消费；但 bars 的时间范围/新鲜度与目录的 instrument identity/ranking 是不同业务约束，不能合并成一个业务结果。
- **observation→derived state**：position fill/cost-basis、account valuation/FX、snapshot projection 都从观察产生后继；但 execution identity/dedupe、货币单位和快照修订不是同一种事件，不以同一个“Observation”标签替代。
- **source→consumer 的连续推进**：poller/scheduler 都是进程内连续来源；pending order、external listing、scheduled snapshot 需要不同的完整性、合并和未知处理。一个 single-flight boolean 不足以承载它们的差异。
- **控制读取→decision**：guard 读取 positions/account 后作决定，但 max-position、whitelist、cooldown 的状态与失败权限不同；guard chain 不应被视为一个业务政策 union。
- **native boundary→wire/domain**：SDK sentinel、native Contract/Order 和 provider error 必须在适配边界解码；trading `aliceId`、market-data `barId`、vendor sourceId 各属不同 identity namespace，不能把同名字符串当作共同身份。

## 2. 共享行为关系回查（不分配业务槽位）

### 2.1 有限读取：返回值存在，但 Query failure/coverage/range 不能被省略

**源码事实。**

- bars 的 `GetBarsOpts` 允许任意 `interval: string`，`toBarInterval` 对未知值静默改成 `'1d'`（`src/domain/market-data/bars/bar-service.ts:39-45`）。`startDateFor` 用近似日历窗口计算起点且没有校验 `start <= end` 或日期有效性（`:70-109`）。vendor path 只对 `end_date` 做本地上界过滤（`:201-223`）；UTA path 把 start/end 传给 broker 后直接 `finalize`，没有本地边界过滤（`:238-274`）。
- bars/source search 用 `Promise.allSettled`，vendor/UTA/capability 失败只表现为缺少候选；capability failure 变成 `{}`，再可能跳过 UTA 候选（`bar-service.ts:277-350`）。`getBars` 把 invalid barId、缺 assetClass、source missing 都变成普通 `Error`（`:371-388`）。`BarsResult` 只有 `bars` 与 `meta`，没有 QueryFailure/Partial/Unavailable 变体（`src/domain/market-data/bars/types.ts:106-138`）。
- trading contract search 对每个 UTA `allSettled` 后只保留 fulfilled hits（`services/uta/src/domain/trading/contract-search.ts:44-64`）；market search 也丢弃 crypto/currency/equity provider rejection（`src/domain/market-data/aggregate-search.ts:101-149`），结果没有 source coverage/status。`resolveBarSource` 在不带 pinned id 时取候选第一项，返回的只有 `barId`/`pickedFrom`，没有 ambiguity 或 incomplete-catalog 证明（`src/tool/source-resolve.ts:33-59`）。

**最小关系结论。** 这些路径可各自构造成 `F`，但当前代码没有一个可以消费的、精确表达“成功但部分覆盖”“无匹配”“源不可用”“范围未满足”的 `E`。把失败 source 从数组删掉不是“隔离”，而是改变成功值的含义：调用者看到的 `[]` 可能是 no match、invalid query、unavailable source 或 filtered result。`toBarInterval` 的 fallback 还改变了请求语义后仍交付正常 `BarsResult`。这些结果差异应在 Candle/Catalog 的实际业务实例中表达，而不是由核心新增统一 Coverage ADT 来替代。

**业务实例 A：Candle（单独，不提升到核心）。** `interval='bogus'` 交付日线而不是拒绝；显式 `start` 下 provider 若忽略下界，vendor 结果仍可含早于 start 的 bar，而 UTA 结果没有本地二次过滤。`isLatestActual` 只比较最后日期与 anchor（`bar-service.ts:167-179`），不能证明 provider 返回了完整连续区间。这要求 Candle 自己声明 interval/range/freshness/partial policy；不能用目录 search 的 ranking 结果代替。

**业务实例 B：Contract/catalog（单独）。** 一个 UTA 成功返回 AAPL、另一个 UTA rejection，当前输出等同于只有 AAPL 的成功 sweep，且 `source` 是裸字符串、`contract` 是 native SDK（`contract-search.ts:54-60`）。这要求目录实例保留 source participation、catalog completeness、instrument identity 和 ranking/truncation 证据；不能把 Candle 的 `BarMeta` 复用为目录真相。

### 2.2 估值与货币：算术关系成立，不等于单位/来源/可接受性成立

**源码事实。**

- `derivePositionMath` 把空/缺金额转成 `0`，空/零 multiplier 转成 `1`，runtime side 只要不是 `'long'` 就按 short 符号计算；输出只有两个裸 string（`services/uta/src/domain/trading/position-math.ts:22-64`）。账户聚合直接把现金和 position marketValue 相加减，没有 currency/scope/margin/fee（`:81-117`）。
- `FxService.getRate` 对 USD 直接返回 `source:'live'` 和当前时间（`:146-149`），vendor snapshot 没有使用其观测时间而是写当前时间（`:165-177`），stale cache 返回普通数值加 `stale` flag（`:184-186`），未知代码最后返回 rate 1、epoch 时间（`:199-204`）。`convertToUsd('0','')` 在验证 currency/rate 前直接返回 `{usd:'0'}`（`:211-219`）。
- manager 对非 USD 账户仅在有 `fxService` 时转换；没有 FxService 时将原 currency 数值直接加入 USD total（`services/uta/src/domain/trading/uta-manager.ts:230-255`）。读取失败的账户则保留一个 equity/cash/PnL 都为 `'0'` 的 row（`:257-259`）。UTA 的 currency guard 只在所有 position currency 与 account base 一致时重算 PnL，否则继续 broker value（`UnifiedTradingAccount.ts:1005-1023`），没有 typed uncertainty。

**最小关系结论。** Decimal 公式可以作为纯 `evolve` 的局部关系，但 `Money` 的单位、FX pair、观测时间和 quality 是其输入有效性的前提，不能被 warning 字符串或 source enum 的三个值替代。FX 不应把 unknown/default/stale 都交付为可供 risk/accounting 无条件消费的数值；account query failure 也不能通过 zero row 伪装成事实。

**与已更新核心 §13.4 的核对。** `docs/uta-capability-runtime-design.md:1504-1527` 已把这条关系写成独立 Account valuation 实例：实际读取得到本次 `a`，`pairs` 只从该 `a` 导出所需货币对，异币种才解释 FX 计算得到 `b`，`value` 消费原 `a` 与本次 `b`；它明确不声称所有账户在同一原生 as-of，也明确“不把普通读取失败自动改成全局 Partial”。这正是本报告把当前 manager/FX 旧行为列为缺口的原因：现状的 zero/pass-through/1:1 分支尚未实现该实例关系。该结论只要求 Account valuation 自己表达这些差异，不把 `Account`、`Coverage` 或 `Partial` 提升为核心公共业务模型。

**业务实例：Account valuation（单独）。** 例如非 USD account `EUR` 且 `FxService` 缺失时，`netLiquidation='100'` 会被直接累加到 USD total；未知 `XYZ` 的 `100` 会变成 `100 USD`；零金额的空 currency 会跳过所有证据检查。这个实例需要明确 broker-reported total、derived total、FX quality、accept/reject per consumer 和 account scope；不能把 FX warning 当成全局通用错误处理。

**业务实例：Cost basis/execution（单独）。** cost basis replay 使用 orderId/operation-result 位置和 WAC；`observeExternalOrder` 在 replay 主循环可处理，但 `isCostBasisRelevant` 排除它（`services/uta/src/domain/trading/cost-basis.ts:44-173`）。同一 order 多次 partial fill 会被 `counted: Set<string>` 按 orderId 去重，而不是 execution identity；未知 action 默认 buy，oversell 归零（`:150-167,83-92`）。这些是 accounting 的 execution/correction/short/lot 差异，不能由 FX 的 Money 类型解决。

### 2.3 快照：capture、persistence、query、equity curve 是不同消费者

**源码事实。**

- builder 先 `uta.sync().catch(() => {})`，然后并发 `getAccount/getPositions/getOrders`（`services/uta/src/domain/trading/snapshot/builder.ts:20-31`）；任何错误最终都变成 `null`（`:81-84`）。快照 record 只有 raw `accountId/timestamp/trigger`、字符串金额、aliceId/position/order fields、health/head/pending，没有 source sequence/revision/checkpoint（`snapshot/types.ts:14-80`）。
- service 把 builder null 记为 `snapshot.skipped` 的 `reason:'no-data'`，所有其他失败也返回 null；all-scope 只收集 fulfilled-null 账户再固定 3 秒重试一次（`snapshot/service.ts:18-25,45-101`）。HTTP `get snapshots` 在 service 缺失或异常时均返回 `{snapshots:[]}`（`routes-trading.ts:611-620`）。
- store 读取坏/不存在 index 时统一返回空 index（`snapshot/store.ts:43-49`）。append 更新 index 后先 `appendFile` chunk，再单独 `saveIndex`（`:63-86`）；`writeChain` 只在本进程内串行。readRange 依赖 index，读取/JSON 错误会抛出，没有 typed read result（`:127-168`）。
- equity curve 把 timestamp 截到分钟、将金额用 `Number(v)||0` 求和，并对缺失账户 carry-forward；异常返回 `{points:[]}`（`routes-trading.ts:647-693`）。post-push/reject hook 是 fire-and-forget（`services/uta/src/main.ts:102-108`），scheduler 也是 Pump tick 直接调用 `takeAllSnapshots`（`main.ts:110-113`; `snapshot/scheduler.ts:31-57`）。

**最小关系结论。** capture 成功不等于 durable snapshot，append 成功不等于 index/query 可见，HTTP 读到 `[]` 不等于历史为空，分钟聚合也不等于同一时刻的原子多账户 observation。必须分别论证：实时读取的 as-of、持久写入的 identity/sequence、query 的 range/read failure、以及 equity curve 的跨账户对齐。

**静态反例。** `doAppend` 的 chunk `appendFile` 发生在 `saveIndex` 的 rename 之前；若后者失败，磁盘可能已有行但下一次 `readIndex` 仍返回旧/空 index。当前 API 没有 receipt 或 reconciliation path 识别这一区别。两个账户同一分钟但不同秒的快照会被归并，后写值覆盖该账户前值，carry-forward 再把不同时间的值合在一个 total；这不是一个通用“snapshot stream”语义。

**业务实例：Snapshot history（单独）。** post-push hook 只触发一次 async capture；builder 还可能在 sync 失败后读取成功，于是 snapshot 混入未确认的 Git pending state 与 live query。删除按 timestamp 会删除 chunk 中相同 timestamp 的全部行（`snapshot/store.ts:88-124`）。这些需要快照自己的 record identity、capture attempt、as-of/checkpoint 和 retention 语义，不应拿 `headCommit` 或 timestamp 推导 source sequence。

### 2.4 连续来源：pending order、external listing、scheduled snapshot 的丢失/合并条件不同

**源码事实。**

- poller 以 closure `running/tickCount` 驱动；并发 tick 在 `running` 时直接 return，slow lane 在 pending check 前仍可做 external listing（`services/uta/src/domain/trading/order-sync-poller.ts:50-77`）。每个账户 failure 只写字符串 log 并继续（`:78-91`），timer callback 丢弃 Promise，stop 只 `clearInterval`（`:98-104`）。
- `UnifiedTradingAccount.sync` 从 in-memory Git pending IDs 得到工作；有 listing 时 present order 直接跳过，消失 order 才 `getOrder`，没有 listing 时使用 in-memory `_pollState` age backoff（`UnifiedTradingAccount.ts:844-915,931-950`）。重启会重置 `tickCount` 与 `_pollState`。
- external observation 没有 `getOpenOrders` 就返回 `{observed:0}`，空 listing 也同样；未知 order 以 bare `orderId` 与 Git known IDs 比较，然后写一条 observed commit（`UnifiedTradingAccount.ts:953-980`）。IBKR 当前 `reqOpenOrders` 只返回该 clientId 的订单，手工 TWS order 需要未证明的 reqAllOpenOrders/permId（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:766-775`）。Mock orderId 是进程内递增 `mock-ord-N`（`MockBroker.ts:278-324`），`setMarkPrice` 是测试控制面（`:546-562`）。

**最小关系结论。** 连续来源不能只用 `Promise<void>` + logger 表示。至少要区分：无工作、已 claim、被合并/跳过、partial/unavailable listing、known remote outcome、remote outcome unknown 和 recovery-required。slow observation 可以在其自身证据下合并；unknown mutation、dispatch 或 fill 不能套用 telemetry 的 lossy coalesce。

**业务实例：Order lifecycle（单独）。** 当前测试中 `setMarkPrice` 触发 pending fill，下一 tick sync 进 Git；这不能证明真实 execution identity、status retention、cumulative/delta fill 或 no-blind-retry。external order 第一次 slow tick 才写 observed commit，若 listing 是空/不完整，当前结果仍是 0 observed。Order 需要自己的 stable command/dispatch/order/execution identity 与 capability-limited listing；不能以 Snapshot 的 timestamp 或 Poller 的 tickCount 替代。

### 2.5 Guard 与身份：控制读取、授权和目录身份必须分别消费

**源码事实。**

- `GuardContext` 只有 native `Operation`, `Position[]`, `AccountInfo`，`OperationGuard` 返回 `string|null`（`services/uta/src/domain/trading/guards/types.ts:1-20`）。max guard 对新 symbol 的 qty order 无 existing position 时无法估算便放行，netLiq≤0 时把 percent 设成 0 也放行（`max-position-size.ts:18-47`）。whitelist 对 `getOperationSymbol === 'unknown'` 直接放行（`symbol-whitelist.ts:16-23`）。cooldown 以裸 symbol 为 key，并在允许前把 `Date.now()` 写入 process-local Map（`cooldown.ts:15-31`）。
- guard pipeline 没有 guard 时直接返回原 dispatcher；有 guard 时并发读 account/positions，拒绝只有字符串包装，随后直接 dispatcher（`guard-pipeline.ts:13-36`）。registry 是可被 `registerGuard` 覆盖的 process-global Map，unknown type 只 warning/skip（`registry.ts:6-34`）。
- trading identity 由 `{utaId}|{nativeKey}` 拼接，`parseAliceId` 只找第一个 `|`，不检查两侧为空或额外 namespace；重建时只校验 UTA 前缀，再让 broker `resolveNativeKey` 返回 native Contract（`UnifiedTradingAccount.ts:509-545`）。
- `contract-discipline` 直接把 IBKR SecType/Contract 作为模型，并用 string errors 验证静态字段（`contract-discipline.ts:21-124`）。`contract-search` 用 raw source string、native Contract、optional `assetClassFor` 和 allSettled drop（`contract-search.ts:27-64`）。`fuzzy-rank` 接收 partial native Contract，返回 ContractDescription，limit/zero-score/source/identity metadata 都不在结果内（`brokers/fuzzy-rank.ts:20-29,75-99`）。
- `OrderHelper` 只处理列出的 Decimal sentinel；`read` 以 truthiness 丢掉 `outsideRth=false`/`parentId=0`，`toWire` spread 任意 SDK enumerable fields 到 `Record<string,unknown>`（`OrderHelper.ts:35-44,68-102`）。market-data 的 `barId` 是 `{sourceId}|{nativeSymbol}`，明确与 trading `aliceId` 处在不同 namespace（`src/domain/market-data/bars/types.ts:1-13,31-52`）。

**最小关系结论。** guard 的“读取→决定”可以是纯计算，但 cooldown 当前有写入副作用；授权失败、未知身份和无法估算不能统一压成 allow/reject text。`aliceId`、`barId`、vendor sourceId 的字符串拼接只能在各自边界解码，不能从 display symbol、nativeKey 或 type guard 推出跨域 Instrument/Account identity。

**业务实例：Order authorization（单独）。** `cancelOrder`/`modifyOrder` 的 `getOperationSymbol` 返回 unknown；whitelist 因此 bypass。新 symbol + quantity 的 max guard 也可能 bypass，而零/负 netLiq 让风险百分比为 0。即使这些是“保守 fail-open”旧行为，也不能被抽象核心当成 guard 组合语义；具体 Order 必须定义 unknown identity、not-estimable exposure、read-only/keyless、approval/dispatch 的消费点。

**业务实例：Catalog/Instrument（单独）。** `BTCUSD` 等 suffix normalization 只是搜索 hint（`contract-search-rules.ts` 通过 protocol re-export），不是 identity resolver；同一 display symbol 可对应不同 vendor/venue/derivative. `resolveBarSource` 也只是在候选不足信息上按 derivative/freshness 排序。目录业务必须自己保留 venue/native identity、catalog revision 和 unresolved/ambiguous outcome。

### 2.6 协议模型：静态 TS 类型不是 runtime boundary，也不是 provider guarantee

**源码事实。**

- `packages/uta-protocol/src/types/broker.ts` 直接 import native `Contract/Order/OrderState/Decimal` 并通过 `contract-ext` 执行声明副作用（`:1-12`）。Position/OpenOrder/Quote/Bar 仍带 native class 或裸 string；`IBroker` 可选方法用 `undefined`/empty array 表示 unsupported/absence（`:477-620`）。
- `BrokerError.from` 只有 closed code set + lexical message classifier，顺序是 market closed → network/rate/5xx → AUTH → exchange-like；没有 provider native code、dispatch identity、idempotency/absence evidence（`broker.ts:16-79`）。`WireBrokerError` 也只是 loose `{code,message,transient,hint}` 接口（`packages/uta-protocol/src/types/errors.ts:10-19`）。
- `Operation`/`OperationResult`/`GitCommit` 仍带 native SDK、Partial<Order>、bare IDs、flat statuses 和 `raw?: unknown`（`packages/uta-protocol/src/types/git.ts:22-102`）；sub-account selector 只在 stage params，注释明确“不 persisted in Operation schema”，UTA 仅把 `[sub:...]` 写进 commit message（`git.ts:256-305`; `UnifiedTradingAccount.ts:759-790`）。
- `packages/uta-protocol/src/schemas/index.ts:1-10` 当前实际只有 `export {}`，没有运行时 Request/Response schema。`OrderEntryResult` 也把 stage/commit/push phase 与 raw PushResult/字符串 error 绑在一起（`services/uta/src/domain/trading/order-entry.ts:29-77`）。

**最小关系结论。** 当前 TS shape 只能作为编译期结构，不足以满足核心 §3.3 所需的同源 parse/encode/execute。`BrokerError` 文本分类也不能决定 post-dispatch retry；原始 ProtocolModels 问题 MAP-9F0ED3057E 应继续保持 [U]，各 adapter 逐自证 native error、idempotency、absence 和 status mapping。任何“把 native 类型搬进核心”都会把实现偶然性当成业务契约。

## 3. 最小 candidate-changing counterexamples（按业务分开）

下列都是可从当前代码路径直接得到的静态 counterexample，不依赖旧 event-flow，也不声称已 runtime 执行。

| 业务实例 | 最小输入/状态 | 当前路径 | 改变候选的事实 | 证据强度 |
|---|---|---|---|---|
| Candle range | `interval='bogus'` 或 provider 忽略 `start` | interval fallback；vendor 只滤 end；UTA 不二次滤 start | 候选必须区分 invalid interval 与 explicit fallback，并把 lower/upper range 履约写入 Candle consumer | [S]+[I] `bar-service.ts:41-45,201-223,238-274` |
| Candle freshness | 最近 bar 与 anchor 间有 holiday/weekend/partial gap | `tradingDaysBetween` 只按周一至周五；freshness 只看末 bar | `isLatestActual` 不是完整覆盖证明；stale/partial 要留证据 | [S]+[I] `bar-service.ts:151-179` |
| Catalog | UTA A returns hits，UTA B rejects | `allSettled` 只保留 fulfilled hits | 成功结果必须能表达 coverage/degraded source；不能把 partial catalog 当 complete | [S]+[I] `contract-search.ts:44-64` |
| FX | amount `100`, currency `XYZ`；或 amount `0`, currency `''` | unknown→rate 1/epoch；zero short-circuit | conversion 需要 unknown/invalid currency 分支；zero 也不能跳过 unit parse | [S]+[I] `fx-service.ts:199-219` |
| Account aggregation | non-USD account、`fxService` absent | 原 currency 字符串直接进 USD total；info error 变 zero row | account valuation 必须区分 base currency、FX evidence、unavailable account；不能 silent pass-through/zero | [S]+[I] `uta-manager.ts:230-259` |
| Cost basis | one order has two executions; delayed external observation | `counted` keyed orderId；relevance excludes observeExternalOrder | execution identity/cumulative-vs-delta/correction semantics must be explicit and adapter-specific | [S]+[I] `cost-basis.ts:52-69,94-132,169-173` |
| Snapshot read-after-write | chunk append succeeds, index rename fails | row may exist while readIndex returns old/empty | append receipt/index durability/query visibility must be separate results | [S]+[I] `snapshot/store.ts:43-86` |
| Snapshot curve | two accounts emit snapshots in same rounded minute | minute grouping + carry-forward + `Number(v)||0` | curve point is not atomic multi-account as-of; alignment/invalid numeric policy belongs to curve instance | [S]+[I] `routes-trading.ts:647-693` |
| Pending order | concurrent tick, worker restart, broker timeout | tick silently dropped; `_pollState` reset; sync exceptions only logged | S needs durable work identity/claim/recovery, not `Promise<void>` timer | [S]+[I] `order-sync-poller.ts:53-104`; `UnifiedTradingAccount.ts:931-950` |
| External order | listing unsupported, empty, or clientId-scoped | all become observed=0; IBKR listing excludes manual TWS orders | no-listing evidence cannot be NoNewOrders; provider scope must remain capability-limited | [S]+[U] `UnifiedTradingAccount.ts:953-980`; `IbkrBroker.ts:766-775` |
| Guard authorization | unknown symbol on cancel; new symbol qty order; netLiq≤0 | whitelist/max return allow; zero guards bypass pipeline | unknown/not-estimable must not silently become allow; guard policy needs explicit decision point | [S]+[I] `guards/symbol-whitelist.ts:16-23`; `max-position-size.ts:29-47`; `guard-pipeline.ts:18-35` |
| Trading identity | `aliceId='|'` or unknown nativeKey | parser accepts empty components; broker resolver may return skeletal/native object | identity parser needs structured failure and source/catalog binding; display/native symbols are not enough | [S]+[I] `UnifiedTradingAccount.ts:515-545`; adapter-specific resolver evidence [U] |
| Protocol error | post-dispatch timeout text contains `timeout` | lexical classifier returns NETWORK | retry/redispatch safety and remote absence remain unknown; error text cannot be the effect result | [S]+[U] `broker.ts:44-77`; original MAP-9F0ED3057E |
| Sub-account | staged write on multi-wallet account | validated id only in commit message, not Operation/GitCommit | restart/replay cannot prove target wallet from operation; explicit scope must be preserved or remain unavailable | [S]+[I] `UnifiedTradingAccount.ts:665-688,759-790`; `git.ts:256-305` |

## 4. 当前核心能否实际构造 consumer：闭合检查

| 当前核心构造 | 可对接的真实源码实例 | 现在能否证明“可构造且可消费” | 尚缺的最小连接 |
|---|---|---|---|
| `F(A,E,R)` 有限计算 | `getBars`, `searchTradeableContracts`, `getRate`, `buildSnapshot` | **部分：** 有返回路径，但 E 常被压成 throw/string/null/[]，R 与来源/范围常丢失 | 每个业务叶子的 parser、精确 failure/coverage/quality 结果（不是核心新增统一模型）、同源 result encoder；Candle 与 Catalog 分开定义 |
| `S(X,Es,Rs)` 连续来源+逐项 consumer | order-sync poller、snapshot scheduler | **否：** 只有 timer/Promise<void>/logger，未保存 source cursor、job identity、claim 或 per-item outcome | 具体 stream source、consumer 顺序、backpressure/coalesce、recovery/stop 语义；不能由 poller 共享给快照 |
| `decide/evolve` 纯状态关系 | cost-basis replay、guard checks、Git pending/status | **部分：** 局部 pure arithmetic/check 可见，但 input state 无 scoped identity/provenance，unknown/malformed 常 default/ignore | 业务实例自己的 state/event identity、unknown policy、消费时的 read-set；不把 cost basis/guard 合成通用状态 |
| saveable construction/resume | Git commit/push、snapshot files | **否：** native SDK/closures/partial fields 仍在 records，snapshot append/index/HTTP query 没有 durable receipt；push 结果不能表达 unknown | 同一封闭定义的 encode/decode/build/consume 与可保存 operands；接受、工作 identity、结果保存、恢复边界需按实例证明 |
| definition description+invocation | protocol package + HTTP routes | **否：** `schemas/index.ts` 空，routes 对错误/数据 cast 或返回 empty，描述与调用不是同一 runtime decoder | runtime schema/codec、错误 payload 与 route consumer 的同源安装；不把 TypeScript interface 当 parser |
| identity-bearing result | trading `aliceId`, market-data `barId`, source/catalog hit | **部分：** 各自字符串能路由部分现有代码，但不能证明跨 scope/venue/catalog revision 或 ambiguity | 每 namespace 自己的 refined identity + lookup failure；禁止 display symbol/nativeKey 互换 |

这个表不是要求 Main 立即设计所有实现；它指出哪些关系当前源码根本还没有对应的可消费结果。尤其 `F` 的“返回了一个数组/字符串”不等于 core §3.3 的同一 Definition 已提供 parser、description、encoder 和解释权。

## 5. 结论与未解决范围

### 5.1 已由当前源码确定的遗漏

- 有限查询的 invalid input、range bound、source failure、partial coverage 和 ambiguity 在 bars/catalog/search 多处被压掉。
- FX/valuation 的单位、来源、观测时间、stale/default/unknown 与 account failure 没有强制消费；纯 Decimal 算术本身不能覆盖它们。
- Snapshot capture、append/index、query、equity curve 各有不同一致性边界；当前 HTTP `[]`/zero/carry-forward 不能作为“无历史/成功聚合”事实。
- Polling 和 scheduler 只有 ephemeral process-local lifecycle；restart/stop/unknown outcome 没有 durable relation。
- Guards 的 unknown/not-estimable fail-open、cooldown 的 process-local write 和 global registry 是具体实现事实，不是核心组合定律。
- Protocol package 仍是 native SDK-shaped compile-time model，runtime schemas 为空；provider error/idempotency/absence 仍必须逐 adapter 取证。
- Trading, market-data and catalog identities are separate namespaces; raw string concatenation is not a cross-domain identity proof.

### 5.2 明确未解决 / 不可由本轮源码决定

- Production snapshot journal 的 schema/version、record identity、monotonic revision/source sequence、gap handling、migration cursor（原问题 `MAP-F64B549F14`；当前 scheduler 仅 in-process Pump，见 `snapshot/scheduler.ts:1-18`）。
- 每个 adapter 的 order listing 完整性、分页、clientId/account scope、status retention、execution identity、cumulative/delta fill、correction semantics；不能从 Mock 或 IBKR comments 推广。[U]
- 每个 provider 的 FX payload/timestamp/freshness SLA、currency registry/alias、derivative multiplier authority、short/margin/collateral semantics。[U]
- 生产是否要求 third-party guard extension；原 Guards closure 保留的结论仅说明当前源码未找到生产 caller，未来扩展若存在需另有版本化 composition-root 事实，不能复活 untyped global registry。
- 生产运行的真实 read-after-write、shutdown drain、outbox/lease 活性、跨进程恢复、授权和 external account effects。本轮禁止用 tests/runtime 补这些事实。

### 5.3 对 Main 的承接建议（不是设计替代）

1. 在当前核心保持 `F/S/decide/evolve/saveable` 的抽象层，不加入 Order/Candle/Account/News 等业务字段；把 §2–§3 的实例缺口分别带回对应业务论证。Account/FX 遵循核心 §13.4 已写明的 `a→pairs→b→value` 关系，并保留各次读取区间而不声称同一 as-of。
2. 对每个实际 consumer 写出其 source/read/parser/result/consumer 关系：Bars 的 bounds/freshness、Catalog 的 identity/coverage、Account 的 Money/FX authority、Snapshot 的 capture/persist/query consistency、Order 的 dispatch/execution/recovery、Guard 的 authorization/read-set。
3. 任何“[]/null/zero/string warning”都先问它是正常值、预期失败、partial/unavailable 还是 unknown；若一个值携带不了这个区分，不能直接接到核心后继。
4. 将 §6 的 question disposition 和 §7 的 source ledger 当追溯索引；§6 只覆盖 63 个原始 question，§7 另列 262 个 MAP 来源（其中大量 MAP 没有对应 question）。`contractDisposition`/`targetModel` 仅是原分析记录，不是当前设计许可。遇到 `[U]` 保留未知，不用旧实验或静态统计补齐。

## 6. 原始问题逐项处置索引

以下问题原文由 `question-inputs.json`/各组 `questions-closure.json` 逐项复制；`disposition` 是原始调查记录，**不是本轮设计采纳**。本节仅覆盖 63 个原始 question（Accounting 52、Snapshots 1、Polling 8、Guards 1、ProtocolModels 1、Identity 0）。closure 的 `remainingCount` 只是原调查的未决计数，不能用来代表本次旧能力来源的覆盖率。非 question 的 MAP 条目不在本节消失，而在 §7 逐项列出并标明其当前源码是否在本轮直接重读。Identity 没有原始问题项。

| 组 | MAP 来源总数 | 原始 question 数 | closure remainingCount（仅原调查字段） | 本轮直接重读相关选段 | 仅原 entries/analysis |
|---|---:|---:|---:|---:|---:|
| Accounting | 52 | 52 | 26 | 29 | 23 |
| Snapshots | 44 | 1 | 1 | 28 | 16 |
| Polling | 14 | 8 | 6 | 8 | 6 |
| Guards | 23 | 1 | 1 | 14 | 9 |
| ProtocolModels | 74 | 1 | 1 | 69 | 5 |
| Identity | 55 | 0 | — | 32 | 23 |

这张表只用于区分追溯对象和本轮读取范围；它不构成覆盖率、完成度或设计成立证明。

### Accounting（原问题 52 项；closure remainingCount=26）

| 原始 MAP | 原问题（原文） | 原始 disposition | 本报告处置位置 |
|---|---|---|---|
| `MAP-CA5605FEB6` | UnifiedTradingAccount.ts:509-520 proves aliceId is {utaId}\|{nativeKey}, not AccountId\|SubAccountId; :784-791 only stamps sub-account IDs in commit messages and leaves Operation/GitCommit untouched. Historical events therefore lack a reversible subAccountId mapping; migration must require an explicit manifest or linked observation and otherwise remain Unavailable, never derive subAccountId from nativeKey. | `empirical-retained` | §2.5 身份/范围（业务差异另见§3） |
| `MAP-977FF0C895` | The product policy for FIFO/lot tracking, short exposure, splits and token migrations remains an evidence decision; no unsupported policy should be represented as WAC reset. | `design-decided` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-7BEE7FDB8C` | Whether a venue reports cumulative fills or per-execution fills must be verified per adapter; the decoder must not infer one from the legacy sync shape. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-68C7EFD89F` | Venue-specific correction semantics and execution identifiers need adapter evidence; until supplied, correction remains UnsupportedCorrection and recovery-required. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-D807137749` | Which legacy Git records can be imported as confirmed fills versus requiring reconciliation requires migration evidence and must be recorded as an import policy. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-FE12115ED5` | Accounting policy versioning is a design decision: one global policyVersion or instrument/venue-specific versions must be chosen from the accounting-policy registry rather than inferred from current code. | `design-decided` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-EBE3DF37DD` | The legacy Git migration ordering and missing timestamps require an import manifest; do not infer durable sequence from filesystem order. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-FE7C71CD03` | UnifiedTradingAccount.ts:509-520 defines aliceId as {utaId}\|{nativeKey}; only :784-791 records sub-account tags in commit messages, and Operation/GitCommit do not carry a subAccountId field. Historical composite-id to subAccountId mapping remains unavailable without linked evidence. | `empirical-retained` | §2.5 身份/范围（业务差异另见§3） |
| `MAP-EB2F40AA83` | Short accounting and close semantics remain a product-policy question; the source does not justify assuming a long-only spot close for every target. | `design-decided` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-556EBB388B` | Observation without an execution price may be completed by a venue callback, but that depends on adapter semantics; it must be a stateful observation update, not a new fill inferred from a second array row. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-082EF635D6` | The vendor snapshot schema and timestamp field must be verified per provider adapter before accepting it as Confirmed. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-592DD5394C` | USD identity is a source-resolved unit relation, not evidence of a live market observation. | `source-resolved` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-612CCE1A5D` | The exact yfinance payload schema and provider timestamp semantics require adapter evidence; the domain must reject unknown shapes until mapped. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-A6935CF652` | TTL/stale admission durations are policy/configuration decisions and require evidence for the consumer that will admit them. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-F57EB058EB` | The maximum stale age and whether an estimate may be accepted are consumer/risk policy decisions, not a generic FX fallback. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-1B24CAB86B` | Authority to approve default FX risk/reservation and whether default values may be used for authoritative equity must be explicit per consumer. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-5159E38E38` | The supported currency registry and behavior for delisted or temporary currency codes require market-data configuration evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-1CA6BEB099` | Notification retention/deduplication window and observability policy remain design decisions. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-1955CFFDB9` | UI numeric estimates versus risk rejection must be explicit per consumer. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-0A93815E49` | Currency registry/alias policy must come from market configuration. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-946AA65B76` | Hub API response schema, timestamps, and freshness SLA require live contract evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-C3F063DA6A` | SLA/policy stale/default thresholds are product/risk decisions. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-3FBA652916` | Protocol names/version/decimal encoding must align with the shared model. | `integration-resolved` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-A46E156A09` | Default-data cadence and approval owner require explicit operational evidence. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-A66387BED8` | Cache TTL/stale window requires agreed policy. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-20D6995F44` | The mandatory provider per broker/account needs capability-registry evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-7B53178995` | Hub endpoint schema/freshness requires external evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-B7DBA0C5CB` | Provider precedence and stale/estimate acceptance must be decided per consumer. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-2683B949E2` | Public protocol shape/precision/rounding must align with the shared model. | `integration-resolved` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-7DA6DF620B` | Legacy GitState import field mapping needs migration evidence; do not infer sequence from snapshot timestamps. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-51B32EF77E` | HistoryContract optionality and derivative canonicalization must align with protocol evidence. | `integration-resolved` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-CD50878370` | Execution identity/correction semantics remain adapter-specific evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-2A6F3FE722` | HistoryContract optionality/derivative canonicalization needs protocol evidence. | `integration-resolved` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-66445C2610` | Wire rounding/scale must match protocol; mapper must not silently quantize. | `integration-resolved` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-0BC39A0EFF` | Native order field observability is adapter-specific evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-B34D1F5166` | History tie/status mapping must align protocol; no default terminal state. | `integration-resolved` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-0C54B9142F` | Tax/reporting corrections/realized PnL need accounting-policy evidence. | `design-decided` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-9B65095C78` | Venue external-vs-UTA order rules require per-adapter/complete-listing evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-B9E75F067C` | Target module export names/mapper placement must align the shared layout. | `integration-resolved` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-022335DA27` | Derivative multiplier authority/fallback requires venue evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-45921BE3BA` | Broker-reported unrealized PnL precedence versus derived PnL is a policy decision. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-1DD062830E` | Instrument classes with intrinsic multiplier one must be enumerated in capability evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-70D15B704F` | Broker short/margin/collateral treatment requires live adapter/account evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-D53569BA15` | Identity ownership and PositionObservation synchronization need an integration decision. | `integration-resolved` | §2.5 身份/范围（业务差异另见§3） |
| `MAP-A901893CDA` | Decimal scale/rounding needs a shared protocol decision. | `integration-resolved` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-948A6A2A73` | Optional versus required broker fields need adapter evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-147386F739` | Intrinsic multiplier rules need secType/venue evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-6033F222D1` | Broker-reported marketValue/PnL precedence and exposing both need policy evidence. | `design-decided` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-C33457A353` | Inventory all PnL callers before deleting an export. | `source-resolved` | §2.2 估值/FX（业务差异另见§3） |
| `MAP-B5B21108F4` | Net liquidation formula and broker total reconciliation require per-broker evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-A318FB662B` | Short/margin semantics require live account/adapter evidence. | `empirical-retained` | §2.2 会计/执行观察（业务差异另见§3） |
| `MAP-A50E762BBD` | Exact account equity policy/native totals/margin reconciliation require adapter evidence. | `empirical-retained` | §2.2 估值/FX（业务差异另见§3） |

### Snapshots（原问题 1 项；closure remainingCount=1）

| 原始 MAP | 原问题（原文） | 原始 disposition | 本报告处置位置 |
|---|---|---|---|
| `MAP-F64B549F14` | 生产历史 journal 是否已有可作为 source sequence 的单调 revision，以及迁移时的 cursor 起点，需在运行数据盘点中确认。 | `empirical-retained` | §2.3 快照 capture→persist→query |

### Polling（原问题 8 项；closure remainingCount=6）

| 原始 MAP | 原问题（原文） | 原始 disposition | 本报告处置位置 |
|---|---|---|---|
| `MAP-A173AC5D0E` | 当前 MockBroker 没有持久化 remote ledger 或独立子进程协议；实现第一条 falsifier 时需实证选择‘测试进程内保留 broker、仅重启 worker’还是独立持久 broker actor，并记录该边界，不能假定 in-memory object 等价于远端持久性。 | `design-decided` | §2.4 连续轮询与恢复 |
| `MAP-9A7B5853BF` | MockBroker 当前递增 order id 没有 venue-side idempotency；第一条测试只能验证 scheduler 的 stable identity/no-blind-retry，不能把该 mock 行为当作 native idempotency evidence。 | `empirical-retained` | §2.4 连续轮询与恢复 |
| `MAP-F6CFDCE6F2` | MockBroker 的 `setMarkPrice` 是测试控制面，不证明真实 venue 的 order-status freshness 或 execution identity；真实 adapter acceptance 仍需分别取得。 | `empirical-retained` | §2.4 连续轮询与恢复 |
| `MAP-855D4FE105` | IBKR 当前 `reqOpenOrders` 只返回该 clientId 的订单（IbkrBroker.ts:766-775），手工 TWS 订单的 permId/reqAllOpenOrders 证据尚未存在；外部观察对这类订单必须保持 capability-limited，不能宣称全账户覆盖。 | `empirical-retained` | §2.4 连续轮询与恢复 |
| `MAP-E279FE276F` | polling cadence/jitter/missed-window/rate-limit 不是当前 source 可证的事实；在配置和 adapter evidence 未齐前只能采用保守 fixed-delay/no-jitter/safe duration。 | `design-decided` | §2.4 连续轮询与恢复 |
| `MAP-BAF46FCF2F` | Observe listing 的可合并窗口、rate limit、lease heartbeat 需由 adapter/运行配置实证；无证据时只允许同一 scope/schedule 的未 claim wake 合并，unknown mutation 不能交给 telemetry 的 lossy policy。 | `empirical-retained` | §2.4 连续轮询与恢复 |
| `MAP-0F70BAA7CC` | IBroker optional `getOpenOrders` 的 unsupported-return-[] 与严格 adapter throw 语义不一致；需按 adapter 证明完整 namespace、分页、scope 与 absence evidence，证据不足时编码 `Unavailable`/`Partial`，不得生成 NoNewOrders。 | `empirical-retained` | §2.4 连续轮询与恢复 |
| `MAP-5D07510B31` | 各 adapter 的 order-status retention、symbol lookup、listing freshness 和稳定 execution identity 未由统一 SPI 证明；无证据时必须落 Unknown/OperatorRequired，而不是由 MockBroker 的 null/order id 推断。 | `empirical-retained` | §2.4 连续轮询与恢复 |

### Guards（原问题 1 项；closure remainingCount=0）

| 原始 MAP | 原问题（原文） | 原始 disposition | 本报告处置位置 |
|---|---|---|---|
| `MAP-4A48C821C3` | Source inspection found no production caller or persisted configuration requiring a third-party guard extension. The current closed built-in policy therefore rejects undeclared extension types; if another owned group has verified a shipped extension requirement, Main must add a separately versioned composition-root layer contract rather than reopening the untyped registry. | `integration-resolved` | §2.5 guard/授权与身份边界 |

### ProtocolModels（原问题 1 项；closure remainingCount=1）

| 原始 MAP | 原问题（原文） | 原始 disposition | 本报告处置位置 |
|---|---|---|---|
| `MAP-9F0ED3057E` | Native SDK/provider error fields, stable code precedence, and idempotency/absence guarantees are unavailable in this shared source; each adapter must supply evidence before classifying a native failure as safe retry or terminal rejection. | `empirical-retained` | §2.6 协议/边界解码 |

### Identity（原问题 0 项）

原始 `question-inputs.json` 没有 Identity 问题项；该组也没有 `questions-closure.json`。因此这里不虚构问题处置，仅由来源 ledger 覆盖其 55 个 MAP 来源。

## 7. 全部原始来源 MAP ledger

以下 262 个来源均来自各组 `entries.md` 的 `mapping source` 与 `symbol`，并与对应 `analyses.json` 按 MAP ID 对齐。它们是**非 question MAP 以及 question 对应 MAP 的完整来源索引**，不等于 262 个都已被当前源码逐段重读。`assessment`/`contractDisposition` 是原分析字段，仅作处置追踪；本报告归档列指向 §2–§3 的行为关系，不把任何旧 targetModel 当作前提。`本轮当前源码核查` 明确区分直接重读的相关选段与仅保留原始 entries/analysis 的范围。

### Accounting（52 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-022335DA27` | `services/uta/src/domain/trading/position-math.spec.ts:5-60` | `derivePositionMath test cluster` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.2 / §3.2 |
| `MAP-082EF635D6` | `services/uta/src/domain/trading/fx-service.spec.ts:1-11` | `makeMockClient` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.2 / §3.2 |
| `MAP-0A93815E49` | `services/uta/src/domain/trading/fx-service.spec.ts:168-175` | `currency normalization test` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.2 / §3.2 |
| `MAP-0BC39A0EFF` | `services/uta/src/domain/trading/order-history.ts:53-68` | `orderFields` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-0C54B9142F` | `services/uta/src/domain/trading/order-history.ts:134-251` | `projectTradeHistory` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-147386F739` | `services/uta/src/domain/trading/position-math.ts:41-46` | `multiplierToDecimal` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-1955CFFDB9` | `services/uta/src/domain/trading/fx-service.spec.ts:135-166` | `convertToUsd warning and zero tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.2 / §3.2 |
| `MAP-1B24CAB86B` | `services/uta/src/domain/trading/fx-service.spec.ts:82-102` | `default-table fallback tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.2 / §3.2 |
| `MAP-1CA6BEB099` | `services/uta/src/domain/trading/fx-service.spec.ts:122-133` | `default warning deduplication test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-1DD062830E` | `services/uta/src/domain/trading/position-math.spec.ts:77-89` | `multiplierToDecimal test` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-20D6995F44` | `services/uta/src/domain/trading/fx-service.ts:81-103` | `FxService state and constructor` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-2683B949E2` | `services/uta/src/domain/trading/fx-service.ts:207-220` | `convertToUsd` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-2A6F3FE722` | `services/uta/src/domain/trading/order-history.ts:24-44` | `toHistoryContract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-3FBA652916` | `services/uta/src/domain/trading/fx-service.ts:12-40` | `Fx rate and conversion result types` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-45921BE3BA` | `services/uta/src/domain/trading/position-math.spec.ts:62-75` | `pnlOf test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-5159E38E38` | `services/uta/src/domain/trading/fx-service.spec.ts:104-120` | `offline and unknown-currency tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-51B32EF77E` | `services/uta/src/domain/trading/order-history.spec.ts:43-120` | `projectOrderHistory behavior tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-556EBB388B` | `services/uta/src/domain/trading/cost-basis.spec.ts:122-134` | `isCostBasisRelevant` and observation completion tests | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-592DD5394C` | `services/uta/src/domain/trading/fx-service.spec.ts:13-28` | `USD passthrough test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-6033F222D1` | `services/uta/src/domain/trading/position-math.ts:48-65` | `derivePositionMath` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-612CCE1A5D` | `services/uta/src/domain/trading/fx-service.spec.ts:30-43` | `live-rate fetch test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-66445C2610` | `services/uta/src/domain/trading/order-history.ts:46-51` | `decStr` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-68C7EFD89F` | `services/uta/src/domain/trading/cost-basis.spec.ts:302-374` | `sync-fill attribution test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-70D15B704F` | `services/uta/src/domain/trading/position-math.spec.ts:91-138` | `aggregateAccountFromPositions test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-7B53178995` | `services/uta/src/domain/trading/fx-service.ts:105-138` | `hubRate` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-7DA6DF620B` | `services/uta/src/domain/trading/order-history.spec.ts:8-41` | `commit, contract, and limitBuy fixtures` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-946AA65B76` | `services/uta/src/domain/trading/fx-service.spec.ts:177-228` | `hub FX table test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-948A6A2A73` | `services/uta/src/domain/trading/position-math.ts:35-39` | `toDecimal` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-977FF0C895` | `services/uta/src/domain/trading/cost-basis.spec.ts:89-265` | `recomputeCostBasisFromCommits test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-9B65095C78` | `services/uta/src/domain/trading/order-history.ts:254-263` | `commitSourceIsExternal` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-A318FB662B` | `services/uta/src/domain/trading/position-math.ts:95-106` | `aggregateAccountFromPositions contract documentation` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-A46E156A09` | `services/uta/src/domain/trading/fx-service.ts:42-71` | `DEFAULT_RATES` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-A50E762BBD` | `services/uta/src/domain/trading/position-math.ts:107-118` | `aggregateAccountFromPositions` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-A66387BED8` | `services/uta/src/domain/trading/fx-service.ts:73-79` | `LiveCacheEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-A6935CF652` | `services/uta/src/domain/trading/fx-service.spec.ts:45-62` | `fresh cache and TTL tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-A901893CDA` | `services/uta/src/domain/trading/position-math.ts:20-33` | `PositionMathInput and PositionMathOutput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-AA?` | `services/uta/src/domain/trading/fx-service.spec.ts:45-62` | `fresh cache and TTL tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-B5B21108F4` | `services/uta/src/domain/trading/position-math.ts:81-93` | `AggregateInput and AggregateOutput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-B7DBA0C5CB` | `services/uta/src/domain/trading/fx-service.ts:140-205` | `getRate` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-B9E75F067C` | `services/uta/src/domain/trading/position-math.spec.ts:1-4` | `position-math test imports` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-B5?` | `services/uta/src/domain/trading/position-math.ts:81-93` | `AggregateInput and AggregateOutput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-C33457A353` | `services/uta/src/domain/trading/position-math.ts:67-79` | `pnlOf` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-C3F063DA6A` | `services/uta/src/domain/trading/fx-service.ts:1-10` | `FX module policy documentation` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-CD50878370` | `services/uta/src/domain/trading/order-history.spec.ts:122-168` | `projectTradeHistory behavior tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-D53569BA15` | `services/uta/src/domain/trading/position-math.ts:1-18` | `position-math module contract documentation` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-D807137749` | `services/uta/src/domain/trading/cost-basis.ts:1-24` | `module documentation and declared cost-basis scope` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-EB2F40AA83` | `services/uta/src/domain/trading/cost-basis.ts:150-167` | `fillDirection` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-EBE3DF37DD` | `services/uta/src/domain/trading/cost-basis.ts:38-134` | `recomputeCostBasisFromCommits` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-F57EB058EB` | `services/uta/src/domain/trading/fx-service.spec.ts:64-80` | `stale cache fallback test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.2 / §3.2 |
| `MAP-FE12115ED5` | `services/uta/src/domain/trading/cost-basis.ts:26-36` | `CostBasisResult and legacy Git imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.2 / §3.2 |
| `MAP-FE7C71CD03` | `services/uta/src/domain/trading/cost-basis.ts:136-148` | `matchesAliceId` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |

### Snapshots（44 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-051EE15C40` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:503-528` | `scheduler run/config tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.3 / §3.3 |
| `MAP-19A41F635E` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:449-476` | `service all-scope/failure isolation/getRecent` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此当前范围 | §2.3 / §3.3 |
| `MAP-22671716C7` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:481-501` | `scheduler lifecycle tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-226B693FB4` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:423-447` | `snapshot service tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-25F7996D49` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:240-271` | `snapshot store delete tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-26E7DEFDF7` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:273-304` | `snapshot store concurrent write tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-27667D4B9F` | `services/uta/src/domain/trading/snapshot/index.ts:1-8` | `snapshot barrel exports` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-2A00814D1F` | `services/uta/src/domain/trading/snapshot/builder.ts:33-80` | `buildSnapshot projection assembly` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-2EF977A049` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:112-126` | `snapshot OPT metadata tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-30284C5902` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:128-137` | `snapshot STK metadata tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-330646FEBC` | `services/uta/src/domain/trading/snapshot/scheduler.ts:46-57` | `SnapshotScheduler lifecycle methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-3AF27244D4` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:58-183` | `snapshot builder tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-3EA45A1B4F` | `services/uta/src/domain/trading/snapshot/builder.ts:13-18` | `buildSnapshot availability guard` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-473BE32758` | `services/uta/src/domain/trading/snapshot/builder.ts:20-31` | `buildSnapshot synchronization and account queries` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-587333CEE9` | `services/uta/src/domain/trading/snapshot/store.ts:36-86` | `snapshot store append and index writes` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-5BD7779096` | `services/uta/src/domain/trading/snapshot/service.ts:27-43` | `createSnapshotService and account store cache` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-5F2BAD0154` | `services/uta/src/domain/trading/snapshot/service.ts:1-18` | `snapshot service policy constants` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-622FCFCD63` | `services/uta/src/domain/trading/snapshot/service.ts:27-43` | `createSnapshotService and account store cache` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-69E23AB274` | `services/uta/src/domain/trading/snapshot/builder.ts:81-85` | `buildSnapshot catch boundary` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-78D69C071D` | `services/uta/src/domain/trading/snapshot/store.ts:88-125` | `snapshot store delete` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-7CCB6F93A0` | `services/uta/src/domain/trading/snapshot/store.ts:127-168` | `snapshot store readRange` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-83DAA2E639` | `services/uta/src/domain/trading/snapshot/types.ts:10-80` | `SnapshotTrigger, UTASnapshot, SnapshotIndex` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-88C7B6755F` | `services/uta/src/domain/trading/snapshot/store.ts:1-35` | `snapshot store constants and interface` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-92BA447044` | `services/uta/src/domain/trading/snapshot/builder.ts:1-12` | `snapshot builder boundary imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-95A7E16E24` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:1-18` | `snapshot test imports and fixtures` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-A605F93FC5` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:94-104` | `snapshot basic fields tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-B273D4875A` | `services/uta/src/domain/trading/snapshot/service.ts:1-18` | `snapshot service policy constants` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-BC1C2B98A1` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:186-208` | `snapshot service fixture` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-BF84B32A4C` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:208-238` | `snapshot store fixture` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-C7360CA0A4` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:273-304` | `snapshot store concurrent write test` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-CECC039853` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:449-476` | `service all-scope/failure isolation/getRecent` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-CF8F8B0486` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:333-356` | `snapshot delete behavior test` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-D073ACA66E` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:358-397` | `snapshot service failure test` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-D8989CCCCB` | `services/uta/src/domain/trading/snapshot/store.ts:141-168` | `snapshot store range query` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-D9EDA3CFCA` | `services/uta/src/domain/trading/snapshot/scheduler.ts:19-29` | `SnapshotConfig and SnapshotScheduler` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-DCBAABE629` | `services/uta/src/domain/trading/snapshot/scheduler.ts:31-44` | `createSnapshotScheduler Pump construction` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-DF2BB19B01` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:137-161` | `snapshot open-order filter tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-E65165A605` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:163-183` | `snapshot disabled/offline/error tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-E9161D7938` | `services/uta/src/domain/trading/snapshot/service.ts:45-76` | `takeSnapshot` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-F2E552347E` | `services/uta/src/domain/trading/snapshot/service.ts:78-102` | `takeAllSnapshots` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-F64B549F14` | `services/uta/src/domain/trading/snapshot/scheduler.ts:1-18` | `snapshot scheduler legacy event boundary` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-F7BC708300` | `services/uta/src/domain/trading/snapshot/scheduler.ts:31-44` | `createSnapshotScheduler Pump construction` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |
| `MAP-FAA33A98FD` | `services/uta/src/domain/trading/snapshot/snapshot.spec.ts:503-528` | `scheduler run/config tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.3 / §3.3 |
| `MAP-FC05F3240D` | `services/uta/src/domain/trading/snapshot/service.ts:20-25` | `SnapshotService interface` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.3 / §3.3 |

### Polling（14 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-0F70BAA7CC` | `services/uta/src/domain/trading/order-sync-poller.ts:62-75` | `external-order observation loop` | `designed` | `retained` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-2D60F8CF3A` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:103-118` | `per-account failure isolation test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |
| `MAP-5D07510B31` | `services/uta/src/domain/trading/order-sync-poller.ts:77-91` | `pending-order sync loop` | `designed` | `retained` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-855D4FE105` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:70-101` | `external order observation test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |
| `MAP-870F4383FA` | `services/uta/src/domain/trading/order-sync-poller.ts:93-104` | `poller finalization and stop` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-8D05311B0B` | `services/uta/src/domain/trading/order-sync-poller.ts:1-18` | `order-sync module contract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-9A7B5853BF` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:15-25` | `placePendingLimitBuy test helper` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |
| `MAP-A173AC5D0E` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:1-13` | `poller test fixture` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |
| `MAP-BAF46FCF2F` | `services/uta/src/domain/trading/order-sync-poller.ts:53-61` | `tick reentrancy and slow-lane schedule` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-B4499C0EF7` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:56-68` | `skip/no-pending poller test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |
| `MAP-E279FE276F` | `services/uta/src/domain/trading/order-sync-poller.ts:20-31` | `OrderSyncPollerOptions` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-E32A9F0696` | `services/uta/src/domain/trading/order-sync-poller.ts:39-51` | `startOrderSyncPoller setup` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-EC918D5C43` | `services/uta/src/domain/trading/order-sync-poller.ts:33-37` | `OrderSyncPoller interface` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.4 / §3.4 |
| `MAP-F6CFDCE6F2` | `services/uta/src/domain/trading/order-sync-poller.spec.ts:27-54` | `full lifecycle poller test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.4 / §3.4 |

### Guards（23 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-1CDFD8E4DA` | `services/uta/src/domain/trading/guards/symbol-whitelist.ts:4-25` | `SymbolWhitelistGuard` | `designed` | `retained` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-1D7814E6DD` | `services/uta/src/domain/trading/guards/registry.ts:6-14` | `builtinGuards and registry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-23766FB528` | `services/uta/src/domain/trading/guards/guards.spec.ts:16-31` | `native guard fixture` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-2DA2B0FD1D` | `services/uta/src/domain/trading/git/types.ts:310-322` | `getOperationSymbol` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-381B0ECC7A` | `services/uta/src/domain/trading/guards/registry.ts:12-19` | `process-global registry map` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-38E91ECD6A` | `services/uta/src/domain/trading/guards/types.ts:11-15` | `OperationGuard` | `designed` | `retained` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-3921C05A55` | `services/uta/src/domain/trading/guards/max-position-size.spec.ts:1-50` | `max guard tests/fail-open` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-3B189C535B` | `services/uta/src/domain/trading/guards/guards.spec.ts:1-14` | `guard fixtures` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-4933588230` | `services/uta/src/domain/trading/guards/cooldown.spec.ts:1-35` | `cooldown tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-4A48C821C3` | `services/uta/src/domain/trading/guards/registry.spec.ts:1-39` | `registerGuard tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-7409CE214D` | `services/uta/src/domain/trading/guards/symbol-whitelist.spec.ts:1-48` | `whitelist tests` | `designed` | `retained` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-865F7C9623` | `services/uta/src/domain/trading/guards/max-position-size.ts:15-47` | `MaxPositionSizeGuard` | `designed` | `retained` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-909C3AD7DA` | `services/uta/src/domain/trading/guards/guard-pipeline.spec.ts:1-104` | `guard pipeline tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-90A054EDC1` | `services/uta/src/domain/trading/guards/max-position-size.ts:5-13` | `max guard defaults` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-97E0672862` | `services/uta/src/domain/trading/guards/registry.ts:21-35` | `resolveGuards` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-ACA43262AC` | `services/uta/src/domain/trading/guards/types.ts:17-20` | `GuardRegistryEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-ADFBE7F5CF` | `services/uta/src/domain/trading/guards/index.ts:1-6` | `guards barrel` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.5 / §3.5 |
| `MAP-B4E6F4C1A3` | `services/uta/src/domain/trading/guards/cooldown.ts:4-13` | `cooldown config` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-CD34F7EFDA` | `services/uta/src/domain/trading/guards/registry.ts:21-34` | `resolveGuards` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-EC7E347D9E` | `services/uta/src/domain/trading/guards/guard-pipeline.ts:13-36` | `createGuardPipeline` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-E8C4D090C3` | `services/uta/src/domain/trading/guards/types.ts:1-9` | `GuardContext` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-F123F6082F` | `services/uta/src/domain/trading/guards/cooldown.ts:15-31` | `CooldownGuard.check` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |
| `MAP-FB69BBC6D0` | `services/uta/src/domain/trading/guards/guard-pipeline.ts:20-35` | `pipeline context/dispatch` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.5 / §3.5 |

### ProtocolModels（74 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-654966E128` | `packages/uta-protocol/src/types/broker.spec.ts:1-3` | `BrokerError test import` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.6 / §3.6 |
| `MAP-ACEFB58A14` | `packages/uta-protocol/src/types/broker.spec.ts:5-19` | `structured BrokerError preservation test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.6 / §3.6 |
| `MAP-1A43E0FCC4` | `packages/uta-protocol/src/types/broker.spec.ts:21-28` | `unknown BrokerError code fallback test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.6 / §3.6 |
| `MAP-D4DBF6173C` | `packages/uta-protocol/src/types/broker.ts:1-12` | `broker module native imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-6C0ADD0EA4` | `packages/uta-protocol/src/types/broker.ts:14-20` | `BrokerErrorCode and code registry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-710D1204ED` | `packages/uta-protocol/src/types/broker.ts:22-42` | `BrokerError constructor and permanence flag` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-6ED1656D7F` | `packages/uta-protocol/src/types/broker.ts:44-61` | `BrokerError.from cross-package wrapper` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-9F0ED3057E` | `packages/uta-protocol/src/types/broker.ts:63-79` | `BrokerError.classifyMessage` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-F59E470DFF` | `packages/uta-protocol/src/types/broker.ts:83-106` | `PositionRisk` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-634E72490E` | `packages/uta-protocol/src/types/broker.ts:108-155` | `Position` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-77D0297A77` | `packages/uta-protocol/src/types/broker.ts:159-168` | `PlaceOrderLeg` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-FE024081BB` | `packages/uta-protocol/src/types/broker.ts:170-180` | `PlaceOrderResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-BAD8B38E04` | `packages/uta-protocol/src/types/broker.ts:184-202` | `ExpandContractFilters` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-403375E19B` | `packages/uta-protocol/src/types/broker.ts:204-211` | `OptionGridEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-89DA5A834C` | `packages/uta-protocol/src/types/broker.ts:213-223` | `ContractExpansion` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-C6BE0A6EA7` | `packages/uta-protocol/src/types/broker.ts:225-246` | `OpenOrder` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-0422181E7C` | `packages/uta-protocol/src/types/broker.ts:248-262` | `AccountInfo` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-C959380106` | `packages/uta-protocol/src/types/broker.ts:264-294` | `SubAccountRef` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-7E5E549A48` | `packages/uta-protocol/src/types/broker.ts:298-313` | `Quote` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-8C2153421E` | `packages/uta-protocol/src/types/broker.ts:315-320` | `MarketClock` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-FC2ABFBF22` | `packages/uta-protocol/src/types/broker.ts:322-334` | `BarInterval and BarWhatToShow` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-BFD66E07FA` | `packages/uta-protocol/src/types/broker.ts:336-347` | `BarParams` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-8C79F4D559` | `packages/uta-protocol/src/types/broker.ts:349-364` | `Bar` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-3EEBF25E8D` | `packages/uta-protocol/src/types/broker.ts:366-413` | `BrokerHealth, UTAReach, UTATier, and BrokerHealthInfo` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-98D887D066` | `packages/uta-protocol/src/types/broker.ts:415-426` | `BrokerConnectionStateEvent` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-609FF636E8` | `packages/uta-protocol/src/types/broker.ts:428-443` | `HistoricalBarsCapability` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-46669371C2` | `packages/uta-protocol/src/types/broker.ts:445-450` | `AccountCapabilities` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-0647BF0194` | `packages/uta-protocol/src/types/broker.ts:452-466` | `BrokerConfigField` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-AE61B1C6B0` | `packages/uta-protocol/src/types/broker.ts:468-473` | `TpSlParams` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-25118F5AFA` | `packages/uta-protocol/src/types/broker.ts:475-498` | `IBroker lifecycle methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-781BB54D06` | `packages/uta-protocol/src/types/broker.ts:500-522` | `IBroker contract search and catalog methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-255335BC1C` | `packages/uta-protocol/src/types/broker.ts:524-529` | `IBroker trading mutation methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-3AB8DE4D1E` | `packages/uta-protocol/src/types/broker.ts:531-551` | `IBroker sub-account methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-BAFF102815` | `packages/uta-protocol/src/types/broker.ts:553-584` | `IBroker account/order query methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-7056B295D1` | `packages/uta-protocol/src/types/broker.ts:585-605` | `IBroker market-data and historical methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-BC6607AA1D` | `packages/uta-protocol/src/types/broker.ts:607-610` | `IBroker getCapabilities` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-40929B6DB6` | `packages/uta-protocol/src/types/broker.ts:611-620` | `IBroker native identity methods` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-A27D9FADF9` | `packages/uta-protocol/src/types/contract-ext.ts:1-31` | `IBKR Contract aliceId declaration augmentation` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.6 / §3.6 |
| `MAP-430A3CCB4D` | `packages/uta-protocol/src/types/errors.ts:1-19` | `WireBrokerError` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-D32AED6801` | `packages/uta-protocol/src/types/git.ts:1-11` | `Trading-as-Git native imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-89E53C0637` | `packages/uta-protocol/src/types/git.ts:13-16` | `CommitHash` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-298D6BB247` | `packages/uta-protocol/src/types/git.ts:18-54` | `Operation discriminated union` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-4B40267FF6` | `packages/uta-protocol/src/types/git.ts:56-58` | `OperationStatus` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-DE16B51F52` | `packages/uta-protocol/src/types/git.ts:60-77` | `OperationResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-FEF9B7F5AE` | `packages/uta-protocol/src/types/git.ts:79-89` | `GitState` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-BDE3556BBA` | `packages/uta-protocol/src/types/git.ts:91-102` | `GitCommit` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-DC3A63D407` | `packages/uta-protocol/src/types/git.ts:104-110` | `AddResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-B611B25F33` | `packages/uta-protocol/src/types/git.ts:112-117` | `CommitPrepareResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-C39C98EBC8` | `packages/uta-protocol/src/types/git.ts:119-125` | `PushResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-FC6B6B08DC` | `packages/uta-protocol/src/types/git.ts:127-131` | `RejectResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-DC943FF022` | `packages/uta-protocol/src/types/git.ts:133-139` | `GitStatus` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-2DA6BBE2CF` | `packages/uta-protocol/src/types/git.ts:141-158` | `OperationSummary` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-18E2D21F66` | `packages/uta-protocol/src/types/git.ts:160-167` | `CommitLogEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-601583B467` | `packages/uta-protocol/src/types/git.ts:169-174` | `GitExportState` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-ED7DB561BF` | `packages/uta-protocol/src/types/git.ts:176-186` | `OrderStatusUpdate` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-A9AE528869` | `packages/uta-protocol/src/types/git.ts:188-192` | `SyncResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-19CA6A1780` | `packages/uta-protocol/src/types/git.ts:194-201` | `PriceChangeInput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-8AD42F6839` | `packages/uta-protocol/src/types/git.ts:203-211` | `SimulationPositionCurrent` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-CAFDD48B6D` | `packages/uta-protocol/src/types/git.ts:213-223` | `SimulationPositionAfter` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-0CEEC81F23` | `packages/uta-protocol/src/types/git.ts:225-246` | `SimulatePriceChangeResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-B2851598C6` | `packages/uta-protocol/src/types/git.ts:248-282` | `StagePlaceOrderParams` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-36EE24CDBE` | `packages/uta-protocol/src/types/git.ts:284-294` | `StageModifyOrderParams` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-011C785E0E` | `packages/uta-protocol/src/types/git.ts:296-306` | `StageClosePositionParams` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-A774AC84F2` | `packages/uta-protocol/src/types/git.ts:308-322` | `getOperationSymbol` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-29B08BE41B` | `packages/uta-protocol/src/types/history.ts:15-30` | `HistoryContract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-8CE1592385` | `packages/uta-protocol/src/types/history.ts:32-34` | `OrderHistoryStatus and OrderHistorySource` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-732B845474` | `packages/uta-protocol/src/types/history.ts:36-59` | `OrderHistoryEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-56C6192DB1` | `packages/uta-protocol/src/types/history.ts:61-76` | `TradeHistorySource and TradeHistoryEntry` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-33B2356199` | `packages/uta-protocol/src/types/index.ts:1-22` | `wire types barrel and contract augmentation side effect` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.6 / §3.6 |
| `MAP-864224E5A6` | `packages/uta-protocol/src/types/manager.ts:1-10` | `manager native imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-75E0ED8B2B` | `packages/uta-protocol/src/types/manager.ts:12-19` | `UTASummary` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-02219D5749` | `packages/uta-protocol/src/types/manager.ts:21-37` | `AggregatedEquity` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-6EAA6A8F74` | `packages/uta-protocol/src/types/manager.ts:39-42` | `ContractSearchResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |
| `MAP-6BAF8CB0BF` | `packages/uta-protocol/src/types/manager.ts:44-58` | `ContractSearchHit` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.6 / §3.6 |

### Identity（55 个来源）

| 来源 MAP | 当前源码定位（原 entries mapping source） | symbol | 原分析 assessment | 原分析 contractDisposition | 本轮当前源码核查 | 本报告归档 |
|---|---|---|---|---|---|---|
| `MAP-0093FE974C` | `services/uta/src/domain/trading/contract-discipline.ts:30-36` | `SEC_TYPES` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-1D24B84F9B` | `services/uta/src/domain/trading/brokers/fuzzy-rank.ts:20-29` | `FuzzyRankInput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-2044134F6B` | `services/uta/src/domain/trading/contract-discipline.spec.ts:110-120` | `FUT validation test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-30D95BD47F` | `services/uta/src/domain/trading/contract-search.spec.ts:9-14` | `makeDesc search fixture` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-3562FB9C00` | `services/uta/src/domain/trading/contract-discipline.spec.ts:78-108` | `OPT/FOP validation test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-36F0A228A0` | `services/uta/src/domain/trading/contract-discipline.spec.ts:46-76` | `universal contract validation test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-3D1C0DC287` | `services/uta/src/domain/trading/order-entry.spec.ts:1-23` | `makeFakeUta test double` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-41607450D3` | `services/uta/src/domain/trading/brokers/fuzzy-rank.ts:75-99` | `fuzzyRankContracts` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-41CDC6BAAB` | `services/uta/src/domain/trading/contract-discipline.ts:38-42` | `SEC_TYPE_SET; isSecType` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-45D5DE1B9D` | `services/uta/src/domain/trading/contract-search.spec.ts:17-30` | `default aggregate search vendor-participation test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-4C9A6FE792` | `services/uta/src/domain/trading/brokers/fuzzy-rank.ts:36-73` | `score` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-4D036C0223` | `services/uta/src/domain/trading/brokers/contract-builder.ts:78-100` | `BuildPositionInput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-4D916C23A7` | `services/uta/src/domain/trading/contract-discipline.ts:1-19` | `module contract-discipline documentation` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-4FA5723DDD` | `services/uta/src/domain/trading/brokers/contract-builder.spec.ts:5-58` | `buildContract validation behavior tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-54ECEAEE5E` | `services/uta/src/domain/trading/contract-discipline.ts:46-51` | `ContractRequirements` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-5A77E2D561` | `services/uta/src/domain/trading/brokers/fuzzy-rank.spec.ts:1-17` | `ranking test fixture helper` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-5BDBD294C0` | `services/uta/src/domain/trading/brokers/contract-builder.spec.ts:102-161` | `buildPosition pass-through, derivation, multiplier, and risk behavior tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-60408331F8` | `services/uta/src/domain/trading/OrderHelper.ts:1-44` | `OrderHelper module and sentinel boundary` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-684E054D47` | `services/uta/src/domain/trading/order-entry.ts:35-73` | `executeOneShotOrder` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-68DA0FDCA7` | `services/uta/src/domain/trading/contract-search.ts:27-42` | `searchTradeableContracts normalization and source selection` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-6C47FFB1F4` | `services/uta/src/domain/trading/contract-search.spec.ts:32-42` | `explicit source override test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-6CEBFDFFDD` | `services/uta/src/domain/trading/contract-search-rules.spec.ts:66-74` | `normalization edge-case tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-73CA066D9E` | `services/uta/src/domain/trading/contract-discipline.spec.ts:138-147` | `assertContract test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-7476DDDBBC` | `services/uta/src/domain/trading/OrderHelper.ts:72-103` | `OrderHelper.read and OrderHelper.toWire` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-75A64813DC` | `services/uta/src/domain/trading/contract-search.ts:16-25` | `search manager/protocol dependencies` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-7B846115CB` | `services/uta/src/domain/trading/contract-discipline.ts:102-112` | `assertContract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-82BEA44FEB` | `services/uta/src/domain/trading/order-entry.ts:1-33` | `OrderEntryPhase and OrderEntryResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-880959554F` | `services/uta/src/domain/trading/contract-discipline.ts:66-66` | `ValidationResult` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-8AF74BCDDF` | `services/uta/src/domain/trading/contract-discipline.ts:21-28` | `IBKR Contract import and SecType re-export` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-8BBBB36AD2` | `services/uta/src/domain/trading/order-entry.spec.ts:25-38` | `one-shot happy-path test` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-933E16B57D` | `services/uta/src/domain/trading/contract-discipline.ts:68-100` | `validateContract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-97CB3270A6` | `services/uta/src/domain/trading/contract-search.ts:1-14` | `contract-search module identity documentation` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-9890D2522D` | `services/uta/src/domain/trading/contract-search-rules.ts:1-7` | `normalizeBrokerSearchPattern compatibility barrel` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-99C18EAB60` | `services/uta/src/domain/trading/contract-discipline.spec.ts:24-44` | `SecType taxonomy test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-9D7DDC4081` | `services/uta/src/domain/trading/order-entry.spec.ts:40-95` | `one-shot phase-error tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-A4E9FFB7DA` | `services/uta/src/domain/trading/brokers/fuzzy-rank.ts:31-34` | `FuzzyRankOptions` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-A999864CD2` | `services/uta/src/domain/trading/contract-search.ts:44-65` | `searchTradeableContracts fan-out and hit projection` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-ACEFA5D60A` | `services/uta/src/domain/trading/brokers/contract-builder.spec.ts:1-3` | `test imports and SDK fixture dependency` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-AE40B3965B` | `services/uta/src/domain/trading/OrderHelper.ts:46-70` | `OrderView and unsetToUndef` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-B7395F4C42` | `services/uta/src/domain/trading/contract-discipline.spec.ts:10-22` | `makeContract test fixture` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-B82909F33A` | `services/uta/src/domain/trading/contract-discipline.spec.ts:122-136` | `STK/CRYPTO/CRYPTO_PERP validation test cluster` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-BA4B6EEB3B` | `services/uta/src/domain/trading/contract-discipline.ts:114-124` | `hasContractField` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-BD0C97191F` | `services/uta/src/domain/trading/brokers/contract-builder.ts:49-74` | `buildContract` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-BD469BCA6D` | `services/uta/src/domain/trading/brokers/fuzzy-rank.spec.ts:71-101` | `limit, stability, quote fallback, and missing-field tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-BE2FC8EECC` | `services/uta/src/domain/trading/contract-discipline.ts:53-62` | `SECTYPE_REQUIREMENTS` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-C0F9438F7F` | `services/uta/src/domain/trading/brokers/fuzzy-rank.spec.ts:19-69` | `exact/prefix/name/regex ranking tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-C3F4ACD09F` | `services/uta/src/domain/trading/brokers/contract-builder.spec.ts:60-205` | `buildPosition pass-through, derivation, multiplier, and risk behavior tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-C6D66D3913` | `services/uta/src/domain/trading/contract-ext.ts:1-7` | `Contract.aliceId compatibility barrel` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-CF1FF8D3C3` | `services/uta/src/domain/trading/contract-search-rules.spec.ts:4-39` | `crypto/currency quote-suffix normalization tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-D0EA3C0CF2` | `services/uta/src/domain/trading/brokers/contract-builder.ts:1-23` | `module boundary, imports, and IBKR-as-truth contract/position funnel` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-D69EDB1AEE` | `services/uta/src/domain/trading/order-entry.ts:75-77` | `errorMessage` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-D9BFDA8A15` | `services/uta/src/domain/trading/contract-search-rules.spec.ts:56-64` | `unknown/default normalization tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-E748A339C5` | `services/uta/src/domain/trading/brokers/contract-builder.ts:27-47` | `BuildContractInput` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |
| `MAP-F61189D796` | `services/uta/src/domain/trading/contract-search-rules.spec.ts:41-54` | `equity/commodity identity normalization tests` | `designed` | `reframed` | 仅保留原 entries/analysis；本轮未逐段重读此 current范围 | §2.7 / §3.5 |
| `MAP-FBB735D928` | `services/uta/src/domain/trading/brokers/fuzzy-rank.ts:1-18` | `catalog-ranking module boundary and SDK imports` | `designed` | `reframed` | 本轮直接重读（所列文件的相关选段） | §2.7 / §3.5 |

### 7.1 本轮真实未逐段重读的范围（不从主线减项）

- `本轮当前源码核查=仅保留原 entries/analysis` 的 82 个 MAP 条目，主要是各组测试 fixture/断言、未直接影响上述关系的 route/adapter 分支，以及未在本轮选读的 broker-specific implementation ranges。它们仍被完整列入 §7，不能被 closure remainingCount、source 数量或“已有名字”当作已实现/已证明。
- Identity 的 55 个 MAP 中，本轮直接重读了 discipline/search/ranking/OrderHelper/contract-builder/UTA identity 的相关选段；Alpaca、CCXT、IBKR、Longbridge 等所有 adapter 身份、目录、错误和 native-key 分支没有逐个展开验证。对应 provider guarantee 保持 `[U]`。
- Polling 的 Mock/IBKR listing 与 UTA/poller 关系已重读；各 adapter 的完整 listing namespace、分页、status retention、execution identity、cumulative/delta fill 和 correction 分支未逐个重读/实证。
- Snapshots 的 builder/service/store/scheduler/types、HTTP read/curve wiring 已重读；生产历史 journal/schema/revision/cursor、部署文件和真实 read-after-write/崩溃交错未读取/未运行。
- ProtocolModels 的共享 `broker.ts/git.ts/history.ts/manager.ts/errors.ts/schemas/index.ts` 相关选段已重读；provider-specific protocol packs、原生 error fields/idempotency/absence 以及完整 runtime codec 履约未逐个读取或证明。
- 因而本报告是“原始 question 全部有处置位置 + 全部 MAP 有来源 ledger + 当前源码关键关系的选段重查”，**不是**“六组旧能力已全盘实现/全盘验证”。任何未读分支仍属于原始主线，需由 Main 在相应业务实例/承接册继续处理；本轮不擅自用核心新增业务 Coverage/Account 模型填补它们。

## 8. 原始材料与核查声明

- 原始入口：`docs/uta-effect-runtime-design/solutions/index.md:3-16,20-45,57-63`。
- 原始组材料（未修改）：`Accounting/`, `Snapshots/`, `Polling/`, `Guards/`, `ProtocolModels/`, `Identity/` 下的 `entries.md`, `analyses.json`, `reviews.json`, `design.md`；存在时另有 `questions-closure.json`。
- 本轮实际读取并核对的当前源码包括：
  - `services/uta/src/domain/trading/{position-math.ts,fx-service.ts,cost-basis.ts,order-history.ts,UnifiedTradingAccount.ts,contract-search.ts,order-sync-poller.ts,OrderHelper.ts,contract-discipline.ts,order-entry.ts}`；
  - `services/uta/src/domain/trading/snapshot/{types.ts,builder.ts,service.ts,store.ts,scheduler.ts}`；
  - `services/uta/src/domain/trading/guards/{types.ts,max-position-size.ts,symbol-whitelist.ts,cooldown.ts,guard-pipeline.ts,registry.ts}`；
  - `services/uta/src/domain/trading/brokers/{ibkr/IbkrBroker.ts,mock/MockBroker.ts,fuzzy-rank.ts,contract-builder.ts}`；
  - `src/domain/market-data/{aggregate-search.ts,bars/types.ts,bars/bar-service.ts}`, `src/tool/source-resolve.ts`；
  - `packages/uta-protocol/src/{types/broker.ts,types/git.ts,types/history.ts,types/manager.ts,types/errors.ts,schemas/index.ts}`；
  - `services/uta/src/http/routes-trading.ts`, `services/uta/src/main.ts`。
- 另核对当前核心账户/FX关系 `docs/uta-capability-runtime-design.md:1504-1527`：保留本次读取的 `a`，由 `pairs` 导出货币对，异币种才解释 FX 后继 `b`，由纯 `value` 消费 `a,b`；只承诺各次读取区间，不声称同一原生 as-of。
- 没有把原始 `design.md`、旧 event-flow、旧 EF/槽位、旧实验、closure resolution 或统计计数当作当前设计证明。所有未在源码明确出现的 provider/生产/运行时承诺保持 `[U]`。
