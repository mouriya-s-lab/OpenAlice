# Extension accommodation draft（实质草稿，非完整设计）

## 0. 目的、证据层次与不继承项

本稿只回答“扩展如何进入当前抽象而不丢掉计算、构造、结果消费和时间语义”。它不是完整核心设计，也不把本轮任何阶段检查、章节数量或旧候选当成完成证明。首先重读 `docs/uta-capability-runtime-design/current-research.md:56-127`：其中明确记录了“静态清单代替事件流”“抽象被业务方案替代”“映射被降为索引”以及“业务例子混入核心”的失败机制；因此下文把事实、由事实可推出的限制、以及待裁决的适配候选分开写。

### 0.1 事实与推论的标记

- **[事实]** 只指当前源码或原始调查文件直接给出的行为，带路径和行号。
- **[未证]** 指当前源码/本次只读调查没有证明的外部或运行时承诺；它不是“核心必须新增某字段”的证明。
- **[适配候选]** 指为了让一个具体消费者安全地使用事实而提出的关系；只对声明了该消费者的扩展生效，不自动成为所有 provider、所有 evidence 或所有 IO 的全局义务。
- **[反例]** 用来否定“同形即可替代”“一个结果即可满足所有消费者”或“旧边界可直接沿用”，不把业务字段倒灌进核心。

五个有直接 `questions-closure.json` 的组的 `analyses.json` 全部读取，六组的原始分析 source ID 均在末尾保留；五组 closure 的原问题文本和处置值仍以原文件为准。`entries.md` 按 source-index/标题和所用事实的必要上下文核对；未逐行展开的镜像正文不被当作已读事实。MockBroker 没有直接 `group: MockBroker` 的 question closure，故不造一个虚假的问题台账，只保留其分析 ID和跨组问题归属。

### 0.2 不把主书候选当成既定事实

`docs/uta-capability-runtime-design.md` 当前的 `Declaration`、`F/S`、`decide/evolve`、连续消费和可保存 `κ/ω` 文字（`:235-355,357-561,1084-1192`）是当前待裁决候选，下面只取其中能被具体操作和消费者检验的关系。它们不是已实现的运行时事实。旧 event-flows、旧 EF/槽位、legacy-accommodation 的 `targetModel`、旧实验及业务对象槽位均不作为设计成立前提。

## 1. 不丢能力的最小公共关系

### 1.1 公开扩展是“操作数—计算—结果消费者”，不是名称或字段表

对于一个真正被公开调用的扩展，先固定一个封闭定义 `d`，其最小关系可写成：

```text
d = (I, A, E, parseI, interpret, decodeA, encodeA, decodeE, encodeE)
interpret : I -> F(A, E, R)
```

这里的 `I/A/E` 是该扩展自己的输入、成功和声明失败；`R` 是实际解释所需的服务。`parseI`、`interpret`、结果/失败解码与编码必须来自同一 `d`。这不是要求每个叶子都拥有相同字段，而是禁止三种消费者各自维护一份不相容的映射：描述消费者说明 `d` 能接受什么，调用消费者按 `d` 解析并运行，结果消费者按同一 `d` 解释成功或声明失败。

已有类型若只是被加上一个值分量，可用实际纯函数构造 `s(a)=(a,x)` 与投影 `π(a,x)=a`；这只保留已取得的 `a`，不替换产生 `a` 的计算。若把输入 `J` 转成 `I`，必须有实际 `u:J -> Result(I,Eu)`；若把成功 `A` 交给另一个消费者，必须有实际 `v:A -> Result(B,Ev)`。只要 `u`/`v` 读取账户、目录、时钟、远端或其他当前事实，它就不再是无副作用的值投影，而是新的 Effect 后继，新增失败、顺序和服务要求都要留在事件流里。相同字段名、相同字符串或同名 `Order` 不提供这个转换。

**[反例]** 一个结果同时含 `orderId`、`status` 和 `success`，并不说明它既能被订单显示消费者、远端执行消费者、结算消费者和审计消费者无损使用；每个消费者需要的关系不同。扩展若不能给某个声称支持的消费者提供实际转换，就应省略该消费入口或暴露明确的未证结果，而不是用宽类型填平。

### 1.2 计算和连续来源的事件流是条件性的

一次有限计算的候选事件流是“解析本次输入 → 解释本次计算 → 成功值进入实际后继，声明失败阻止成功后继；缺陷/中断/进程丢失不伪装成作者声明的领域失败”。连续来源则是“来源实际交付 `x_i` → 逐项消费者实际处理 → 保存本次进度/前缀 → 再按所选策略取得下一项”。只在确实声明连续消费的 leaf 上保留前缀、停止、取消、恢复等语义；普通 pull、一次性诊断或本地模拟控制不因类型相似而自动变成 Stream。

同样，sequence、digest、coverage、cursor、writer identity 等字段只有在所选消费者的承诺会观察到它们时才进入该声明。例如需要合并并发 evidence 的 sink 才可能需要顺序/冲突关系；一个只返回单次本地诊断路径的 sink 不会因“evidence”这个名字自动获得这些字段。字段缺失首先是该具体消费者未被证明，不能反推核心对所有 evidence 的强制 schema。

### 1.3 只有选择了可恢复外部效果，才进入 `κ/ω` 接受边界

对一个明确承诺“进程停止后仍可恢复”的外部写效果，候选保存包 `κ` 至少要固定定义、可编码输入和捕获值、原结果消费者及程序/目标绑定；每次实际发生另有 `ω`。其事件流是：

1. 纯 `decide/evolve` 产生提议；
2. 在一个为该效果选择的接受边界内，接受状态变化和 `saveable(κ,input,capture)`；
3. 取得实际资源并按该效果自己的并发策略放行 `ω`；
4. 解释外部工作，保存同一 `ω` 的成功/声明失败，或在边界不明时保存 `Unknown`；
5. 用原 `κ` 的结果消费者在**当前**状态上作下一次决定，并再次接受。

这不是所有 Effect 的默认包装。普通查询、Candle/Instrument/News 拉取、只写证据文件、Mock 控制面，除非各自明示“外部效果可恢复且结果需重连”，不需要被放进同一本地 effect WAL，也不自动获得交易审批、补偿或 lease。lease 是某个并发/恢复实现为取得独占放行所选的机制，不是核心每个 leaf 必须带的字段；同理，状态事件与 saveable work 的本地原子接受只对这类可恢复外部效果成立。

### 1.4 结果消费者决定保留什么，不把未证字段补成结论

一个 provider 可以同时提供多个消费者：展示消费者可能只需规范化后的值；执行准备消费者可能还需原始编码、单位、部署身份和前置事实；恢复消费者还需 `κ`、`ω`、目标绑定和原结果。它们共享同一输入/结果构造，但不互相升级。

- 如果消费者只要求公共读值，保留读值及其来源/适用范围即可；不能顺手声称它支持写入。
- 如果消费者要发起外部写，所有由该写路径实际计算出的操作数必须进入明确的输入或捕获值，不能让解释器从当前默认配置重建；失败和响应不确定性也必须进入结果关系。
- 如果消费者要在已知类型上继续组合，实际转换函数必须保持无法转换的分支；不能用 `as`、字符串相等或“能 import”消除分支。
- 如果消费者要恢复，必须使用原定义和原编码/程序身份；新定义可用于新调用，不自动解释旧结果。

## 2. 六组来源如何分别落入这条关系

以下先写 `[事实]`，再写 `[适配候选]`。每个业务/来源例子保持独立；它们只是检验公共关系的实例，不是核心类型全集。

### 2.1 MockBroker：控制输入、模拟演化和真实写授权必须分离

**[事实]** `MockBroker` 明确是进程内 exchange；`setMarkPrice`/`tickPrice`/`fillOrder`/外部 deposit、withdraw、trade 属于不在 `IBroker` 上的 simulator control panel，routes 通过 `instanceof MockBroker` 直接调用（`services/uta/src/domain/trading/brokers/mock/MockBroker.ts:1-17,546-578`; `services/uta/src/http/routes-simulator.ts:81-223`）。订单、持仓、mark price、cash 和 call log 都在进程 map/数组中（`MockBroker.ts:185-208,278-324,579-621,665-796`）。`placeOrder` 的 market 分支直接 `_applyFill` 并写 `Filled`，limit/stop 写 `Submitted`；`setMarkPrice` 会触发 pending matcher；`externalTrade` 则绕过 `placeOrder`，甚至允许没有旧仓位时开 short（`:278-324,799-839,718-755`）。

**[事实]** 当前 `UnifiedTradingAccount.stagePlaceOrder` 的写入准入只执行自身的 keyless/config 检查和订单字段校验，再把 `aliceId` 解成 contract 后加入 staging（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:549-557,603-638,693-724`）。Mock 控制 HTTP 返回 `ok`/`filled` 或快照，并没有修改这一写授权关系。

**[适配候选]** 为 simulator 控制定义自己的输入和结果关系，而不是把它伪装成交易 effect：

```text
SimControlInput  = MarkUpdate(nativeKey, price)
                 + ManualFill(orderId, optional qty/price)
                 + ExternalDeposit(nativeKey, qty, optional contract)
                 + ExternalTrade(nativeKey, side, qty, price, optional contract)
SimControlResult = local control outcome + optional simulator-state observation
```

这里的和只是当前控制面四类输入的一个**业务实例**；真正的公共定义仍由该 simulator leaf 自己声明。解释器执行的实际计算是 `setMarkPrice → _matchPendingOrders → fillOrder`、`fillOrder → _applyFill → cash/position/order update` 或 external control 的独立 map mutation。若未来把 reducer 抽出来，纯 reducer 只能计算下一模拟状态；控制调用本身仍需明确其作用域、实例代次及是否持久，不能用纯返回值冒充远端事实。

`SimControlResult` 的消费者可以是 simulator UI 的 `getSimulatorState`、测试场景的状态断言，或专门的“外部刺激观察”投影。它不能直接接到 `TradingApproval`、`OrderAck` 或真实 broker 的执行消费者。要允许交易 proposal，仍须有独立的账户/环境/权限/批准关系；Mock 管理控制不自动授予该关系。若某一测试另行选择 DurableMockVenue，只有那一个被声明为可恢复的 control/effect leaf 才需要 `κ/ω`；当前 in-memory Mock 本身不提供这个承诺。

**[不可继承]** `getMarkPrice` 的 `null`、递增 `mock-ord-N`、默认 100、AAPL-like generic contract、map 中的 full/partial fill 和 `STP LMT` 的触发即成交，只说明 fixture 行为。特别是 `getCapabilities` 宣传 STP LMT 而 matcher 把它折叠成触发时 fill（`:519-520,799-839`）；不能生成通用 StopLimit leaf。deposit 用 raw nativeKey 而 contract 可能用 localSymbol，`_applyFill` 又按 `getNativeKey` 入 map（`:675-697,917-923`），说明 identity 冲突需要在 simulator 自己的控制/观察关系中保留，不能静默合并。

### 2.2 LeverUp：把签名所消费的实际操作数、提交回应、等待结束与远端观察分开

**[事实]** 当前 open 路径不是一个纯 `prepare` 值函数，而是一串实际取得：先 `resolvePair`，再调用 `fetchPythPrice` 取得 Hermes response 中的 update bytes 和解析价格；代码随后计算 `qtyD * priceD`、以 USDC/qty/price 的固定 scale 转换，调用 `generateOpenSalt` 读取时间和随机数，读取当前时间形成 deadline，使用 private-key account 执行 `signOpenPosition`，最后 POST relayer（`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:213-317`; `pyth.ts:31-72`; `decimals.ts:15-55`; `eip712.ts:121-162`）。`getMarketClock` 是另一个实际读取当前时间的 provider 操作，当前 open 并没有自动消费它（`LeverupBroker.ts:516-518`）。

因此这条业务流的事件顺序必须保留为：

```text
resolvePair
  -> fetchPyth（取得 updateData 与 parsed quote）
  -> [若该 flow 声明时段前置] getMarketClock
  -> 计算 amount/qty/price/protection 的 native 数值
  -> 取得 salt 与 deadline
  -> 以同一操作数执行签名
  -> 用同一签名和同一操作数构造 POST 请求
  -> sendOpenPosition
  -> 收到或未收到 relayer submission response
```

其中“用同一操作数构造请求”可以是纯序列化函数，但只能消费已经取得的那一次 `quote`、`salt`、`deadline`、schema/domain、签名和单位转换结果；不能为了把代码叫作纯函数而在构造阶段重新抓 Pyth、重新取时钟、重新生成 salt/deadline 或重新签名。`signOpenPosition` 虽然是本地函数调用，却消费 credential 并产生可在链上执行的授权载荷；它必须位于受保护的签名/发送边界。private key、签名以及含有可执行授权的 native payload 不得交给公开 Agent，也不得无条件进入普通日志、诊断或公开 evidence。若可恢复流程需要在发送前后继续使用原签名，必须在受保护的 effect 记录中保存原始可解码操作数/签名或明确终止为“需重新准备”；重建绝不能把新 salt/deadline/quote 当成原批准请求。

**[事实]** 当前 relayer submit response 只有 `inputHash`；status 只有 `executed/success/txnHash/reason`，而本地 `pollUntilExecuted` 在等待窗口结束时构造 `executed:false, success:false, reason:'poll timeout'`（`relayer-client.ts:42-93`）。broker 收到 inputHash 后立即把 process-local order map 置为 `Submitted`（`LeverupBroker.ts:296-313`），`getOrder` 以后才 GET status，GET 出错则保留旧 map 状态（`:450-492`）。

**[适配候选：结果消费者]** 将这条 flow 拆成下列各自消费同一操作数的结果：

| 结果阶段 | 消费的同一次值 | 可交付的含义 | 明确不能推出 |
|---|---|---|---|
| `PythAcquired` | feed identity、update bytes、parsed quote、取得时间 | 请求构造可消费的一次报价证据 | 不证明 quote 可执行、价格新鲜策略或部署接受 |
| `Signed` | 原 pair/units/protection、schema/domain、salt、deadline、trader、签名 | 发送边界可消费的精确授权载荷；公开边界只暴露受限引用 | 不证明 relayer 收到、链上执行或 finality；签名本身不能公开给 Agent |
| `RelayerSubmissionResponse` | 同一 POST body 的 `inputHash` | “收到一个 relayer response/本次提交标识” | 不自动是通用 Order ACK、订单创建、成交或链上 inclusion |
| `WaitEnded` | inputHash、本地等待计时器、最后一次真实 status response（若有） | “本地等待结束”及最后已取得的观察；可决定转人工/reconcile | 不把 timeout 生成的 `false/false` 当远端拒绝，不授权重发 |
| `RelayerStatusObservation` | 同一 inputHash 的实际 GET response | 仅按已证明的 provider 语义解释 `executed/success/...` | 不自动是账户仓位、成交量、交易 finality |
| `ChainFinalityObservation` | 已证明关联的 txnHash、block/confirmation 事实 | 若 provider 另有此 consumer，解释链上最终性 | 当前 source 没有该证据，不能由 status 字段改名得到 |
| `Position/AccountObservation` | trader scope、reader page/rows、USDC chain read | 独立账户/仓位投影 | 不反向证明某一个 inputHash 已执行，reader page 0 也不完整 |

`WaitEnded` 是本地等待动作的结果，不是 `RelayerStatusResponse` 的伪造值。若最后一次 status 获取本身失败，结果应保留“最后真实观察 + 获取失败/未知”；若没有成功取得过 status，则没有终态观察。该 flow 不因 timeout 自动 send second request；只有另一个显式的、具备同一 effect 身份和真实 absence/idempotency 依据的消费者，才能决定下一步。`TradingGit.parseOperationResult` 对 `Filled`/`Cancelled`/`Inactive` 之外默认映射 `submitted`（`TradingGit.ts:929-977`），也不能增加这些语义。

**[适配候选：open/close 输入]** 对实际要发起 open 的 provider leaf，可以将操作数分为三类：

1. 调用者/配置提供的 `pair identity`、side、quantity、保护意图，以及 collateral/leverage/notional 选择；
2. 运行中实际取得的 Pyth update/quote、可选 session observation、deployment/schema 选择、salt、deadline；
3. signing scope/credential reference 及由其产生的签名。

并非所有项都必须公开成用户字段；“保留能力”要求它们在需要发送、重建或审计时有同一关联、同一单位和同一安全存储边界。当前代码的 USD/1x、USDC/LVUSD、scale 和 zero protection 只是实现假设，当前 source 没有 native conformance 证明；不能补一个看似确定的 leverage、collateral、EIP-712 primary type 或 fee unit 来宣称 capability。

close 是独立业务流：当前 `closePosition` 忽略 `_quantity`，先读 open positions，取第一个相同 pair，再以 `positionHash/deadline/signature` POST（`LeverupBroker.ts:327-374`）。因此只在真实证据支持整仓语义时声明 `CloseAll`；含 quantity 的调用不得静默变成整仓，partial-close 需独立 leaf 或显式 unavailable。open 与 close 不共享一套“Order ACK”结果，仅可共享各自 provider 声明明确引用的 relayer/chain 观察关系。

**[适配候选：失败与未知]** pair/order-type/quantity 在 POST 前被拒绝是输入/构造失败；fetchPyth、clock、签名、POST 或 status GET 的传输/资源失败，按发生位置保留不同 failure。POST 期间网络失败即使本地抛异常，也不证明远端未收到；poll timeout 是 `WaitEnded`，不是拒绝。若该 flow 被声明为可恢复外部 effect，才把发送后未知送入其 `κ/ω` 恢复或 reconcile consumer；普通 quote/read flow 不因此获得交易恢复义务。

### 2.3 LeverUpProtocols：单位和协议字节是可组合计算，不是全局数字常量

**[事实]** `qtyToWei`、`priceToWei`、`amountInToWei` 是实际 Decimal→bigint 函数；当前常量是 qty 10dp、price 18dp、USDC 6dp，超额精度用 `ROUND_DOWN` 截断，但函数没有统一的有限性、符号或范围校验（`decimals.ts:15-55`）。Pyth helper 把 JSON cast 到接口，检查 binary data，随后把 price/exponent 转成 JavaScript Number/`Math.pow`（`pyth.ts:14-72`）。EIP-712 导出 nested/flat 两套 open primary type；salt 使用 `Date.now()+Math.random`（`eip712.ts:4-10,52-124`）。pairs 模块把 `TESTNET_PAIRS` 设为 `MAINNET_PAIRS`，而网络常量和 pair 地址/endpoint 的权威性不在该模块内（`pairs.ts:29-81`）。

**[适配候选]** 这些代码应作为 provider-local 构造函数和证据来源，而不是作为核心的 `number` 语义：

- 单位转换消费者若要执行 open，实际消费 `(Instrument, collateral token, field role, declared scale, rounding policy)`，并将原始 bigint 与其字段/网络身份一起交付；只展示 quote 的消费者可消费 Decimal projection，不获得写能力。
- Pyth 的显示消费者可消费 parsed price，但执行消费者必须明确是否也消费同一响应中的 update bytes、feed identity 与 freshness；如果它不需要这些操作数，不能反过来宣称执行 leaf已满足。
- Schema variant 选择必须在 dispatch 前由 provider declaration 固定并记录其定义身份；nested 签名被拒绝后切 flat 是本地兼容实验，不得在一次外部 dispatch 已发生后盲切另一 schema 重发。close bytes 偶合相同也不证明 open schema 可互换。
- `TESTNET_PAIRS = MAINNET_PAIRS` 是源码现状，不是 testnet deployment proof。只受该 pair/deployment 影响的写 leaf 可保持未证；不依赖它的公共结构/读 leaf 不应被全局阻断。

**[未证]** fee currency/scale、collateral acceptance、leverage semantics、zero TP/SL semantics、accepted primary type、contract bytecode/domain、relayer idempotency 和 finality 均不能从本地类型/注释/bytes32 形状得到。它们是对应 provider leaf 的证据输入；没有证据时保留未证分支，不自动改写所有协议或所有业务。

### 2.4 Catalog 与动态 pack：同一包内解析、解释、编码和消费

**[事实]** `BrokerPresetDef` 当前携带展示标签、engine、Zod preset schema、fingerprint、`toEngineConfig`、可选 `isPaper`；静态 `BROKER_PRESET_CATALOG` 供 wizard 使用（`packages/uta-protocol/src/brokers/preset-catalog.ts:37-98,497-588`）。factory 先按 preset 解析，再按 engine load pack、解析 engine config、调用 `createBroker`（`services/uta/src/domain/trading/brokers/factory.ts:26-47`）。pack module 当前只暴露 API version、engine、configSchema 和 createBroker（`services/uta/src/domain/trading/brokers/registry.ts:23-33,113-123`）。这些事实说明现有边界还没有把“公开定义的结果消费者”放进 pack module；它们不单独证明某个抽象设计必须采用某组字段。

**[适配候选]** 动态 pack 若要公开一个 capability leaf，应由同包封装以下实际关系，而不是再建一个全局名字表：

```text
PackLeaf d = (identity/revision,
              input declaration I + decode/encode,
              success declaration A + decode/encode,
              domain-failure declaration E + decode/encode,
              interpreter I -> F(A,E,R),
              declared result consumers)
```

`identity/revision` 只在调用、结果恢复或 catalog 选择需要区分定义时保留；不是所有 data result 都必须带一个人工 `CatalogRevision`。catalog/CLI/help 消费者从 `d` 取得展示/输入描述；调用消费者仍按 `d` 解码输入；解释器运行的就是 `d`；结果消费者再按同一 `d` 解码 `A/E`。如果要把 `A` 交给一个静态已知类型 `B`，需一个实际 `A -> Result(B,ConversionError)`，不能因为字段同名或能 import 就强转。编码/解释/授权不由 preset 名称或 engine union 自动生成。

安装 provenance 仍可由现有 manifest/pointer resolver 负责（`src/core/broker-packs.ts:23-172`），但本稿不把“contentId 非空”说成已重算包内容，也不从这个事实强制所有描述拥有 digest。若某一部署安全消费者要求内容摘要，就在该安装/发布声明中实际消费摘要及验证结果。

静态 preset 仍可承担配置迁移和 wizard 选择。它不能单独成为 capability authority：`isPaper` 的 mode 字符串、credential 字段 presence、engine 能 import 都只是 hints/构造前置。动态目录若没有某叶子，应保留结构缺失；不为所有 provider 填充 `Unsupported` 伪叶子。

**[无普遍 discovery 前置]** `searchTradeableContracts` 返回 source/contract/asset class，`stagePlaceOrder` 却只解析 UTA id、调用 `resolveNativeKey` 并 staging；LeverUp 对未知 key 合成最小 CRYPTO_PERP contract，直到 `placeOrder` 才返回 `Unknown LeverUp pair`（`contract-search.ts:27-64`; `UnifiedTradingAccount.ts:515-544,603-724`; `LeverupBroker.ts:213-223,535-546`）。这证明该公开路径的输入验证弱、且发现 identity 没有被可选地绑定到 proposal；它不证明**所有**写请求都必须先 search 或携带 catalog revision。允许手工 native identity 的 provider 可以在自身 declaration parser/interpreter 中直接验证；需要目录版本来解释安全含义的 provider 才应把该版本作为实际操作数。公共要求是“消费者需要的关系必须有实际构造”，不是“所有来源必须经过同一种 discovery 流”。

### 2.5 LiveEvidence：证据产生、写入和能力判断是分开的消费者

**[事实]** `LivePaperEvidence` 是可选字段的 TypeScript interface；`recordLivePaperEvidence` 通过 runId 文件 append JSONL，固定写 `schemaVersion:1`、时间、git commit、`paper:true`、`broker:'ibkr'`，但当前代码没有通用的 sequence/digest/concurrency/conflict/coverage validator（`services/uta/src/domain/trading/__test__/e2e/live-paper-evidence.ts:6-86`）。E2E 场景还直接调用 raw CCXT `exchange.createOrder`、手动写 symbol cache，或按 OKX/TWS 错误 skip（`ccxt-bybit.e2e.spec.ts:186-230`; `ccxt-okx.e2e.spec.ts:104-228`; `ibkr-paper.e2e.spec.ts:270-299`）。

**[适配候选]** 将证据写入当作一个独立的 `EvidenceSink` leaf：其输入是已经过场景/来源边界解析和必要 redaction 的 evidence record，解释器是 append/import，结果消费者是报告、检索或测试结论投影。结果应至少区分“记录已写入”“编码失败”“写入冲突/未知”；是否需要 writer ordering、digest 或 coverage，取决于该 sink 的实际消费者是否要比较并发顺序、完整性或覆盖范围。不能因名为 evidence 就把这些字段强加给所有 evidence。

E2E raw broker 操作是 evidence producer 或明确的 `ExternalStimulus` 业务实例，不是 UTA 普遍 dispatch；它们的 account/environment/native id 必须由各自场景声明和证据记录，不由文档里的 “paper/demo” 字样或 ID substring 授权。一个 bracket/trigger/quote/cleanup 结果只有被相应的结果消费者核对后才能成为该场景证据；缺少 parent leg、stable native identity、完整 namespace 或 cleanup 结果应保留场景级未证，不可升级为所有 provider capability。

证据写入失败不能触发同一外部交易的盲目重发，这是“该交易 effect 选择了证据引用消费者”时的边界关系；单纯独立诊断 append 不需加入交易原子边界。证据 record 也不自动成为交易批准、执行 finality 或恢复依据，除非另有明确的、带 scope 的 availability/observation 转换。

### 2.6 TargetGaps：只对选中的可恢复 effect使用持久接受/恢复

**[事实]** `TradingGit.executePush` 当前逐项调用 `executeOperation`，然后读状态、构造内存 commit、调用 `onCommit`；`createGitPersister` 只是写 `commit.json`，读取失败还尝试 legacy path，最终可返回 undefined（`services/uta/src/domain/trading/git/TradingGit.ts:119-185`; `git-persistence.ts:14-48`）。UTA 启动会先 purge ephemeral UTA 目录，再初始化账户、启动 snapshot/poller，health 返回 `ok:true`（`services/uta/src/main.ts:56-87,102-152`; `src/core/config.ts:797-821`）。当前 UTA 依赖中没有 Effect/sql/sqlite-node/better-sqlite3（`services/uta/package.json:7-34`）；这些事实不能被改名成已完成的 effect journal。

**[适配候选：controlled effect only]** 当且仅当某 provider leaf 声称外部写需要跨进程恢复时，使用如下实际关系：

```text
derive/construct (其中 decide/evolve 部分可为纯值；实际外部操作数取得仍保留为 Effect)
  -> accept {state event, saveable κ(input,capture), definition binding}
  -> [若并发策略需要] claim/lease ω
  -> dispatch external work
  -> capture same occurrence result or OutcomeUnknown
  -> save result under κ/ω
  -> consumeκ(result, current State) -> next decide/evolve/accept
```

`κ` 不保存任意闭包，而保存本次输入、捕获值、定义/程序 identity 和结果消费者能解码的值；`ω` 区分相同输入的两次合法发生。`claim/lease` 只是独占放行或 fencing 的一个运行时实现，只有实际存在并发恢复竞争时才有意义。外部操作发出后响应丢失，不能用本地超时/租期失效/查询未找到自动改成“未发生”；若没有真实 absence/finality 证据，结果消费者应保留 Unknown 或 ReconcileBeforeRetry。若 provider 已以外部证据证明不同的原子/幂等关系，声明可以据此采用更强的消费；本地 generic map 或 mock 不提供该证据。

普通 `getAccount`/quote/position pull、连续数据帧、独立 evidence append、Mock control 和安装/配置读取不因其返回 Promise 就自动进入上述接受边界。它们可以有各自的 cursor、stream lifecycle、缓存、权限或失败消费者；只有声明为可恢复外部 effect 的 leaf 才需要将状态事件与 saveable work 放在一起。这样既保留特定可恢复 effect 的停止窗口安全，也不把本地 atomicity、WAL 或 lease 误写成全局业务义务。

`NOTE-9-1` 所说的 ReconcileBeforeRetry 是“当前没有 broker idempotency/absence/fencing 证据时”的保守策略候选，不是所有 provider 的定义。没有证据时，selected effect 可以禁止盲目 resend、交给 reconcile/operator；取得明确 native guarantee 后，仍要由该 provider 的实际 result consumer 证明那项更强的策略，不能因读取一次 status 就获得。

`main.ts` 的 purge 只有在被清理目录同时承载该 effect 的 durable authority 时，才必须先分类未完成工作；不依赖它的 ephemeral simulation/data cache 仍可按其自己的生命周期清理。`TradingGit` 目前的提交顺序是兼容事实，不是新抽象必须把所有外部操作改成同一本地原子事务的证明。


## 3. 来源假设、证据缺口与可接受的范围

本节不把“缺某字段”直接翻译成“核心必须新增字段”。左列是当前源码/原调查可核对的事实，中列是该事实**不能证明**的承诺，右列是只有当某个具体消费者声明后才成立的适配关系。

| 来源事实（可核对） | 当前不能证明的承诺 | 只有在具体消费者声明后才采用的关系 |
|---|---|---|
| Mock 的控制方法直接改进程 map；`setMarkPrice` 还能触发 matcher，`externalTrade` 绕过 order pipeline（`MockBroker.ts:546-578,665-755,799-839`；`routes-simulator.ts:103-223`；ID `MAP-FED35111E9`, `MAP-B8A614D67A`） | 不证明真实 venue effect、账户批准、外部顺序、持久性或 native idempotency | simulator control 只向 simulator UI/test/观察消费者交付 `ControlResult`；若某个测试声明 durable mock effect，才另建其 `κ/ω` 与持久结果消费者 |
| Mock market fill、partial fill、WAC、cash arithmetic 在 Decimal map 上可运行（`MockBroker.ts:278-324,579-621,917-965`；ID `MAP-74610A30AF`, `MAP-47DB032F5A`, `MAP-150B8F86DC`） | 不证明 Quantity/Money scope、remote execution identity、restart recovery 或跨 venue accounting | 纯模拟 reducer 可保留这些算术；需要对外报告时另加有单位/作用域的投影，不能把 map 状态当 authority |
| Mock 宣称 STP LMT，但 matcher 把 stop-limit 压成触发时 fill（`MockBroker.ts:519-520,799-839`；ID `MAP-559086B869`, `MAP-89456D4461`, `MAP-202708E052`） | 不证明真实 stop→working-limit 状态或保护关系 | 不发布通用 StopLimit 消费入口；仅保留明确的 simulator approximation，除非有独立语义证据 |
| LeverUp POST 返回 `inputHash`，broker 立即写本地 `Submitted`；status 只有 `executed/success/txnHash/reason`（`LeverupBroker.ts:276-313,450-492`; `relayer-client.ts:42-93`; IDs `MAP-2FF2A5B544`, `MAP-A3B8CD6164`, `MAP-B100B9C54C`） | 不证明 order creation、fill、chain inclusion、finality、duplicate-submit 或 lookup retention | submission、status observation、chain/finality 作为不同结果消费者；没有 native semantics 时保留 opaque/Unknown，不改名成通用 Order ACK |
| LeverUp 代码按 `qty*price` 假定 USD/1x，以固定 qty/price/USDC scales 转 bigint（`LeverupBroker.ts:231-255`; `decimals.ts:15-55`; IDs `MAP-B9BAFEC82F`, `MAP-63F62A28BF`） | 不证明所有 pair/collateral/leverage/fee/PnL 的单位和精度 | 执行 leaf 明确消费的 field role、scale、currency、rounding、price evidence；公共 quote projection 可只消费已解析值 |
| `eip712.ts` 同时有 nested/flat primary types，salt 用时间/随机；pairs testnet alias mainnet（`eip712.ts:4-10,52-124`; `pairs.ts:29-81`; IDs `MAP-6786905A37`, `MAP-50F0F7A825`, `MAP-D33182231F`） | 不证明 deployed schema、domain、testnet address、salt dedupe 或 contract acceptance | provider-specific declaration 在 dispatch 前固定 schema/deployment identity；不因本地 shape/bytes32 或 mode label 宣称已部署可写 |
| reader 只取 page 0、过滤 OPEN，unknown pair 静默跳过（`reader-client.ts:80-90`; `LeverupBroker.ts:416-448`; IDs `MAP-0233341AE8`, `MAP-BC7663242A`, `MAP-68B42E34DB`） | 不证明空仓、完整 listing、fee/PnL valuation 或 closed-row retention | 只有需要“完整 account absence/valuation”的消费者才要求 coverage/cursor/units；普通 quote/单页诊断不自动承担同样义务 |
| static preset 供 wizard，`isPaper` 看 mode，factory/pack loader 只作 config parse/createBroker（`preset-catalog.ts:37-98,102-106,497-588`; `registry.ts:23-33,113-123`; IDs `MAP-607170E22C`, `MAP-F3151B31E7`, `MAP-E745F1370E`） | 不证明 environment、permission、account scope、native idempotency 或 capability tree | 同一个动态 pack definition 生成描述、输入解析、解释、结果编码和已声明消费者；静态 preset 只做选择/迁移提示 |
| current adapters differ: Alpaca/Longbridge/IBKR/CCXT each have own account/placement/query behavior (`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:101-257`; `longbridge/LongbridgeBroker.ts:125-267`; `ibkr/IbkrBroker.ts:73-223,231-312`; `ccxt/CcxtBroker.ts:160-181,309-398,417-473`; IDs `MAP-9AD9951502`, `MAP-3392948A39`, `MAP-E52D407CDC`, `MAP-1E5FD0A690`) | 不证明 generic adapter wrapper 能提供跨 venue retry/lookup/finality/partial-fill semantics | per-provider leaf retains exact native extension and only exposes consumers backed by that adapter’s evidence; no universal action matrix |
| E2E setup uses first-match IDs, `isPaper`, credential presence, TCP probe and timeout; tests may use raw exchange calls, skips and best-effort cleanup (`setup.ts:25-138`; `ccxt-bybit...:186-230`; IDs `MAP-A9C599CFB8`, `MAP-68FD1B154A`, `MAP-FFA9030D49`) | 不证明 paper/live environment、complete callback/cleanup、bracket linkage、or native capability | scenario-specific evidence producer and sink retain exact observed/Unknown result; availability projection must be explicit and scoped |
| evidence writer appends optional records to runId JSONL (`live-paper-evidence.ts:6-86`; ID `MAP-C2F022975E`) | 不证明 concurrent order, digest, full coverage or atomic coupling to a trading mutation | only a sink whose consumer observes ordering/integrity/coverage gets those relations; independent evidence append is not a transaction WAL |
| `TradingGit` executes broker operations before `getGitState`/`onCommit`; commit persistence is JSON with legacy fallback (`TradingGit.ts:119-185`; `git-persistence.ts:14-48`; IDs `NOTE-5-1`, `NOTE-5-4`, `NOTE-7-1`) | 不证明 effect acceptance, atomicity, durable dispatch identity or restoration for every operation | selected externally mutating/recoverable effect uses `κ/ω` acceptance; ordinary read/data/control remains outside until its own consumer declares recovery |
| startup purges ephemeral UTA directories and then starts poller/snapshot/health (`main.ts:56-87,102-152`; `config.ts:797-821`; IDs `NOTE-12-1`, `NOTE-18-2`) | 不证明 every deleted directory is effect authority, nor that all startup paths need the same recovery gate | gate cleanup only where the path contains durable unfinished effect records; classify that authority before deletion, while unrelated ephemeral data follows its own lifecycle |

### 3.1 特别裁决：三个容易被误承接的原始问题

1. **`MAP-47A0790F1B`（Leverup MarketSession）**：原问题要求“versioned calendar/evidence 后才 write”。当前 `LeverupBroker.getMarketClock` 恒返 `isOpen:true`（`LeverupBroker.ts:516-518`），所以当前源码没有提供 calendar evidence；但这只说明“依赖 session 的 LeverUp effect”缺前置事实。一个不依赖交易时段的 public Instrument、Pyth quote 或其他业务 leaf 不因此必须拥有 calendar。若某个 effect 的声明明确把 session 作为 precondition，才需要该 effect 自己的 session observation/consumer；否则将该问题机械升级为核心义务就是把业务政策倒灌进核心。
2. **`NOTE-9-1`（ReconcileBeforeRetry）**：原问题保留的是无 native idempotency、absence/fencing 证据时的保守操作策略。它不是所有 provider 的结果类型，也不是查询一次就能自动取得的权限。没有证据时，selected effect 可以禁止盲目 resend、交给 reconcile/operator；有真实 native conformance 的 provider 可以声明不同的重试/lookup consumer，但仍不能凭 mock 或 generic adapter 继承该保证。
3. **`MAP-A94BD9AD27` / LP-8（Connection Layer）**：当前 `ReaderClient`/`RelayerClient` 是具体实现类，确实没有显示公共 descriptor；但“实现类未自描述”不单独证明核心必须有某个名为 Connection Layer 的抽象。只有当多个消费者要共享 connection scope、resource lifetime、timeout/cancellation 或 endpoint identity 时，才需要在它们的实际构造中保留这些操作数和服务关系；不共享的单次 pull 可以由自己的声明直接提供。

### 3.2 特别裁决：发现、目录和未知 native identity

`searchTradeableContracts` → `stagePlaceOrder` 的 LeverUp 反例仍然有效，但结论限于**当前 path 的验证弱点**：`parseAliceId` 只检查 `|`，`resolveNativeKey` 对未知值造最小 contract，`placeOrder` 才拒绝未知 pair（`contract-search.ts:27-64`; `UnifiedTradingAccount.ts:515-544,603-724`; `LeverupBroker.ts:213-223,535-546`）。

这不要求所有 write API 先执行 search，也不要求每个来源都持有 `CatalogRevision`。允许手工 native identity 的 provider 可以在同一 declaration 的 input parser/interpreter 中直接验证；只有其语义确实依赖目录版本或 discovery provenance 时，才把该绑定作为实际操作数。公共要求是“写消费者需要的 identity/validation 关系必须有实际构造”，而非“所有写请求必须经过同一目录前置”。

## 4. 应改变的旧语义：从“继承名字”改为“保留实际关系”

下表的“旧语义”是当前源码或历史调查中可见的旧入口；“改变”是本稿对扩展承接的裁决候选，不声称已经实现。原始 question 的旧候选措辞仍在其 closure 文件中，仅作为可回查身份。

| 旧入口/语义 | 应改变的解释 | 仍需保留的真实能力 |
|---|---|---|
| `IBroker`/`brokerEngine`/全局 action switch 把所有 provider 压成同一结果 shape | 改成 provider-owned declaration leaf；由实际 input/result/error/consumer 组合产生公开入口；不支持的 leaf 结构性缺失，不填 universal Unsupported | 现有 SDK/协议仍可在 adapter 内使用；只有声明拥有对应消费者才公开 |
| Mock `setMarkPrice`、`fillOrder`、externalTrade 等管理控制 | 改成显式 simulator-control 输入/结果/来源；不进入真实 write-approval 或 OrderAck 消费者 | 保留可注入 mark、partial/full fill、外部短仓和本地状态检查，作为 Simulation 实例 |
| Mock `STP LMT` capability 与 trigger-time fill 的近似 | 改成 approximation/未提供真实 StopLimit leaf | 保留测试触发行为本身，不能让近似值承诺 working-limit/保护语义 |
| LeverUp `success:true + orderState=Submitted` 作为通用提交/订单结果 | 改成 relayer response、local wait、remote status、chain finality、position observation 的分层结果；不把任意一层命名为通用 Order ACK | 保留 inputHash、status 字段和交易 hash 作为 provider-native opaque observations |
| `pollUntilExecuted` timeout 返回 `false/false`，调用者可沿旧结果继续 | 改成 `WaitEnded`（本地等待结束）+ 最后一次实际远端观察/观察错误；timeout 不启动第二次发送 | 保留轮询间隔/停止行为作为该业务 flow 的运行策略 |
| LeverUp 每次重建重新抓 Pyth、取时钟、生成 salt/deadline、签名 | 改成一次 flow 中实际取得的值进入后续纯请求序列化；恢复使用同一 captured operands/受保护签名，不能当原批准请求重造 | 保留签名算法和 native payload 形状；private key/signature 不进公开 Agent/log |
| `qty*price` 的 USD/1x、固定 USDC/scale、raw fee/PnL | 改成 provider-local typed units/quote/collateral/leverage/protection conversion；缺 evidence 就保留未证/拒绝 dependent leaf | 保留当前明确转换函数和 Decimal 算术作为局部实现证据 |
| `closePosition(_quantity)` 忽略数量并取第一条 matching pair | 改成显式 `CloseAll` 或有证据的 partial leaf；不得静默丢 quantity，positionHash/选择事实要进入该 flow | 保留 native close request 的 positionHash/deadline/signature 能力 |
| `resolveNativeKey` 对未知值造最小 Contract | 改成 provider-specific unresolved identity/late validation；允许手工 identity 的 provider 可在自身 parser/interpreter 验证，不普遍要求先 search/catalog revision | 保留已知 key 的 round-trip；未知值只能作为待验证输入，不能当 capability evidence |
| 静态 preset `isPaper`、credential field presence、engine import 代表可用写能力 | 改成配置提示与 runtime evidence 分开；同包 declaration 负责输入解析/解释/编码/结果消费者，availability/authorization 由实际边界产生 | 保留 wizard/migration/preset identity 和 installed-pack provenance |
| E2E 文档/ID substring/TCP/first account/optional skip 代表 paper 或 native capability | 改成 scenario-specific evidence producer + typed scope/result/Unknown；只有明确 availability projection 才改变能力 | 保留真实测试场景、raw observations、skip 原因作为证据材料 |
| JSONL evidence 默认要求所有 record 有 digest/sequence/coverage，或失败后重发交易 | 改成这些关系按 sink consumer 选择；独立 append 不等于交易 WAL，append 失败不改变外部 effect 的发送事实 | 保留 runId、recordedAt、gitCommit 和已实现 JSONL 记录字段 |
| `TradingGit` execute→snapshot→commit JSON 被当成每项 effect 的原子接受 | 改成仅 selected durable external effect 使用 `κ/ω` 接受/恢复；普通 query/read/data/control 不被强制改造 | 保留 stage/commit/push 兼容行为作为迁移观察，不把它当新 authority |
| 所有 operation 默认都需 lease/lock/compensation | 改成只在实际有并发放行、经济冲突或恢复竞争的 leaf 引入对应机制；lease 是实现选择，不是核心 tag | 保留具体 effect 需要的互斥/补偿/unknown-safe 语义 |
| startup purge 一律必须先经过新 effect journal，或反之完全不管 | 改成先判断被清理路径是否承载 selected durable effect authority；仅该路径需要 recovery classification | 保留 ephemeral simulator/cache 可按自身生命周期清理 |
| `MAP-47A0790F1B` 的 versioned calendar 条件被升级成所有写的核心前置 | 改成 session 只在具体 effect 声明并消费 session evidence 时才是前置；不依赖时段的业务不被阻断 | 保留当前 LeverUp always-open 只是“未提供 calendar evidence”的事实 |
| `NOTE-9-1` 的 ReconcileBeforeRetry 被升级成全 provider 统一策略 | 改成无 native idempotency/absence/fencing evidence 时的保守选项；真实 provider 可声明更强策略，但必须有自己的结果/absence consumer | 保留“未知不可盲重发”的安全分支 |
| `MAP-A94BD9AD27` 的无 Connection Layer descriptor 被当成抽象必然缺口 | 改成只有共享 endpoint scope、资源生命周期、取消/超时或多个消费者确实需要同一 connection relation 时才抽象 | 保留每个具体 client 的实际 IO 语义，不因 class 形状推导核心 |

## 5. 原始 ID 入口（身份保留，不代替论证）

下面只提供可回查入口；上面的具体操作/消费者论证才是本稿内容。原始问题逐字文本、原分析完整字段、原 closure `disposition`/`resolution` 均仍保留在这些文件中，本稿不把其中旧候选 `targetModel` 自动升格为新语义。

### 5.1 Question closure IDs

- **Leverup** — `docs/uta-effect-runtime-design/solutions/Leverup/questions-closure.json`：
  `MAP-2FF2A5B544`, `MAP-2FF2A5B544`, `MAP-A2A0451C27`, `MAP-B9BAFEC82F`, `MAP-A3B8CD6164`, `MAP-B100B9C54C`, `MAP-50F0F7A825`, `MAP-D1A1D77A33`, `MAP-5E91CFA930`, `MAP-5EDC8088C6`, `MAP-6786905A37`, `MAP-AFEC8DA518`, `MAP-B53E29D3CC`, `MAP-123F8DBC3D`, `MAP-0233341AE8`, `MAP-5D7C69A184`, `MAP-481A2438E0`, `MAP-47A0790F1B`, `MAP-4AD307691B`, `MAP-96C363D9C7`, `MAP-BC7663242A`
- **LeverupProtocols** — `docs/uta-effect-runtime-design/solutions/LeverupProtocols/questions-closure.json`：
  `MAP-63F62A28BF`, `MAP-93BB15270F`, `MAP-CA68AA9D2A`, `MAP-B6898CEF97`, `MAP-EB598077BB`, `MAP-98D8B226B2`, `MAP-A8F11986D4`, `MAP-351C6A94E7`, `MAP-73F74DC466`, `MAP-518E08C180`, `MAP-6E2E6F9904`, `MAP-A9DB1F677B`, `MAP-12314DC5A5`, `MAP-2D927BE0BD`, `MAP-6D6A28953D`, `MAP-CAE8A402AD`, `MAP-14017B6DD3`, `MAP-7B2ED6A111`, `MAP-6528AEB1B4`, `MAP-D33182231F`, `MAP-ACD640430F`, `MAP-902BBDA309`, `MAP-6690E83E34`, `MAP-970DB739F5`, `MAP-C5F7182D33`, `MAP-6966FD8244`, `MAP-A94BD9AD27`, `MAP-4996C21AA2`, `MAP-6CE514231C`, `MAP-D8D93BC61D`, `MAP-68B42E34DB`, `MAP-1F4643BAB5`, `MAP-2B8DD3E4BD`, `MAP-D8B1941723`, `MAP-339E61F930`, `MAP-25EDC2AA39`, `MAP-96515A5FA2`, `MAP-A283DD30CA`, `MAP-09A529447A`, `MAP-B24803E3AD`, `MAP-7DDADCCAD1`
- **Catalog** — `docs/uta-effect-runtime-design/solutions/Catalog/questions-closure.json`：
  `MAP-9AD9951502`, `MAP-607170E22C`, `MAP-6496594BF0`, `MAP-B40F4C1C42`, `MAP-F3151B31E7`, `MAP-9D3DC42AC9`, `MAP-1E5FD0A690`, `MAP-C4C40BAECB`, `MAP-3392948A39`, `MAP-AE59785B88`, `MAP-2564A889E7`, `MAP-50C8158380`, `MAP-75B61EBF36`, `MAP-1986FE3044`, `MAP-E52D407CDC`, `MAP-601F6E2834`, `MAP-E745F1370E`, `MAP-EBB7846E5F`, `MAP-BB8EAF65B0`, `MAP-6E3C5642E6`, `MAP-2F4E92A2AE`, `MAP-B9545FA731`, `MAP-F62E863C78`, `MAP-2862195456`, `MAP-DE2769E2F7`, `MAP-42A8E8BFCC`, `MAP-FA8441EFDE`, `MAP-F45EE8D4C7`
- **LiveEvidence** — `docs/uta-effect-runtime-design/solutions/LiveEvidence/questions-closure.json`：
  `MAP-4D4A864108`, `MAP-E5356E684D`, `MAP-A60C86B58F`, `MAP-FBF3A41608`, `MAP-7DAC2704FB`, `MAP-B5990574ED`, `MAP-FFA9030D49`, `MAP-C2F022975E`
- **TargetGaps** — `docs/uta-effect-runtime-design/solutions/TargetGaps/questions-closure.json`：
  `NOTE-5-4`, `NOTE-7-1`, `NOTE-9-1`, `NOTE-18-1`, `NOTE-18-2`
- **MockBroker** — 没有 `group: MockBroker` 的原始 question closure；以下十个是 `question-inputs.json` 中由其他组拥有、但明确提及 MockBroker/simulator 的入口：`MAP-177DF827E5`, `MAP-189E766E12`, `MAP-C735359708`, `MAP-5B98644210`, `MAP-F54308897B`, `MAP-2810B2FE69`, `MAP-A173AC5D0E`, `MAP-9A7B5853BF`, `MAP-F6CFDCE6F2`, `MAP-5D07510B31`。它们仍按原属 `CoreAccount`、`TradingJournal`、`RuntimeComposition`、`Polling` closure 回查，不改标。

### 5.2 全量原分析 source IDs

这些 ID 对应各组 `analyses.json` 的非 question mapping/analysis 条目；列出它们是为了保留原研究身份，不表示按数量完成设计，也不替代上文对事实和消费者的论证。

- **MockBroker** — `docs/uta-effect-runtime-design/solutions/MockBroker/analyses.json`：
  `MAP-2807C05FCC`, `MAP-74610A30AF`, `MAP-50275FA75F`, `MAP-377A30A5EC`, `MAP-5484E0ABE8`, `MAP-B20F6E5551`, `MAP-BDF7756398`, `MAP-399D99B7AB`, `MAP-BEE79BFA7C`, `MAP-0DD83C8637`, `MAP-E9E1A05333`, `MAP-B4C7FEA646`, `MAP-CDC7079D83`, `MAP-ADE49309E9`, `MAP-47DB032F5A`, `MAP-0151919B70`, `MAP-9DFD3B9879`, `MAP-D6BA46AF1A`, `MAP-0F7F332B24`, `MAP-559086B869`, `MAP-26F708C6F8`, `MAP-B4CEC1AF32`, `MAP-1F7945D7FF`, `MAP-8C05962CF7`, `MAP-A20A4E0C8F`, `MAP-03B79FC368`, `MAP-46ED6C273F`, `MAP-5FA8553583`, `MAP-F133CDF76E`, `MAP-09ABC1ADD4`, `MAP-5842AA2B07`, `MAP-0BBDEA8E36`, `MAP-C0D557E0BD`, `MAP-04B4087714`, `MAP-BBC8C72572`, `MAP-202708E052`, `MAP-5D79D1084D`, `MAP-FED35111E9`, `MAP-A3F1814B97`, `MAP-AB61645548`, `MAP-B8A614D67A`, `MAP-F0F4E26989`, `MAP-89456D4461`, `MAP-48652AA629`, `MAP-5729FF3D09`, `MAP-67B9817A3D`, `MAP-91432AF5F2`, `MAP-38E8988911`, `MAP-150B8F86DC`, `MAP-CF5A1A7070`, `MAP-BF81183BD5`
- **Leverup** — `docs/uta-effect-runtime-design/solutions/Leverup/analyses.json`：
  `MAP-6F4E5CBAB5`, `MAP-5FA94B52E3`, `MAP-C6C1199DD4`, `MAP-A9E4B4C39D`, `MAP-E00D066E13`, `MAP-DD63DE7255`, `MAP-AC474EA806`, `MAP-405AB5279C`, `MAP-7F36FE8E07`, `MAP-A8A98337B2`, `MAP-C78F741F42`, `MAP-F8AC526698`, `MAP-2FF2A5B544`, `MAP-D61B8CB8B4`, `MAP-A2A0451C27`, `MAP-50F8D30457`, `MAP-AC1BAD4D60`, `MAP-B9BAFEC82F`, `MAP-A3B8CD6164`, `MAP-CA4DC0FDF9`, `MAP-B100B9C54C`, `MAP-B04EEC79F3`, `MAP-50F0F7A825`, `MAP-D1A1D77A33`, `MAP-CB02240E08`, `MAP-BC274E8422`, `MAP-079143FA81`, `MAP-BA518AF53A`, `MAP-5E91CFA930`, `MAP-61E3A9F0E4`, `MAP-796DFD3470`, `MAP-6A6E5DA953`, `MAP-E8C004E0EC`, `MAP-796C0C5B19`, `MAP-D8C97E1870`, `MAP-90178E421A`, `MAP-5EDC8088C6`, `MAP-6786905A37`, `MAP-AFEC8DA518`, `MAP-04032EFDC4`, `MAP-B53E29D3CC`, `MAP-123F8DBC3D`, `MAP-0233341AE8`, `MAP-5D7C69A184`, `MAP-481A2438E0`, `MAP-47A0790F1B`, `MAP-4AD307691B`, `MAP-96C363D9C7`, `MAP-BC7663242A`
- **LeverupProtocols** — `docs/uta-effect-runtime-design/solutions/LeverupProtocols/analyses.json`：
  `MAP-63F62A28BF`, `MAP-93BB15270F`, `MAP-CA68AA9D2A`, `MAP-B6898CEF97`, `MAP-EB598077BB`, `MAP-98D8B226B2`, `MAP-A8F11986D4`, `MAP-351C6A94E7`, `MAP-73F74DC466`, `MAP-518E08C180`, `MAP-6E2E6F9904`, `MAP-A9DB1F677B`, `MAP-12314DC5A5`, `MAP-2D927BE0BD`, `MAP-6D6A28953D`, `MAP-CAE8A402AD`, `MAP-14017B6DD3`, `MAP-7B2ED6A111`, `MAP-6528AEB1B4`, `MAP-D33182231F`, `MAP-ACD640430F`, `MAP-902BBDA309`, `MAP-6690E83E34`, `MAP-970DB739F5`, `MAP-C5F7182D33`, `MAP-6966FD8244`, `MAP-A94BD9AD27`, `MAP-4996C21AA2`, `MAP-6CE514231C`, `MAP-D8D93BC61D`, `MAP-68B42E34DB`, `MAP-1F4643BAB5`, `MAP-2B8DD3E4BD`, `MAP-D8B1941723`, `MAP-339E61F930`, `MAP-25EDC2AA39`, `MAP-96515A5FA2`, `MAP-A283DD30CA`, `MAP-09A529447A`, `MAP-B24803E3AD`, `MAP-7DDADCCAD1`
- **Catalog** — `docs/uta-effect-runtime-design/solutions/Catalog/analyses.json`：
  `MAP-9AD9951502`, `MAP-DA5BBE56B3`, `MAP-14D51E5BA4`, `MAP-607170E22C`, `MAP-6496594BF0`, `MAP-B40F4C1C42`, `MAP-ACA4BDF989`, `MAP-B295179D05`, `MAP-F3151B31E7`, `MAP-9D3DC42AC9`, `MAP-1E5FD0A690`, `MAP-AB521AFE64`, `MAP-55E14D3598`, `MAP-C4C40BAECB`, `MAP-3392948A39`, `MAP-AE59785B88`, `MAP-1B0FB784F5`, `MAP-D5792AEA38`, `MAP-2564A889E7`, `MAP-50C8158380`, `MAP-75B61EBF36`, `MAP-F093E8F942`, `MAP-E89067CA5C`, `MAP-1986FE3044`, `MAP-E52D407CDC`, `MAP-CC2177368A`, `MAP-00030A134A`, `MAP-9F3FB86CB7`, `MAP-67CE26F92B`, `MAP-601F6E2834`, `MAP-E745F1370E`, `MAP-EBB7846E5F`, `MAP-BB8EAF65B0`, `MAP-6E3C5642E6`, `MAP-2F4E92A2AE`, `MAP-B9545FA731`, `MAP-F62E863C78`, `MAP-2862195456`, `MAP-DE2769E2F7`, `MAP-42A8E8BFCC`, `MAP-FA8441EFDE`, `MAP-52A6B771BA`, `MAP-9A17C2A8CC`, `MAP-E954ABE476`, `MAP-4FEAB1D03E`, `MAP-ED0CF2A5B8`, `MAP-4E1058C577`, `MAP-2C6D7EBC2D`, `MAP-5A3B0B2D15`, `MAP-1A1C5B18E7`, `MAP-5EA8C0B0F9`, `MAP-675DD80E1B`, `MAP-4B0B9AFD2F`, `MAP-7EFC86AB32`, `MAP-83A8C3AFDE`, `MAP-5A9FDC9F74`, `MAP-8C711FFB8`, `MAP-277E14E1BA`, `MAP-F5D0B6A7A7`, `MAP-CAEC5C7A8B`, `MAP-05D5E2E8D1`, `MAP-BF5A3E7A4D`, `MAP-E2D6D594D5`, `MAP-E77FDD04E9`, `MAP-FD5C84DA97`, `MAP-87C2D1C7B5`, `MAP-F1ADCB3B22`, `MAP-36C82AC019`, `MAP-3D9E3BCF3D`, `MAP-70FE9D28FD`, `MAP-B6D7A6AA62`, `MAP-9E1CB433BC`, `MAP-751E2DD44D`, `MAP-2C5764CE16`, `MAP-FD20A97FB8`, `MAP-D1B7B64B07`, `MAP-4CB7A4B30A`, `MAP-E8DDB64B0D`, `MAP-25322F3268`, `MAP-44BD5E648B`, `MAP-E1520FC5E4`, `MAP-D85E7C4F0E`, `MAP-1FCEB6EEBB`, `MAP-0E2C8E1BFE`, `MAP-8E2B9E6AE7`, `MAP-D1E53B31B5`, `MAP-0F4E5C6BB2`, `MAP-2A94A8D3A1`, `MAP-5D154D0E4E`, `MAP-44C3B1C8B6`, `MAP-7A4F5FD19A`
- **LiveEvidence** — `docs/uta-effect-runtime-design/solutions/LiveEvidence/analyses.json`：
  `MAP-5A0732EC10`, `MAP-60855A8312`, `MAP-7E7AB00B65`, `MAP-415093F05F`, `MAP-DA8940C7D3`, `MAP-D684830A67`, `MAP-0FB902DDBC`, `MAP-A9C599CFB8`, `MAP-B65B828516`, `MAP-68FD1B154A`, `MAP-585A2F9006`, `MAP-32BC46FDBD`, `MAP-4D4A864108`, `MAP-E5356E684D`, `MAP-14606B82FF`, `MAP-444A62C6D5`, `MAP-301A0F7EF8`, `MAP-50F731ABB9`, `MAP-8D31A540CC`, `MAP-5460468AB4`, `MAP-A60C86B58F`, `MAP-914C5731FE`, `MAP-CCFD876360`, `MAP-CC43DAFDFD`, `MAP-4B824156CE`, `MAP-FBF3A41608`, `MAP-7DAC2704FB`, `MAP-0A7103653D`, `MAP-C7223C2B36`, `MAP-D16449202E`, `MAP-58AE86AEDD`, `MAP-47ED37A445`, `MAP-B5990574ED`, `MAP-8D95A00EF9`, `MAP-E4B0D38A44`, `MAP-9762F1BB09`, `MAP-25C7BC81F2`, `MAP-813BFD59A1`, `MAP-EE69E2CB46`, `MAP-2B14BC2DD9`, `MAP-B41A0A0990`, `MAP-FFA9030D49`, `MAP-F9A4323AA5`, `MAP-424F0FB69C`, `MAP-8800585703`, `MAP-FA821E371F`, `MAP-C2F022975E`, `MAP-3BF311EBD5`, `MAP-C34FFFADB8`, `MAP-85AF389920`, `MAP-73F753A129`, `MAP-3D797361F3`, `MAP-B4CCE8940E`, `MAP-23AEA53AD6`, `MAP-FACA90D0FC`, `MAP-58F0FF7798`, `MAP-B164304E0C`, `MAP-8CB6B26E83`, `MAP-628E0887B1`, `MAP-42049295D7`, `MAP-E9EB273A72`, `MAP-E136AE0A4B`, `MAP-4A1400D914`, `MAP-BA81ADF360`, `MAP-96BCC45A7C`, `MAP-3FD0A99D87`, `MAP-CAA43D746F`, `MAP-47B29B6218`, `MAP-61B4CADFAF`, `MAP-5C9F33F93C`, `MAP-DC819A17DE`, `MAP-34BF36C838`, `MAP-147173C2A5`, `MAP-55F8053385`, `MAP-81E8AC49C4`, `MAP-6119E3BEEE`, `MAP-7076DD2230`, `MAP-5F648FC9E1`, `MAP-C63562DE19`, `MAP-3EEA8F2FEB`, `MAP-04EB2CF21F`, `MAP-14999AF99F`
- **TargetGaps** — `docs/uta-effect-runtime-design/solutions/TargetGaps/analyses.json`：
  `NOTE-2-1`, `NOTE-2-2`, `NOTE-4-1`, `NOTE-4-2`, `NOTE-5-1`, `NOTE-5-2`, `NOTE-5-3`, `NOTE-5-4`, `NOTE-5-5`, `NOTE-7-1`, `NOTE-7-2`, `NOTE-8-1`, `NOTE-8-2`, `NOTE-8-3`, `NOTE-8-4`, `NOTE-9-1`, `NOTE-12-1`, `NOTE-12-2`, `NOTE-13-1`, `NOTE-14-1`, `NOTE-15-1`, `NOTE-16-1`, `NOTE-17-1`, `NOTE-18-1`, `NOTE-18-2`, `NOTE-19-1`

### 5.3 补充来源 ID 与处置位置

§5.2 的长行保留各组已列出的 source IDs；以下补充同一 `analyses.json` 中此前未在长行显示的 ID，避免把 source-index 的身份误读成“只处理了举例的几项”：

- **Leverup**：`MAP-17D90B12AC`, `MAP-406869F527`。处置位置：§2.2 的实际 open/close 操作数、等待/远端观察和失败关系；涉及 session、重试或 discovery 的分支再由 §3.1–§3.2 裁决，旧入口的语义变更汇总于 §4。
- **Catalog**：`MAP-E9688DBE16`, `MAP-21AAC99E0D`, `MAP-F8525C7A99`, `MAP-5C311A55C1`, `MAP-1D576100CB`, `MAP-41D1B056C8`, `MAP-819A30C052`, `MAP-006AF2BF79`, `MAP-AE04CD83E4`, `MAP-E43DFC70EF`, `MAP-6367D87808`, `MAP-C3B978232C`, `MAP-093F5766C9`, `MAP-E010E516DB`, `MAP-D914E7F49F`, `MAP-16D7FC3B84`, `MAP-4D0C34ED53`, `MAP-E981F551DA`, `MAP-6E311CAABB`, `MAP-D74564C976`, `MAP-076B691F74`, `MAP-F4B8428675`, `MAP-D3ABE635D3`, `MAP-2092F69746`, `MAP-923D3E5DC8`, `MAP-EFDE4EFD6B`, `MAP-964B3CADF0`, `MAP-2E9FCB05D5`, `MAP-AB74D13B81`, `MAP-1729810891`, `MAP-E2F6BC0E7E`, `MAP-2E5F0661A6`, `MAP-507FF8C434`, `MAP-CEF7AFFAF1`, `MAP-D47789CDE0`, `MAP-D74C77540F`, `MAP-D37C32D3D3`, `MAP-3BB0EF71F5`, `MAP-30B07B33AF`, `MAP-AD49E3FECC`, `MAP-D0D9F4AA44`, `MAP-5C8AA54A45`, `MAP-D804E25471`, `MAP-13ABF99986`, `MAP-24015C5378`。处置位置：§2.4 的动态 pack 同包解析/解释/编码/结果消费关系，以及 §3.2 的 discovery/catalog revision 条件裁决；旧 preset/engine 语义统一在 §4。

这些补充 ID 与 §5.2 的完整各组长行合并后才是 source-ID 覆盖；它们的共同处置位置不取代各条原始 `sourceEvidence`、`currentBehavior`、`problem` 和 `targetModel`，原文仍以对应 `analyses.json` 为准。

### 5.4 各组 source-ID 到论证位置的映射

为使“保留身份”也保留处置位置，§5.2/§5.3 每个组内的每个 source ID 均按以下组内映射读取；这不是按条目数量验收，也不把同组条目压成同一业务实例：

| 原始组 | 每个 source ID 的主要处置位置 | 独立实例边界 |
|---|---|---|
| MockBroker（51） | §2.1；§3 的 Mock rows；§4 的 simulator-control/StopLimit rows | simulator control、模拟 reducer、真实 write authorization 分开 |
| Leverup（51） | §2.2；§3 的 submission/status/units rows；§3.1–§3.2 的 session/retry/identity 裁决；§4 的 LeverUp rows | open、close、relayer wait、chain/position observation 分开 |
| LeverupProtocols（41） | §2.3；§3 的 units/schema/deployment rows；§4 的 protocol conversion rows | quantity/price/collateral/schema/deployment 作为同一协议实例的不同操作数，不升级为全局常量 |
| Catalog（93） | §2.4；§3 的 pack/discovery rows；§4 的 dynamic-pack/preset rows | pack definition、preset wizard、runtime availability/authorization 分开 |
| LiveEvidence（82） | §2.5；§3 的 evidence rows；§4 的 evidence/E2E rows | producer、sink、能力判断、交易 effect 分开 |
| TargetGaps（26） | §2.6；§3 的 persistence/startup rows；§4 的 selected-recoverable-effect rows | ordinary read/data/control 与选中的可恢复外部 effect 分开 |

如果某条 source analysis 没有在上文被再次点名，它仍按其原组和上表位置进入该组的事实/未证/适配三列；不把“未点名”改写成“已证明”，也不把 group-level routing 改成新的核心槽位。

## 6. 尚未解决的事实与验证边界

- 本稿没有执行任何真实链、relayer、broker、paper account、pack install/import、并发 sink 或 restart 实验。因此 nested/flat accepted schema、fee/collateral/leverage units、testnet deployment、relayer idempotency/retention/finality、venue environment/permission、evidence sink ordering 和 native ABI 均未被本稿证明。
- 原始问题中标为 `design-decided`、`integration-resolved` 或 `empirical-retained` 的处置值只作为历史调查状态。尤其 calendar、ReconcileBeforeRetry、Connection Layer、digest/sequence/coverage、统一 WAL/lease 等，本文已明确哪些是条件性候选，不能把状态标签当成新核心义务。
- 本稿没有给 Order、Candle、Instrument、News、Mock control 或 evidence sink 分配新的核心槽位；这些名字只在各自实例段落说明操作数与消费者如何连接。任何最终核心选择仍需用独立抽象事件流继续反驳/验证。

## 7. 本稿使用的当前事实源

- 抽象候选（仅作为可反驳接口，不当作实现事实）：`docs/uta-capability-runtime-design.md:235-355,357-561,603-751,1084-1192`。
- 研究失败和边界：`docs/uta-capability-runtime-design/current-research.md:56-127`；原始入口：`docs/uta-effect-runtime-design/solutions/index.md:5-16,47-63`。
- Mock：`services/uta/src/domain/trading/brokers/mock/MockBroker.ts:1-17,185-324,519-621,665-796,799-839,858-965`；`services/uta/src/http/routes-simulator.ts:81-223`。
- LeverUp：`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:213-317,327-518,522-566`；`relayer-client.ts:1-107`；`reader-client.ts:24-110`；`eip712.ts:1-190`；`decimals.ts:1-55`；`pairs.ts:29-81`；`pyth.ts:14-72`。
- Catalog/pack：`packages/uta-protocol/src/brokers/preset-catalog.ts:18-106,294-333,437-588`；`services/uta/src/domain/trading/brokers/factory.ts:26-47`；`registry.ts:23-123`；`src/core/broker-packs.ts:23-172`。
- Discovery/staging：`services/uta/src/domain/trading/contract-search.ts:27-64`；`services/uta/src/domain/trading/UnifiedTradingAccount.ts:515-557,603-724`。
- Live evidence：`services/uta/src/domain/trading/__test__/e2e/live-paper-evidence.ts:6-86` 及本稿 §2.5 所列 E2E sources。
- Durable/launch boundary：`services/uta/src/domain/trading/git/TradingGit.ts:119-185,929-977`；`services/uta/src/domain/trading/git-persistence.ts:14-48`；`services/uta/src/main.ts:56-87,102-152`；`src/core/config.ts:797-821`。

本稿是只读草稿；没有修改仓库源码、运行 build/lint/tests/formatter/runtime、请求外部服务或写入真实账户。
