# UTA core rework：六组 surface accommodation 候选承接稿

> **稿件性质**：供 Main 整合的候选正文，不是实现规范、不是当前实现的证明，也不是全量索引。它把已经重新调查过的真实契约，按六个业务/边界组分别承接到主书的候选关系中。
>
> **证据边界**：本稿以 `docs/uta-capability-runtime-design/current-research.md:56-127` 的纠偏记录和 `local://uta-core-rework/surface-contract-recheck.md` 为导航；实际函数、消费者和时序仍以对应源码和该 recheck 的完整 ledger 为准。当前没有运行、测试、构建、格式化或生产运行证据，因此本稿不宣称任何目标已经落地。

## 0. 承接规则与阅读方法

### 0.1 这份稿子要承接的是什么

此前的事件流、EF、slot 和 legacy target 判断已经被否定。它们只能作为纠偏历史或原始材料入口，不能再被当作现行前提。本稿不把旧事件流换一个名字继续使用，也不把旧对象的名称、统计数量或 `targetModel` 索引当作设计表达。

本稿只保留一组很窄的共同关系：

1. **声明先于调用**：每个可消费能力由它自己的声明/定义 `d` 确定输入、输出、失败和作用域；`d` 不是一个把所有业务动作收拢起来的全局 action union。
2. **数据读取和受控效果分开**：数据读取产生带来源和时点的 observation；受控效果产生显式的接受、派发、确认、观察或未知结果。查询不能因为“顺便修正”而偷偷成为写入事务。
3. **边界先解析**：HTTP、进程间 transport、broker response、配置和持久化数据在边界解析为精确的 domain variant；不能用成功类型泛型、`unknown` 转换或 truthy 布尔值把不确定性藏掉。
4. **资源责任有所有者**：账户资源、journal、进程、代理、supervisor 的存续和关闭各有所有者；账号不是进程，proxy 不是 broker authority，reload 不是 reconnect。
5. **接受和最终完成分层**：本地接受、远端已派发、native receipt、提交后观察、最终状态彼此不等价；调用方超时/取消也不证明远端没有处理。
6. **作用域显式**：账户、子账户、principal、配置版本、请求关联和 operation identity 各自有不同边界，不能用一个字符串或一个 header 复用全部语义。

这些是写作上的共同语法，不是要求六组共用一个万能 `Provider`、`ActionContractMap` 或 SDK。真正的字段、函数、结果消费者和时序在下面各组分别实例化；某组的缺陷可以反过来收紧共同关系。

### 0.2 来源与代表性标记

六组的原始问题、来源分析和完整身份仍由 `surface-contract-recheck.md` 的 ledger 追溯。本稿只在每组列出代表性身份，不用代表性列表冒充全量完成：

| 组 | recheck 中的原始问题量 | source-analysis ledger | 本稿主要入口 |
|---|---:|---:|---|
| CoreAccount | 34 | 93 | `surface-contract-recheck.md` CoreAccount ledger；`UnifiedTradingAccount.ts`、`uta-manager.ts` |
| TradingJournal | 45 | 68 | TradingGit、git persistence、EventLog 与 TradingJournal design |
| AliceClients | 8 | 94 | `UTAClient.ts`、`UTAAccountSDK.ts`、`UTAManagerSDK.ts`、trading proxy |
| Supervisor | 0 | 21 | health、restart-trigger、Guardian 边界与 Supervisor design |
| RuntimeComposition | 32 | 105 | UTA/Alice/Guardian 启动、配置、关闭、注册和调度组合根 |
| HttpRoutes | 2 | 103 | `routes-trading.ts`、`routes-simulator.ts`、`trading-proxy.ts` |

“原始问题量为 0”只表示 Supervisor 没有被原始问卷单独列出，不表示它没有待决问题；其 21 个 source-analysis 身份和本稿的未决项仍必须处理。

### 0.3 与主书 §7.5 的接缝

Main 已在主书 §7.5 写出 Alice→UTA 的候选调用链。本稿把它当作**待检验候选**而不是事实复述，并明确指出三个必须保留的断点：

- 当前 `UTAClient.request<T>` 仍把成功 JSON 直接转成 `T`；当前 proxy 转发 `x-request-id` 等选定 header，但不注入 `Authorization`，也没有响应关联验证。
- 当前 BFF 路由创建自己的 30 秒 controller；调用方的取消信号没有贯通到 UTA 的真实等待，且 `UTAClient` 的 timeout controller 在传入 caller signal 时会被绕开。
- “最终定义 `d` 生成 client、service credential 加 delegated subject、UTA 解码精确 `Outcome`”是合理的目标关系，但最终 route/capability 清单、credential/verifier 的持有者、响应 echo、失败 variant 和 non-local transport 尚未由源码证明。

因此，§7.5 可以作为 AliceClients/HttpRoutes 的交叉目标，但不能用它掩盖当前 surface 的缺口，也不能把 `x-request-id` 说成业务幂等键。受控效果的 operation identity 必须由 TradingJournal/效果边界另行定义。

---

## 1. CoreAccount：账户作用域、连接健康、子账户选择与实际账户观察

### 1.1 来源入口和身份保留

本组在 recheck 中有 34 个原始问题和 93 个 source-analysis 身份。代表性身份包括：
原始材料入口：`docs/uta-effect-runtime-design/solutions/CoreAccount/design.md`；当前源码 `services/uta/src/domain/trading/UnifiedTradingAccount.ts`、`services/uta/src/domain/trading/uta-manager.ts`；完整身份追溯到 recheck 的 CoreAccount 原始问题与 source-analysis ledger。

- R1：`MAP-00D45A7149`（永久/失败记录）、`MAP-03A2A17A58`（等待连接）、`MAP-0A714E7908`（grace）、`MAP-12EBFAE5E6`（reach attempt）、`MAP-3714A83594`（connect）、`MAP-4144027899`（子账户测试）、`MAP-463948E2EB`（health/recovery）、`MAP-70C8DB0025`（listener）、`MAP-7ACD53B4BE`（构造参数/监听器）、`MAP-7DA2BE5D55`（close）、`MAP-A0A0E5EBC7`（broker call）、`MAP-B4A46EAD8C`（connect fire-and-forget）、`MAP-C7ACDD9C7A`（health threshold）、`MAP-DBBD7BE69C`（commit）、`MAP-FFFCA4765D`（guards）。
- R2：`MAP-062ABEC10D`、`MAP-079C9ED6FF`、`MAP-100C8043F8`、`MAP-124109541E`、`MAP-152865F791`、`MAP-189E766E12`、`MAP-1F24B04239`、`MAP-27891FCB27`、`MAP-4221233892`、`MAP-49119F272B`、`MAP-7864431508`、`MAP-7A53419830`、`MAP-8DFEA924F8`、`MAP-A0C78D8C68`、`MAP-C1727C9E38`、`MAP-E59A917F82`，覆盖 stage、校验、TIF/overlay、cancel、TPSL、capabilities 与 push。
- R3：`MAP-044AE7B4DD`、`MAP-076B11499E`、`MAP-0AF3B67931`、`MAP-4189A98E6F`、`MAP-520CFD3057`、`MAP-58E656CE5A`、`MAP-5B98644210`、`MAP-5C48EEF269`、`MAP-6B72864B5E`、`MAP-6E4258767C`、`MAP-7C856D1CDF`、`MAP-80F3D97161`、`MAP-81E9BDAC4E`、`MAP-82E54D80F1`、`MAP-8B7A06270E`、`MAP-A4B5DBBF39`、`MAP-B3655A0EA7`、`MAP-C11719131D`、`MAP-C735359708`、`MAP-CBFF2224B1`、`MAP-D19FB60347`、`MAP-D4F5440582`、`MAP-D615CBA78E`、`MAP-E991350693`、`MAP-F0694AE4F6`、`MAP-F5D4E6C3D4`，覆盖 submitted-order observation、sync、external orders、pending IDs、子账户和 wallet reconciliation。
- R4–R7：`MAP-188B023F53`、`MAP-229EF12AA4`、`MAP-36B15212DF`、`MAP-6227B2AFB6`、`MAP-7AF82C011B`、`MAP-BA5730BE0C`、`MAP-D37BF3A34F`、`MAP-E8B780DC9D`、`MAP-EE6C7F95C5`、`MAP-FE83587457`，以及 `MAP-92B40EBFD5`、`MAP-7F92A5F120`、`MAP-2965B55AF1`，覆盖 expansion、market/contract、identity、PnL、saved state、read-only/keyless 和 options。

交叉纠偏可回看历史 `NOTE-8-1`（账户/暴露/作用域冲突）、`NOTE-8-4`（close 数量 reread 没有版本/新鲜度）和 `NOTE-5-3`（各种接受/最终标准的区别）。这些 NOTE 是纠偏锚点，不是要恢复的旧目标。旧 event-flow/EF/slot 文件仍在 superseded archive 中，但不属于当前账户契约。

### 1.2 已观察到的真实 surface

`UnifiedTradingAccount` 当前实际把 broker、`TradingGit`、guards、health/recovery、子账户缓存和若干回调放在同一对象内：

- options 公开 guards、saved state、callbacks、`readOnly`、keyless、vendor 等选择，但没有 typed principal、credential authority 或 policy owner。
- 构造时安装 listener，构造流程中由 `_getState` 并行读取 account、positions、orders；它按 `aliceId` 过滤 `Submitted`/`PreSubmitted`，因此该读取是“本地已关联的 submitted 状态 + broker 读取”的组合，不是全局订单事实。
- `_connect` 是异步 fire-and-forget；manager 的 `initUTA` 在连接完成前返回。`waitForConnect` 只在被调用时等待该对象自己的连接 promise。`_attemptReach` 先 `broker.init`，funded 账户还要成功读取 account 才算可达；失败会进入永久/暂时失败记录。`callBroker` 有约 1.5 秒 grace，offline/recovering 会快速失败，随后由 listener、计数器和 recovery timer 驱动状态改变。
- `_ensureSubAccounts` 如果 broker 提供 `listSubAccounts` 就缓存其结果，否则回退到 default；当存在多个子账户时，stage/dispatch 路径要求显式 selector，并验证 selector 与 contract 的 `subAccountForContract` 一致。这个 fallback 是当前行为，不是可接受的长期“默认子账户”证明。
- stage place 会展开 `aliceId`、overlay symbol、解析子账户、把价格/数量转换为 Decimal、默认 TIF `DAY` 并处理 TPSL；modify/close/cancel 有各自校验和 guard。commit 给消息盖子账户，push 前再次检查 mutability、disabled 和 offline。
- `sync` 在 broker 有 `getOpenOrders` 时走 listing mode，否则按订单读取并使用内存 `_pollState` 的 age/backoff。`observeExternalOrders` 只为 listing 中的外部订单建立 synthetic observed 记录。缺少 listing 时，CCXT 路径可能将 missing listing 变成 `[]` 警告；`getOrder` 的 null 也没有证明“订单不存在”。这是 submitted-order observation，不是一个名为 WaitingOrder 的新前提。
- `getPositions` 先读 broker positions，再做 wallet reconciliation：以 commits 重算成本基础，排除 in-flight pending `aliceId`，比较 drift，必要时用 broker avgCost/market fallback，并通过 `recordReconcile` 记录 synthetic reconcile；这条路径可能改变 avgCost/unrealizedPnL 的投影。synthetic reconcile state 会把 account totals 置零，不能当成普通账户 snapshot。
- market/contract expansion、quote、historical、clock、details 和 capabilities 是另一些 broker/contract surface；instrument identity、numeric formatting、sentinel/default expansion 不能被合并成一个“账户字段”。

### 1.3 候选承接：AccountAggregate 只承接账户关系，不吞掉进程和业务日志

候选的 CoreAccount 不是把现有类复制成新名称，而是把已有实际分界写清楚：

1. **账户身份**：本地 `AccountId`、provider account identity、子账户 identity 和 credential/principal 分开表达。provider 没有可靠 native identity 时，结果应是显式 `IdentityUnavailable`/`Unverified` 之类的 domain 状态，而不是从 label、数组位置或 `aliceId` 猜出 account owner。具体 variant 名称由实现组裁决，但不得把空字符串、`0`、sentinel 和 numeric formatting 当身份。
2. **账户连接**：账户资源拥有 `BrokerConnection` 和其 account-scope health；`BrokerHealth` 的 offline/recovering/ready 不能覆盖 `RuntimeHealth`。一个账户 reach 失败可以让该账户不可读或不可交易，却不能自动把整个 UTA process 标成死亡；反过来 process stopping 也不能伪装成每个账户都得到 broker 终态。
3. **子账户选择**：把“发现结果”和“选择结果”分开。候选 relation 至少需要表达 `NotQueried`、`Unavailable`、`Discovered(set)`、`SelectionRequired`、`SelectedAndVerified` 这类互斥状态；多子账户时，受控操作必须带选定的 subaccount，并在 dispatch 前验证 contract scope。当前无 listing 时的 default fallback 只能成为被记录的能力限制，不能静默扩大写入范围。
4. **keyless/readOnly**：不要用两个松散 boolean 让不合法组合在内部传播。候选上分成 credential participation、read capability 和 mutation authority 三个受约束维度：keyless 账户可以按声明参与公开/缓存数据，但不能因缺 credential 生成可执行 proposal；readOnly 可以读和预览，但 broker mutation guard 必须在实际 dispatch 边界拒绝。`getAggregatedEquity` 当前跳过 keyless/unhealthy，说明这是 manager 的聚合策略，不是账户已被“删除”或 process collapsed。
5. **受控订单**：账户层负责把具体 contract、subaccount、Decimal 和 guard 交给 TradingJournal/效果边界；本地 staged/commit/pending hash 不是 native order idempotency，也不是 native receipt。账户层可以返回“本地准备/接受”和 provider operation result 的分层结果，但不能把 unknown status parser 的默认 submitted 变成事实。
6. **观察和 reconcile**：账户层提供带 `observedAt`、source、coverage 和 account/subaccount scope 的 broker observation。listing complete、listing partial、listing unavailable、single lookup null 必须是不同证据等级；空集合不自动证明没有订单。position drift 的结果应明确是 valuation/cost reconciliation，而非 fill、trade 或 order completion。若需要写入 journal，必须通过显式的 reconciliation effect/worker，而不是把普通 query 的副作用作为隐藏契约。

这些关系保留了现有函数的业务语义，同时使错误不能跨层伪装：账户仍可以发起 reach、读取状态和执行 guards，但不会成为进程管理器、通用 journal、Alice client 或 HTTP router 的替身。

### 1.4 真实时序实例 A：冷启动、reach 和子账户选择

1. UTA manager 读取配置、创建 broker、恢复 git state，再构造 `UnifiedTradingAccount`。构造器安装 listener 并启动 `_connect`；manager 返回前连接不一定完成。
2. `_attemptReach` 调用 broker init；funded account 继续读取 account 以证明私有可读性。若失败，账户自己的失败/永久失败与 recovery timer 记录原因；process health 不应由一个账户的失败直接代替。
3. 需要账户数据的消费者显式调用 `waitForConnect` 或受约束的 account read。尚未 reach 时，`callBroker` 的 grace/recovering/offline 分支产生账户级 failure，而不是一个“空账户”成功。
4. 连接成功后尝试 `_ensureSubAccounts`。有 provider listing 时得到 discovered set；没有 listing 时得到受限 fallback。若合同要求多个子账户而调用没有 selector，guard 在 stage/dispatch 前拒绝；若 selector 与 instrument 的 subaccount mapping 冲突，也拒绝。
5. manager 聚合 equity 时跳过 keyless 或 unhealthy account，并对健康、可读的账户作 FX conversion；这个聚合结果只表示当前可读账户集合，不证明被跳过账户不存在，也不改变其账户 identity。

### 1.5 真实时序实例 B：本地 order pipeline 与 submitted observation

1. 调用 stage place，账户边界先扩展/规范化 contract，写入 `aliceId`/subaccount、Decimal 字段和 TIF，再将 intent 放入 `TradingGit` staging。
2. commit 将子账户信息写入 commit message，随后 push。当前 `TradingGit.push` 的实际顺序是先调用外部 `executeOperation`，再读取 git state、追加内存 commit、触发 `onCommit` 并清理 staging；如果过程在外部结果和本地回写之间中断，不能事后声称两侧已原子完成。
3. provider 返回的 operation result 经过当前 parser；未知状态可能按 submitted-like 默认处理。账户层必须保留“provider 响应无法确定”的失败/未知，不得用本地 pending hash 冒充 native receipt。
4. 后续 `sync` 若有 open-order listing，就对 listing 做观察；否则按已知订单读取并遵守 backoff。listing 缺失、单笔 null、空列表各自只提供相应证据。`observeExternalOrders` 只产生 submitted/external observation，不创造“等待中但尚未提交”的全局业务状态。
5. `_getState` 再次并行读取 account/positions/orders 时，只把本地关联且处于 submitted/pre-submitted 的记录纳入过滤；它不是对 provider 全量历史、幂等状态或最终结算的证明。

### 1.6 真实时序实例 C：position observation 与 cost reconciliation

1. `getPositions` 从 broker 得到当前位置；账户层记录来源和观察时间，并识别当前 in-flight pending 的 `aliceId`，避免把尚未确认的受控动作重复计入。
2. 以 `TradingGit` commits 重算成本基础，与 broker position 比较；drift 超过现有阈值时，按 instrument 的实际 avgCost/market 信息计算候选修正。价格、数量、multiplier 和 sentinel 的精度规则必须由对应 provider/contract 声明提供，不能由一个全局 `Number` 规则覆盖。
3. 当前实现可能调用 `recordReconcile`，追加 synthetic `reconcileBalance` 并改变成本/PnL 投影。候选契约将其标为 valuation-only reconciliation；它不能被查询消费者解释为 fill，也不能静默产生交易效果。
4. 若产品需要持久留痕，则由显式的 reconciliation worker/effect 消费这次 observation；若只是临时 valuation，结果应在读取边界返回而不写 journal。哪一种是正式产品语义仍是未决项，不能以当前副作用推导结论。

### 1.7 保留、纠正和原因

**保留**：账户拥有 broker 连接、account/position/order 读取、subaccount contract 验证、readOnly/keyless guards、listener/recovery、market/contract 查询和具体账户级结果。这些都能在现有函数和其消费者中定位。

**纠正**：

- 不再把 `UnifiedTradingAccount` 当作进程边界；`UTAManager` 与 Supervisor 的生命周期另行承接。
- 不再把 manager 返回、health `ok` 或 `startedAt` 当成账户交易 ready；连接 promise、私有读取、账户能力和 process phase 分开。
- 不再把 default subaccount fallback、label、数组索引或 `aliceId` 直接提升为 provider identity。
- 不再把 keyless 当作“坏账户”、readOnly 当作装饰选项，也不把聚合跳过当作删除；它们是明确的参与/权限结果。
- 不再把 local pending hash、staged record、synthetic observation 或 `OperationResult` 的 submitted-like fallback 当作 native idempotency、receipt 或最终状态。
- 不再把空/null/listing 缺失解释成 provider 明确报告的 absence。
- 不再把 reconcileBalance 当 fill/trade，也不把 instrument identity 与 numeric formatting 混为一体。

### 1.8 未读、未决和证据门槛

本组仍不能默默跳过以下分支：

- Mock/CCXT 之外 broker packs、live venue 的 identity、listing completeness、native idempotency、replace/bracket atomicity、终态和错误分类尚未由本次 recheck 证明。
- credential、principal、policy owner、secret lifetime、账户 identity 的 provider-specific contract 尚未确定；现有 options 不能填补它们。
- subaccount listing 不可用时，哪些 provider 允许 default、哪些必须 fail、其配置和持久化 owner 尚未统一。
- close 数量 reread 的 freshness/version contract、账户/position/order consistency window、recovery 时的旧资源责任尚未具备运行证据。
- Decimal precision、lot/multiplier、FX、sentinel/empty contract 的全量 provider 规则尚未读完，不能写成 global policy。
- `getPositions` 的 reconciliation 是纯 valuation、显式 journal effect，还是某种受控 read-after-reconcile，必须由业务选择并用真实 failure/consumer 证据裁决。

---

## 2. TradingJournal：TradingGit、EventLog、受控效果与观察记录的真实分界

### 2.1 来源入口和身份保留

本组有 45 个原始问题和 68 个 source-analysis 身份。代表性身份包括：
原始材料入口：`docs/uta-effect-runtime-design/solutions/TradingJournal/design.md`；当前源码 `services/uta/src/domain/trading/git/TradingGit.ts`、`services/uta/src/domain/trading/git/interfaces.ts`、`services/uta/src/domain/trading/git-persistence.ts`，以及独立 EventLog；完整身份追溯到 recheck 的 TradingJournal 原始问题与 source-analysis ledger。

- R2：`MAP-2DD4753D43`（push/executePush）、`MAP-B9BBBF4697`（add/commit）、`MAP-951F07F5BA`（reject）、`MAP-C3E41E2B51`（beginWrite/assertPrepared）、`MAP-973EB4700E`（parser）、`MAP-1A49DD8DEE`（projection tests）、`MAP-25866E7F22`（hash guard）、`MAP-2CCB3134A8`（execution/clear）、`MAP-6A0302D45C`（format）、`MAP-C2C9449357`（interface）。
- R3：`MAP-0CBE2FB0D9`（pending hash）、`MAP-2F871AAB45`（known IDs）、`MAP-31E8F89464`（sync）、`MAP-3D5359223F`（sync attribution）、`MAP-595E9F79F1`（observed）、`MAP-87101B3109`（pending IDs）、`MAP-9540E06E03`（reconcile）、`MAP-CA6C7E648F`（conflict）、`MAP-D4E27E6A2A`（sync tests）、`MAP-E5FDCD5D01`（observation interface）、`MAP-FE5C1D68F9`（failed cancel）。
- R4：`MAP-0043603515`（imports/sentinels）、`MAP-3A7B50FFCA`（derivative simulation）、`MAP-49CD3DC4C6`（rehydrate）、`MAP-9D6D33CC94`（order）、`MAP-9EF5070764`（parser）、`MAP-A899CFD901`/`MAP-DB23AFEBB2`（simulation）、`MAP-FA38762FE7`（sentinel）。
- R5：`MAP-02A55B62AE`（barrel）、`MAP-0D11241FE8`（legacy paths）、`MAP-110B9E5ED3`（shim）、`MAP-1E81D2713F`（callback）、`MAP-24879D4410`（rehydrate operation）、`MAP-26E3CBF3C8`（persistence boundary）、`MAP-3CAB2FACBC`（show）、`MAP-470C74976B`（serialization/round）、`MAP-515C919214`（hash）、`MAP-5478B3A377`（commit）、`MAP-6897B55067`（export/restore）、`MAP-78D27998B6`（audit queries）、`MAP-9E51B81D73`（load）、`MAP-BD4401DF5F`（log）、`MAP-D1C7BFF02C`（persister）、`MAP-D89349A0F1`（status）、`MAP-E516D05AD7`（summary）、`MAP-E712DEE4C8`（synthetic reconcile）、`MAP-F70A1BBFEE`（config）、`MAP-F746052C23`（prepare）。

交叉身份 `NOTE-4-1`、`NOTE-4-2`、`NOTE-7-1`、`NOTE-7-2`、`NOTE-8-2`、`NOTE-8-3`、`NOTE-12-2` 是历史 writer、memory staging、storage schema、durable DispatchStarted、polling 和错误吞咽的纠偏入口。它们用来保留问题来源，不能恢复旧 JSON/SQLite/event-flow 作为现行 authority。

### 2.2 已观察到的真实 surface

当前有两个不能混淆的记录面：

1. `TradingGit` 在内存中维护 staging、pending、inflight、commits、head、round 和 config。`add/commit` 形成本地 proposal；commit hash 由 SHA-256 后截取短值；`push` 先执行外部 operation，再读取 git state、追加内存 commit、执行 `onCommit`，最后清理。`reject` 记录用户拒绝；`recordReconcile` 和 `recordObservedOrders` 追加 synthetic record 并调用 callback。
2. `EventLog` 是独立的 disk-first JSONL append-only authority，当前主要承载 `account.health` 等 health 事件，有自己的 sequence/recovery/listener；它没有与 TradingGit order transaction 共享 identity 或提交边界。

持久化边界也不是一个已经证明的 durable journal：

- git persistence 主路径为 `data/trading/<accountId>/commit.json`，同时还存在历史 Bybit/Alpaca 路径；load 对 JSON parse/IO 等错误采取 fallback/undefined，不能区分 malformed、absent、old version 和 quarantine。
- persist 没有已证明的 schema/version、atomic write、lock 或 lease；restore 会恢复 Decimal，但对形状和缺失 multiplier 的处理仍带 fallback/trust。
- 没有 durable pre-dispatch intent。内存 `_pollState` 也会在进程重启时重置。
- `parseOperationResult` 从 unknown record 提取状态，未知 status 可能默认为 submitted；这不能当作 provider 的统一结果契约。

### 2.3 候选承接：JournalStore 只做受控效果 authority，projection/observation 各自可追溯

候选 TradingJournal 需要把“记录了什么”和“谁可以改变交易事实”分开表达：

1. **受控效果 authority**：由 JournalStore/Writer 保存受控 operation 的最小、可恢复记录，包括业务 operation identity、scope、operand digest/版本、approval/dispatch 状态、provider attempt 和不确定结果。具体 record variant 应至少能区分 draft/prepare、approval/queue、DispatchStarted、acknowledged/rejected、Unknown/recovery；不能把所有过程压成 `submitted: true`。
2. **operation identity 独立于 transport correlation**：TradingGit 的短 pending hash 可作为本地预提交冲突检查或引用，但不能自动取得 provider 幂等语义。`x-request-id` 只用于一次 transport 关联和日志串联，不是业务幂等键。若 provider 具备 native client id 或 idempotency key，必须在 provider-specific effect declaration 中出现；未知时要显式记录。
3. **写入顺序有责任边界**：当前 `push` 的外部先行顺序是事实和 failure evidence，不是目标保证。候选受控效果应先持久化足以恢复的 accepted/DispatchStarted 信息，再在允许的 provider effect 上执行；若 provider 已接受而本地等待被取消，journal 保留 accepted/unknown responsibility。callback 只能是 projection/notification，不是 journal 写入成功的唯一证明；callback 失败不能抹掉已 durable 的 authority。
4. **ObservationJob 独立于受控写入**：submitted order observation 读取 provider listing 或已知订单，不应伪造新的 dispatch；listing complete/partial/unavailable、single order found/not-found/unknown、observedAt、cursor scope 都写入观察结果。`PollCursor` 只有在具体 provider/job 承诺跨重启连续性时才要求 durable；不能因为有一个内存 `_pollState` 就给所有 provider 加全局 cursor 契约。
5. **Reconciliation 是 valuation 记录**：position/wallet drift observation 可以被显式 reconcile command 消费，记录 valuation-only/cost-basis adjustment；它不是 fill、trade 或 order completion。普通 `getPositions` 若只负责数据读取就不能暗中追加 journal；若产品需要 read-after-reconcile，必须让消费者看到明确的 command/effect 结果，不能依赖查询副作用。
6. **EventLog 保持独立**：health/runtime 事件继续由 EventLog 管理；它可以用 operation/account/process reference 做关联索引，但不能因为共用 JSONL 就变成 TradingJournal authority，也不能把健康 sequence 当 order transaction sequence。
7. **Legacy importer 是一次性边界**：历史 JSON/legacy path 如需迁移，先保留 source digest、路径、scope、schema guess 和 import result；mixed/unknown/malformed 应进入 `OperatorRequired`/quarantine，而不是 fallback 为新 journal 的空状态。superseded archive 只提供证据入口，不是运行时默认来源。
8. **Simulation 不写受控 journal**：`TradingGit.simulate` 的 derivative exclusion、multiplier、Decimal/price parsing 必须在纯 snapshot/显式 simulation 输入上计算；模拟 fill 不得借用真实 dispatch record。

### 2.4 真实时序实例 A：受控订单从 draft 到 Unknown/recovery

1. CoreAccount 根据真实 contract、subaccount、readOnly/keyless guard 生成 draft；TradingJournal 保存其 scope、operand 和本地引用。此处不是 provider 已接受。
2. 审批/策略边界生成 prepared plan；审批 actor、policy 和版本必须出现在具体业务实例，而不能假设所有 provider 共享一个 approval schema。
3. Writer 原子地保存足以恢复的 DispatchStarted 和 operation identity，然后调用 provider effect。当前源码还没有这个 durable pre-dispatch fence；这是要由目标实现和 provider evidence 证明的候选。
4. provider 返回 native receipt/accepted/rejected/unknown。transport disconnect、malformed response 或 correlation mismatch 不能默认为 rejected 或 submitted；记录 Unknown 并保留 recovery owner。
5. 调用方在等待阶段 timeout/cancel，只取消本地 wait；不撤销远端已接受的业务。若 provider 的具体 cancel/stop capability 被声明并授权，才可以产生另一个显式 operation。
6. 后续 ObservationJob 按 provider 能力观察 submitted order。观察到 native receipt 或最终 status 后，Writer 完成 ack/observe projection；观察不到时仍保留 Unknown，而不是按“空列表”清掉责任。

这条时序同时暴露当前实现的真实断点：`TradingGit.push` 外部操作先行、内存追加/回调/clear 后行，回调失败与 persistence ack 不等价，进程中断时没有 durable fence。历史 callback probe 中还曾观察到 duplicate dispatch；它证明需要检查 writer/consumer 次序，不证明 broker 自身重复执行。

### 2.5 真实时序实例 B：submitted order observation

1. Poller 选取本地已提交或 provider 宣称可观察的订单集合。当前 poller 的 fairness/backoff 是内存状态；重启会丢失 `_pollState`。
2. provider 有 `getOpenOrders` 时，listing 可有 complete/partial/unavailable 结果；对 listing 中的订单做 observation。没有 listing 时，对已知订单逐笔读取并按 age/backoff 安排。
3. listing 未包含某个已知订单时，调用 `getOrder`；空/null 只意味着本次查询没有得到确定结果，不能直接写 terminal absence。CCXT missing listing 变为 `[]` 的路径必须保留“coverage unavailable”来源。
4. observation writer 记录 source、observedAt、coverage 和 scope；它不重放 original dispatch，也不把 observation 变成新的 order intent。
5. 只有具体 job/provider 承诺跨重启 cursor 时，才把 cursor 与 durable observation checkpoint 绑定；否则可从 journal 的 submitted set 重新构造下一次观察，不制造假的全局连续性保证。

### 2.6 真实时序实例 C：wallet drift 的显式处理

1. CoreAccount 读 broker positions，同时得到本地 in-flight set 和 TradingGit commit projection。
2. Journal-side pure classifier 计算 no-drift、drift、insufficient evidence 或 provider data unavailable；分类结果不自动改变 authority。
3. 如果 policy 允许 valuation reconcile，显式命令把 observation 交给 writer，生成 valuation-only record，并让 projection 更新 avgCost/unrealizedPnL。结果向调用方返回“observed/reconciled/deferred/unknown”中的精确 variant，而不是借用 order status。
4. 如果只是行情/展示读取，返回当次 valuation，不写 TradingJournal。任何为读取而发生的持久化必须在产品契约中显式命名并可恢复。

### 2.7 保留、纠正和原因

**保留**：TradingGit staging/commit/push/reject、pending hash conflict、order/sync/observation/reconcile projections、Decimal/simulation、EventLog 的 health append-only 语义和已有 persistence 文件入口。这些都是事实材料，便于迁移时不丢 source identity。

**纠正**：

- `TradingGit` 不是已经满足 durable transaction 的 journal；内存追加、callback、clear 和外部 effect 的时序必须暴露。
- EventLog 不等于 TradingJournal；health sequence 不等于 order commit sequence。
- pending hash、git head 或 local accepted 不等于 provider native id、idempotency 或 receipt。
- observation 不等于 transaction；submitted observation 不等于 waiting order，也不等于 finality。
- query-time reconcile 不应继续以隐式写入作为无名契约；必须改成显式 valuation effect 或纯读取。
- persistence fallback 不等于“数据不存在”；malformed、absent、legacy、unknown version 各自需要证据和 operator path。
- 没有证据就不指定 SQLite、Effect、SQL 版本、ABI、lease 或 provider-wide exactly-once；`NOTE-7-1` 正是这些选择仍 blocked 的入口。

### 2.8 未读、未决和证据门槛

- 现有 shipped data 的版本清单、真实历史 commit 文件、legacy mixed-account 情况、malformed/partial recovery 行为尚未完成 inventory；不能写迁移已覆盖全部文件。
- storage authority、schema/version、atomic write、locking/lease、snapshot 与 journal 的关系尚未裁决；`NOTE-7-1`/`NOTE-7-2` 是 blocked-on-evidence，不是默认 SQLite 方案。
- provider native idempotency、replace/bracket/all-or-compensate、partial fill、cancel unknown 和终态映射没有跨所有 packs 的证明。
- approval actor/policy owner、DispatchStarted 的安全边界、recovery owner、caller cancellation 与 remote stop 的关系还需要按实际业务实例确定。
- polling fairness/budget、provider cursor 和跨重启连续性不能被一条全局规则覆盖；只有具体 provider/job 的 promise 才能使 cursor 变成必需字段。
- callback failure、projection rebuild、EventLog/journal cross-reference、shutdown error 的报告形态仍未落地；当前 `catch`/fallback 不能当作完成证明。

---

## 3. AliceClients：从 optimistic SDK 到声明绑定的受控边界

### 3.1 来源入口和身份保留

本组原始问题有 8 个，但 source-analysis 有 94 个，不能以“问题量少”缩减承接。代表性身份包括：
原始材料入口：`docs/uta-effect-runtime-design/solutions/AliceClients/design.md`；当前源码 `packages/uta-protocol/src/client/UTAClient.ts`、`src/services/uta-client/UTAAccountSDK.ts`、`src/services/uta-client/UTAManagerSDK.ts`、`src/webui/routes/trading-proxy.ts`；完整身份追溯到 recheck 的 AliceClients 原始问题与 source-analysis ledger。

- `MAP-139EBB287C`（transport/auth/correlation 文档）、`MAP-A4FE5AF865`（wire principal/auth 缺失）、`MAP-A458F81B6D`（route/list 决策）、`MAP-06118417F5`（cancellation）、`MAP-7E1806AFC4`（HttpError）、`MAP-22C9C06082`（client headers）、`MAP-8C22894ED4`（Effect/Promise）、`MAP-E56045946F`（safeJSON/redaction）。
- `MAP-42C229AF4E`、`MAP-A12828EECA`、`MAP-CED1F6DB38`、`MAP-D030B466D9`、`MAP-EDCEFC83C3`、`MAP-EEF88CE91D` 分别关联 manager context、Guardian dependency、availability、unavailable reason、capabilities 和 SDK dependency；这些是同一 transport/client 边界的代表入口。
- 相关 historical NOTE：`NOTE-2-1`（BFF loopback/no auth）、`NOTE-2-2`（polling/compensation）只能作为问题来源；credential/verifier gap 由本组的 `MAP-A4FE5AF865` 等 source identity 追溯，它们不证明目标 auth 已存在。

### 3.2 已观察到的真实 surface

- `packages/uta-protocol/src/client/UTAClient.ts` 提供 generic method/path/body/query、base URL、fetch、timeout；非 2xx 被压成 `UTAHttpError(status, body, message)`。成功响应经过 `safeJSON` 后直接 `as T`，只检查/设置 content type，没有 typed principal、credential、correlation echo 或 response decoder。
- `UTAClient` 创建内部 AbortController 和 timer，但实际 fetch 使用 `opts.signal ?? controller.signal`；传入 caller signal 时，内部 timeout controller 不再控制该 fetch。这使“timeout 已覆盖 caller wait”不能直接从源码成立。
- `trading-proxy.ts` 转发有限的 common headers 和 `x-request-id`，但不添加 `Authorization`；proxy 自己有约 30 秒 controller，且不会把 Alice caller signal 传给 UTA fetch。直接 UTA route 仍是 loopback/no-auth surface。
- `UTAAccountSDK` 对很多数据方法是真实 HTTP wrapper，但 `health`/`getHealthInfo` 是 optimistic/synthesized healthy，`wait` 立即返回，capabilities 为空；`getState/export`、stage/commit/push/reject/sync、contractFromAliceId、nudge、close 等存在 NI/no-op。`UTAManagerSDK` 的 lifecycle 也多为 no-op，`reconnect`/`remove` 实际触发 Guardian whole-process restart。
- Alice startup 等待 UTA health 750ms；不可用时继续 lite mode。工具层存在 `unknown`/record cast。这个 fallback 是当前可用性策略，不是“UTA 已经 ready 但客户端懒得等待”的证明。

### 3.3 候选承接：每个 capability descriptor 生成自己的 client

Main §7.5 的方向可保留，但需要写成具体的业务边界而不是万能 SDK：

1. **定义 `d` 是叶子 capability 的声明**：`d` 同时绑定路由/方法、输入 schema、输出 schema、失败 variant、scope、是否 data read 或 controlled effect，以及所需 principal/delegation。当前 route 全表尚未裁决，因此不能把 `d` 偷换成固定的全局 route inventory。
2. **client 只做 transport interpreter**：Alice 根据真实用户/Workspace auth 取得 delegated subject，去除 body supplied actor，编码输入，带 service credential 和 delegated subject 调用 UTA，接收后按 `d` 解码精确 `Outcome`。成功 JSON、错误 JSON、content type 不满足、correlation mismatch 和 transport failure 都在 boundary 分类；不能用泛型 cast 将 malformed 当成功。
3. **service auth 与业务授权分层**：候选 wire 采用标准 `Authorization: Bearer <service credential>` 作为 UTA 验证的 service credential，delegated subject 另以明确的受保护上下文承载；具体 header 名称和 verifier owner 仍需与实际 protocol 源码裁决。UTA 先验证 service、delegation scope 和请求关联，再验证 subject 是否有权使用 `d`、输入是否满足 definition；body 中的 actor 字段不能覆盖已认证 principal。
4. **关联不是幂等**：`x-request-id` 只用于一次 outbound/inbound transport correlation、日志和响应配对；它不是业务 operation identity，不是重复提交保护，也不替代 TradingJournal 的 durable fence。远端 acceptance 一旦发生，caller 取消不会撤销该业务；如需取消，必须走另一个声明的 stop/cancel capability。
5. **timeout/cancellation 进入真实等待**：caller 的 AbortSignal、proxy timeout、UTA client timeout 和 downstream wait 需要组合成一个实际生效的 cancellation boundary。timeout 只表示当前调用没有在期限内得到可判定结果；它不能证明 UTA 未处理。若已收到 accepted receipt，返回 accepted/unknown 并由 journal/observation 继续承担责任。
6. **凭据由受信启动配置注入**：service credential 分别由 trusted startup/config/secret store 提供给 Alice 和 UTA，不从 Agent、provider payload 或用户 body 继承；loopback 只减少网络暴露，不提供 auth。若 transport 变为 non-local，必须有 secure transport 和相应 verifier，不能继续靠 loopback 假设。
7. **no-op 不计为契约**：客户端只暴露已经由 descriptor 声明并有真实实现的能力；不能把 optimistic healthy、立即 wait、空 capabilities、no-op lifecycle 或 NI 方法列入“兼容 SDK”。无能力应为结构化 unavailable/unsupported，或根本不生成该 descriptor。
8. **推送/长等待另行声明**：若业务需要 push/stream，使用该 capability 自己的 typed stream/AsyncIterable 和生命周期，不把所有 request/Promise 强行提升成 universal effect runtime。

### 3.4 真实时序实例：Alice 到 UTA 的一次受保护调用

1. Alice web 入口先完成用户/Workspace authentication，形成已验证的 Alice subject。body 中若带 `actor`、`userId` 或类似字段，应用层不得用它覆盖 authenticated subject。
2. Alice 根据请求选择可用的 descriptor `d`，解析输入，生成一次 transport correlation id，并让 client 按 `d` 编码。当前代码中 route 清单、输入 decoder 和 actor stripping 还未完成，这一步是目标而非现状。
3. client 向 UTA 发送 service credential、delegated subject 和 `x-request-id`。当前 proxy 只转发选定 header、没有 Authorization；因此必须把这一差距保留为实现门槛。
4. UTA transport boundary 先验证 service auth、delegation scope、correlation 关联，再按 `d` 检查 subject、definition 和 input。拒绝应在业务 effect 前返回精确 auth/access/input failure。
5. UTA producer 执行 data read 或把受控 effect 交给 Journal/dispatch boundary；返回体按 `d` 解码。malformed body、错误 content type、非预期 correlation、非 2xx 和 transport disconnect 分别留在 boundary failure，不能被 `as T` 抹平。
6. Alice consumer 根据 `Outcome` 决定展示、重试提示、Unknown/recovery 或继续观察；不得把 `UTAHttpError` 的 status/name 当作完整业务结果。
7. 如果 caller 在第 5 步等待期间 timeout/cancel，client 只结束本地 wait。若 UTA 已持久化 DispatchStarted 或 provider 已接受，Journal 继续持有责任；调用方不能因为 timeout 就重新提交同一业务 operation，也不能把 timeout 解释成远端未执行。

### 3.5 与现有 SDK/route 的具体消费关系

- Alice 启动只应消费明确的 process/runtime health readiness；不能消费 UTA 当前 optimistic `health='healthy'` 作为交易 ready。
- 数据工具（account、positions、orders、quote、clock、details、search）按各自 descriptor 解码；它们的 account/subaccount scope 来自 validated request，不由 label/URL prefix 猜测。
- 受控工具（stage/commit/push/reject/sync）必须消费 Journal/CoreAccount 的分层结果；不应调用 SDK 的 no-op/NI 方法，也不应让 `pending hash` 变成 HTTP 幂等键。
- manager `reconnect/remove/closeAll` 是 process/account ownership 问题，不能通过一个 Alice generic client 假装成 HTTP data method。当前 `UTAManagerSDK.reconnect` 触发 Guardian restart，必须和 CoreAccount 的 account-scoped stop-old/start-new 明确分开。

### 3.6 保留、纠正和原因

**保留**：generic transport 的方法/path/body/query 形状、独立 Alice/UTA 进程边界、健康探测入口、现有数据能力的真实 HTTP wrappers、lite fallback 和 selected-header forwarding；这些都是迁移时可复用的事实。

**纠正**：

- 不再把 `request<T>` 成功 cast 当作协议解析。
- 不再把 loopback、空 Authorization、optimistic healthy 或 immediate wait 当作 trust/readiness。
- 不再把 service credential、delegated subject、body actor、x-request-id 和 business operation identity 混成一个字段。
- 不再把 30 秒 proxy timeout 或 UTA client timeout 当作远端取消；要让 timeout/cancel 真正进入 fetch/等待链并保留 accepted/unknown。
- 不再把 no-op/NI SDK methods 当作兼容性契约；没有实现的能力必须显式 unavailable/unsupported。
- 不再把 §7.5 的目标序列当作当前实现；它是候选承接，最终必须由 descriptor、verifier、response echo 和运行证据收口。

### 3.7 未读、未决和证据门槛

- `d` 的最终 route/capability inventory、descriptor versioning、输入/输出/error schema 尚未完成；`MAP-A458` 代表的 route list 决策不能被猜测。
- service credential 的生成、注入、verifier、delegation scope、Alice/UTA 责任边界尚未由当前源码实现；`Authorization` 的目标选择不等于已部署 auth。
- correlation response echo、跨 proxy 的 AbortSignal/timeout 组合、accepted 后的 Unknown/recovery 回传方式尚未验证。
- exact failure tags、redaction、content-type/schema mismatch、non-local secure transport 和 push stream semantics 尚未裁决。
- `UTAAccountSDK` 的各个 NI/no-op 方法哪些被替换为真实 descriptor、哪些结构性移除，需要按消费者逐一迁移；不能以空返回保持旧假契约。

---

## 4. Supervisor：只承接进程边界和可观察重启，不承接账户/订单 authority

### 4.1 来源入口和身份保留

Supervisor 没有原始问卷条目，但有 21 个 source-analysis 身份。代表性身份包括：`MAP-17FC029A85`、`MAP-236805847B`、`MAP-42056E5B7F`、`MAP-43A7CB72EF`、`MAP-4510706FF1`、`MAP-505C4A4F7D`、`MAP-52D552B9B4`、`MAP-6F1E8D6910`、`MAP-9767014E35`、`MAP-9D3F24C206`、`MAP-A565129D19`、`MAP-A630EBD86C`、`MAP-A6456BE807`、`MAP-A9866AE52B`、`MAP-ABEDDF53B2`、`MAP-AF5DDC0F35`、`MAP-B3BED45272`、`MAP-B9DC6715CE`、`MAP-CEB68E968D`、`MAP-DF9D77E0FF`、`MAP-E993F5FB47`。它们覆盖 health wire、URL、baseline、trigger options/result、disabled、polling 和 restart docs。
原始材料入口：`docs/uta-effect-runtime-design/solutions/Supervisor/design.md`；当前源码 `src/services/uta-supervisor/health.ts`、`src/services/uta-supervisor/restart-trigger.ts`、`src/services/uta-supervisor/url.ts`，以及 Guardian child/watch boundary；完整身份追溯到 recheck 的 Supervisor source-analysis ledger。

这些身份与 `NOTE-13-1`（过窄 health）、`NOTE-16-1`（observability）一起保留。Supervisor 的 source ledger 本身就是入口，不应因为原始问题计数为零而把它并入 RuntimeComposition 的账户问题。

### 4.2 已观察到的真实 surface

- UTA health 当前只返回 `{ok, startedAt, utas}`；`health.ts` 的 decoder 通过对 unknown 做宽松 Partial/cast，只检查 `ok`、string `startedAt` 和 number `utas`。没有 runtime phase、boot generation、snapshot freshness、journal readiness 或 process stopping/failure reason。
- `waitForUTAReady` 把 health carrier 当 optional；Alice 启动约等 750ms，拿不到结果就继续 lite mode。
- `restart-trigger.ts` 使用旧 flag protocol：先 fetch health 取 baseline，原子写 flag，轮询 health 直到 `startedAt` 改变；result 以 boolean/optional string/error 表达，没有 request identity 或 Guardian request status。
- Guardian watcher 的重启主要是 child process 的 SIGTERM/SIGKILL + health polling；控制 server 目前偏向 status/stop，不能证明有 request-correlated restart completion、generation 或 owner。
- Supervisor 没有 broker authority、subaccount selector、order receipt 或 TradingJournal commit；把这些交给它会重叠 CoreAccount/Journal 的 ownership。

### 4.3 候选承接：RuntimeHealth 和 Guardian protocol 的最小进程合同

1. **RuntimeHealth 只描述 process**：候选 response 需要区分 `Initializing`、`Recovering`、`Ready`、`Stopping`、`Failed` 等 phase，并携带可验证的 boot identity/generation、snapshot/runtime observedAt 和 account count/summary。具体 wire 字段仍待实现，但单一 `ok` 必须不再同时代表进程存活、journal 可写和所有账户可交易。
2. **Ready 有门槛**：Ready 应表示组合根已完成其声明的 startup barrier（配置解析、journal/projection、必要 transport/provider scope、对外服务）；某账户失败可以作为 scoped account failure，不自动推翻 process。Alice 只消费 process readiness 和明确的 account capability，不把 `utas: n` 当交易 ready。
3. **Restart 是 whole-process operation**：Supervisor/Guardian 负责 UTA child 的启动、停止、重启和 status；它不能做一个 account reconnect，也不负责 native order result。account 级 stop-old/start-new 由长寿命 UTA manager 负责。
4. **请求关联而非 wildcard**：restart request 需要 request identity、目标 runtime/owner、提交结果和可查询 status。完成条件至少要绑定 baseline 与新 boot generation，且 local Ready 真的出现；仅仅 `startedAt` 改变或 health JSON 能解析不够。并发 request 的 coalescing/拒绝/排队要有结构化 result，不能靠 boolean。
5. **失败可观察**：旧 child 崩溃、health 永不回 Ready、SIGTERM 后需 SIGKILL、disabled 或 URL 不可解析，都应返回精确 status/failure，并保留 request context；不能把超时简化为“重启失败但也许好了”。
6. **边界安全**：control endpoint 要有明确的 local/non-local auth、principal 和 allowed operation；loopback 或 shared URL 不是 auth。若只允许本机，仍要防止任意本机进程获得超出声明的 restart/stop 权限，具体机制需证据。

### 4.4 真实时序实例：一次与 request 关联的全进程重启

1. Supervisor 读取并解析 refined UTA endpoint/config，观察 baseline runtime（包括明确的 unavailable/failed 状态，而不是 wildcard）。
2. Supervisor 向 Guardian control 提交 restart request，得到 request identity 和 accepted/rejected；如果 Guardian 正在处理同一 runtime 的 request，按已定义的 coalescing/status 返回，不覆盖旧 request。
3. Guardian 停止旧 UTA child；期间 health 为 Stopping/Unavailable。旧进程的 account state、journal responsibility 和 Unknown operation 不因 child stop 被当作已完成。
4. Guardian 启动新 child；组合根走其 startup barrier。新 child 只有在达到本次运行声明的 Ready 条件后，才向 Supervisor 暴露 completion。
5. Supervisor 查询/订阅 request status，核对新 boot generation/boot identity 与 baseline 变化，并核对本次 request 的 Ready 结果。新 process 可 Ready 而某个账户仍 scoped failed；这两个事实必须分开。
6. Alice/client 收到结构化 completion 后再恢复对应调用或进入 unavailable/recovery。调用方此前的 timeout 不能重发未知的交易 operation；它必须经 Journal observation/recovery。

### 4.5 保留、纠正和原因

**保留**：loopback health、Guardian child ownership、启动/停止信号、baseline 与 health polling 作为可迁移的观测机制，`resolveUTAUrl`/disabled 入口作为配置材料。

**纠正**：

- 不再用 health `{ok, startedAt, utas}` 代表完整 runtime readiness。
- 不再用 `startedAt` 改变、boolean trigger 或 wildcard baseline 代表本次 restart 已成功。
- 不再让 supervisor reconnect 某个账户、确认订单 receipt、执行 broker effect 或关闭 journal。
- 不再把 old flag protocol 当最终 restart API；它需要由 end-to-end request/status 协议替换后才能删除。
- 不再把 control status/stop 的存在推导成 restart protocol 已存在。

### 4.6 未读、未决和证据门槛

- `runtime.restart-uta` 的准确 method/path、request/status schema、auth、coalescing、generation 和 owner 尚未实现/裁决。
- Guardian 在 signal failure、rapid crash loop、disabled、启动 fatal 和 health partial 状态下的 status semantics 尚未由运行证据收口。
- RuntimeHealth 的 wire version、snapshot freshness、journal/projection readiness、account scoped error 的完整 schema 尚未确定。
- 本机 control endpoint 的权限边界、Windows/非 loopback 场景、非本地 secure transport 尚未调查。

---

## 5. RuntimeComposition：把组合根、账户资源、journal、调度和配置重载各归其位

### 5.1 来源入口和身份保留

本组有 32 个原始问题和 105 个 source-analysis 身份。代表性身份覆盖所有 R1–R7：
原始材料入口：`docs/uta-effect-runtime-design/solutions/RuntimeComposition/design.md`；当前源码 `services/uta/src/main.ts`、`services/uta/src/types.ts`、`services/uta/src/domain/trading/uta-manager.ts`、Alice main/配置入口和 Guardian startup resilience；完整身份追溯到 recheck 的 RuntimeComposition 原始问题与 source-analysis ledger。

- R1：`MAP-018E718257`（keyless construction）、`MAP-02559D426B`（health/offline stage）、`MAP-071F6FB24A`（imports）、`MAP-1F940280FC`（health）、`MAP-21CC430684`（recovery）、`MAP-246FD3AA47`（add/remove）、`MAP-29525F619A`（keyless fallback）、`MAP-29B9B4702C`（timeouts）、`MAP-2F3E94599C`（registration tests）、`MAP-32D2FDFBF9`（cleanup）、`MAP-4030819860`（bootstrap）、`MAP-6474FE1FB1`（manager fields）、`MAP-687A495AFD`（failfast）、`MAP-7AFA062D0F`（readiness polling）、`MAP-857191C07B`（config）、`MAP-8B4B00BB08`（close server）、`MAP-997D4009EE`（closeAll）、`MAP-A1F54D2BA5`（close cleanup）、`MAP-A227BE1784`（offline）、`MAP-C764A73F05`（reconnect）、`MAP-C8D7A0F889`（initialization isolation）、`MAP-CDD00B4C1B`（purge/keyless）、`MAP-D142657C9D`（register）、`MAP-D71042F42A`（healthy）。
- R2–R6：`MAP-41FE208558`、`MAP-C466C2AC10`（broker exports/factory）、`MAP-167CD10E5C`、`MAP-9717307646`、`MAP-DFDC1D0116`（search/poller）、`MAP-38975A9375`、`MAP-C762FC3F5D`、`MAP-C9D53377C0`、`MAP-DC4CB2CF21`、`MAP-DCAD63E801`（keyless/catalog/asset）、`MAP-09E0F7957B`、`MAP-38D1A9619B`、`MAP-4F1B3065A3`、`MAP-58B5F119B7`、`MAP-64E32766E4`、`MAP-C2848F848F`、`MAP-E09A9CD997`（setters/snapshots/hooks/scheduler）。
- R7：`MAP-0A182AEB30`、`MAP-0FC5D42419`、`MAP-14BB289E6A`、`MAP-1C9449F63F`、`MAP-2810B2FE69`、`MAP-2C295F499B`、`MAP-3A811B60A0`、`MAP-3E7F87BDF4`、`MAP-4682CE1389`、`MAP-529FB3A498`、`MAP-609A59F711`、`MAP-62BFB82A86`、`MAP-756E9DC555`、`MAP-77923C5EA9`、`MAP-780C76C803`、`MAP-7DD89036D6`、`MAP-80C471F58F`、`MAP-81F5FC7879`、`MAP-A52D6896E9`、`MAP-B0317A6228`、`MAP-B82F61A75F`、`MAP-F0D5CAEC8A`、`MAP-FADF0D8D68`，覆盖 guards/context、route、simulator、reload、shutdown、config、types、catalog 和 observability。

主要交叉纠偏是 `NOTE-12-1`（启动缺少 journal classification）、`NOTE-12-2`（吞咽 persistence/shutdown error）、`NOTE-13-1`（health 太窄）、`NOTE-2-1`（BFF bridge）、`NOTE-2-2`（dispatch/poller）、`NOTE-19-1`（历史 embedded SQLite authority）。这些身份帮助 Main 追溯来源；本稿不把旧配置/旧事件流重新写成组合根。

### 5.2 已观察到的真实 composition 和 ownership 缺口

UTA service `main.ts` 当前大致承担：load config、创建 EventLog/ToolCenter/UTAManager、purge ephemeral、构造 keyless data、逐账户 initialize（catch account failures）、注册 CCXT tools、设置 FX 和 mutable setters、启动 snapshot scheduler/order poller/catalog interval、注册 health/Hono routes、绑定 loopback、SIGINT/SIGTERM 关闭。启动 health 当前只拼 `{ok:true, startedAt, utas}`；shutdown 用 `closeAll`/EventLog，并 catch 错误后退出。

Alice main 在启动时解析 trading policy、决定 disabled、创建 `UTAClient`/`UTAManagerSDK`，等待 UTA 750ms；不可用则继续 lite mode。Guardian 负责启动 UTA child。由此形成了多个实际边界，但没有一个已证明的统一 startup/shutdown contract。

配置/重载有两个并行现实：

- Alice 配置路径 seal `accounts.json`，通知旧 reload，再由 SDK remove/reconnect；
- generic config 写入后独立 restart；
- `UTAManager.reconnectUTA` 在 UTA 进程内读配置、remove old、创建/register new、await connect；
- `UnifiedTradingAccount.close` 清 listener/recovery timer 后关 broker，但 initial connect/recovery 可能与 close 交错，health callback 没有 owner identity；
- `UTAManagerSDK.reconnect` 的实际动作却是 Guardian whole-process restart，而非 account reconnect；
- 没有一个相关 request/generation/ack 证明配置版本已经被所有消费者接受。

此外，EventLog、TradingGit persistence、snapshot/projection、broker registry、FX、poller、catalog、HTTP server 和 SDK 都有自己的 lifecycle/错误处理；不能用一个 `startedAt` 或 broad manager wrapper 把它们声明为一致。

### 5.3 候选承接：组合根只编排，不重写各组业务

候选 RuntimeComposition 采用分层责任，但每层只拥有真实需要的关系：

1. **Config boundary**：读取 raw config 后解析为带 schema/version、mode、endpoint、account scope、credential reference 和 reconfiguration generation 的 immutable configuration snapshot。未知/缺失/secret reference failure 必须可区分；Alice、UTA、Guardian 不各自发明一套 mode/URL/config parser。
2. **Journal and projection layer**：先打开/恢复 JournalStore、EventLog 和可重建 projections，分类 malformed/absent/legacy/unknown；没有证据的历史文件不能自动 fallback 成空账。EventLog 与 TradingJournal 继续分开，cross-reference 通过明确 identity。
3. **Provider/account scopes**：根据 configuration snapshot 为每个 account 创建 CoreAccount resource；keyless 只能在 provider capability 允许的构造路径中创建，不能从 Alice/Agent payload 找 credential。单账户 reach/identity/subaccount failure 进入 scoped result；组合根仍能报告 process readiness/partiality。
4. **Data jobs and effect dispatcher**：snapshot、observation poller、catalog/market refresh、FX 和受控 dispatch 各自声明输入、输出、scheduler ownership 和 stop/drain 语义。poller 不自动持有交易 authority；catalog/FX 不伪装账户 health。
5. **Transport and public routes**：HTTP/proxy 只消费组合根公开的 descriptor/capability 和 RuntimeHealth，不直接控制 broker/private fields。auth/principal 在 Alice/transport boundary 验证，账户层只消费已解析的 scoped principal。
6. **Account replacement owner**：长寿命 `UTAManager` 对 account-scoped replacement 串行负责：撤销旧实例 active eligibility，quiesce/await/release；close 失败不能 reopen；新实例 acquisition 失败时没有 active instance；manager 保留新旧资源的 cleanup 责任，只在 handoff 保护完成后 publish。这个 stop-old-then-start-new 是候选选择，不是当前 close 的自然结果。
7. **Process replacement owner**：配置/代码/运行时需要 whole-process restart 时，由 Supervisor/Guardian 处理 request/status/generation；组合根不会自己写 restart flag，也不把 process restart 当 account reconnect。
8. **Shutdown owner**：组合根停止 ingress 和 scheduler，标记 Stopping，停止接收新 controlled effects，drain/mark Unknown，关闭账户资源，flush Journal/EventLog/projections，最后关闭 transport。`Promise.allSettled` 可以是底层策略，但最终要产生带资源 owner、失败和 Unknown responsibility 的 ShutdownReport，不把 catch 后退出当成功。

这套关系不要求全局状态机吞掉业务差异；它只规定谁能创建/关闭什么、何时发布什么。CoreAccount 仍解释 subaccount/health/reconcile，TradingJournal 仍解释 accepted/observation/Unknown，AliceClients 仍解释 transport/auth，Supervisor 仍解释 process restart，HttpRoutes 仍解释外部输入。

### 5.4 真实时序实例 A：启动 barrier 和 scoped account failure

1. Guardian 启动 UTA child；composition root 解析 config snapshot，建立 process identity 和 generation。
2. 打开 JournalStore/EventLog，加载并分类 persisted data；malformed/unknown version 进入明确 quarantine/operator result，不静默变空。
3. 构造 provider registry、FX/market dependencies、CoreAccount scopes；keyless account 只走 declaration-allowed path。每个 account 自己 reach、discover subaccounts 和建立 health。
4. 注册 observation/snapshot/catalog jobs，但只有在各自 dependency barrier 满足时运行；不可读账户不会被排除到不存在，仍以 scoped unavailable 表示。
5. composition root 发布 RuntimeHealth phase Ready/Partial/Failed；Alice 只等待 process contract。单账户 unhealthy 不能使 process health 伪装成健康账户，也不必让整个 process 被一个账户拖成不可用，除非 config policy 明确要求。
6. HTTP routes 根据该 generation 的 descriptors/capabilities 开放；未 ready 的 capability 返回结构化 unavailable，而不是 optimistic empty list。

### 5.5 真实时序实例 B：账户配置版本的替换

1. Alice 入口鉴权并解析新的 account/config input；配置写入形成新 immutable revision。写入成功不等于 UTA 已应用。
2. 若目标只是 UTA 内 account scope 变化，reconfiguration owner 提交带 revision/request identity 的 account replacement；manager 停止旧实例的 active eligibility，quiesce/await/release。
3. 旧实例 close 时，initial connect/recovery race 必须由 owner 收口；close failure 不 reopen 旧 active instance。新实例 acquisition/reach 失败时，manager 发布无 active instance + failure，保留 cleanup responsibility。
4. 新实例完成必要 connect/subaccount/health barrier 后，manager 在 protected handoff 中 publish。消费者按 revision/generation 看到单一 active resource。
5. 如果 config 变更影响 process-level mode/endpoint/provider registry，则不走 account reconnect；Supervisor 接受 whole-process restart request，Guardian 启动新 generation，Alice 等待新的 RuntimeHealth。
6. 状态回报必须区分 config persisted、replacement accepted、new account ready、process restarted；当前 notify/reconnect/restart 的混用不能继续作为一个成功布尔值。

### 5.6 真实时序实例 C：关闭和 Unknown responsibility

1. Supervisor/组合根先拒绝新 ingress，进入 Stopping；poller/snapshot/catalog 停止创建新的 work。
2. Journal/dispatch boundary 对正在等待的 controlled effect 做 drain 或持久化 Unknown/recovery responsibility。调用方中断不抹掉远端 acceptance。
3. manager 按账户 owner 关闭连接；连接 close、recovery timer、listener callback 的竞态被收束，账户不在 process 已停止后继续发布无 owner 的 health。
4. flush JournalStore、TradingGit projection、EventLog 和 snapshots，分别报告成功/失败；不能因为 EventLog catch 了异常就称 journal 已持久化。
5. 最后关闭 HTTP/proxy transport，Guardian 观察 child 退出并返回 ShutdownReport/RuntimeHealth Stopping/Failed。资源 owner 必须能追溯到具体失败，不能只给 boolean。

### 5.7 保留、纠正和原因

**保留**：当前 UTA/Alice/Guardian 的 process 分层、manager account map、keyless construction、EventLog、snapshot/poller/catalog、FX、loopback bind、startup catch 和 closeAll 等材料；它们是实际迁移入口。

**纠正**：

- 不再让多个入口各自解释 mode、URL、配置 revision 或 restart；配置 parser/owner 统一，消费层得到 immutable snapshot。
- 不再把 UTA manager 的 `initUTA` return、health `ok` 或 Alice 750ms wait 当 startup barrier。
- 不再把 account reconnect 与 whole-process restart 混名；当前 SDK reconnect 触发 Guardian restart 的事实必须在边界上显式。
- 不再让 `close` race、`Promise.allSettled`、catch-and-exit 或 old flag 暗中承担资源 ownership、durable Unknown 和 shutdown acknowledgement。
- 不再把 EventLog、TradingGit、snapshot、broker registry、FX 和 route state 合成一个无来源的 runtime state。
- 不再以一个 broad `UTAManager`/universal SDK 充当六组的共同 domain；组合根只编排已明确的组间关系。

### 5.8 未读、未决和证据门槛

- configuration schema/version、mode authority、secret reference、provider catalog ownership、reconfiguration generation、snapshot persistence authority 尚未完全裁决。
- shipped packaging/dist/vendor、broker ABI/pack compatibility、registry dynamic load、IBKR codec 和 live/paper/session mode 仍有 blocked branches；不能宣称启动 barrier 已覆盖所有 provider。
- RuntimeHealth readiness 的具体 criteria、partial account failure wire、ShutdownReport、Guardian crash fixture 和 observability fields 尚未实现/运行验证。
- journal/projection restore 分类、legacy path inventory、atomicity/lock/lease、shutdown persistence errors 尚未收口。
- account replacement 的 quiesce/await/release、旧 listener/recovery race、new acquisition failure 与 protected publish 需要真实端到端证据。
- Alice/UTA credentials、auth middleware、simulator/admin mode、non-local transport 仍是边界前提，不应由 composition root 临时注入字符串。

---

## 6. HttpRoutes：外部 HTTP interpreter、作用域与数据/受控效果的分离

### 6.1 来源入口和身份保留

本组原始问题只有 2 个，source-analysis 有 103 个；代表性入口包括：
原始材料入口：`docs/uta-effect-runtime-design/solutions/HttpRoutes/design.md`；当前源码 `services/uta/src/http/routes-trading.ts`、`services/uta/src/http/routes-simulator.ts`、`src/webui/routes/trading-proxy.ts`；完整身份追溯到 recheck 的 HttpRoutes 原始问题与 source-analysis ledger。

- R2：`MAP-0FC7B6DD68`（expected hash）、`MAP-165076A00B`（commit message）、`MAP-24F7AD27D6`（fill simulator）、`MAP-27AD48107A`（empty numerics）、`MAP-2FADFA4CDF`（push failure）、`MAP-32AD0C3DCD`（close wallet）、`MAP-4DE6045663`（invalid numbers）、`MAP-52CB0F382D`/`MAP-58D4065C2F`（place/stage）、`MAP-631DC01624`（simulator schema）、`MAP-6AED1E318D`（close validation）、`MAP-6AF6021791`（hash conflict）、`MAP-6BF94B5092`（reject）、`MAP-6E09B3ED77`（happy place）、`MAP-7B9EA96B62`（push）、`MAP-8239373D6C`（orders）、`MAP-891F1FEA91`（precision）、`MAP-9B42BF213C`（modify）、`MAP-9CF3FC0756`（place validation）、`MAP-A034B94A3A`（cancel validation）、`MAP-A33EC0E470`（missing）、`MAP-AC5E619E59`/`MAP-D236542360`/`MAP-D5B92C2A08`（cancel）、`MAP-EA13BA2333`/`MAP-F42728FD63`/`MAP-F454EFC3B2`/`MAP-FE1C608463`（stage/commit/history/hash）。
- R4：`MAP-0682C42EA8`（sentinel/filter）、`MAP-07DB18F4C8`（decimal）、`MAP-08E9053B72`（details expansion）、`MAP-0B6606BE1C`（search）、`MAP-0C2AAEE0A8`（identity）、`MAP-146D2109B6`（resolve）、`MAP-1E2638E1F3`（open order）、`MAP-248B2B5279`（simulator spec）、`MAP-2F790BE2E6`（details）、`MAP-3C6243143F`/`MAP-3CBE1C6172`/`MAP-3CDB550874`（historical/schema/search）、`MAP-4D35581185`/`MAP-4EFAFBF364`（snapshot/subaccount）、`MAP-560B7EEA32`（malformed quote id）、`MAP-5FBCD3EE4E`（quote）、`MAP-6A13EE36A7`（simulator/external schema）、`MAP-8456875518`（quote POST）、`MAP-861915C783`（expand）、`MAP-87FA16A102`（account）、`MAP-8D000718DA`（one-shot）、`MAP-CA93BD9449`/`MAP-CEE9B91D31`/`MAP-DF17C576FF`（group/source/quote resolution）、`MAP-D250B2BDC3`/`MAP-D3212B77F2`/`MAP-D58BA63EC0`（positions/clock/asset）、`MAP-E66037B98B`/`MAP-EBC1DF5535`（cross-UTA details）。
- R5/R7：`MAP-3194C27217`、`MAP-75C6D069F1`、`MAP-8F1E449867`、`MAP-A7201E902B`、`MAP-AC8C619E99`、`MAP-B9C114CCA4`、`MAP-D034C92CBD`、`MAP-F589132F03`、`MAP-FC80F364B6`（sync/snapshot/equity/wallet/history）；`MAP-0E76C75480`、`MAP-1BDBE358B1`、`MAP-1C7C835F5A`、`MAP-21CA670156`、`MAP-2444CEB754`、`MAP-25883E620A`、`MAP-2B0B0BF616`、`MAP-2F69B76FDC`、`MAP-38469CADA4`、`MAP-3A43AEAF75`、`MAP-3C4CDD1C56`、`MAP-3D3861C921`、`MAP-3FABE05A73`、`MAP-44AA5A48AB`、`MAP-468691D82C`、`MAP-4AFBEA2B00`、`MAP-6837C09018`、`MAP-6CE9D89D9B`、`MAP-6FA0B99F88`、`MAP-793589DE30`、`MAP-8588C24A12`、`MAP-8878826403`、`MAP-8A6F5C59E6`、`MAP-95C382B4F8`、`MAP-9DB36046FA`、`MAP-A88187B75A`、`MAP-AB73E0949C`、`MAP-D266753674`、`MAP-DB305A9D5D`、`MAP-E98645ED1A`（simulator、UTA GET、mock、external trade、FX、marks/tick/fill/reconnect）。

这两个原始问题不能代表 103 个 source-analysis 能力已被解决；完整来源仍由 HttpRoutes ledger 追溯。交叉 `NOTE-14-1`、`NOTE-15-1`、`NOTE-18-1` 是 route bridge、simulator/prod auth 和 implementation/live evidence 的纠偏入口。

### 6.2 已观察到的真实 surface

`services/uta/src/http/routes-trading.ts` 当前是一个直接调用 domain 的 Hono 路由集合：

- `/uta`、equity、search、FX、test-connection、reconnect、sync、simulate、subaccounts、account、positions、orders、clock、quote、expand、historical、details、wallet log、order/trade history、show/status、commit/reject/push、stage 和 one-shot place/close/cancel 等混在同一模块。
- 一部分 route 有 zod/schema validation，但不少 body 使用 `Object.assign`/raw object，`expectedPendingHash` 通过 string cast 取得；one-shot 用 phase tag 映射 status，错误仍部分依赖 generic catch/name/status。
- account query 对 offline 做 503+nudge；BrokerError 的 permanent/transient 映射是实际现状，但不是完整 typed route error taxonomy。snapshot/equity-curve 等路径会 catch 后返回空 points；`Number(v)||0` 和 minute rounding 可能把 malformed/absent/zero 混成同一输出。
- orders 默认 pending ids；这应被理解为本地 submitted-order observation 的 query choice，而不能表述为 provider complete open-order listing。`getOpenOrders` 不可用、listing empty、single `getOrder` null 各自需要保持 coverage/absence 证据。
- `routes-simulator.ts` 直接 resolve `MockBroker`，提供 mark/tick/fill/cancel/deposit/withdraw/trade 等 dev paths；解析和错误有 schema，但 simulator/prod auth/mode gate 没有由当前 route 证明。
- BFF proxy forwards selected headers and `x-request-id`、以自己的 controller fetch UTA；direct UTA route loopback/no-auth。当前没有 Authorization service credential injection、delegated principal verification 或 response correlation check。

### 6.3 候选承接：HTTP 只解释外部输入，不成为第二个 domain

1. **descriptor-derived route**：每条外部 route 绑定一个真实 capability descriptor `d`，由 route interpreter 解析 path/query/body/header/principal，调用该 descriptor 的 data/effect handler，再把精确 output/error 编码成 wire response。不得用全局 ActionContractMap 把所有 route 归一，也不得用 status/name/generic catch 重新推导业务。
2. **scope explicit**：URL 中的 account、subaccount、provider/source、instrument identity 和 request principal 都要经 schema/authorization 解析；缺 subaccount 时按该 provider/account 的真实能力返回 `SelectionRequired`/unavailable，而不是默认 `default` 并扩大写入范围。`/uta` list 是 discovery；`/uta/:id/...` 是已选 account scope；跨 UTA details/search 必须显式声明范围。
3. **data route vs controlled route**：account/positions/quotes/history/clock/details/order observation 是 data reads，返回 observation source/coverage/freshness；stage/commit/push/cancel/close/simulated fill 是受控 effects 或 dev capability，需 auth、readOnly/keyless guard、approval/operation identity 和 Journal result。HTTP route 不直接把 local pending hash 变成 provider idempotency。
4. **auth/delegation at boundary**：Alice-facing route 应消费已验证的 service credential + delegated subject；body actor 被忽略/拒绝。直接 UTA route 要么是受保护 internal capability，要么明确只在可信 transport 中可用；loopback 不得被解释为 auth。当前 surface 尚未实现此 verifier。
5. **typed input/output/error**：numeric string、Decimal、sentinel、quote/contract、historical dates、subaccount selector、expected hash、source/asset class 各自解析；malformed number、missing identity、unsupported capability、offline, permanent BrokerError, transient failure, hash conflict, auth denial、transport timeout、Unknown effect 不应全部落入 400/500 generic catch。HTTP status 只是外层映射，domain error identity 必须保留。
6. **observation semantics**：orders route 的默认 pending query 只能返回已提交/已知订单观察；listing unavailable/partial、empty、single null 不可变成 no orders/terminal absence。positions route 如果触发 reconciliation，必须显式返回或调用 reconciliation command；普通 GET 不应静默写 TradingJournal。
7. **simulator boundary**：Mock simulator 是显式 dev/admin capability，需要 verified principal、mode/config gate 和 source scope；生产 route 不因 URL 能 resolve `MockBroker` 就获得 simulator authority。simulated mark/fill/deposit/trade 的 result 不能与 live native receipt 共用不加区分的 status。
8. **snapshot/FX/partial data**：equity、FX、wallet/status 等 route 若只拿到部分 source，应返回 partial/unknown/observation metadata，而不是 catch 后制造空成功。`Number(v)||0`、zero totals、minute carry-forward 只有在具体 schema 允许时才可使用；malformed/absent 必须不同。
9. **transport correlation and timeout**：proxy/route 可以透传 `x-request-id` 做 correlation，但 business operation identity 由 Journal/controlled effect 产生；route timeout 不取消已接受远端 effect，response 需要能表达 accepted/unknown/recovery。incoming caller signal、proxy controller、UTAClient timeout 必须真正组合，不得各自看似存在却互相绕开。

### 6.4 真实时序实例 A：账户/订单 observation GET

1. Alice/auth boundary 验证 principal 和 delegated scope；route 解析 account id、可选 subaccount、query filters 和 source。
2. route 选择 account descriptor，检查该账户当前 capability/health；keyless 可读性、readOnly 和 private-data permission 不应靠 route label 猜。
3. CoreAccount 读取 broker account/positions/orders；若 orders 使用 pending ids 或 listing，结果带 scope、observedAt、coverage。listing unavailable、empty、single null 按各自 variant 返回。
4. route 编码 typed observation；如果账户 unhealthy，可返回 scoped unavailable/partial，而不是全局空数组。若 getPositions 需要 cost reconciliation，route 要么消费显式 reconcile result，要么只返回纯 valuation，不隐藏 write。

### 6.5 真实时序实例 B：受控 order route

1. route 解析 contract、side、quantity/price Decimal、TIF、subaccount、expected pending hash 和 operation intent；body actor 不作为 authority。非法 numeric/sentinel/identity 立即是 input failure。
2. CoreAccount 执行 readOnly/keyless/mutability/subaccount/contract guards，并 stage。TradingJournal 创建 draft/prepared identity；expected hash 只做本地冲突/并发保护。
3. approval/dispatch boundary 按声明的 capability 执行，持久化 DispatchStarted/operation identity；route 不因 HTTP 进入就直接认为 native order 已完成。
4. provider 返回 accepted/rejected/unknown；route 映射为 typed response。transport timeout/caller cancellation 后，仍保留 Journal responsibility；后续 observation route/job 负责恢复。
5. cancel/close/modify 作为各自 descriptor 和 operation，不因共享 URL 前缀就获得同一 semantics。phase、hash conflict、broker permanent/transient failure、unknown status 保留为可区分结果。

### 6.6 真实时序实例 C：simulator/admin route

1. 请求先通过 verified dev/admin principal 和 simulator mode gate；生产/普通 Alice principal 不能仅凭 route 参数切换。
2. route 解析 mock id、contract、numeric values 和 action-specific body；resolve failure、unsupported action、invalid state 是明确 errors。
3. MockBroker 执行 mark/tick/fill/cancel/deposit/withdraw/trade，返回 simulator-specific output，不能伪装 live native receipt。
4. route 记录必要 audit/observability reference，但不把 simulator state 写成 live TradingJournal 交易事实；若 simulator 需要 journal，必须使用其自己的 declared scope。

### 6.7 保留、纠正和原因

**保留**：现有 route families、zod schema、order phase helpers、expected pending hash conflict、BrokerError 的部分 status mapping、account/equity/quote/history/simulator consumers、proxy selected-header forwarding 和 MockBroker dev material。

**纠正**：

- 不再把 route 数量或两个原始问题当作全部能力证明；103 个 source IDs 仍须按 ledger 追溯。
- 不再让 generic `Object.assign`、string cast、`Number(v)||0` 或 empty-on-error 作为未声明的协议。
- 不再把 orders 默认 pending ids 说成完整 open-order listing，也不把 empty/null 说成 absence。
- 不再让 GET positions 的隐藏 reconcile、snapshot catch、FX skip 或 equity carry-forward 变成无名写入/成功。
- 不再把 HTTP status/name、`x-request-id`、expected hash 和 native idempotency 混成一层。
- 不再允许 simulator path 在未验证 principal/mode 的情况下成为 production capability。
- 不再让 direct UTA loopback/no-auth 或 proxy 无 Authorization 的现状被写成“内部已可信”。

### 6.8 未读、未决和证据门槛

- 最终 route/descriptor inventory、wire schema、auth/delegation/verifier、错误到 HTTP status 的完整映射尚未收口。
- 全量 adapter sentinel、Decimal/lot/multiplier、instrument identity、historical/quote/details contract 仍需 provider-specific source；`MAP-0682` 不能被一个示例替代。
- simulator 的 verified principal、mode/admin gate、audit scope、live/prod exclusion 尚未实现或运行验证。
- proxy/UTA timeout、caller cancellation、response correlation、accepted/Unknown route response 尚未由真实链路证明。
- snapshot/equity/FX partial semantics、wallet log/history consistency、query-time reconciliation 是否纯读尚未裁决。
- 直接 UTA routes 的 auth 与 non-local transport secure policy、internal endpoint owner 尚未确定。

---

## 7. 六组之间的最小整合关系

下面只列出必须在 Main 主书中保持一致的接缝，不把它们重新扩成第七个“万能核心”：

| 接缝 | 生产者 | 消费者 | 必须保持的区别 |
|---|---|---|---|
| 账户 scope / subaccount | CoreAccount | Journal effect、Alice client、HttpRoutes | local account id、provider identity、subaccount selector、principal 不是同一字符串 |
| 受控 order acceptance | CoreAccount guards + Journal Writer | provider effect、Alice/HTTP response | draft/accepted/DispatchStarted/native receipt/observed/final/Unknown 分层 |
| submitted observation | broker listing/single lookup + ObservationJob | CoreAccount state、TradingJournal projection、HTTP GET | listing coverage、empty/null、absence、waiting order 不混淆 |
| cost reconciliation | CoreAccount wallet/position observation | explicit valuation/reconcile command 或纯 read consumer | valuation-only 不等于 fill/trade；query 不隐藏 write |
| transport call | Alice descriptor client | UTA declaration/handler | service auth、delegated subject、input/output/error decode、correlation；`x-request-id` 不作幂等 |
| account replacement | UTAManager | RuntimeComposition | stop-old/quiesce/release/start-new/publish；不是 process restart |
| process restart | Supervisor/Guardian | RuntimeComposition/Alice startup | request/status/generation/Ready；不是 account reconnect/order authority |
| public HTTP | HttpRoutes/proxy | Alice/UTA handlers | route-specific scope/auth/schema/error；不是 broad SDK passthrough |
| health | account/runtime producers | manager/Alice/Supervisor | BrokerHealth、AccountHealth、RuntimeHealth 分层 |
| audit | TradingJournal/EventLog | projections/observability | order authority、health log、transport correlation 各有 identity |

主书整合时，若某个真实业务分支不能满足上述关系，应修改关系本身或该业务的候选，不得以旧对象换名、统计或 `targetModel` 索引把缺口隐藏掉。

## 8. 尚未读完或不能默默跳过的共同分支

以下项目在当前材料中仍是 blocked/unread/undecided，列出是为了让后续承接可继续追踪，不是把它们包装成 TODO 已完成：

- Mock/CCXT 之外 broker pack、live venue、IBKR codec、pack ABI/版本、live/paper/session 行为。
- provider native identity、native idempotency、replace/bracket/partial-fill/cancel unknown、absence/finality 和各 provider 的 order status mapping。
- 全量 instrument sentinel、Decimal/lot/multiplier、FX 和历史/quote/details schema。
- credential secret 的 provisioner、service verifier、delegation scope、principal/policy owner、生命周期和 non-local secure transport。
- descriptor `d` 的最终 route 清单、schema/version、typed errors、response correlation/echo、push stream 和 cancellation semantics。
- Journal storage technology、schema/version、atomicity、lock/lease、legacy import inventory、projection rebuild、EventLog cross-reference、shutdown error authority。
- RuntimeHealth/ShutdownReport 的 wire shape、readiness criteria、account partiality、Supervisor restart request/status/coalescing/generation。
- config mode/URL/schema authority、reconfiguration generation、account replacement race、snapshot/poller/catalog ownership、pack loading 和 crash-loop policy。
- simulator 的 verified admin/mode boundary，以及所有 HTTP data/effect route 的实际 downstream side effects。

在这些分支有实际 source/failure/evidence 之前，本稿只提供可检验承接文字，不声称“全量完成”、不声称“已实现”、也不把本地 recheck 当 runtime proof。
