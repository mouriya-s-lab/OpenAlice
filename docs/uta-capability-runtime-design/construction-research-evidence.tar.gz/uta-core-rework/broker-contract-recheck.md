# Broker contract recheck（Alpaca / CcxtCore / CcxtVenues / Ibkr / IbkrBridge / Longbridge）

状态：只读源码调查材料；不改设计、不写代码、不运行 build/lint/test/formatter/runtime，也不访问真实账户或试单。

## 0. 调查边界与事实层级

本稿先读取 `docs/uta-capability-runtime-design/current-research.md:56-127`。其中明确了当前设计仍未完成、抽象与业务实例必须分层、旧 event-flow/旧 EF/旧槽位/旧 `legacy-accommodation` 不能作为设计成立前提。`local://uta-core-rework/order-contract-grounding.md` 仅作 Order 业务实例的导航；以下每个行为结论重新回到当前源码。

来源层级如下：

1. 当前源码、当前 SDK 声明和当前仓库样例是行为事实。
2. `solutions/*/entries.md`、`analyses.json`、`questions-closure.json` 是原始调查身份、问题和来源导航；其中的 `targetModel`、`accepted`、历史设计标签不被本稿当成当前设计裁决。
3. 本稿把“输入值/函数操作数变化”和“旧公共关系根本表达不了的差异”分开。没有原生保证的地方只记录为未知/未证实，不把 mock、静态数组、Promise 存在或 SDK 方法名提升为保证。

已读取的原始分析上下文：

- Alpaca：`analyses.json:3517-3537` 的 cross-group contracts/additional findings；entries 中 place/modify/cancel/close、capability、order observation、pack 相关条目。
- CcxtCore：`analyses.json:3432-3449`；entries 中 place、status/decoder、query、capability、idempotency 相关条目。
- CcxtVenues：`analyses.json:2185-2207`；entries 中 market identity、Bitget/Bybit/Hyperliquid route、listing、cancel、idempotency 相关条目。
- Ibkr：`analyses.json:2415-2437`；entries 中 native Order/contract、place/modify/cancel/close、order listing、capability 相关条目。
- IbkrBridge：`analyses.json:2215-2239`；entries 中 callback、collector、account/position/tick、order identity 相关条目。
- Longbridge：`analyses.json:3822-3838`；entries 中 native order mapping、query、scope/environment、lifecycle 相关条目。

未作的工作也明确写出：没有把每个非 Order 的历史 mapping entry 逐行重新设计；未在真实 venue 执行任何 probe；没有把原始分析中的候选模型重新命名成当前设计。原始问题本身没有删改，末尾 ledger 列出六组 `questions-closure.json` 的全部 163 个问题 ID 及其历史 disposition，并把每个 ID 定位到本稿具体处置段。

## 1. 先给结论：哪些是操作数差异，哪些是公共关系缺陷

### 1.1 可以留在 provider leaf/codec 的输入值或函数操作数差异

这些差异改变的是同一类意图进入原生调用时所需的值、转换函数或调用参数，不能被抹平为一个“所有券商都一样”的字段：

- **Instrument / native identity**：Alpaca 使用大写 ticker（当前 adapter 只接受 STK）；CCXT 使用 market key/unified symbol，并可能需要 symbol 才能查订单；IBKR 以 conId/完整 Contract 路由；Longbridge 使用带 `.HK/.US/.SH/.SZ/.SG` 后缀的 symbol。
- **Order kind / TIF / trigger**：Alpaca 把 IBKR 风格字符串映射为 REST 字符串；CCXT 把 STP 转为基础 `market`/`limit` 加 `triggerPrice`，TRAIL 直接拒绝；IBKR 直接把 `Order` 交给 EClient；Longbridge 把 MKT 按市场映射为 MO/ELO，把 STP 映射为 MIT，把 TIF 限定为 SDK enum。
- **Sizing**：Alpaca 在 `qty` 与 `notional` 同时存在时优先 `qty`；CCXT 的 `cashQty` 要先取 ticker 计算 amount；IBKR 直接保留 Decimal `totalQuantity`；Longbridge 要求正的 `submittedQuantity`，没有 Alpaca/CCXT 的 notional 分支。
- **Provider extensions**：Alpaca 的 bracket/OTO payload、CCXT 的 `extraParams`/`reduceOnly`/venue override、IBKR 的 `percentOffset`/OCA/parent/transmit/native fields、Longbridge 的 `triggerPrice`/trailing fields 都是 provider-declared operands。它们不能变成全局 Order 变体枚举。
- **Query operands**：CCXT 的 `symbol` hint、Bybit category/conditional path、Bitget `productType`/`planType`、IBKR reqId/orderId/clientId、Longbridge orderId 都是不同的 lookup/namespace 操作数。

### 1.2 现有公共关系确实表达不了的差异

当前 `IBroker`/legacy protocol 的关系不能安全表达以下事实：

1. **成功等待的边界不同**：Alpaca/CCXT/Longbridge 的 create/replace 通常拿到 SDK response 或 `void` Promise；IBKR `placeOrder`/`cancelOrder` 的 SDK mutator 是 `void`，adapter 另等同 orderId 的 callback，而且 `openOrder` 任意状态就能 resolve place/cancel waiter。
2. **Ack、远端状态、终态观察不是同一关系**：`PlaceOrderResult` 只有 `success`、可选 `orderId/error/orderState/legs`（`packages/uta-protocol/src/types/broker.ts:170-180`）。它没有区分“本地调用完成”“provider response 到达”“远端接受”“终态/成交已观测”“结果未知”。
3. **Dispatch 后的 Unknown/idempotency 不能由 bool 表达**：各组源码都没有统一证明 client-order-id、native deduplication、retention horizon、accepted-before-ack 或 DELETE/replace 的最终一致性。一个 timeout/connection loss 可能发生在远端已接受之后，公共 `success:false` 会错误地看成确定拒绝。
4. **查询覆盖/缺席不能由 `null`/`[]` 表达**：Alpaca `getOrder` 捕获所有异常返回 null；CCXT 需要 symbol 且把 regular/conditional 查询错误 catch 成 null；IBKR `reqOpenOrders` 只覆盖当前 client；Longbridge 没有 listing，逐单 `orderDetail` 还把 native id 丢到 `Order.orderId=0`。这些都不能统一解释为 definitive absence。
5. **能力不是静态字符串数组**：`getCapabilities()` 的 `supportedOrderTypes` 只是一组候选或兼容元数据，不能表示 account/venue/product/environment/session/namespace/SDK-version 证据、暂时 unavailable、未声明 leaf 或 capability revision。
6. **Close、attachment、modify 的关系不是统一的 place 别名**：Alpaca full close 是 native DELETE、partial close 是读仓位后 reverse MKT；CCXT close 是读仓位后 place，并且仅 derivatives 加 `reduceOnly`; IBKR/Longbridge 都是读仓位后 reverse MKT。IBKR attachment 直接拒绝，CCXT 无 verified override 直接拒绝，Longbridge `placeOrder` 的 `_tpsl` 被忽略。公共可选 `tpsl`/`closePosition` 参数无法承诺这些语义。
7. **Native identity/evidence 丢失不能靠状态字符串补回**：CCXT 把 opaque id `parseInt(... ) || 0` 放进 legacy `Order.orderId`；Longbridge 的 `mapOpenOrder` 固定 `order.orderId=0` 且没有填 `OpenOrder.orderId`；IBKR bridge 丢 `permId/clientId` 并可合成空 Contract/Order。观察关系必须保留 identity presence/absence/conflict。

因此，公共关系至少需要把“输入编译、原生调用、返回/ack、后续观察、查询覆盖、能力可用性”视为不同关系；这不是给每个 provider 设计一套业务模型，而是避免一个 `success/status/null/[]` 关系冒充全部语义。

## 2. 逐 provider 当前源码核对

### 2.1 Alpaca

#### A-input：原生参数构造

当前 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:273-347`：

- `resolveSymbol` 只接受有 symbol 且 secType 为空或 `STK` 的 Contract；请求 payload 写 `symbol`、小写 `side`、`ibkrOrderTypeToAlpaca` 的 type、`ibkrTifToAlpaca` 的 `time_in_force`。
- `MKT/LMT/STP/STP LMT/TRAIL` 映射为 `market/limit/stop/stop_limit/trailing_stop`；未知 order type 直接 `toLowerCase()`，不是能力证明。
- `DAY/GTC/IOC/FOK/OPG` 有显式映射；未知或空 TIF 走 `tif.toLowerCase() || 'day'`，所以空值会变成 Day。这是当前输入编译行为，不是公共 TIF 语义。
- quantity 采用 `totalQuantity`，否则采用 `cashQty` 写成 `notional`；两者同时存在时 qty 优先（`287-294`）。这是真实的 provider operand precedence，不能作为全局 Order 的默认。
- `lmtPrice`、`auxPrice`、`trailingPercent` 分别写 limit/stop-or-trail fields；`outsideRth` 写 `extended_hours`。
- 同时有 TP 和 SL 时写 `order_class='bracket'`，只有一个时写 `order_class='oto'`；place response 的 `legs` 才把 child id 传出（`309-343`）。本地构造不是 bracket/OTO 原子性、held-leg retention 或 client idempotency 的证据。

`modifyOrder`（`349-368`）只为实际提供的字段组 PATCH，不能表达 clear/retain 的原生语义；`auxPrice` 统一变成 `stop_price`，`trailingPercent` 写 `trail`，TIF 仍走未知到 Day 的 mapper。SDK 仅证明 PATCH endpoint 存在（`services/uta/node_modules/@alpacahq/alpaca-trade-api/dist/resources/order.js:31-32`），不证明 version/CAS/idempotency。

#### A-return：调用返回与含义

- create/replace 把 SDK raw response cast 为 `AlpacaOrderRaw`，将 raw `status` 通过 `mapAlpacaOrderStatus` 映射；未知 status 默认 `Submitted`（`alpaca-contracts.ts:42-72`）。
- cancel 调用 SDK `cancelOrder` 后丢弃返回值，本地新建 `OrderState.status='Cancelled'`（`370-379`）。这是“cancel Promise resolve + adapter 合成状态”，不是终态/absence 观测。
- full close 调用 SDK `closePosition(symbol)`，partial close 先 `getPositions`，根据 side 构造 reverse MKT/DAY，再递归调用 place（`381-413`）。两条路径虽然共享 `PlaceOrderResult`，但原生操作、identity、残余仓位和未知恢复语义不同。
- SDK `getByClientOrderId` endpoint 存在（`order.js:18-20`），adapter place 并没有设置/返回 `client_order_id`；endpoint 不证明 server idempotency、retention、group atomicity。

#### A-query：查询/观察和实际消费者

- `getOrder`（`482-498`）对单 ID 查询，任何异常都返回 null；`getOpenOrders`（`500-509`）固定 `{status:'open'}`，没有 adapter pagination/held/conditional namespace policy。
- `mapOpenOrder`（`630-655`）保留 UUID `OpenOrder.orderId`，但只映射少数 raw fields；raw `filled_at/created_at/client_order_id/updated_at` 不进入公共对象，`order.orderId` 固定 0。只有 `bracket` 且 legs 存在时提取 tpsl；OTO 单腿不进入 `extractTpSl`。
- 源码注释明确 held stop leg 可能不在 open-orders listing（`327-331`），所以 place-time child ids 与之后 listing 是不同观察来源；不能以 listing 缺席判定不存在。
- `UnifiedTradingAccount.sync` 的 listing/absence consumer（`UnifiedTradingAccount.ts:828-878`）也只在公共 `getOpenOrders` 与 `getOrder` 之间作兼容判断，无法生成 coverage/Unknown/definitive absence 证据。

#### A-support：实际支持缺席

`getCapabilities()`（`593-600`）静态返回 STK、五类 order type、IEX history；`getContractDetails()`（`259-268`）也给出静态 orderTypes。当前源码没有 account permission、instrument-specific limit、TIF-by-class、venue/session acceptance、native version、DELETE final-state 或 close reduce-only 证明。因此：

- MKT/LMT/STP/STP LMT/TRAIL 是当前 adapter 能编译的候选，不是每个 account/mode 的可执行能力。
- bracket/OTO payload 是输入构造事实；atomicity、child retention、held-leg visibility、retry/idempotency 仍未证实。
- full close DELETE 的 client identity/reduce-only/idempotency/residual semantics 未证实（SDK `position.js:8-12` 只显示 DELETE path）。
- unknown future status、error envelope、pagination/entitlement 不能默认成 Submitted/empty/success。

### 2.2 CcxtCore 与 CcxtVenues

#### C-input：通用 CCXT adapter 的原生参数构造

当前 `CcxtBroker.ts:509-626`：

- `contractToCcxt` 先找 localSymbol，再找 symbol，再按 base/secType/quote 搜索；没有唯一结果就失败。`ccxt-contracts.ts:118-180` 的 fallback 在 currency 省略时隐式偏好 USDT/USD/USDC，且 `exchangeName` 参数在 resolver body 不参与 lookup。
- `totalQuantity` 转成 decimal string，再在最终 createOrder 边界 `parseFloat` 为 JS number；cashQty 没有 native notional，先 `fetchTicker` 再计算 amount（`520-534`）。
- `MKT/LMT` 映射为 `market/limit`；STP/STP LMT 使用基础 market/limit 加 `params.triggerPrice`；TRAIL/TRAIL LIMIT 直接 refusal（`576-595`）。
- tpsl 只有存在 `overrides.placeOrderWithTpSl` 才能 dispatch；没有 override 则 refusal。即使有 override，通用 params 只构造 `takeProfit`/`stopLoss` shape，真正 native attach 是 venue-specific。
- `extraParams` 是未经精确 schema 的 spread；该参数袋不是跨 venue capability。`placeOrder` 返回 createOrder raw `id/status` 的映射。
- `closePosition`（`691-726`）先读 positions，以 wire symbol 或 symbol+secType 找持仓，再 reverse MKT；仅 `CRYPTO_PERP/FUT` 写 `reduceOnly:true`，spot 明确不写。

`CcxtBroker.modifyOrder`（`647-689`）先按 cache/hint 查询原单，再用原单 type/side/qty/price 填 `editOrder`；stop/trail/TIF 放 params。它要求原单 query 成功，且未定义 clear/retain 语义。`cancelOrder`（`628-645`）从 in-process symbol cache 找 symbol；默认 helper 先 regular cancel，失败后若有 symbol 再 `stop:true`，最终 adapter 合成 Cancelled。该 fallback 是当前 helper 操作序列，不是安全 idempotency 证明。

#### C-return：返回状态不是统一远端结果

`ccxt-contracts.ts:36-52` 把 `closed` 直接映射 Filled、`open` 映射 Submitted、canceled/cancelled 映射 Cancelled，unknown/undefined 默认 Submitted；create/edit raw response 和 synthetic cancel 都进入同一 `PlaceOrderResult`。CCXT response “有对象”不等于 fill/terminal；venue status vocabulary、closed/fill finality 和 retention 都在 `CcxtVenues` 问题中明确未证实。

#### C-query：查询、listing 和实际消费者

- `getOrder`（`1112-1129`）没有 symbol cache/hint 就直接 null；有 symbol 时 regular+`stop:true` default helper 或 Bybit 四路径 override；所有 lookup/convert 异常 catch 为 null。
- `convertCcxtOrder`（`1132-1168`）找不到 market 返回 null；missing side/amount/type 用 buy/0/market，missing status 经 mapper 变 Submitted；opaque id 用 `parseInt(o.id,10)||0` 写 legacy `Order.orderId`，但 `OpenOrder.orderId` 保留字符串。
- `getOpenOrders`（`1178-1205`）keyless 直接 []；普通失败在非 strict override 时 warning 后 []，strict provider 才抛错。Bybit override（`bybit.ts:13-29,43-52`）按 regular/conditional open/closed 四路径查单，listing 逐 spot/swap category；Bitget override（`bitget.ts:17-66`）逐六个 namespace listing，缺 id 行被跳过并按 `symbol:id` 合并。
- `getPositions`（`1033-1097`）把 derivative rows 与 balance-derived spot holdings 合并；zero/unknown market/unpriced ticker rows 被跳过，Hyperliquid override（`hyperliquid.ts:43-53`）用 `abs(notional)/abs(contracts)` 补 mark，但不证明原生单位/符号。
- `getFundingRate`/`getOrderBook`（`1330-1375`）缺 rate/level/timestamp 时分别填 0 或 Date.now；这是当前 compatibility output，不是 observation provenance。

#### C-support：静态/venue-specific 支持缺席

- CcxtCore `getCapabilities()`（`1290-1295`）只列 CRYPTO/CRYPTO_PERP 与 MKT/LMT；translator 能处理 FUT/OPT 不等于 action capability。
- `ccxtTypeToSecType` unknown type 默认 CRYPTO（`24-33`），`marketToContract` 对 expiry/contractSize/strike/optionType 做 unknown cast，缺 contractSize 时 multiplier='1'（`76-110`）。因此 derivative identity/capability 不能由 fallback 生成。
- Bitget 当前 override 明确 Classic-only、spot/derivatives wallet、USDT-FUTURES productType，并 strict private/open-order reads；这只约束 Bitget leaf，不能推广到其他 venue。
- Bybit category/listing/conditional path、Hyperliquid market emulation、OKX/other regular-vs-conditional fallbacks 都是 provider-specific operations。`overrides.ts:146-234` 的 raw hook presence 不是 idempotency/compensation/attached-order proof。
- `CcxtBroker` keyless path 返回 zero USD account and [] orders (`932-939`, `1099-1102`, `1178-1180`)；这些 compatibility values 不能成为 private absence/permission/Complete listing。

### 2.3 Ibkr：原生 Order 直通与 broker 语义

#### I-input：IBKR 不做跨 SDK 字段翻译

`IbkrBroker.placeOrder`（`480-507`）把经 `resolveRoutableContract` 得到的 Contract 和调用者传入的完整 `Order` 原样交给 `client.placeOrder`；`packages/ibkr/src/order.ts:37-75` 的字段包括 action、Decimal totalQuantity、orderType、prices、TIF、parent/OCA/transmit、percentOffset、trail 等。`packages/ibkr/src/client/orders.ts:33-75,459-508` 负责 server-version gates 和 wire serialization，但方法返回 `void`，wire error 由 wrapper callback 报告。

当前仓库样例给出的是输入构造事实而非能力总表：MOC=`orderType MOC`（`OrderSamples.py:95-108`）；MOO=`MKT + tif OPG`（`111-126`）；LOC=`LOC + lmtPrice`（`436-451`）；LOO=`LMT + tif OPG + lmtPrice`（`454-470`）；REL=`REL + auxPrice offset + lmtPrice cap`，且样例注明股票/期权/期货纸账户不可用（`211-235`）。`Order.percentOffset` 只在 `order.ts:72` 注明 REL-only，单位/scale和 exact account/product acceptance 并未由这些声明证明。

因此 IBKR 的 native operand 差异不是“把所有 Order 转成另一个 JSON shape”，而是“调用者必须提供已满足 provider leaf 的原生 Order fields + fully resolved Contract”；公共 `Partial<Order>` 不能表达 clear/retain、产品/venue/session 合法组合或 percent offset unit。

#### I-return：waiter/callback 的真实边界

- place：`getNextOrderId()` → `requestOrder(orderId)` → void `client.placeOrder` → await Promise；bridge `openOrder`（`request-bridge.ts:738-748`）只要同 orderId callback 到来就 resolve，不检查 status。
- cancel：同 orderId `requestOrder` → void `client.cancelOrder` → await；adapter 丢弃 resolved `CollectedOpenOrder`，本地新建 Cancelled（`IbkrBroker.ts:545-558`）。`orderStatus('Cancelled')` 也可 resolve waiter，但 matching `openOrder`（即使 Submitted）同样可 resolve。
- modify：先 `getOrder`，原地修改 `Order`，按同 numeric orderId 再调用 placeOrder（`509-543`）；不是一个带 native version/CAS 的公开关系。
- close：读 positions 后 reverse MKT/DAY，再走 place（`561-585`）。

所以 IBKR `success:true` 的最小源码事实是“liveness probe 通过、void mutator 被调用且 orderId waiter 被 callback 结束”；不是 independent send receipt、remote accept、fill 或 terminal cancellation。

#### I-query：listing/observation 与 consumer

- `requestOpenOrders`/`requestCompletedOrders` 是 single-slot collectors（`request-bridge.ts:244-269`），分别调用 reqOpenOrders 与 reqCompletedOrders(true)，由 `openOrderEnd`/`completedOrdersEnd` resolve。
- `getOpenOrders` 明确只覆盖当前 clientId；manual TWS orders 需要 reqAllOpenOrders + permId，但当前 bridge/adapter 没有接通（`IbkrBroker.ts:766-775`）。`getOrder` 先 open listing 再 completed listing（`777-785`），空结果不是 definitive absence。
- `openOrder` 不保留 permId/clientId；`orderStatus` 收到二者但使用 `_permId/_clientId` 丢弃，只缓存 filled/avgFillPrice，cancel-only path 还能合成空 Contract/Order（`request-bridge.ts:750-777`）。
- account/position callbacks 用 conId upsert、zero quantity 删除、按 multiplier 归一化 avgCost，但丢 accountName（`604-642`）；account values 以 currency-qualified/plain BASE keys 写 cache，downloadEnd 交换 pending/live（`644-678`）。这些是数据观察/投影事实，不是 Order dispatch authority。

#### I-support：当前未能宣称的支持

`getCapabilities()`（`874-879`）静态列出 STK/OPT/FUT/FOP/CASH/WAR/BOND 和 MOC/LOC/REL 等候选，未含 account permission、environment、venue/product/session 或 SDK capability fingerprint。attached TP/SL 在 `placeOrder` 明确拒绝（`481-489`）。因此 MOC/LOC/REL/OPG、percentOffset、bracket、manual-order observation、calendar-sensitive writes 都不能由静态列表自动启用。

### 2.4 IbkrBridge：callback/collector 是单独的异构边界

IbkrBridge 不构造订单 payload；它决定 native callback 如何结束等待、如何保留/丢失 identity、如何覆盖 listing/account/tick namespace：

- `requestOrder` 以 orderId 单槽等待且 timeout 删除 waiter（`request-bridge.ts:231-242`）。
- `openOrder` 既 resolve order waiter 又追加 open listing；没有 place/modify/cancel operation tag（`738-748`）。
- `orderStatus` 只在 Cancelled 时 resolve waiter，filled/avgFillPrice 另存 cache，permId/clientId 丢弃（`750-777`）。
- 2100-2199 status 被静默忽略，1100/1101/1102 是连接 hint；unknown 10xxx/21xx 不可从当前 classifier 扩展成完整 rejection/ready 事实（`488-517`）。
- accountName、generation、native sequence、currency/instrument snapshot context、callback uniqueness/horizon、late callback after close 都不是当前 callback contract；`updatePortfolio`/`updateAccountValue`/`accountDownloadEnd` 仅给本地 cache semantics（`604-678`）。

这组事实说明“请求发出→回调→观察”的关系不能只被 provider `placeOrder` 返回值包住；bridge callback 需要独立的 correlation、coverage、identity presence/absence、generation 和 stale/unknown 语义。它仍不要求把 IBKR callback 细节放进公共 Order 字段。

### 2.5 Longbridge

#### L-input：SDK enum/option 构造

`LongbridgeBroker.ts:71-120,271-312`：

- MKT 在 HK 变 ELO，其他市场变 MO；LMT→LO，STP→MIT，STP LMT→LIT，TRAIL→TSMPCT，TRAIL LIMIT→TSLPPCT；未知 orderType refusal。
- DAY/空→Day，GTC→GoodTilCanceled，GTD→GoodTilDate，IOC/FOK/OPG→null/refusal；其他未知 TIF 默认 Day。
- `SubmitOrderOptions` 必须有 symbol/orderType/side/submittedQuantity/timeInForce；adapter 只传 submittedPrice、triggerPrice、trailingPercent 的一部分（SDK declaration `index.d.ts:3181-3218` 还声明 expireDate/outsideRth/limitOffset/trailingAmount 等，但 adapter 未映射）。
- `_tpsl` 参数被命名但未使用；close 读持仓后 reverse MKT/DAY，非 native close/reduce-only。

#### L-return/query：response、观察、消费者

- submit Promise 只被读取 `resp.orderId`，adapter 固定返回 `New`（`303-312`）；SDK response envelope/version 和 accepted-before-ack 未由 local mock/ledger 证明。
- replace 与 cancel SDK 方法都是 `Promise<undefined>`/`Promise<void>`（SDK `2244`, `2287`）；adapter 在 resolve 后合成 Replaced/Canceled（`315-343`）。
- `getOrder` 调 `orderDetail`，所有异常返回 null；没有 `getOpenOrders` listing，`getOrders` 逐单调用（`613-629`）。
- `mapOpenOrder` 只映射 symbol/side/quantity/type/price/TIF/status/avg executed price，固定 `order.orderId=0`，没有设置 `OpenOrder.orderId`（`696-712`）。这使 provider native string id 不进入通用 observation identity；查询消费者只能依赖调用时的 requested id。
- SDK `Order` declaration 实际有 updatedAt、triggerAt、trailing、currency 等（`index.d.ts:744-806`），但当前 adapter 不保留它们；声明存在也不等于 response/version/conformance 已验证。

#### L-support/lifecycle：实际缺席

- `getCapabilities()` 静态列 STK 和五种 order type（`674-680`），但 market suffix、account environment、paper endpoint、order-class/session acceptance 仍需证据。
- `searchContracts` 不是完整 catalog，只 echo 输入（`237-243`）；`resolveSymbol` 对无 suffix 的 symbol 会从 currency 推断，CNY 时 SH 优先导致 SH/SZ ambiguity（`longbridge-contracts.ts:67-91`）。
- `close()` 是 async no-op，源码没有 verified release/unsubscribe API（`230-233`）；GC 不是确定性 native release。
- `init()` 只 probe `tradeCtx.accountBalance()`；quote endpoint coverage、SDK error code/status、paper/live endpoint/account binding 未被该 probe 证明（`180-228`）。

## 3. 按关系集中论证（不按 provider 再造六套业务模型）

### 3.1 Place / modify

Place 的共同可见关系是“语义 Order 意图经过 instrument/venue-specific compiler 后调用 native mutation”，但每个 compiler 的操作数不同：

- Alpaca 需要 ticker、REST type/TIF、qty/notional precedence、optional bracket/OTO。
- CCXT 需要 market symbol、number amount/price、trigger params、venue override；cashQty 还引入 quote fetch。
- IBKR 需要完整 native Contract + native Order，SDK 自己序列化/版本门控。
- Longbridge 需要 suffix-aware enum、positive quantity、SDK Decimal-like values。

这是输入值/函数操作数差异，可以由 provider leaf 精确声明。相反，公共 `Partial<Order>` 不能表达“某字段 omission 是 retain 还是 clear”“某 TIF 只在某 product/session 有效”“某 native field 未声明就不能出现在 command”，因此 generic method signature 本身不足。

Modify 进一步证明关系差异：Alpaca PATCH 可能需要 version/clear semantics；CCXT 必须先 fetch original 才能补 type/side；IBKR 同 orderId re-place 且原地改对象；Longbridge replace 必须 quantity。它们不是一个可互换的 `Partial<Order>` operation。

### 3.2 Cancel / return / observation

四个 adapter 都可能在 SDK Promise resolve 后返回 `Cancelled`，但等待点不同，且 IBKR 的 matching `openOrder` 可以在 callback status 仍 Submitted 时结束 cancel waiter。当前 `PlaceOrderResult.success` 无法说明：

- native bytes 是否发送；
- provider 是否接受；
- remote order 是否已进入 Cancelled；
- query 是否看到终态；
- 该 id 是否在所有 namespace/retention horizon 中已不存在。

因此 Cancel 的公共关系必须与后续 observation/coverage 关系分开；“本地合成 Cancelled”不能被提升为跨 provider terminal fact。

### 3.3 Close / inverse place

Close 不是普遍的 `place(reverse(Order))`：

- Alpaca full close 是 DELETE，partial close 是 reverse MKT；两者 client identity、reduce-only、residual semantics 未证实。
- CCXT close 只有 derivatives 写 reduceOnly，spot 不写；反向 market 仍可能是另一个 native action。
- IBKR/Longbridge 都读 exposure 后 reverse MKT；读取与 dispatch 之间可发生 exposure drift，且没有 venue CAS。

所以“close”是独立 operation relation，需要暴露 exposure precondition/observation/unknown，而不是把 close 作为所有 provider 的 place alias。这里是公共关系不足，不只是 quantity/side 操作数不同。

### 3.4 Protection / attached order

- Alpaca 当前能生成 bracket/OTO payload，place response 可带 child ids；不证明 atomicity、held child listing、parent/leg retention。
- CCXT 没有 verified override 就拒绝 attached TP/SL；不同 venue 的 attach native field 不同。
- IBKR 当前明确拒绝 tpsl，虽然 SDK Order 有 parent/transmit 字段。
- Longbridge `_tpsl` 被忽略，不能假装支持。

因此一个公共 optional `TpSlParams` 只能是输入提示，不能成为“protected order”关系。未声明/未证实的 attachment leaf 必须缺席或不可用，不能静默降级成裸 entry 或把 ledger 的 tpsl 当 venue fact。

### 3.5 Query / listing / absence

当前实际 consumer `UnifiedTradingAccount.sync` 使用“listing presence → alive；listing absence → getOrder confirm；getOrder 仍可 Submitted”的兼容流程（`UnifiedTradingAccount.ts:828-878`）。四类 provider 证明此关系不完整：

- Alpaca open-only query 没有 pagination/held namespace。
- CCXT lookup 需要 symbol，conditional/regular path 和 category 由 venue 决定；非-strict failure 可变成 []。
- IBKR open listing 仅 current client，manual orders 另需 reqAllOpenOrders/permId。
- Longbridge 没有 listing，逐单 observation 又丢 native id。

因此 `OpenOrder[]` 与 `OpenOrder|null` 不能承担 coverage, Partial, Unavailable, Unknown, DefinitiveAbsent 的全部含义；absence 不是一个裸布尔值。

### 3.6 Capability / support absence

静态 capability arrays、`getContractDetails.orderTypes`、SDK declaration 和 override function presence 都不能证明 account/venue/product/session/environment/namespace 的实际支持。缺席有三种不同情况：

1. **未声明/不在 leaf schema**：调用输入本身不成立，不能生成 command。
2. **已声明但当前证据不足/暂不可达**：leaf 存在但 availability 是 Unknown/Unavailable，不能 dispatch。
3. **已 dispatch 后结果未知**：不是 capability failure，也不是已知 rejection，应进入 observation/recovery。

把三者压成一个 `unsupported` 字符串会同时损失输入校验、运行时可用性和 dispatch outcome。

## 4. 原始问题与来源 ID 处置 ledger

说明：原问题文本逐字保留在各组 `questions-closure.json`；以下使用其 `MAP-*` ID 作稳定定位，不重复改写原文。每行的“历史 disposition”是原档案标签，不是当前设计裁决；“本次处置”指向本稿具体源码段。`source anchor` 是当前源码复核位置，原始 evidence 列表仍可从同一 MAP entry 回查。

### 4.1 Alpaca（49 条）

Source anchors：A1=`AlpacaBroker.ts:151-203` init；A2=`:211-268` catalog/details；A3=`:273-347` place；A4=`:349-413` modify/cancel/close；A5=`:417-480` account/position；A6=`:482-509` order query；A7=`:511-591` quote/history；A8=`:593-625` capability/clock/identity；A9=`:630-674` order decoder；A10=`alpaca-types.ts:1-86`；A11=`alpaca-contracts.ts:42-72`；A12=`@alpacahq/.../resources/order.js:18-32`/`order.d.ts:1-15`；A13=`.../resources/position.js:8-12`；A14=`.../datav2/entityv2.d.ts:47-77`；A15=`packages/uta-broker-alpaca/src/index.ts:1-8`。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-4C741F2512 | empirical-retained | response envelope/idempotency → §A-return/A3,A12；未作 native guarantee |
| MAP-BDB66E4D30 | integration-resolved | health/close → §A-return/A1；account probe 不等于 mutation readiness |
| MAP-3372FF782B | empirical-retained | client id/group atomicity → §A-return/A3,A12；Observe/observation 未由源码证明 |
| MAP-D34D87EEB6 | empirical-retained | quantity/price scale → §A-input/A3；Decimal 接受不是 venue limit 证明 |
| MAP-186E3AA482 | empirical-retained | permission/order limits → §A-support/A2,A8；静态 details 不足 |
| MAP-D25F93A942 | empirical-retained | version/replace idempotency → §A-return/A4,A12；未有 native version |
| MAP-3C0F790B85 | empirical-retained | PATCH clear semantics → §A-input/A4,A12；omission 不解释为 clear |
| MAP-A99C29C26A | empirical-retained | cancel absence/eventual consistency → §A-return/A4,A6；DELETE ack 不等终态 |
| MAP-053E34F691 | empirical-retained | close DELETE identity/reduce-only → §A-close/A4,A13；未证实 |
| MAP-3DA66A43BA | design-decided | account currency/sequence → §A-query/A5；只保留来源缺失事实，不采纳旧设计结论 |
| MAP-20EEB58E82 | design-decided | list/get 无 provider sequence → §A-query/A6；本地 projection sequence 不是 native sequence |
| MAP-4AF53E630B | empirical-retained | raw response identity/version/time → §A-return/A6,A9；缺失不授权 retry/lookup |
| MAP-3C5D748AD0 | design-decided | feed/venue context → §A-query/A7,A14；缺失保持未知 |
| MAP-CDB6B2021B | empirical-retained | generator pagination/feed entitlement → §A-query/A7；不得从 generator 名称宣称 complete |
| MAP-B0EB90D81C | design-decided | clock timezone/calendar → §A-query/A7,A8；不从 Date 推断 session authority |
| MAP-A1FCB75450 | empirical-retained | order variants/notional/account permission → §A-support/A3,A8；按 leaf evidence |
| MAP-63A967FD50 | empirical-retained | denial/entitlement body → §A-return/A7,A12；unknown body 不升级为 fallback |
| MAP-1F8F896823 | design-decided | asset jurisdiction/currency → §A-query/A2,A10；metadata 不完整时不供 mutation |
| MAP-0F3A295D51 | empirical-retained | TIF by order class → §A-input/A3；当前 unknown→Day 是 legacy 行为，不是保证 |
| MAP-B9801A7C06 | empirical-retained | error body/retry-after → §A-return/A7；未知 envelope 保留证据 |
| MAP-36636F09DE | integration-resolved | pack registry surface → §A-support/A15；本稿不改 pack |
| MAP-49BC37B6CE | integration-resolved | single-scope discovery → §A-support/A1；不预设 default account |
| MAP-0ABCB3F3AD | empirical-retained | reconnect/rate limits → §A-return/A1；init retry 不是 mutation retry |
| MAP-DEA87BE3CD | design-decided | malformed catalog batch → §A-query/A2；当前 refresh 是 data path |
| MAP-B25118D3A4 | empirical-retained | exchange/order static lists → §A-support/A2,A8；候选而非 account capability |
| MAP-CFEE6FFFEA | empirical-retained | client lookup/idempotency/held leg → §A-return/A3,A6,A12；endpoint 存在不够 |
| MAP-E8E6E71EFB | empirical-retained | replace updated/version identity → §A-input/A4；不作 automatic retry/CAS claim |
| MAP-D276945617 | empirical-retained | DELETE final state/absence → §A-return/A4,A6；ack 与 observation 分离 |
| MAP-7C95D7E4A8 | empirical-retained | close DELETE reduce-only/idempotency → §A-close/A4,A13；保留 native uncertainty |
| MAP-A57DA48B5D | design-decided | account currency/read ordering → §A-query/A5；不把 Promise.all 当 common snapshot |
| MAP-FBF8E94277 | empirical-retained | short market_value sign → §A-query/A5；不以 abs 授权 |
| MAP-C2CA1F9078 | design-decided | Axios error classes → §A-return/A7；unknown/transport 不变 null-success |
| MAP-AECC0CF17C | empirical-retained | order listing pagination/held namespace → §A-query/A6,A12；open-only 不等 Complete |
| MAP-1D39C444E7 | source-resolved | SDK child fields vs local raw → §A-query/A7,A10,A14；缺字段显式未知 |
| MAP-21C40C002D | empirical-retained | feed traversal/quality → §A-query/A7；不以 SDK generator 宣称 complete |
| MAP-0A1AF127FE | empirical-retained | capabilities beyond examples → §A-support/A8；unproven extension absent/unavailable |
| MAP-9C9DF0B00B | design-decided | timezone/calendar → §A-query/A8；session-sensitive write 不从 clock row 推断 |
| MAP-D988AF12EE | design-decided | ticker scope → §A-support/A8；public identity 与 account/order scope 分开 |
| MAP-2C63E4B337 | empirical-retained | client/version fields → §A-return/A9；缺失不满足 retry/CAS |
| MAP-3059D38FCE | empirical-retained | bracket/OTO atomicity/child listing → §A-return/A3,A6,A9；parent/legs 独立观察 |
| MAP-EAC4E9DC46 | empirical-retained | future status enum → §A-return/A11；unknown 不默认 Submitted |
| MAP-ADF2C4D82C | design-decided | non-secret config handoff → §A-support/A15；非本次 broker behavior 设计 |
| MAP-E1BE5EBCAD | design-decided | currency/observation timestamp → §A-query/A5,A10；来源缺失保留 |
| MAP-D50CF7C166 | empirical-retained | status/group/version completeness → §A-return/A9,A12；native capture 未证实 |
| MAP-9E30EAD352 | design-decided | feed/venue raw context → §A-query/A7,A10,A14；缺失不伪造 |
| MAP-13D1329A19 | source-resolved | VWAP/trade count optional fields → §A-query/A7,A10,A14；数据字段不成为 Order field |
| MAP-0E85D36517 | empirical-retained | activity pagination/execution identity → §A-query/A10；没有 fill stream/ID 保证 |
| MAP-D0F05BBCB5 | design-decided | clock calendar → §A-query/A8,A10；不扩大 session capability |
| MAP-CBE13E6174 | integration-resolved | registry v2 surface → §A-support/A15；仅记录接口缺口 |

### 4.2 CcxtCore（6 条）

Source anchors：C1=`CcxtBroker.ts:303-398` init/readiness；C2=`ccxt-contracts.ts:24-180` type/status/identity；C3=`CcxtBroker.ts:509-726` mutation；C4=`:728-1097` account/position；C5=`:1112-1205` order query；C6=`:1239-1375` bars/funding/book/capability；C7=`overrides.ts:31-234` hooks/defaults。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-412EC97A15 | empirical-retained | realtime quality → §C-support/C6；static/e2e label 不足 |
| MAP-DA97124E26 | empirical-retained | Bybit conditional client id → §C-query/C5,C7；namespace-scoped identity 未证实 |
| MAP-23A28BDB57 | empirical-retained | static realtime/finality → §C-support/C6；不作 quality/terminal proof |
| MAP-DD87586D0B | empirical-retained | idempotency/clientOrderId → §C-return/C3,C7；Dispatch 后未知不重发 |
| MAP-D8B89D3086 | empirical-retained | duplicate create → §C-return/C3,C7；override 存在不等 dedup |
| MAP-1FEC8E666F | empirical-retained | per-venue historical quality → §C-support/C6；保持 quality unknown |

### 4.3 CcxtVenues（38 条）

Source anchors：V1=`ccxt-contracts.ts:55-180` market identity/quote policy；V2=`CcxtBroker.ts:509-726` place/cancel/modify/close；V3=`CcxtBroker.ts:1112-1205` lookup/listing；V4=`overrides.ts:146-234` defaults/registry；V5=`exchanges/bitget.ts:17-66`；V6=`exchanges/bybit.ts:13-52`；V7=`exchanges/hyperliquid.ts:20-53`；V8=`CcxtBroker.ts:1033-1097,1239-1375` positions/market data。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-2FB8A60A26 | empirical-retained | native id↔unified symbol stability → §C-support/V1；未证实只保留 identity evidence |
| MAP-00DA721165 | empirical-retained | derivative expiry/contractSize → §C-input/V1；不能以 fixture 生成 capability |
| MAP-1767B100E0 | empirical-retained | type vocabulary → §C-support/V1；unknown 不默认 CRYPTO |
| MAP-C2F10E778E | empirical-retained | timeframe by venue/env/version → §C-support/V4；必须 runtime evidence |
| MAP-F0A14EF839 | empirical-retained | status/finality/retention → §C-return/V2,V3；closed 不单独等 Filled |
| MAP-63CF278660 | empirical-retained | derivative field coverage → §C-input/V1；fallback multiplier 不作事实 |
| MAP-249466CED5 | design-decided | quote preference → §C-input/V1；明确是 resolver policy，不是 universal rule |
| MAP-054253553C | empirical-retained | order-book timestamp/sequence → §C-query/V8；local now/缺 sequence 不作 continuity |
| MAP-A023467285 | empirical-retained | funding precision/timestamp → §C-query/V8；缺失不填 0/now |
| MAP-F12C6450E2 | empirical-retained | funding tool reliability → §C-query/V8；broker rejection 不变成功 |
| MAP-CC557A8B9C | empirical-retained | depth/sequence/freshness → §C-query/V8；不支持深度不伪造空 book |
| MAP-D084EF97BB | empirical-retained | Bitget Classic/Unified family → §C-support/V5；transport option 不启用 family |
| MAP-A5CD6EF457 | empirical-retained | Bitget plan parent/child/paging → §C-query/V5；route 参数不证明 relation |
| MAP-2305603E29 | empirical-retained | Bitget permission vs network → §C-support/V5；strict failure 不写 zero |
| MAP-0AD385A30A | empirical-retained | Bitget contractSize/mark/PnL → §C-query/V5,V8；listing 与 valuation 分开 |
| MAP-D119678B33 | empirical-retained | Bitget cursor/rate limit → §C-query/V5；未证明不能 Complete |
| MAP-D0F4B7EAFE | empirical-retained | Bitget ID scope → §C-query/V5；默认复合 identity |
| MAP-5AA0964109 | empirical-retained | Bitget permission/timeout fields → §C-return/V5；Unknown/Unavailable |
| MAP-8BF5C81D82 | empirical-retained | Bitget family probe → §C-support/V5；注释/constant 不足 |
| MAP-B432FAA965 | empirical-retained | Bitget open-order namespace → §C-query/V5；缺席不能移除 |
| MAP-4714F941FF | empirical-retained | Bitget namespace materiality → §C-support/V5；spot success 不覆盖 derivatives |
| MAP-B224A5F3E2 | empirical-retained | Bitget response scope markers → §C-query/V5；route param 不等 scope proof |
| MAP-56798F3CBB | empirical-retained | Bitget six namespace coverage → §C-query/V5；partial 保留 rows |
| MAP-8F4D954D91 | empirical-retained | Bybit category id collision/paging → §C-query/V6；ScopedOrderRef |
| MAP-4651A86203 | empirical-retained | Bybit 10016 semantics → §C-return/V6；message 不构成 permission |
| MAP-A80A70DAA5 | empirical-retained | Bybit four-path absence → §C-query/V6；catch-all not NotFound |
| MAP-9D14A7D985 | empirical-retained | Bybit category listing → §C-query/V6；未扫完不能 empty |
| MAP-DD9535B452 | empirical-retained | Hyperliquid slippage/market emulation → §C-input/V7；ticker/ref price 不等 idempotency |
| MAP-DD56DE539D | empirical-retained | Hyperliquid client identity/lookup → §C-return/V7；unknown 只 observe/recover |
| MAP-AE93DB138F | empirical-retained | Hyperliquid mark units/sign → §C-query/V7,V8；derived mark 不作 valuation authority |
| MAP-5CC2CA6EF1 | integration-resolved | pack/version loading → §C-support/V4；只记录 boundary，不改 loading |
| MAP-ED742AC7B1 | empirical-retained | per-venue idempotency/attachment → §C-support/V2,V4；hook 不等 capability |
| MAP-663AADE476 | empirical-retained | regular/conditional absence → §C-query/V3,V4；异常不解释成 absent |
| MAP-5B4370AB4D | empirical-retained | cancel fallback/idempotency → §C-return/V2,V4；当前 fallback 不被提升为安全 retry |
| MAP-F032485592 | empirical-retained | client order id/retention → §C-return/V2,V4；字段未证实则 Unknown |
| MAP-6AAB1AB711 | empirical-retained | positions scope/paging/PnL → §C-query/V4,V8；Partial/Unavailable |
| MAP-A1AE3F307F | empirical-retained | OKX/other venue probes → §C-query/V3,V4；不可跨 venue 推广 |
| MAP-AB05DEE8D4 | empirical-retained | registry/account-family/jurisdiction → §C-support/V4；registry presence 仅装配 |

### 4.4 Ibkr（14 条）

Source anchors：I1=`IbkrBroker.ts:76-229` config/lifecycle；I2=`IbkrBroker.ts:384-476` expansion；I3=`IbkrBroker.ts:480-585` place/modify/cancel/close；I4=`IbkrBroker.ts:759-879` query/capability；I5=`request-bridge.ts:231-269,454-517,738-798` order bridge；I6=`request-bridge.ts:604-734` account/position/tick；I7=`packages/ibkr/src/order.ts:37-75`；I8=`packages/ibkr/src/client/orders.ts:33-75,459-508,780-819`；I9=`packages/ibkr/ref/samples/Python/Testbed/OrderSamples.py:95-126,211-235,436-470`。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-F4D1FDCBB6 | empirical-retained | paper/live evidence → §I-support/I1；port/config hint 不等 observed environment |
| MAP-7BA90560A5 | empirical-retained | managed account scope → §I-query/I5,I6；只保留 first account 是 source defect |
| MAP-5F63915F5B | integration-resolved | aliceId/conId → §I-input/I2,I3；alias 不等 native identity |
| MAP-86EFC621F8 [idempotency] | empirical-retained | replay safety → §I-return/I3,I5；不作 resend claim |
| MAP-86EFC621F8 [MOC/LOC/REL/OPG] | empirical-retained | account/product acceptance → §I-input/I7-I9,I4；样例映射不等 capability |
| MAP-86EFC621F8 [percentOffset] | empirical-retained | REL unit/scale → §I-input/I7,I8；未证实保持 unavailable |
| MAP-661D1A0287 | source-resolved | permId/clientId dropped → §I-query/I5；synthetic cancel 不是 identity proof |
| MAP-3FBCE06D0D | design-decided | AccountDownloadResult timestamp/sequence → §I-query/I6；只记录 source 缺失 |
| MAP-444B5B305F | empirical-retained | reqAllOpenOrders/permId coverage → §I-query/I4,I5；current-client listing 不 Complete |
| MAP-6D904561E8 | empirical-retained | tradingHours/calendar → §I-support/I4；local NYSE fallback 不是 native calendar |
| MAP-C44B9CCD9F | empirical-retained | permission/capability fingerprint → §I-support/I1,I4；static list 是 candidate |
| MAP-E39D85CC2A | empirical-retained | 10xxx error table → §I-return/I5；unknown code 不重分类 |
| MAP-69B1FD6A99 | empirical-retained | subAccount/environment → §I-query/I1,I5,I6；不能从 first token/port 推断 |
| MAP-DD39DF4F2F | source-resolved | orderStatus identities dropped → §I-query/I5；本次重查确认 |

### 4.5 IbkrBridge（49 条）

Source anchors：B1=`request-bridge.ts:130-229,397-517` connect/error/lifecycle；B2=`:231-307` request/order/time waiters；B3=`:454-517` accounts/errors；B4=`:521-580` contract/summary collectors；B5=`:593-678` position/account callbacks；B6=`:682-734` ticks/snapshot；B7=`:738-798` order callbacks/listings；B8=`IbkrBroker.ts:480-585,759-839` bridge consumers。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-9FCA9EFBE0 | empirical-retained | accountName provenance → §Bridge/B3,B5 |
| MAP-96192FAD43 | empirical-retained | SDK version compatibility → §Bridge/B1；当前未验证 |
| MAP-E1E35E6D53 | empirical-retained | late nextValidId → §Bridge/B1；generation fence 必要 |
| MAP-2905EACC44 | empirical-retained | EClient timer lifecycle → §Bridge/B1；source 未证明 |
| MAP-D932C26FEF | design-decided | 10089 code/message → §Bridge/B3；numeric code/version evidence，不靠 wording |
| MAP-0DDC87F65C | empirical-retained | 21xx meaning → §Bridge/B3；informational only |
| MAP-90AB7C4BFE | empirical-retained | 1101 data maintained → §Bridge/B1,B3；不等 private readiness |
| MAP-EA3426DB91 | empirical-retained | currentTime seconds/skew → §Bridge/B1,B3；health evidence only |
| MAP-EA146DB928 | empirical-retained | throw-after-bytes ambiguity → §Bridge/B1；不据此判 no remote effect |
| MAP-BEB6FE316A | design-decided | snapshot context → §Bridge/B6；当前 requestSnapshot 只带 reqId/resolve policy |
| MAP-0FFE8EF06E | empirical-retained | snapshot end completeness → §Bridge/B6；end 不等 fields complete |
| MAP-63AEC10CAF | empirical-retained | reconnect download ordering → §Bridge/B5；gap/rebaseline |
| MAP-0DF25AB1B4 | source-resolved | no native stream sequence → §Bridge/B5；local receive sequence only |
| MAP-CD565305A6 | empirical-retained | zero position semantics → §Bridge/B5；zero row source quality 未证实 |
| MAP-02C7AD6770 | empirical-retained | account tag families → §Bridge/B5；unknown qualified rows |
| MAP-8446FB3C9C | empirical-retained | conId scope uniqueness → §Bridge/B5；必须 bind scope |
| MAP-55F8FAEE10 | source-resolved | no full-download sequence → §Bridge/B5；local sequence/rebaseline |
| MAP-AF2240CA8D | integration-resolved | DU1 fixture/default scope → §Bridge/B3,B5；不能 inference |
| MAP-B4CCAF38F7 | empirical-retained | BASE tag semantics → §Bridge/B5；BASE only when explicit |
| MAP-3A9EBFB7AC | empirical-retained | BASE indefinite absence → §Bridge/B5；provisional |
| MAP-FA3A258F67 | integration-resolved | intended base currency → §Bridge/B5；callback currency is provenance |
| MAP-367B727301 | design-decided | module/barrel boundary → §Bridge/B1,B7；raw SDK stays adapter-local |
| MAP-425C7453CF | design-decided | timeout defaults → §Bridge/B1,B2；operational values not protocol guarantees |
| MAP-CAF9BBFC26 | empirical-retained | reqId/orderId uniqueness → §Bridge/B2,B7；generation-scoped evidence |
| MAP-845E2E1907 | empirical-retained | id reuse horizon → §Bridge/B2,B7；late callback stale |
| MAP-C907FECB22 | empirical-retained | listing completeness → §Bridge/B2,B7；single-slot/end coverage |
| MAP-F1F5CC8E26 | integration-resolved | health event persistence → §Bridge/B1,B3；not an Order callback guarantee |
| MAP-5BAF58A52C | design-decided | shared client ownership → §Bridge/B1；setter/source fact only |
| MAP-3C19D7269C | empirical-retained | account token/subaccount → §Bridge/B3；opaque directory |
| MAP-B062D3EBE2 | empirical-retained | connect rejection bytes → §Bridge/B1；no mutation conclusion |
| MAP-E3F1D354E8 | empirical-retained | callback ordering after disconnect → §Bridge/B1,B7 |
| MAP-39C8BA9947 | integration-resolved | sync/async native ack boundary → §Bridge/B7,B8；DispatchStarted relation is not callback status |
| MAP-3C364480A5 | design-decided | tick context → §Bridge/B6；no inferred instrument/currency |
| MAP-96642209F5 | empirical-retained | callback identity completeness → §Bridge/B7；perm/client evidence gated |
| MAP-D9471DCF4C | design-decided | timestamp/skew policy → §Bridge/B3,B6 |
| MAP-73BED6D9B7 | empirical-retained | accountName matching → §Bridge/B3,B5；mismatch quarantine |
| MAP-78A465AAC0 | empirical-retained | callback uniqueness/horizon → §Bridge/B7；duplicate/late evidence |
| MAP-5E70703666 | empirical-retained | byte boundary → §Bridge/B7,B8；post-boundary unknown |
| MAP-5560ED4CEB | empirical-retained | managed account ordering → §Bridge/B3；preserve all tokens |
| MAP-C4E36D3BF5 | empirical-retained | native error semantics → §Bridge/B3；unknown code conservative |
| MAP-2CC312D952 | empirical-retained | contract detail completeness → §Bridge/B4；hub/leaf not inferred |
| MAP-812E5F3DBE | empirical-retained | expiry/exchange multiplicity → §Bridge/B4；unknown non-tradeable |
| MAP-47D85C4ABA | empirical-retained | summary tag coverage/duplicates → §Bridge/B4,B5；Partial |
| MAP-A914DC7B3C | empirical-retained | conId→Instrument identity → §Bridge/B4,B5；conflict unavailable |
| MAP-EA0EAB9AD4 | empirical-retained | avgCost multiplier convention → §Bridge/B5；raw facts retained |
| MAP-21AAFAB4E1 | empirical-retained | accountDownloadEnd completeness → §Bridge/B5；data readiness only |
| MAP-3AB2C8FA44 | empirical-retained | tick-code registry → §Bridge/B6；unknown raw diagnostic |
| MAP-EDE0047578 | empirical-retained | order callback lookup → §Bridge/B7；not Ack/fill/absence |
| MAP-BFAD7F58E4 | empirical-retained | native timestamp semantics → §Bridge/B3,B6；consumer tolerance required |

### 4.6 Longbridge（7 条）

Source anchors：L1=`LongbridgeBroker.ts:71-120` order/TIF mapping；L2=`:125-233` config/init/close；L3=`:237-313` catalog/details/place；L4=`:315-362` modify/cancel/close；L5=`:613-713` query/decoder/capability；L6=`longbridge-types.ts:44-90`, `longbridge-contracts.ts:33-143` raw shapes/status; L7=`node_modules/longbridge/index.d.ts:744-806,2244-2287,2918-3242` SDK declarations。

| MAP ID | 历史 disposition | 本次处置 / source anchor |
|---|---|---|
| MAP-7805D80DA1 | empirical-retained | response envelope/accepted-before-ack → §L-return/L3,L7；fixture 不证明 native |
| MAP-ABF45B8D66 | empirical-retained | error code/status/quote probe → §L-support/L2,L3；accountBalance probe 不覆盖 quote |
| MAP-B35B59A740 | empirical-retained | response schema/remote ledger → §L-return/L3,L5,L7；default-zero mock 不扩能力 |
| MAP-50CE86A3DE | empirical-retained | paper endpoint/account → §L-support/L2；paper flag/URL hint 不等 observed |
| MAP-4DE673DCFE | empirical-retained | error code/probe coverage → §L-support/L2,L5；unknown 不分类为 success/retry |
| MAP-39CF059275 | source-resolved | no release API → §L-support/L2；close no-op 是当前 source fact，不发明 hook |
| MAP-FCDA99890A | empirical-retained | endpoint/account evidence → §L-support/L2,L6；environment unknown blocks mutation |

## 5. 最终交接给 Main 的约束（不是新设计）

1. 保留四类 provider leaf 的具体编译操作数：native identity、quantity/price/TIF/trigger、namespace/symbol hints、scope/session/environment evidence。不要为了统一字段而把这些差异压成一个 provider-neutral Order variant。
2. 核心关系必须能区分 `prepare/compile`、native dispatch、provider response/ack、后续 Order observation、query coverage/absence、capability availability。当前 `PlaceOrderResult`/`OpenOrder|null`/`OpenOrder[]`/静态 `AccountCapabilities` 均不足以承载全部事实。
3. `success:true + orderState` 不是跨 provider terminal/fill/cancel confirmation；尤其 IBKR 的 waiter 和多个 adapter 的 synthetic Cancelled 必须作为具体反例保留。
4. Close、attached protection、modify 不能从 place 的公共可选参数自动推出。它们的 native operation、precondition、identity、residual/observation 和 support absence 都不同。
5. 未声明或未证实的 native capability 必须在对应 leaf 保持 absent/unavailable；不能通过 unknown→Day、unknown status→Submitted、missing timestamp→now、missing level→0、missing order→null/empty、fallback cancel/create 来制造“支持”。
6. 原生保证未知的地方继续保持 Unknown/Partial/Unavailable/ObserveRequired 这类证据边界；本稿没有引入重试、兼容层或补偿操作，也没有声称任何 runtime/e2e 结果。
