# 公开构造：Unit/扩展、异构 Provider 与 AI/CLI 外层

> 本稿只研究“作者怎样构造一项可调用且可发现的能力”，以及固定/动态结果怎样进入后继消费者。它不是 Provider 清单、CLI 产品重写或全书完成声明；不改生产代码，也不继承被否定的 event-flows、第 16 章或其派生协议。
>
> 记号：
>
> ```text
> F<A,E,R> = Effect<A,E,R>
> S<X,E,R> = Stream<X,E,R>
> R1 ⊔ R2 = 同一次解释必须同时提供的服务要求
> ```
>
> `⊔` 是 requirement 的并集，不是成功值的联合；`+` 在失败/值位置表示明确的和类型。缺陷、进程丢失和中断不被偷偷改写成作者声明的领域失败。

## 1. 先指出此前候选的真实断裂

`core-expression.md` 已经说对方向，但下列位置仍是关系断言，不是可消费的构造：

| 位置 | 已经说出的主张 | 尚未构造的关系 |
|---|---|---|
| `core-expression.md:117–131` 的 `define(σI,σA,σE,access)(h)` | 同一声明同时供调用与描述，`h` 是实际作者函数 | 没有给出 `define` 的返回值；没有说明 raw 输入怎样由 `σI` 解析、权限函数如何与 `h` 连接、失败怎样编码，也没有规定描述所读的确切闭包成员 |
| `core-expression.md:133–142` 的 `foreign(d)(i)` | encode、交换、decode 在跨进程边界完成 | 没有区分 wire transport failure、协议违约和 Provider 的声明失败；没有规定 success/failure 响应怎样判别，因而还不能把异构进程的结果送入后继 |
| `core-expression.md:144–173` 的 `Certified`、`n/v` | 动态结果可以展示，或经投影进入已知类型 | 没有构造带 binding 的动态结果，也没有写出投影/后继的输入操作数；“安装族相容”仍可能被读成一句口号 |
| `core-expression.md:175–205` 的 `retainWhen` | 外层输入是 Order、source、config、recipient 的积，内部捕获 predicate/ask/answers | 没有给出这个 HOF 返回的 Definition、实际 admission 函数、source/answer 消费函数，亦未区分初始接纳真正需要的 R 与后来 worker 才需要的 R |

因此本稿不通过给旧式 `h`、`d` 或 `retainWhen` 继续加字段来补洞，而是给出返回对象、每个函数的操作数和每个消费者的求值式。有限描述也不从任意闭包反射：作者必须把语义/codec 作为声明操作数传入，HOF 只保证调用和描述读的是同一份声明。

## 2. Unit 与扩展：先构造值，再构造计算

### 2.1 公共值的最小操作数

```text
type Result<A,E> =
  | { _tag: "Success"; value: A }
  | { _tag: "Failure"; error: E }

interface Codec<A> {
  decode(raw: WireDocument): Result<A, DecodeFailure>
  encode(value: A): WireDocument
  jsonSchema: JsonSchema
}

interface Unit<A> {
  id: UnitId
  version: Revision
  codec: Codec<A>
  meaning: SemanticDescription
}
```

`WireDocument` 是受限的跨语言编码值；外部 `unknown` 只在 `Codec.decode` 的边界进入，立即成为 `Result`，不会在核心内部以递归 JSON、map 或 `any` 继续流动。`SemanticDescription` 不是从 `Codec` 的字段名推理出来的；它由作者声明单位、约束、含义及版本。

`Unit` 不连接 Provider、不拥有 Scope、不执行 IO。它给后续构造三个东西：

1. 精确的输入/输出值类型 `A`；
2. 同一值的 parser/encoder/JSON schema；
3. 可核验的语义身份，而不只是结构 shape。

### 2.2 一个真正的积扩展

```text
type ProductValue<B,X> = Readonly<{
  base: B
  extension: X
}>

extend : Unit<B> × Unit<X> -> Unit<ProductValue<B,X>>
baseOf : ProductValue<B,X> -> B
baseOf(value) = value.base
```

`extend(base, extension)` 的 codec 同时解码两个子 codec；它不展开对象后让后者覆盖前者。实现可以使用显式的 `base`/`extension` 命名空间；若要平铺，必须在构造时证明字段不相交。基础 codec 的约束仍在积内执行，`baseOf` 保留同一个已验证的基础值。不能只复制 `.shape`，因为这样会丢失 refine、单位和跨字段约束。

如果扩展有自己的约束，它是 `extension` Unit 的约束；如果有跨 base/extension 的关系，则再传入一项以 `ProductValue<B,X>` 为输入的具名纯约束。扩展不会以“额外 metadata”逃离声明。

### 2.3 Order：共同 base，不预设 quantity/pricing

下面给一个作者可以采用的最小交易 base；它不是要求所有未来 Provider 的原生对象都长这样：

```text
type OrderBase = Readonly<{
  intent: IntentId
  instrument: InstrumentRef
  direction: Direction
}>

type OrderValue<Terms,Extra> =
  ProductValue<OrderBase, ProductValue<Terms,Extra>>

termsOf(value: OrderValue<Terms,Extra>) = value.extension.base
extraOf(value: OrderValue<Terms,Extra>) = value.extension.extension
```

`OrderBase` 没有 `quantity`、`pricing`、`session`、`option` 或任何 SDK 字段。某一作者的声明可以这样组合：

```text
const venueATerms : Unit<ATerms> = unit(
  "venue-a.terms.v1",
  product(
    sum("size",
      unitsAmount,
      cashAmount),
    sum("execution",
      marketExecution,
      limitExecution /* 此分支自身携带 limitPrice */)),
  "Venue A 的 size/execution 条款"
)

const venueAExtra : Unit<AExtra> = unit(
  "venue-a.extra.v1",
  product(session, venueFlags),
  "Venue A 的 session 与原生附加条款"
)

const venueAOrder : Unit<OrderValue<ATerms,AExtra>> =
  extend(orderBase, extend(venueATerms, venueAExtra))
```

这只是 `venueA` 作者的一次选择，不是 UTA 的 `Terms` 枚举。另一作者可以声明：

```text
type BTerms = Readonly<{
  budget: Money
  quoteMode: QuoteMode
}>
type BExtra = Readonly<{
  auctionTicket: AuctionTicket
}>

const venueBOrder = extend(orderBase, extend(bTerms, bExtra))
```

`venueB` 不需要 quantity 或 pricing 字段；如果它需要别的 size/报价关系，就在自己的 `BTerms` 中构造。核心不生成 `Order × 60` 的固定组合，也不把所有字段设成 optional。

`option` 同理：只有某个声明的 `Terms`/`Extra` Unit 含有 option 分支时，它才进入那个 Order 的 parser、描述和调用函数。不能因为另一个 Provider 有 option 就向 `OrderBase` 添一个全局可选字段。

### 2.4 Candle：完全相同的扩展规则

```text
type CandleBase = Readonly<{
  source: SourceRef
  instrument: InstrumentRef
  interval: Interval
  openedAt: Instant
  open: Price
  high: Price
  low: Price
  close: Price
  volume: Volume
}>

type CandleValue<Extra> = ProductValue<CandleBase,Extra>
```

某个来源可以构造：

```text
const candleExtra = unit(
  "venue-a.candle-extra.v1",
  product(vwap, tradeCount, nativeTimestamp),
  "Venue A 的 VWAP、成交笔数及原生时间戳"
)
const richCandle = extend(candleBase, candleExtra)
```

历史 Pull 与实时 Push 可以复用 `richCandle` 的 item Unit；Pull/Push 的交付与生命周期仍由各自计算声明，不把连续值收集成一次有限返回。

`close` 和 `vwap` 即使都编码成 decimal 字符串，也不是相同语义；`Price` 的单位、来源和 finality 仍在 Unit 中。两个 Provider 也可能都导出 `{ price: "100" }`，一个含义是 USD 的成交价，另一个含义是报价币计价的指示价；没有相同 Unit identity、单位和声明投影，不能互换。结构相同不是语义相同。

## 3. `define`：一个 HOF 同时产生 typed call、wire call 与 description

### 3.1 作者声明与实现函数是不同操作数

```text
interface Declaration<I,A,E,P> {
  id: CapabilityId
  revision: Revision
  input: Unit<I>
  success: Unit<A>
  domainFailure: Unit<E>
  access: AccessRequirement<P>
  semantics: CapabilitySemantics
}

type Authorize<I,P,Ra> =
  (principal: Principal, input: I)
    -> F<PermissionWitness<P>, AuthorizationFailure, Ra>

type Handler<I,A,E,P,Rh> =
  (input: I, witness: PermissionWitness<P>)
    -> F<A,E,Rh>

type CallFailure<E> =
  | { _tag: "InputDecode"; issue: DecodeFailure }
  | { _tag: "Unauthorized"; issue: AuthorizationFailure }
  | { _tag: "Domain"; error: E }

interface Definition<I,A,E,P,R> {
  declaration: Declaration<I,A,E,P>

  // 已经过 input codec 的 typed consumer
  invokeTyped:
    (principal: Principal, input: I)
      -> F<A, E + AuthorizationFailure, R>

  // AI/CLI 的 wire consumer；失败仍是结构化的预期失败
  invokeDocument:
    (principal: Principal, raw: WireDocument)
      -> F<WireDocument, CallFailure<E>, R>

  describe: () -> PublicDescription
}
```

`P` 是权限需求的声明类型；`PermissionWitness<P>` 是实际授权计算返回的证据，不是“环境里有 BrokerClient”就能伪造的值。`R` 是 `Ra ⊔ Rh`，并且不能因为 `invokeTyped` 最后返回 A 就抹去授权或 handler 的要求。

### 3.2 `define` 的实际构造

function define<I,A,E,P,Ra,Rh>(
  declaration: Declaration<I,A,E,P>,
  authorize: Authorize<I,P,Ra>,
  handler: Handler<I,A,E,P,Rh>,
): Definition<I,A,E,P,Ra ⊔ Rh> {
  const invokeTyped = (principal, input) =>
    authorize(principal, input).flatMap(witness =>
      handler(input, witness))

  const invokeDocument = (principal, raw) =>
    declaration.input.codec.decode(raw).fold(
      decodeFailure =>
        fail({ _tag: "InputDecode", issue: decodeFailure }),
      input =>
        authorize(principal, input).fold(
          authorizationFailure =>
            fail({ _tag: "Unauthorized", issue: authorizationFailure }),
          witness =>
            handler(input, witness).fold(
              domainFailure =>
                fail({ _tag: "Domain", error: domainFailure }),
              success =>
                succeed(declaration.success.codec.encode(success)))))

  const describe = () => deriveDescription({
    id: declaration.id,
    revision: declaration.revision,
    semantics: declaration.semantics,
    inputSchema: declaration.input.codec.jsonSchema,
    successSchema: declaration.success.codec.jsonSchema,
    domainFailureSchema: declaration.domainFailure.codec.jsonSchema,
    access: declaration.access,
  })

  return { declaration, invokeTyped, invokeDocument, describe }
}
```

上段是关系记法：实际 `Effect` 的 `map/flatMap/fold` 名称按所选库落地。关键不在某个库的语法，而在三条引用同时来自 `declaration`：

- `invokeDocument` 先解析同一 `input.codec`，再交给保存的 `invokeTyped`；
- 成功和领域失败分别使用同一 `success`/`domainFailure` codec；
- `describe` 读取同一组 codec、权限和语义 identity。

`encodeCallFailure` 还需要固定的边界失败 Unit（输入解码、授权、传输等）；它们不是把 `domainFailure` 替换成字符串。声明加载不能把不可表达 schema 降级成 `{}`。当前 CLI 在 `src/server/cli.ts:217–240` 的旧路径会在 JSON schema 转换失败时留下空 schema；公开构造不能复制这一失真行为，而应在定义/安装边界拒绝该声明或将其标为不可用。

`define` 没有也不能检查 `handler` 的任意闭包体。作者必须自己把 `semantics`、单位、约束和实现 revision 放入 `Declaration`；如果闭包行为改变但声明和实现 digest 不变，TypeScript 无法凭反射发现漂移。这个限制是事实，不是再加一个字段可以消除的。

## 4. `foreign`：异构进程只共享 UTA 边界

Provider 可以是 REST 服务、Java gateway、Python SDK 进程、WebSocket、ABI 或完全不同的程序。它们不共享 native `Contract`/`Order` 类型；共享的是某个已安装 capability 的 UTA 声明及其 wire 边界。

```text
type ForeignReply<A,E> =
  | { _tag: "Success"; value: A }
  | { _tag: "DomainFailure"; error: E }

type ForeignFailure<E> =
  | { _tag: "RequestEncoding"; issue: RequestEncodingFailure }
  | { _tag: "Transport"; issue: TransportFailure }
  | { _tag: "Protocol"; issue: ProtocolFailure }
  | { _tag: "ProviderDomain"; error: E }

interface ForeignEndpoint<I,A,E,Rt> {
  encodeRequest: (input: I) -> Result<WireRequest, RequestEncodingFailure>
  exchange:
    (request: WireRequest)
      -> F<WireResponse, TransportFailure, Rt>
  decodeReply:
    (response: WireResponse)
      -> Result<ForeignReply<A,E>, ProtocolFailure>
}
```

`decodeReply` 的实现由 Provider 作者用所选声明的 success/failure codecs 构造；它必须先识别响应分支，再解码对应 payload，不能“先当 A 解码失败再猜 E”。`WireRequest`/`WireResponse` 是外部协议边界，不把 SDK 对象带入 UTA 公共类型。

```text
foreign<I,A,E,Rt>(
  endpoint: ForeignEndpoint<I,A,E,Rt>,
): (input: I) -> F<A, ForeignFailure<E>, Rt> =
  input => endpoint.encodeRequest(input).flatMap(request =>
    endpoint.exchange(request)
      .mapError(issue => ({ _tag: "Transport", issue }))
      .flatMap(response =>
        endpoint.decodeReply(response)
          .mapError(issue => ({ _tag: "Protocol", issue }))
          .flatMap(reply =>
            reply._tag === "Success"
              ? succeed(reply.value)
              : fail({ _tag: "ProviderDomain", error: reply.error })))))
```

完整 Provider 定义由 `foreign` 处理函数和 `define` 组合；失败 Unit 必须是 `ForeignFailure<E>` 的和，而不是继续声称只有 E：

```text
const providerOrderDeclaration = declaration(
  input = venueAOrder,
  success = venueAReceipt,
  domainFailure = sum(providerRejection, providerObservationFailure),
  access = privateOrderAccess,
  semantics = venueAOrderSemantics,
)

const venueAOrderDefinition = define(
  providerOrderDeclaration,
  authorizeVenueAOrder,
  foreign(makeVenueAEndpoint(providerOrderDeclaration)),
)
```

`makeVenueAEndpoint` 可以在内部调用任意 SDK；主机只接收 `A`、`E` 或明确的边界失败。另一个 Provider 用自己的 `Terms`、`Extra`、wire request、response decoder 和失败 Unit，仍然可以由同一 `define`/`foreign` 关系安装。这里没有全局 Provider union，也没有把不同原生接口强行交集化。

## 5. 固定后继：缺少的参数必须有真实操作数

### 5.1 固定后继的最小关系

设前段和后段已经是同一编译单元内的已知定义：

```text
h  : Definition<I,A,E1,P1,R1>
mk : I × A × C -> Result<J,Em>
k  : Definition<J,B,E2,P2,R2>
```

`C` 是调用者明确给出的配置/窗口/收件人等输入；若后段所需值不能从 `I × A` 纯粹推出，就不能省略 C。固定后继 HOF 的调用和描述可构造成：

```text
thenWith(h, mk, k) : Definition<
  ProductValue<I,C>,
  B,
  E1 + Em + E2,
  P1 + P2,
  R1 ⊔ R2
>

invoke(i,c) =
  h.invokeTyped(i).flatMap(a =>
    mk(i,a,c).flatMap(j =>
      k.invokeTyped(j)))
```

`mk` 是纯函数时不增加 R；若缺失参数必须通过外部查询取得，则实际操作数是：

```text
lookup : I × A × C -> F<J,El,Rl>
```

此时 `thenWith` 的失败包含 `El`，要求包含 `Rl`，并且 lookup 是一项真实 IO，不能藏在 `decide` 或 schema 默认值里。若没有 C、纯 `mk`、或 `lookup`，后继根本没有合法输入构造；不能由“两个 schema 都有 symbol”自动猜出 J。

描述同样由这组定义生成：外层 input 是 `I × C`，success 是 B，failure 保留 `E1/Em/E2` 及阶段，权限是 P1/P2 的实际组合。`mk` 不另收一份最终结果 schema，因此不会出现“调用走 k、描述却描述另一个 D2”的错配。

### 5.2 A 已知时的消费者求值

当 `A` 在编译期已知，后继可以直接读 A 的精确字段。若 `A` 是 `CandleValue<VenueExtra>`，且消费者只依赖 base：

```text
baseCandle : CandleValue<VenueExtra> -> CandleBase
baseCandle(value) = value.base

aboveThreshold : CandleBase × Threshold -> TriggerDecision<CandleBase>
aboveThreshold(candle, threshold) =
  if decimalCompare(candle.close, threshold) > 0
    then { _tag: "Matched", evidence: candle }
    else { _tag: "NoMatch" }
```

若业务改为使用 `value.extension.vwap`，则消费者的输入关系必须改为 `CandleValue<VenueExtra>`，或者作者再提供一项明确的投影；不能继续假装 `baseCandle` 已包含 VWAP。

## 6. 动态选择：保留关联，不伪造 A

### 6.1 运行时能力的存在边界

编译后的 TypeScript 不能因为目录在运行时发现了一个新 Provider，就自动增加 `A` 的 union 成员。动态目录持有的是每个已安装定义的闭包，但对主机公开的是 binding 关联的文档：

```text
interface Binding {
  providerInstance: ProviderInstanceId
  capability: CapabilityId
  revision: Revision
  contractDigest: ContractDigest
}

interface BoundDocument {
  binding: Binding
  slot: "input" | "success" | "failure"
  payload: WireDocument
}

type DynamicResult =
  | { _tag: "Success"; value: BoundDocument }
  | { _tag: "Failure"; value: BoundDocument }
```

`SomeDefinition` 的动态调用闭包由具体 `Definition<I,A,E,...>` 安装时产生：它先按该 binding 的 input codec 解码，再按同一 binding 的 success/failure codec 编码返回。主机不把 payload cast 成某个猜想的 `A`。

```text
consumeDynamic : DynamicResult -> DynamicPresentation
consumeDynamic(result) =
  presentationOf(result.value.binding, result.value.payload)
```

这个消费者可以安全地把声明结果展示给 AI，或把它作为下一次受 binding 约束的输入；它不能从 payload 的字段名推出成交、K 线 close 或 cancel 语义。

### 6.2 动态 A 进入已知 B 的两个真实方案

**方案一：安装一项纯投影。**

```text
projectAt :
  (sourceBinding: Binding, sourceSuccess: Unit<A>, target: Unit<B>,
   convert: A -> Result<B, ProjectionFailure>)
  -> BoundDocument(success of sourceBinding)
  -> Result<BoundDocument(success of target), ProjectionFailure>
```

`convert` 是作者实际提供的纯函数；它必须说明单位、信息损失和失败。`projectAt` 先核对 source binding/digest，再解码 A、执行 convert、用 B codec 编码。没有 `convert`，不能把动态 A 当作 B。

**方案二：安装一项直接消费动态 A 的后继。**

```text
nextAt :
  (sourceBinding: Binding,
   successorBinding: Binding,
   makeInput: BoundDocument × ExplicitConfig
                 -> Result<BoundDocument(input of successor), InputBuildFailure>)
  -> F<BoundDocument, DynamicFailure, Rsource ⊔ Rsuccessor>
```

`makeInput` 可以只复制经过声明的 binding 关系，也可以消费一个外部明确输入；需要目录、账户或策略事实时，那项读取必须成为独立的 Effect。它不能从任意闭包自动求出输入前像。

若某 Provider 新增必填参数 `session`：

- 静态定义的 `I` 变成带 `session` 的新 product，所有固定后继的 `mk`/调用者都会出现真实的类型断裂，直到它们提供 session；
- 动态定义的 input schema 和 contract digest 同时改变；旧 binding 不能静默使用当前默认值；
- 若作者确实有默认政策，必须显式提供 `defaultSession : Context -> Result<Session, ...>` 或把 session 作为两阶段调用由 caller 提供，且该关系进入描述/失败；schema 自己不能选择交易时段。

这就是“保留关联”而不是“安装族相容”一句话：结果、投影、后继输入和 revision 都指向同一个 binding。

## 7. 具体作者声明：`retainWhen` 如何生成外层能力

这一节把前面的操作数真正装配成一个外层 AI/CLI leaf。它不预定义所有动作，也不让等待条件直接执行 Provider 的 native send。

### 7.1 输入和作者函数

先定义所需的形状：

```text
type RetainInput<I,J,C> = Readonly<{
  order: I
  source: J
  trigger: C
  recipient: Recipient
}>

type TriggerDecision<B> =
  | { _tag: "NoMatch" }
  | { _tag: "Matched"; evidence: B }

type RetainDisposition<I> =
  | { _tag: "Keep"; order: I }
  | { _tag: "Discard" }
```

`RetainDisposition` 是这个作者选择的政策，不是 UTA 的 Agent 回答全集；另一作者可显式声明 Replace/Amend 等不同 Unit。

连续来源只需暴露它自己的声明关系：

```text
interface StreamDefinition<J,X,Es,Rs> {
  request: Unit<J>
  item: Unit<X>
  failure: Unit<Es>
  open: (request: J) -> S<X,Es,Rs>
}
```

`retainWhen` 的真实操作数（写成最小但完整的类型依赖）是：

```text
order       : Definition<I,OrderAck,Eo,Po,Ro>
source      : StreamDefinition<J,X,Es,Rs>
project     : X -> Result<B,Ep>
triggerUnit : Unit<C>
predicate   : I × B × C -> TriggerDecision<B>
makeQuestion:
  I × X × B × C × Recipient × QuestionKey -> Q
ask         : Definition<Q,AskAck,Ea,Pa,Ra>
answers     : StreamDefinition<AnswerInput,Ans,Eb,Rb>
answerInput : Q -> AnswerInput
answerRule  : I × Q × Ans -> Result<RetainDisposition<I>,Er>
writer      : RetainWriter<I,J,C,Q,B,RetainDisposition<I>,Rw>
authorizeAdmission:
  RetainInput<I,J,C> × Principal
    -> F<PermissionWitness<Padmit>,AuthorizationFailure,Rauth>
```

`project` 可以是 `baseOf` 的已知纯投影，例如 `X = CandleValue<VenueExtra>`、`B = CandleBase`；它也可以是有失败的显式转换。`order` 被捕获是为了保留实际 Provider binding 及未来显式下单关系，但 admission 本身不会调用 `order.invokeTyped`。

`writer` 的必要操作数不是任意数据库 map，而是这些精确关系：

```text
admit:
  (input: RetainInput<I,J,C>, orderBinding: Binding, sourceBinding: Binding)
    -> F<AdmissionReceipt,AdmissionFailure,Rw>

scheduleQuestion:
  (waiting: Waiting<I,J,C>, question: Q, evidence: B)
    -> F<QuestionReceipt,WriterFailure,Rw>

applyAnswer:
  (waiting: Waiting<I,J,C>, question: Q,
   disposition: RetainDisposition<I>)
    -> F<DispositionReceipt,WriterFailure,Rw>
```

`Waiting` 保存的是原始 `I/J/C/Recipient`、Order/Source binding、intent revision 与显式的 trigger ordinal；它不是把 native handler 公开给 worker。`QuestionKey` 可由这些已经保存的身份和 ordinal 纯构造，不能从当前时间或随机数偷偷生成。

### 7.2 HOF 返回什么

```text
interface RetainCapability<I,J,C,X,B,Q,Ans> {
  admission: Definition<
    RetainInput<I,J,C>,
    AdmissionReceipt,
    AdmissionFailure,
    Padmit,
    Rauth ⊔ Rw
  >

  consumeSource:
    (waiting: Waiting<I,J,C>, item: X)
      -> F<SourceStep, Es + Ep + WriterFailure, Rs ⊔ Rw>

  runQuestion:
    (principal: Principal, question: Q)
      -> F<AskAck, Ea + AuthorizationFailure, Ra>

  openAnswers:
    (question: Q) -> S<Ans,Eb,Rb>

  consumeAnswer:
    (waiting: Waiting<I,J,C>, question: Q, answer: Ans)
      -> F<DispositionReceipt, Eb + Er + WriterFailure, Rb ⊔ Rw>
}
```

外层 admission 的 schema 是 HOF 内部实际构造的 product：

```text
admissionInputUnit = product4(
  order.declaration.input,
  source.request,
  triggerUnit,
  recipientUnit,
)

admission = define(
  declaration(
    id = "retain-when",
    revision = retainRevision,
    input = admissionInputUnit,
    success = admissionReceiptUnit,
    domainFailure = admissionFailureUnit,
    access = admissionAccess,
    semantics = retainSemantics,
  ),
  authorizeAdmission,
  input => writer.admit(
    input,
    orderBinding = orderBindingOf(order),
    sourceBinding = sourceBindingOf(source),
  ),
)
```

因此同一次 HOF 构造得到：

1. `admission.invokeTyped(principal, input)`，它只接收完整的 `RetainInput<I,J,C>`；
2. `admission.invokeDocument(principal, raw)`，它按上面相同的 product codec 解析 AI/CLI 输入；
3. `admission.describe()`，它从同一 product、receipt、failure 和 access 声明生成精确 schema。

它没有维护第二份 `CLI_EXPORTS` 参数表。外层只返回本地接纳 receipt；`source`、`ask`、`answers` 的 requirements 不是因为它们被捕获就假装已经在初次 admission 中执行。

### 7.3 消费者的实际求值

下面给出一项具体作者政策。`richCandle : CandleValue<VenueExtra>`，`project = baseOf`，阈值 `trigger.threshold` 是 `Decimal`，问题发送给 `recipient = agent`。

```text
predicate(i, base, config) =
  if decimalCompare(base.close, config.threshold) > 0
    then { _tag: "Matched", evidence: base }
    else { _tag: "NoMatch" }

makeQuestion(i, x, base, config, recipient, key) =
  Question(
    key = key,
    recipient = recipient,
    intent = i.intent,
    trigger = base.close,
    threshold = config.threshold,
    orderBinding = capturedOrderBinding,
  )

answerRule(i, q, answer) =
  match answer with
  | Keep    -> { _tag: "Success", value: { _tag: "Keep", order: i } }
  | Discard -> { _tag: "Success", value: { _tag: "Discard" } }
```

`Keep`/`Discard` 的解析必须由 Answer 的精确 Unit 完成；`answerRule` 不调用 order handler。

`consumeSource` 的实际函数是：

```text
consumeSource(waiting, x) =
  project(x).flatMap(base =>
    match predicate(waiting.order, base, waiting.config) with
    | NoMatch ->
        succeed({ _tag: "Ignored" })
    | Matched(evidence) ->
        let key = questionKey(waiting.intentRevision, waiting.triggerOrdinal)
        let q = makeQuestion(
          waiting.order, x, evidence, waiting.config,
          waiting.recipient, key)
        writer.scheduleQuestion(waiting, q, evidence)
          .map(receipt => { _tag: "QuestionScheduled", receipt }))
```

这里的顺序事实是当前 `consumeSource` 的求值，不是全局事件协议：先解码/projection，再纯谓词，再以 writer 接纳问题关系。`scheduleQuestion` 成功不等于 `ask` 已发送；`runQuestion` 是另一个明确的消费者：

```text
runQuestion(principal, q) = ask.invokeTyped(principal, q)
```

它返回 `AskAck`，只表示 ask 声明的接纳/调用结果。若要消费回答，必须另开同一 `question` 关联的订阅：

```text
openAnswers(q) = answers.open(answerInput(q))

consumeAnswer(waiting, q, answer) =
  answerRule(waiting.order, q, answer).flatMap(disposition =>
    writer.applyAnswer(waiting, q, disposition))
```

`Keep` 使 writer 保存原意图及其原 Order binding；`Discard` 关闭等待意图。二者都不从 Answer 自动调用 Provider native send。作者若确实要在 Keep 后发送，必须另外构造一个接收 `RetainDisposition<Keep>` 的明确 `send` 后继，并再次满足该 Order definition 的权限、输入和恢复条件；receipt 不能把私有 handler 变成公共发送函数。

### 7.4 手工检查一条完整值路径

| 已有输入 | 求值 | 可观察结果 |
|---|---|---|
| CLI/AI 给出 `order:I`、`source:J`、`trigger.threshold=100`、recipient | `invokeDocument` 用 HOF 生成的 product codec 解码，授权后执行 `writer.admit` | 返回 `AdmissionReceipt`；保存完整 I/J/config/recipient 与两个 binding；没有 Provider order call |
| source 产生 `x1:richCandle`，`baseOf(x1).close=99` | `project(x1)`，然后 `predicate(...)=NoMatch` | 没有问题、ask 或发送；普通显示消费者仍可独立显示 x1 |
| source 产生 `x2`，`baseOf(x2).close=101` | 纯 `predicate` 命中；`questionKey`、`makeQuestion`、`writer.scheduleQuestion` | 保存带原意图和 source evidence 的问题关联；随后才由 owner 解释 `ask`/`answers` |
| `ask` 返回 `AskAck` | `runQuestion` 的 `A=AskAck` 交给其指定后继 | 得到投递/调用的精确结果；不能将 Ack 解释成 Keep/Discard |
| answers 产生 `Keep` | `answerRule` 构造 `RetainDisposition<Keep>`，`writer.applyAnswer` | 状态保留原 I 与 Order binding；没有 native send |
| answers 产生 `Discard` | `answerRule` 构造 `Discard` | 状态关闭等待意图；没有“补偿一个从未发送的订单” |

这个例子只用了 `CandleBase.close`。如果业务改为 `richCandle.extension.vwap`，必须把 `predicate` 的输入改成 rich Candle 或安装 `vwap` 投影；`baseOf` 不会凭空产生它。若 source 的新增字段是必填，`source.item` codec、动态 item schema 和 binding digest 一起改变，缺字段在 source 解码处失败。

## 8. AI/CLI 外层：从最终 Definition 生成，而不是手写动作表

对任意 `Definition`（包括 `venueAOrderDefinition` 或 `retain.admission`）使用同一个薄外层：

```text
interface PublicLeaf {
  path: CapabilityPath
  description: PublicDescription
  invoke:
    (principal: Principal, raw: WireDocument)
      -> F<CallResultDocument, PublicCallFailure, RuntimeRequirements>
}

toPublicLeaf(definition) = {
  path: pathFrom(definition.declaration.id),
  description: definition.describe(),
  invoke: definition.invokeDocument,
}
```

`toPublicLeaf` 只消费 `Definition` 已经给出的描述和调用闭包，不知道 Order/Candle/Provider 的业务字段。AI 得到 input/success/failure schema、语义版本、权限和当前 binding；CLI 把 raw document 交给同一个 `invokeDocument`。自然命令名、帮助和层级是展示层选择，不生成第二个参数契约。

这并不意味 CLI “未定义”：每一片叶子的 schema 是确定的，只是叶子由已安装声明计算得到。也不意味任意闭包都可被发现：没有 `Declaration`、codec、binding 和实现关联的普通函数只能作为内部计算，不能冒充自描述能力。

### Provider 专有能力的可观察后果

| 情形 | 正确的公开结果 | 禁止的替代 |
|---|---|---|
| Provider 声明了 `cancel` 定义 | 目录中出现这个 definition 的 cancel leaf；其 input/success/failure/access 都来自该定义 | 在全局 Order 上放 `cancel?:`，然后所有 Provider 都暴露一个可能返回 `not supported` 的命令 |
| Provider 没有 `cancel` | 没有 cancel leaf；AI 不能调用不存在的能力 | 用空 schema 或万能 cancel handler 掩盖缺席 |
| Provider 的 Order Terms 含 option 分支 | 该 Order 的 product/sum schema 含 option 所需精确字段；调用函数接收对应值 | 因另一个 Provider 支持 option 就把 option 加到 OrderBase |
| Provider 没有 option | 该声明的 parser/description 中没有 option 分支 | 接收任意 option JSON 后在 native 端猜测 |
| 新增必填 `session` | 同一 product codec、`describe` 和 invoke 同时要求 session；固定后继必须补真实输入/适配器 | 运行时替 caller 选默认 session |
| 两个能力 JSON shape 相同而含义不同 | Unit identity/单位/来源不匹配时拒绝；需要显式 projection | 以结构相同、字段同名或 `as` cast 互换 |

## 9. 关系的边界与能保证的内容

这份构造能保证的，是在作者履约前提下：

- product 扩展同时保留 base/extension codec、约束和投影；新增字段会进入同一声明消费，不会被 shape 展开静默丢掉；
- `define` 的 typed call、wire call、描述和失败 schema 引用同一份声明；调用函数不会与另一份 CLI 参数表漂移；
- `foreign` 在 UTA 边界区分 Provider domain failure、transport、协议和请求构造失败，native SDK 不越界；
- 固定后继只有在前段得到 A 且显式 `mk`/`lookup` 产生合法 J 时才消费 k；失败和 requirement 不被擦除；
- 动态 A 以 binding 关联文档保留；进入已知 B 必须有 binding 核对及安装的纯投影/显式适配，不能靠同形 JSON；
- `retainWhen` 初始 admission 只接纳等待意图，source/ask/answer 是各自实际消费者；Ack、Keep、Discard 不互相冒充；
- `toPublicLeaf` 对最终 Definition 生成确定 schema 和调用入口，但不从任意闭包反射，也不需要预定义一张所有动作表。

不能由这些关系自动保证 Provider 实现诚实、不同来源的业务等价、远端幂等、连续流终止、成交判据或任意动态 A 的已知投影。缺失对应声明/函数/权限/输入时，正确结果是构造失败、能力不可用或保持动态文档，而不是补默认值。

本稿是来源回查、类型关系、闭包构造和手工求值；按本轮要求未运行 build、lint、formatter、tests 或产品 runtime，亦未修改原始材料和生产代码。
