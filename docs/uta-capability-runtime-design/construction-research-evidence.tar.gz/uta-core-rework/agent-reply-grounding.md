# Alice Workspace/Agent 回复与 UTA 可见入口核查

## 研究边界与证据等级

本材料只核查当前源码中已经存在的 Alice Workspace/Agent 接纳、启动、结果读取、回复落盘，以及 UTA 当前可见入口。先读取了 `docs/README.md`，按 owner 表定位了 `docs/project-structure.md`、`docs/workspace-issues-and-scheduling.md`、`docs/conversation-provenance.md`、`docs/workspace-agent-guidance.md`；随后以 `src/`、`services/uta/src/`、`packages/uta-protocol/src/` 的当前实现为事实源。

- `[S]`：当前源码路径实际执行/持久化的行为。
- `[I]`：owner 指南或类型/工具接口承诺；不能单独证明外部进程已运行。
- `[U]`：本次没有调用或启动的外部行为，不能从源码推断成功。

按任务约束，本材料不把旧 event stream、旧 EF/Slot 帧、旧 §11 阶段机或 threshold-policy 研究当作行为事实；也不修改核心抽象或业务文档。

## 结论摘要

1. `[S]` Alice 已有一条可完整追踪的“人类 Issue 评论让 Agent 回复并把最终答案写回 Issue”路径。它覆盖了目标解析、接纳、异步任务记录、子进程运行、结构化结果、最终回复 comment、delivery 状态和 provenance。
2. `[S]` `conversation_ask` 的 `dispatched`/工具层 `running` 只表示通过了接纳并创建了任务；它不是 Agent 子进程已经成功启动的证明。任务先以 `status: running` 持久化，之后才 fire-and-forget 启动子进程；真正的启动证据是 `processStarted`/`spawn`。
3. `[S]` 当前公共身份分层可消费：`taskId` 是一次执行，`resumeId` 是产品 Session，`agentSessionId` 是 Agent 原生后端 Session。`taskId` 贯穿 headless 任务、对话审计日志和 Issue 回复；`agentSessionId` 只用于重新打开原生运行时，不跨入产品 provenance。
4. `[S]` 通用 `conversation_ask` 只返回任务地址并允许 `await/read` 取 `assistantText`；它不会自动把通用回复写入 Inbox，也不会把回复提交给 UTA。当前真正的自动最终回复消费者是 Issue comment 专用完成器。
5. `[S]` UTA 当前只有 health/trading/simulator HTTP 路由；协议和 Alice UTA SDK 暴露的是一次性 HTTP 查询/写入与历史 K 线读取。当前代码没有 Candle 订阅传输、UTA→Alice 回调、Order 状态事件到 Agent 的调用，或通用的 Order inquiry/reply consumer。
6. 因此“特定 Candle 订阅触发等待 Order，再按配置返回 Agent 询问保留/如何保留”目前只能停在业务边界缺口：需要业务适配层提供触发事件身份、等待订单关联、产品 Session/Workspace 目标、task 结果关联及 typed decision 消费。不能通过给核心 Candle/Order/Agent 增字段或套用 Issue 字段来假装该路径已经存在。

## 1. Alice 的真实可见入口与接纳契约

### 1.1 公共命令只提供 Workspace 协作入口

`alice-workspace` 的命令目录有 `conversation.ask/await/collect/read`、`inbox.push/read/ask`、`issue.update/comment/create/list/show/ask`，但没有 UTA、Candle、Order 订阅或 Order Agent 回复命令（`src/server/cli-commands.ts:166-218`）。

`conversation_ask` 的描述和 schema 只允许一种目标：

- `resumeId`：继续一个已知产品 Session；
- `inboxId`：询问某个 Inbox 条目的可归因发送者；
- `issueId`（可带 `wsId`）：Issue provenance 的 creator；
- `wsId`：在指定 Workspace 创建新 worker；
- `harness`：在默认 Chat/AutoQuant/Prediction Workspace 创建新 worker。

工具强制目标数为一（`src/tool/conversation.ts:167-239`）。底层 `WorkspaceConversationTarget` 也只有 `resume/workspace/harness/inbox/issue/report/trade-decision` 等 Workspace 产品目标，没有 UTA、Candle 或 Order variant（`src/core/workspace-tool-center.ts:45-123`）。这说明当前 Agent 接纳入口是 Workspace 协作 API，不是 UTA 事件入口。

### 1.2 “接纳”与“实际启动”是两个边界

`createWorkspaceConversationControl.ask` 先解析目标；无法解析时记录 `runtime.rejected` 并返回 `unavailable`。可解析后，它会验证 Workspace、固定 Session 的 Agent 约束、Agent adapter 的 headless 能力，再调用 `dispatchHeadlessTask`（`src/workspaces/conversation-control.ts:275-375`）。

实际异步 dispatch 的前置检查包括：

- Workspace 必须仍为 active；
- adapter 必须声明 headless 能力并能组装命令；
- 当前运行数不能达到 `MAX_CONCURRENT_HEADLESS`；
- 精确 `resumeId` 必须存在、未 retired/deleted、属于同一 Workspace 和 Agent、已有 `agentSessionId`；
- 同一精确 Session 必须不在运行，并且要先 `claimResume`，以阻止两个 HTTP 请求同时写同一原生 transcript；
- 新 Session 才能使用本次显式 runtime selection，精确继续则复用持久化 binding。

这些条件和 lease 逻辑在 `src/workspaces/service.ts:1819-1897`。它们证明的是“请求被允许创建一次执行”，不是外部 Agent 已经活着。

通过前置检查后，服务按以下顺序写入本地状态：

1. `SessionCoordinator.ensure` 获取或创建产品 `resumeId`，并写入 Session roster；
2. `HeadlessTaskRegistry.create` 生成唯一随机 `taskId`，以 `status: running` 持久化任务；
3. ResumeRegistry 记录 `latestTaskId`，Session 状态变为 running；
4. 若是对话请求，写一条 `conversation.dispatched` 审计事件；
5. 然后才以 `void runHeadlessTaskMethod(...)` fire-and-forget 执行（`src/workspaces/service.ts:1901-1977,1994-2075`；任务记录字段见 `src/workspaces/headless-task-registry.ts:87-142,201-243`）。

因此，接纳响应中返回的 `taskId/resumeId` 可以作为后续关联键，但不能被消费方解释为“Candle 触发的 Agent 已经成功启动”。

### 1.3 实际启动证据和 Agent 身份

`runHeadlessTaskMethod` 组装命令、环境和日志路径，把 `AQ_RUN_ID=taskId`、`OPENALICE_RESUME_ID=resumeId`、`OPENALICE_SIGNATURE=@resumeId` 注入 headless 子进程环境，再把 adapter 的 session-id、assistant-text、output-event 解析 hook 交给 `runHeadlessTask`（`src/workspaces/service.ts:1656-1803`）。

`runHeadlessTask` 的行为是：

- 命令解析/系统错误在 spawn 前失败时，返回 `processStarted: false`、稳定的 `launchErrorCode`、无 `agentSessionId`；
- `child.once('spawn')` 后才把 `processStarted` 置为 true；
- stdout 通过 adapter hook 提取原生 `agentSessionId`、assistant text 和结构化 output event；
- 进程退出后写结构化 snapshot、stdout/stderr 尾部和终态结果（`src/workspaces/headless-task.ts:318-424,427-471,480-571`）。

`taskId`、`resumeId`、`agentSessionId` 的职责不能混用：

- `taskId`：一次 headless execution，亦是 `AQ_RUN_ID` 和结果/回复关联键；
- `resumeId`：跨多个 headless turn 稳定的产品 Session 身份；
- `agentSessionId`：adapter 从 Agent stdout 抓到的原生后端 id，缺失时该 Session 不能被精确 resume。

任务记录明确把 `agentSessionId` 标为 adapter-native 且只用于 reopen（`src/workspaces/headless-task-registry.ts:87-137`）；它不是 UTA 可消费的业务订单身份。

### 1.4 结果读取、回复来源与审计日志

`conversation.read` 通过 `taskId` 读取 `HeadlessTaskRegistry` 与结构化 snapshot，返回 status、resumeId、workspace、agent、assistant text、错误和结构化内容；`conversation_await` 只是以 250ms 间隔轮询同一个 read，直到终态或等待预算耗尽（`src/workspaces/conversation-control.ts:408-428`；`src/tool/conversation.ts:31-72,75-142`）。这是一条“任务结果可读取”的契约，不是自动回复投递契约。

`AgentConversationLog` 会按 `taskId` 记录 `conversation.dispatched` 和 `conversation.completed`，其中完成事件带 `assistantText`、status 和 error。该日志文件明确声明自己是 analysis/audit projection，`HeadlessTaskRegistry` 才是 execution truth，日志不是 dispatch authority（`src/workspaces/agent-conversation-log.ts:1-12,32-78,139-223`）。

通用 `conversation_ask` 的执行函数在得到 `dispatched` 后，只返回 task/resume/workspace/agent/resolution；若请求 `await`，再将 `conversation.read` 的结构化结果合并到返回值（`src/tool/conversation.ts:75-142`）。该路径没有调用 `inbox_push`，也没有调用 UTA SDK。因此：

- Agent 可以通过自身显式调用 `inbox_push` 产生 Inbox 条目；
- 调用方可以消费 `conversation_read/await` 的 `assistantText` 并自行持久化；
- 但“通用 Agent 回复自动成为 UTA 的订单决定”不是当前契约。

## 2. 一条已经完整落地的真实分支：Issue 评论到最终回复

为核对“接纳—启动—结果—最终消费”的完整链路，当前最小真实分支是人类在 Issue 上发表评论。它不是 Candle/Order 业务，只用来证明现有 Alice 回复基础设施的边界。

### 2.1 入口和接纳

`POST /api/issues/:wsId/:id/comments` 会：

1. 校验 Workspace/Issue id 和评论文本；
2. 以 `human` 作者将源评论写入 `<issue>.comments.json`；
3. 写入人类评论的 provenance；
4. 调用 `dispatchIssueCommentReply`；
5. 对 `scheduled` 结果把源评论 delivery 写为 `pending(targetResumeId, taskId)`，然后返回 Issue detail（`src/webui/routes/issues.ts:374-437`）。

`dispatchIssueCommentReply` 的目标规则是当前业务专用契约：

- 固定 Issue owner 存在时，询问该精确 `resumeId`；
- 没有固定 owner 且来源是人类时，按 Issue creator provenance 解析并允许 reconstruction；
- 没有固定 owner 的非人类 note 不自动 fan-out；
- 没有 conversation control、目标不可达、Workspace/Agent/runtime/capacity 出错，都返回 failed delivery；
- ask 时给任务附加 `HeadlessInquirySubject={kind:'issue',workspaceId,issueId,relation,commentId}`，所以完成器知道要回答哪条评论。

具体调用和 subject 在 `src/workspaces/issues/comment-delivery.ts:43-132`。这个 `subject` 是现有 Issue 业务的可消费关系，不是公共 Candle/Order 关系。

### 2.2 启动与最终保存

服务 dispatch 会先持久化任务和 pending 状态，再启动 headless 子进程。运行期间，结构化 progress 会更新任务，并且只在 `subject.kind === 'issue'` 且有 `commentId` 时更新源评论的 pending progress（`src/workspaces/service.ts:1994-2048`）。

进程终止后，无论正常返回还是异常分支，服务都会：

- 根据结构化结果计算 headless status；
- 更新 `HeadlessTaskRegistry` 的终态、退出信息、`processStarted`、错误和 output summary；
- 写 `conversation.completed`（如果这是 conversation dispatch）；
- 调用 `completeIssueCommentInquiry`（`src/workspaces/service.ts:2075-2233`）。

完成器只处理带 Issue `commentId` 的 inquiry（`src/workspaces/service.ts:895-939`），然后 `recordIssueCommentReply`：

- 当 status 为 `done` 且有非空 `assistantText` 时，以 `comment-reply-${taskId}` 作为稳定回复 comment id；
- 回复作者使用 `@resumeId` 签名，并设置 `replyTo` 为源评论 id；
- 写一条带 `issue-comment-reply:${taskId}` fingerprint 的 provenance；
- 将源评论 delivery 更新为 `replied(targetResumeId,taskId,replyCommentId)`；
- 将回复投影到 Desk。

这些最终消费和保存规则在 `src/workspaces/issues/comment-delivery.ts:135-218`，delivery 的 tagged union 在 `src/workspaces/issues/comments.ts:56-105`。

这是当前源码中已经完整闭合的“结果变成用户可见 durable reply”的路径。它成立的关键不是 Agent 对话本身，而是 Issue 业务提供了 `subject.commentId` 和专用 completion consumer。

### 2.3 失败、忙和重复语义

| 边界 | 当前可核实行为 | 持久化后果 |
|---|---|---|
| 输入文本/Issue 不合法 | 路由返回 400/404/422；不会进入 Agent dispatch（`src/webui/routes/issues.ts:380-402`） | 没有源评论或只保留既有文件 |
| conversation control 不可用 | `dispatchIssueCommentReply` 返回 failed delivery（`src/workspaces/issues/comment-delivery.ts:69-77`） | 源评论已保留，delivery 记录失败 |
| 精确 owner 不存在、retired、deleted、wrong workspace/agent、not ready 或 busy | `conversation.ask`/`dispatchHeadlessTask` 返回 unavailable 或抛出对应错误（`src/workspaces/conversation-control.ts:275-314`；`src/workspaces/service.ts:1846-1877`） | 源评论保留，delivery 记录失败；无固定 owner 时仅可按 creator/reconstruction 分支 |
| headless capacity 已满、Workspace 停止接纳或 adapter 无 headless | dispatch 抛错，被 Issue dispatch 转成 failed delivery（`src/workspaces/service.ts:1834-1841`；`src/workspaces/issues/comment-delivery.ts:123-131`） | 源评论保留，未形成可消费的 pending reply |
| 外部命令在 spawn 前失败 | `processStarted:false`，有 `launchErrorCode` 和错误文本，无原生 session id（`src/workspaces/headless-task.ts:388-424,449-462`） | 任务 failed，Issue delivery 最终 failed，不生成回复 comment |
| Agent 退出但没有最终 assistant text | `recordIssueCommentReply` 将 `done` 但无 reply 视为失败 | delivery failed，写 Desk failure，不生成空回复（`src/workspaces/issues/comment-delivery.ts:195-217`） |
| 同一完成结果被重复处理 | 回复 id 固定为 `comment-reply-${taskId}`；同 Issue sidecar 的 read-modify-write 由 mutation chain 串行化，重复 id 返回 `created:false`（`src/workspaces/issues/comments.ts:157-218`） | 不追加第二条相同回复；provenance fingerprint 也会返回既有记录（`src/core/provenance-store.ts:139-147`） |
| 同一人类 POST 请求被重试 | 路由不提供业务幂等键；没有 `options.id` 时源 comment id 使用随机 UUID（`src/workspaces/issues/comments.ts:203-218`） | 每个重试可能产生新的源评论和新的 Agent task；只有完成重放具备上述稳定回复 idempotence |
| 两次对同一 fresh Workspace 的 `conversation_ask` | Headless registry 每次分配新的随机 task id；当前没有外部 trigger identity/dedup key | 两个独立执行；不能把 taskId 随机唯一误作业务事件去重 |

这个表揭示了可复用的最小模式：**业务入口自己持久化 source；dispatch 返回 task/resume；完成器用稳定业务关系消费 assistantText；回复写入使用稳定 id 和 mutation serialization。** 通用 conversation surface 本身只提供中间两步。

## 3. 当前 UTA / Candle / Order 的真实可见契约

### 3.1 UTA 服务没有 Workspace/Agent 回调入口

UTA 启动时建立的 HTTP app 只有 health、`/api/trading` 和 `/api/simulator`；`UTAEngineContext` 仅暴露 `utaManager`、`fxService`、可选 `snapshotService`，没有 Workspace、Agent、Inbox 或 conversation service（`services/uta/src/main.ts:143-168`；`services/uta/src/types.ts:1-30`）。

所以即使 UTA 内部观察到订单状态，当前 UTA 进程也没有源码路径把该状态回调到 Alice Workspace 或直接创建 Agent inquiry。

### 3.2 协议是一次性 HTTP + 查询，没有 Candle subscription

底层 `UTAClient` 的请求最终等待一个 HTTP response；公开 helper 是 request/get/post/put/delete，不是 stream、subscription 或 webhook consumer（`packages/uta-protocol/src/client/UTAClient.ts:22-29,63-99`）。`IBroker` 的连接 push listener 只针对 `BrokerConnectionStateEvent`；交易操作和查询包括 `getQuote`、`getOpenOrders`、`getOrder`、`getHistorical`，没有 market-data subscription 或 Candle callback（`packages/uta-protocol/src/types/broker.ts:475-498,524-595`）。协议 schema barrel 当前也为空（`packages/uta-protocol/src/schemas/index.ts:1-10`）。

Alice 侧 `UTAAccountSDK` 对应的是账户、订单、quote、market clock、historical bars，以及 stage/commit/push/reject/sync 的 HTTP delegation；没有 `subscribe`、Inbox、conversation 或 Agent reply 方法（`src/services/uta-client/UTAAccountSDK.ts:126-195,226-341`）。

### 3.3 Order 状态当前由轮询更新到 UTA 内部 Git

UTA 启动一个 10 秒 pending lane 和较慢的 external-order observation lane；`startOrderSyncPoller` 每 tick 遍历健康账户，调用 `observeExternalOrders`、`getPendingOrderIds` 和 `uta.sync()`，只记录日志，不调用 Workspace/Agent callback（`services/uta/src/main.ts:116-128`；实际 tick 在 `services/uta/src/domain/trading/order-sync-poller.ts:39-105`）。

`UnifiedTradingAccount.sync()` 读取 pending order，向 broker 查询 open/order 状态，生成 `OrderStatusUpdate`，然后执行 `git.sync`；这改变 UTA 的持久化交易状态，没有向 Alice 发布 Order transition event（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:827-915`）。当前可见的 `onPostPush/onPostReject` callback 只是账户操作后的 hook，现有 UTA 初始化用它们触发 snapshot；它们不是成交/订单状态 Agent 通知（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:41-47`；`services/uta/src/main.ts:102-108`）。

UTA trading HTTP 确实有 stage modify/cancel、commit、push/reject 等写入口，但它们是请求—响应操作，且 push/reject 使用 `expectedPendingHash` 保护 pending commit 一致性；没有“收到 Agent 答复后按订单身份继续操作”的调用边（`services/uta/src/http/routes-trading.ts:421-496,498-606`）。

### 3.4 当前 K 线是 pull contract；`subscription` 不是已存在的 live callback

当前 BarService 只暴露 `searchBarSources` 和 `getBars` Promise；UTA bar account 只要求 `getHistorical`，没有 subscribe/push method（`src/domain/market-data/bars/types.ts:111-158`）。UTA 分支实际组装 `BarParams` 后调用 `acct.getHistorical({aliceId: barId}, params)`（`src/domain/market-data/bars/bar-service.ts:237-274`），Web route 也是 `GET /api/bars` 后返回 `{results,meta}`（`src/webui/routes/bars.ts:20-59`）。

`BarCapability` 中的 `'subscription'` 出现在 bar source/meta 的 capability/quality 标签中（`src/domain/market-data/bars/types.ts:67-80`）；在这个 pull-only Service contract 里，它不是已实现的订阅传输、事件回调或 Candle trigger。不能把这个字符串当作特定 Candle 订阅已经存在的证据。

### 3.5 本次调查范围内未发现 UTA→Alice reply call/type

对以下当前源码范围进行了定位：

- `services/uta/src` 的服务入口、trading/simulator routes、UTA manager、order-sync poller、UnifiedTradingAccount；
- `packages/uta-protocol/src` 的 broker types、client、schemas；
- Alice `src/services/uta-client` SDK、trading proxy、bars route、Workspace CLI/Agent conversation surface。

在该范围内没有对应的 UTA→Alice callback endpoint、Candle event wire type、Order inquiry subject、Agent reply callback 或 UTA consumer。这里的结论只限于上述源码范围，不延伸为对外部交易所 SDK 行为的断言。

## 4. 对“Candle 触发等待 Order，再询问 Agent”的最小业务连接

这部分是业务边界条件，不是已经存在的公共规则；不改核心字段，也不把候选回答政策升级成 UTA/Workspace 全局工作流。

### 4.1 需要先补齐的输入与关联

特定 Candle 订阅触发至少要能给出以下业务输入：

- 订阅/事件的稳定身份和版本或时间点；
- 被触发的具体 contract/bar identity 及事件语义（例如哪一个 bar 完成、哪一个价格条件命中）；
- 等待中的 Order 身份、UTA/account scope、当前生命周期和可变更版本；
- 该订单属于哪个产品 Session/Workspace，或者允许哪种 provenance-aware reconstruction；
- 此次询问的持久关联键，以及重复 Candle event 的去重语义。

当前 UTA broker/protocol 没有第一项的订阅事件契约，当前 `HeadlessTaskTrigger` 只有 Issue variant、`HeadlessInquirySubject` 只有 Inbox/Issue variant（`src/workspaces/headless-task-registry.ts:41-85`）。这不是建议把 Candle/Order 字段塞入 core；而是说明应由该业务自己的 adapter/store 保存外部 event↔waiting-order↔task 的关系。

### 4.2 Agent 询问只能复用接纳/读取，不会自动完成订单消费

若业务边界已经提供了上述稳定关系和目标映射，最小可复用路径是：

1. 业务 adapter 解析到一个可接受的产品 Session target：精确 `resumeId`，或明确允许 reconstruction 的 Workspace/来源；
2. 调用既有 `WorkspaceConversationControl.ask`，将询问作为普通 Agent prompt；
3. 持久化返回的 `taskId`、`resumeId` 和业务 event/order 关系；只有这一步成功才算 Alice 接纳，不把返回的 task id 当作子进程启动证明；
4. 以 `conversation.read/await` 消费终态 `status` 和 `assistantText`，或由业务边界监听 headless completion；
5. 在业务边界把自由文本解析成该实例的 typed decision，例如“原样保留、按配置修改后保留、取消/放弃”。这些只是该订单业务的候选分支，必须由具体配置和订单状态决定，不是通用 Agent policy；
6. 在重新读取订单状态并执行一致性检查后，调用现有 UTA stage modify/cancel 或相应交易写入口；
7. 持久化 event/order/task/decision/result，使用稳定 event identity 防止重复 Candle event 或重复完成消费。

现有 `conversation.ask` 若不传 `subject` 仍可启动 Agent，但 core 就没有可查询的 Order inquiry reverse link；此时 event↔task 关系必须完全由业务 adapter 持久化。若试图直接复用 `HeadlessInquirySubject`，当前 union 只能表达 Inbox/Issue，会把非 Issue 业务错误地伪装成 Issue。

### 4.3 “保留/如何保留”的下游安全边界

Agent 的 `assistantText` 只能是结果载荷，不能直接当作交易写操作。业务消费者仍需：

- 确认对应的 task 是自己这次 Candle/order inquiry，而不是同 Session 的另一轮；
- 确认回复已达终态且不是 launch/runtime failure；
- 重新读取订单生命周期，处理在 Agent 等待期间已成交、取消、过期或被其他操作者修改的情况；
- 对 typed decision 与允许的订单动作做显式解析和拒绝非法答案；
- 使用 UTA 现有的状态/预期 hash 等一致性保护后再写入。

当前 UTA 暴露了 stage-modify/stage-cancel 和 push/reject HTTP 操作，但没有把这些操作与 `conversation.read` 结果连接起来。因此，缺少业务 consumer 时，最多只能得到 Agent 的可读回复，不能声称订单已经被“保留”或“按回复修改”。

### 4.4 条件性最小分支

只有在业务适配层同时提供“真实 Candle event + waiting Order durable record + Session/Workspace target + task/result 关联 + typed decision consumer”时，才可形成该业务的端到端分支：事件命中后询问 Agent，Agent 终态回复被该订单业务消费，再以订单当前版本执行动作并写结果。

如果任一项不存在，当前正确结论是“该边界未接入/不可用”，而不是复用 Issue 的 `commentId`、把 `BarCapability:'subscription'` 当事件、把随机 `taskId` 当事件幂等键，或把通用 `conversation.completed` 审计记录当作 UTA 已收到决定。

## 5. 外部行为仍未核实

- `[U]` 本次没有启动任何 native Agent CLI；adapter 的 stdout session-id、assistant-text 和 output-event 解析 hook 只证明 Alice 定义了接收接口，不能证明某个外部 Agent 实际发出这些行或按预期退出。
- `[U]` 本次没有连接交易所/券商 broker，也没有验证外部 SDK 是否另有 websocket/stream 能力。当前仓库的 `IBroker` 与 UTA HTTP/protocol 没有公开这种能力，因此不能把外部能力倒推为当前 UTA 契约。
- `[S]` 在当前仓库可见边界内，Alice 已能消费 headless 结构化结果；Issue comment 是已实现的最终回复保存者；UTA 没有对应的 Agent reply consumer。

## 可复用契约清单

| 能力 | 当前可复用事实 | 不能越界解释为 |
|---|---|---|
| 接纳 | `conversation.ask` 解析 target、检查 runtime、创建 `taskId/resumeId` 并返回 | Agent 子进程已成功启动 |
| 精确继续 | `resumeId` + `agentSessionId`，并用 `claimResume` 防止同一 Session 并发 turn | 业务事件幂等 |
| 新执行 | `HeadlessTaskRegistry.create` 分配随机 `taskId`，保存 inquiry（若有） | Candle event/order 的稳定 identity |
| 启动证明 | `processStarted` 和 `spawn` 回调；失败有 `launchErrorCode` | 外部 CLI 语义已被本次研究验证 |
| 结果关联 | `taskId` 关联 registry、structured snapshot、conversation log、Issue completion | UTA 已订阅或收到回复 |
| 最终回复 | Issue 专用 completion 用稳定 comment id、replyTo、delivery、provenance 完成消费 | 通用 conversation 自动写 Inbox/UTA |
| UTA 写入 | 现有 stage/commit/push/reject/cancel 路由 | Agent 回复自动驱动订单动作 |
| Candle 数据 | 当前 `getBars/getHistorical` pull contract，`subscription` 只作为 capability label | 已有 Candle live trigger |
