# Broker accommodation draft

> 本稿是给 Main 整合用的候选承接正文，不是新的权威模型、实现代码或全量问题索引。它把六组已经回到当前 source 的业务，分别写成“具体输入 → 目标构造 → 原生解释 → 结果消费者”的实例。公共构造只在第 0 节出现一次；各 Provider 不共享一套参数表，也不因为有同名函数就得到同一语义。
>
> 导航依据：`local://uta-core-rework/broker-contract-recheck.md`。原始材料入口：`docs/uta-effect-runtime-design/solutions/{Alpaca,CcxtCore,CcxtVenues,Ibkr,IbkrBridge,Longbridge}/entries.md` 及同目录 `analyses.json`。本稿保留代表性 `MAP-*` 身份，全部问题和原始 source 身份仍由这些原始 files 追溯；这些入口中未检出可引用的 `NOTE-*`，不虚构 NOTE 身份。旧 event-flow、EF、slot、legacy accommodation 结论不作为本稿前提。

## 0. 一次性的公共构造：业务实例如何进入核心

主书 §6.1 已经把 Order 定为不可变交易意图：共同部分是 InstrumentRef、方向和意图标识，size、pricing、time、relationships、protection 等是精确条款；quantity 与 notional 是有判别字段的二选一，而不是一个可能承载两种单位的 number。主书 §13.1–13.3 又把三个关键关系固定下来：需要行情的金额换算是带读取的 prepare；原生全量 close 与读后反向 Order 是两个操作；查询结果只有交给实际业务消费者并核对覆盖范围，才能形成有限的缺席判断。

以下六组都使用同一个高阶构造关系，但不重复定义 Provider 核心：

- `B` 是本次业务的共同输入（已验证的 InstrumentRef、方向、调用范围及意图）。
- `X` 是该 Provider 叶子的实际条款，例如 `AlpacaSize`、`CcxtAmountPlan`、`IbkrNativeOrder` 或 `LongbridgeOrderTerms`。`X` 由和/积构造保证非法组合不可进入下一步。
- `v_X` 是该叶子的纯约束与单位检查；`e_X` 是实际 native request 的构造；`d_X` 是在相应资源/权限成立时解释 request 的 IO；`a_X` 解码本次 response 或 observation；`consume_X` 使用同一捕获的输入、发生标识和当前状态，决定如何保存、继续观察或停止。
- `d_X` 的 response 不是自动终态。response/ack、远端状态、成交、账户/持仓和后续查询是不同的可消费值。`consume_X` 只能依据该 Provider 叶子真正交付的证据作出结论。
- 观察工作保留原始 `B/X`、工作发生标识 `ω`、native identity 和 query scope。一次失败、连接中断或响应丢失不允许通过重跑 `d_X` 假装未发生。
- 普通数据读取使用相同的“值→消费者”关系，但不继承交易批准、补偿或终态语义。账户、持仓、报价、历史、FX、order book 和 session 都必须使用它们自己的读取结果、单位、来源和时间。

能力描述也只在声明处建立：每个叶子直接关联自己的长字段（实际 instrument/product、账户范围、原生 route、支持的条款、适用环境或其它确有证据的上下文）及自己的 `v_X/d_X/a_X`。不能从 `MKT`、`fetchOrder`、某个 SDK getter、override 注册或一张短静态数组反推出所有其它能力；不适用的字段不被强行设成所有叶子的必填字段。

下文不把 `Close`、`Protection`、`Coverage` 预先做成六个 Provider 都必须实现的全局枚举，而是把真实差异放在各自 `X/e_X/a_X/consume_X` 中。

---

## 1. Alpaca：数量/金额二选一，REST PATCH 保留语义，以及完整 close 与反向订单分离

### 1.1 目标调用构造：一个数量限价单

选择一个可具体消费的输入：

```text
B = {
  instrument: STK(AAPL),
  account: selected Alpaca account,
  side: Buy,
  intent: Open
}
X = {
  size: Quantity(10),
  pricing: Limit(100.00 USD),
  time: Day,
  protection: None
}
```

目标构造 `AlpacaPlace(B, X)` 先运行 `v_AlpacaPlace`：`resolveSymbol` 必须确认 `AAPL/STK`，`Quantity` 与 `Notional` 恰有一个，`Limit` 携带 limit price，TIF 是已知声明值。当前 source 的入口是 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:273-347`；它确实把 symbol、side、type、TIF、quantity/price 等写入 Alpaca payload。目标的 `e_X` 保留这些 provider leaf 字段，不能因为公开 Order 也有 side/price 就把 Alpaca 请求降成公共对象交集。

Alpaca 的 size 和 TIF 采取以下确定承接：

- `AlpacaSize = Quantity{amount} | Notional{currencyAmount}`，是精确二选一。当前 source 有 qty 优先、否则使用 cashQty/notional 的分支，但目标不允许两者同时成为一个模糊 payload；若同时出现，`v_X` 直接拒绝。
- 该叶子**省略 TIF 时使用声明的 Day 默认**，这是叶子输入规则，不是把缺失值伪装成未知；但传入了不在该叶子声明内的 raw TIF 时，`v_X` 拒绝 UnknownTif。显式 Day、省略后采用声明 Day、未知值三者保留不同来源。
- `d_X` 只在接纳和工作保存成立后调用 create-order；其 response 经 `a_X` 解码为原生 UUID、状态事实和可能的 child-leg identity。收到 response 只交给后续 `consume_AlpacaObservation`，不直接写成 Filled/terminal。

现有 `UnifiedTradingAccount.sync`（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:828-878`）是实际的兼容消费方：它按订单存在/不存在继续同步。目标消费者不再把 `null`、异常被丢弃的 row 或兼容 `Order.orderId=0` 当作确定缺席，而是消费保留原生 UUID、查询范围和异常原因的观察值；兼容 projection 可以继续给旧调用者，但不得回流成为 dispatch identity。

```mermaid
sequenceDiagram
    participant Caller as Order caller
    participant Accept as AlpacaPlace(B,X)
    participant Broker as AlpacaBroker interpreter
    participant API as Alpaca REST
    participant Consume as Order observation consumer
    Caller->>Accept: STK(AAPL), Buy, Quantity(10), Limit(100), omitted TIF
    Accept->>Accept: v_X: choose Quantity, apply declared Day, validate Limit
    Accept->>Broker: saved work ω and native payload
    Broker->>API: createOrder(AAPL, buy, limit, qty=10, tif=day)
    API-->>Broker: response UUID/status
    Broker->>Consume: a_X(response, ω), not terminal proof
    Consume->>API: later getOrder(UUID) within recorded query scope
    API-->>Consume: order observation or scoped query failure
```

### 1.2 金额单、保护关系和修改

当 `X.size = Notional(500 USD)` 时，Alpaca target 仍直接编码 Alpaca 的 notional leaf，不借用 CCXT 的 ticker-to-quantity 逻辑。当前 source 对 Alpaca payload 支持 qty/notional，见 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:273-347`；这只证明该 request shape 已进入当前适配器，不证明数量与金额可同时提供，也不证明任何其它 Provider 具有同一原生承诺。

Bracket 与 OTO 是 Alpaca 自己的 `X.protection` 变体：当前 place 路径为 bracket 组装两条 legs、OTO 组装一条 leg，并从 response/`mapOpenOrder` 提取部分 child 信息（`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:273-347,630-655`）。目标 `AlpacaProtection` 必须把 parent、child、held condition 和它们各自的原生 identity 交给 `consume_X`；普通 `getOpenOrders({status: 'open'})` 不覆盖 held leg 时，只形成局部 observation，不能删除保护责任或生成完整 listing。SDK 有 client-id lookup 路径（`packages/uta-broker-alpaca` 的 `order.js:18-32`），但当前 place 没设置 `client_order_id`，所以目标不宣称已有客户端幂等身份。

修改的目标语义是：PATCH 未提供的字段表示 **retain**；clear 不是公共 optional-field 行为。只有 source 有精确的原生 clear contract 时，叶子才安装 `Clear(field)`；当前 Alpaca source 只证明 PATCH 对提供字段发出（`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:349-368`），没有精确 clear/CAS/idempotency 证据，因此当前叶子不安装通用 clear。未知 TIF 在 modify 中同样拒绝，不继续借 mapper 默认 Day。

### 1.3 完整 close、部分 close 与数据消费

Alpaca 目标明确保留两个操作数：

- `AlpacaFullClose{instrument, account}` 解释为 SDK close-position DELETE。它消费 provider 的 full-close response 与后续 position observation；不先伪造一个 quantity order。
- `AlpacaPartialClose{instrument, account, quantity}` 先读取同范围 position，再纯构造反向 MKT/Day `Order(Quantity(q))`，最后把这个新 Order 交给自己的接纳/解释/观察。`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:349-413` 与 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:417-480` 是现有 source 路径。读到长仓 5、请求减 2，只能构造卖 2；本地预测 3 不等于成交后的远端 3。竞争者在读取后、派发前把仓位改成 0 时，普通卖 2 甚至可能建立短仓 2；只有真正的 provider reduce-only 叶子才可提供更强保证，Alpaca 当前 source 没有此证据。

`getAccount` 在 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:417-480` 用 `Promise.all` 并发读取 account 与 positions，账户/持仓消费者应保存各自的读取区间，不把并发误写成同一 snapshot。`getPositions` 的 STK/USD projection、`getQuote` 的 snapshot、SIP→IEX 历史 feed 回退和 `getClock` 都是独立 data leaves（`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:417-591`）。缺少或未接消费的 fill activity（`services/uta/src/domain/trading/brokers/alpaca/alpaca-types.ts:68-79`）继续表示未接入的观察能力，不生成虚假的成交 stream。

### 1.4 直接声明的能力字段与 source 反例

Alpaca place leaf 的长字段应直接写在声明/描述中：`instrument.secType=STK`、`size=Quantity|Notional`、`pricing` 的已支持分支、`time.tif`（含省略时的 Day declaration）、`outsideRth`、`protection=None|Bracket|OTO`、account/environment reach，以及该 leaf 的 response/query observer。`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:593-600` 的静态 STK/五种 order type/IEX 数组只作为声明候选，不推导权限、instrument eligibility、held-leg listing、paper/live 或 final close。`init` 的 account probe 与 detached catalog 刷新（`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:157-268`）分别供 account-readiness 和 catalog leaf 消费。

本组的关键修正不是增加一张 Alpaca 特判表，而是让以下差异进入同一目标构造的不同操作数：`Quantity`/`Notional`、明确/省略/未知 TIF、`None`/`Bracket`/`OTO` protection、retain/有证据的 clear、FullClose/PartialClose，以及 UUID observation/兼容 numeric projection。

**代表追溯身份：** `MAP-3372FF782B`（place payload/tests）、`MAP-CFEE6FFFEA`（place payload）、`MAP-D25F93A942`（modify）、`MAP-053E34F691`（close）、`MAP-0F3A295D51`（未知 TIF）、`MAP-0ABCB3F3AD`（初始化）、`MAP-0A1AF127FE`（静态 capability）、`MAP-4AF53E630B`（order query）、`MAP-AECC0CF17C`（open-order listing）、`MAP-A99C29C26A`（cancel）、`MAP-3C5D748AD0`（quote）、`MAP-0E85D36517`（未消费 fill interface）、`MAP-13D1329A19`（历史 bars）。原始入口为 `docs/uta-effect-runtime-design/solutions/Alpaca/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:157-674`、`services/uta/src/domain/trading/brokers/alpaca/alpaca-contracts.ts:13-73`、`services/uta/src/domain/trading/brokers/alpaca/alpaca-types.ts:1-86` 与 `docs/uta-effect-runtime-design/solutions/Alpaca/analyses.json:3517-3537`。

---

## 2. CcxtCore：金额 prepare 有真实 ticker IO，通用层只承接可替换的基础计算

### 2.1 目标调用构造：cashQty → quote observation → quantity Order

选一个具体金额输入：

```text
B = {
  instrument: CCXT market resolved to BTC/USDT,
  account: selected wallet scope,
  side: Buy,
  intent: Open
}
X = {
  amount: Cash(500 USDT),
  quoteSource: ticker.last then declared fallback,
  quantityRounding: market amount precision/step,
  pricing: Market,
  time: provider-declared default
}
```

目标 `CcxtAmountOrder(B, X)` 的第一段不是纯 `e_X`：`resolveContract` 得到 venue-bound symbol 后，`prepareCashAmount` 解释 `fetchTicker(symbol)`，将本次 quote、币种、as-of、精度和 fallback 依据保存在 `ω`，再由纯 `convertCashToQuantity` 计算 decimal amount。当前实际 IO 在 `services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:509-626`（金额分支具体为 `services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:520-534`）；它在 cashQty 路径调用 `fetchTicker`，这不能被命名成无副作用的纯编译。

目标锁定本次换算结果后，`e_X` 只消费已保存的 quote observation 和 amount，生成 `createOrder` 的精确数量；恢复/重试不能沿用旧批准却重新取价重算数量。若调用者选择明确 `Quantity(0.01 BTC)`，则 `v_X/e_X` 不需 fetchTicker；若调用者选择金额，则必须带明确 quote policy，缺价格、币种不符、精度/step 不满足都在 prepare 失败。已有 limit price 只作为价格条款的业务值；若沿用当前 source “cashQty 即使带 limit 也先 fetchTicker”的行为，必须把该 ticker 解释为显式 freshness/适用性检查，而不能假装它是无关读取。目标可以删去不被 `X` 消费的 fetch，但不能把已发生的 IO 从证据中抹掉。

```mermaid
sequenceDiagram
    participant Caller as Amount order caller
    participant Prepare as CcxtAmountOrder(B,X)
    participant Exchange as CCXT exchange
    participant Place as Ccxt native place leaf
    participant Consumer as Order/observation consumer
    Caller->>Prepare: Cash(500 USDT), Buy BTC/USDT
    Prepare->>Exchange: fetchTicker(BTC/USDT)
    Exchange-->>Prepare: quote q or preparation failure
    Prepare->>Prepare: convertCashToQuantity(500,q,precision)
    Prepare->>Place: frozen quantity plan and quote evidence
    Place->>Exchange: createOrder(symbol, market, buy, amount, params)
    Exchange-->>Place: CCXT response
    Place->>Consumer: decoded response linked to ω
    Consumer->>Exchange: later order lookup/observation as required
```

### 2.2 通用 mutation、查询消费者与 identity

在 `services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:509-726`，通用层的 `e_X` 处理 MKT/LMT，STP/STP LMT 以 `params.triggerPrice` 进入 provider route，Trail 当前拒绝，TP/SL 只有 override 存在时才可编码，`extraParams` 不能未经叶子 schema 检查直接扩散。修改先用 cache/symbol hint 取原单，补齐 type/side/qty/price 后调用 edit；取消的 regular-first 与 stop fallback 是两个 route，不是一个原子 cancel。目标为每个 route 保存自己的 native params 和失败，不把默认 helper 的存在升级为 capability。

部分 close 仍按 §13.2 处理：读取 positions，纯构造反向 MKT Order；只有 `CRYPTO_PERP/FUT` 的 provider leaf 才可加入 `reduceOnly`，spot 不复制该字段（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:691-726`）。通用 CcxtCore 不能把这个读后派发程序和某 venue 的原生 close 混为一个 action。

查询目标选用主书 §13.3 的实际消费者：

```text
CcxtOrderQuery = { venue, accountScope, instrument/symbol hint, brokerOrderId }
lookupOutcome = FoundObservation | DefinitiveAbsentInScope | QueryUnavailable | ProtocolFailure
assess(query, lookupOutcome, currentOrderState) -> next business decision
```

`getOrder` 需要 symbol hint/cache；没有 symbol 或 provider lookup 失败不能静默生成 absence。`getOrders` 顺序消费每个 ID，`getOpenOrders` 由选中的 default/override 决定 route。当前转换器 `services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:1112-1205` 与 `services/uta/src/domain/trading/brokers/ccxt/ccxt-contracts.ts:36-52` 存在 `null`、`parseInt(id)||0` 和 unknown→Submitted 等 projection；目标 `a_X` 先保留 opaque native id、scope、status raw evidence，`assess` 只有在实际查询范围充分时才接受缺席。兼容的 numeric Order projection 不进入 lookup identity。

### 2.3 账户、持仓和公共数据的消费者

账户叶子直接消费 `resolveSubAccounts` 的 selector、wallet type、scope 和 strictness。keyless `getAccount` 的 zero USD 与 keyless `getPositions` 的空数组（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:728-1111`）目标只表示“公共模式下没有 private read”，不表示真实零余额/零持仓。带凭据的账户计算把 stablecoin cash、资产估值、衍生品 PnL 分开；`Accounting` 消费者必须知道哪部分是 native balance、哪部分是 balance-derived spot valuation。

spot positions 由 wallet total、stablecoin/reserved 过滤、market lookup、批量/逐 symbol ticker 读取后构造（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:797-885`）；不能定价的资产是 `MarkUnavailable/omitted-by-source-policy`，不是零市值。derivative position 与 spot position 是不同 scope/quantity/mark 叶子，`Promise.all` 只表达并发读取，不表达同一 snapshot。funding、orderbook、historical 和 clock 继续由各自数据消费者使用：当前缺 funding→0、timestamp→now、level→0 的映射（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:1234-1375`）要改成带缺失/来源/新鲜度的结果，不能为方便下游而制造完整数据。

### 2.4 直接声明的能力字段与同组替换

CcxtCore 只提供 capability declaration 的构造/发现连接：选中的 leaf 直接声明 venue-bound market identity、amount unit（Quantity 或 Cash+QuotePolicy）、pricing branch、trigger/TP-SL extension、wallet/subaccount scope、所需 exchange method、以及当前初始化/权限事实；`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:303-398` 的 `ensureInit`/market retries 不会自动填满这些字段。`services/uta/src/domain/trading/brokers/ccxt/overrides.ts:31-234` 的 default/override 函数只是实现组合点，不能由函数名反推所有 capability。

同一公共构造中的替换操作数是：`Quantity` ↔ `Cash(quoteSource, rounding)`；MKT/LMT/STP；regular ↔ conditional route；普通 cancel ↔ stop fallback；spot ↔ derivative wallet；native mark ↔ derived mark；keyless/public ↔ private/account scope。每次替换都必须替换相应 `v/e/d/a/consume`，而不是只改一个 order type 字符串。

**代表追溯身份：** `MAP-022EF0154D`（ensureInit）、`MAP-030151E268`（数量下单）、`MAP-DD87586D0B`（place preflight/sizing/TP-SL gate）、`MAP-D8B89D3086`（direct createOrder）、`MAP-7A96BC3C72`（getAccount）、`MAP-452BD82D18`（getPositions）、`MAP-43A1221FB0`（getOrder）、`MAP-68984949FD`（getOrders）、`MAP-B1984D4EF6`（getOpenOrders）、`MAP-03894C09ED`（converter）、`MAP-724573CD02`（historical OHLCV）、`MAP-DD2E55D8B2`（funding rate）、`MAP-C20A19F881`（order book）、`MAP-1FEC8E666F`（static capability）、`MAP-0694EDABFF`（retry constants）、`MAP-0F3B0FE1A7`（CcxtMarket schema）、`MAP-13B0841BEB`（spot synthesis）。原始入口为 `docs/uta-effect-runtime-design/solutions/CcxtCore/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:303-1375`、`services/uta/src/domain/trading/brokers/ccxt/ccxt-contracts.ts:1-180`、`services/uta/src/domain/trading/brokers/ccxt/ccxt-types.ts:1-75`、`services/uta/src/domain/trading/brokers/ccxt/overrides.ts:31-234` 与 `docs/uta-effect-runtime-design/solutions/CcxtCore/analyses.json:3432-3449`。

---

## 3. CcxtVenues：Bitget、Bybit、Hyperliquid 以不同叶子替换通用 route

本组不另造 Provider 核心；它把 CcxtCore 的 `B/X/v/e/d/a/consume` 实例化到三个真实 venue。venue/category、产品族、查询命名空间、参考价和派生 mark 进入各自 `X`，不是通用 CcxtCore 的隐藏 switch。

### 3.1 Bitget：六命名空间 listing 的目标程序

选择账户范围与 listing 业务：

```text
B = { venue: Bitget Classic, accountScope, requested categories: spot + swap }
X = BitgetListingPlan{
  namespaces: source-defined six namespace leaves,
  swapProductType: USDT-FUTURES,
  identity: symbol + brokerOrderId scoped by venue/category,
  failurePolicy: strict per required namespace
}
```

`e_X` 按 `services/uta/src/domain/trading/brokers/ccxt/exchanges/bitget.ts:17-66` 的实际顺序调用各 namespace；`fetchBalance`/`fetchPositions` 的 swap route 带 `productType: 'USDT-FUTURES'`，spot 与 derivative wallet 不共用一个无 scope 的 balance。每个 response 经 Bitget native row decoder 产生 `ScopedOrderRef{venue,category,symbol,brokerOrderId}`。缺 broker id 的 row 是 identity/protocol gap，不是空 row；当前 source 会跳过它，目标 `a_X` 应保留 `MissingIdentity` 事实。任一 required namespace 失败，`consume_BitgetListing` 只保存已覆盖 rows 与该 namespace failure，不进行 absence removal；六路齐全且各自结束证据满足时，才允许该业务自己的 complete listing 结论。

```mermaid
sequenceDiagram
    participant Caller as Listing consumer
    participant Plan as BitgetListingPlan
    participant API as Bitget Classic private API
    participant Fold as Bitget listing consumer
    Caller->>Plan: spot + swap open-order request
    loop six declared namespaces
        Plan->>API: fetch namespace with route/product params
        API-->>Plan: rows or namespace error
        Plan->>Plan: decode ScopedOrderRef; retain missing-id evidence
    end
    Plan->>Fold: rows + per-namespace results + scope
    Fold->>Fold: merge symbol:brokerOrderId within venue scope
    Fold-->>Caller: complete/partial/unavailable listing observation
```

### 3.2 Bybit：四路按 ID 查询作为一个 provider lookup operand

Bybit 的具体查询输入为 `{accountScope, symbol, brokerOrderId}`。`e_X` 由 `services/uta/src/domain/trading/brokers/ccxt/exchanges/bybit.ts:1-52` 选择四条固定 path：regular-open、conditional-open、regular-closed、conditional-closed；conditional path 传 `stop: true`。`a_X` 对每条 path 只返回 `Found`、`DefinitiveAbsent`、permission/transport/protocol failure 等精确结果；最后只有四条都给充分 absence evidence 时，`consume_BybitLookup` 才把该 ID 的本次查询判为 scoped absence。任一 timeout、权限错误或 schema 错误阻止“not found”结论，不能继续用 catch-all null。

all-open listing 是另一个 `X`：spot 与 swap category 分别调用并合并，category coverage、cursor/as-of 和 instrument identity 由 listing consumer 保存。某 category failure 时保留另一 category 的已读 rows；这不是把异常改成空数组，也不要求 generic CcxtCore 为所有 venue 安装相同 category。

### 3.3 Hyperliquid：显式价格与缺 mark 的两个不同替换

Hyperliquid market input 选为：

```text
B = { venue: Hyperliquid, instrument, accountScope, side: Buy }
X = { quantity: 1, pricing: Market(reference-price policy), time: IOC }
```

`services/uta/src/domain/trading/brokers/ccxt/exchanges/hyperliquid.ts:20-41` 当前在 market 且没有显式 price 时取 `fetchTicker`，优先 `last`/`close`，再把 reference price 交给默认 createOrder；显式 price 会跳过 ticker。目标把这次 quote 读取固化为 `PreparedHyperliquidMarket{referencePrice, quoteObservation, slippagePolicy}`，`e_X` 只编码已冻结的 IOC-limit/native extension，重试不重新取价。若没有有效 reference price，不产生 dispatch；如果 native evidence 不能证明 market emulation/slippage bound，声明为该叶子不可用，而不是宣称普通原生 MKT。

`fetchPositions` 在 `services/uta/src/domain/trading/brokers/ccxt/exchanges/hyperliquid.ts:43-53` 对缺 mark 的 position 可能用 `abs(notional)/abs(contracts)` 派生。目标 decoder 输出 `Mark = Authoritative | Derived{formula,inputs,observedAt} | Unavailable`；`contracts=0`、单位未证实或结果非 finite 时，accounting consumer 只能看到 degraded/unavailable，不能把 derived mark 当 native。

### 3.4 capability 长字段和三类 venue 的替换边界

每个 venue leaf 直接携带适用的长字段，而非从静态 `CRYPTO/CRYPTO_PERP + MKT/LMT` 推导：

- Bitget leaf 声明 `Classic` family、spot/swap wallet route、`USDT-FUTURES` product parameter、六 namespace 和 `symbol:id` identity。
- Bybit leaf 声明 spot/swap category、regular/conditional open/closed path、每 path 的 error/absence decoder 和 category coverage。
- Hyperliquid leaf 声明 reference-price/IOC emulation policy（只有证据满足时安装）、显式 price 规则和 mark provenance。

这些长字段只在对应业务适用时出现；例如 Hyperliquid position mark 不需要承担 order listing 的 category 字段，Bitget account balance 也不从静态 order type 反推。`services/uta/src/domain/trading/brokers/ccxt/overrides.ts:146-234` 的 registry 只负责装配这些具名 leaves；registry presence 不是 capability proof。

同组其它差异都作为实际 operation operand 替换：Bitget 的 namespace 与 productType、Bybit 的四条 lookup path/category、Hyperliquid 的显式/隐式 reference price、原生/派生 mark、regular/conditional cancel、TP/SL override 的存在或缺失。每个替换都保留自己的 response、coverage 和数据消费者。

**代表追溯身份：** `MAP-00DA721165`（market translator）、`MAP-00DCA04091`（contract resolver）、`MAP-1767B100E0`（type mapping）、`MAP-249466CED5`（quote preference）、`MAP-054253553C`（order book）、`MAP-2305603E29`（strict account）、`MAP-0AD385A30A`（Bitget balance/position route）、`MAP-B224A5F3E2`（Bitget product route）、`MAP-B432FAA965`（Bitget listing）、`MAP-D119678B33`（Bitget namespace sweep）、`MAP-56798F3CBB`（Bitget all-open sweep）、`MAP-D0F4B7EAFE`（Bitget identity dedup）、`MAP-CC557A8B9C`（order-book tool）、`MAP-A023467285`（funding rate）、`MAP-A80A70DAA5`（Bybit four-path lookup）、`MAP-8F4D954D91`（Bybit spot/swap listing）、`MAP-9D14A7D985`（Bybit category sweep）、`MAP-4651A86203`（Bybit partial failure）、`MAP-DD56DE539D`（Hyperliquid reference price）、`MAP-DD9535B452`（Hyperliquid semantics）、`MAP-AE93DB138F`（Hyperliquid position mark）、`MAP-5B4370AB4D`（cancel fallback）、`MAP-F032485592`（default place）、`MAP-6AAB1AB711`（position route）。原始入口为 `docs/uta-effect-runtime-design/solutions/CcxtVenues/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/ccxt/exchanges/bitget.ts:17-66`、`services/uta/src/domain/trading/brokers/ccxt/exchanges/bybit.ts:1-52`、`services/uta/src/domain/trading/brokers/ccxt/exchanges/hyperliquid.ts:20-53`、`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:509-726,1033-1375` 与 `docs/uta-effect-runtime-design/solutions/CcxtVenues/analyses.json:2185-2207`。

---

## 4. Ibkr：完整 native Contract/Order 进入解释器，操作关联不能只靠 orderId

### 4.1 目标调用构造：一个 REL 原生订单

选择一条带 native extension 的具体业务：

```text
B = {
  instrument: canonical IBKR Contract(conId, symbol, exchange, currency),
  accountScope: selected IBKR account,
  side: Buy,
  intent: Open
}
X = {
  nativeOrder: Order(orderType=REL, totalQuantity=10, percentOffset=0.05),
  time/session terms: those declared by this leaf,
  protection: None
}
```

`v_IbkrPlace` 先通过 `resolveRoutableContract` 确认 canonical conId/routing，再校验 REL 所需的 native fields；`cloneContract` 保证 combo/delta 等结构的 ownership 不被修改。`e_X` 保留完整 `ib_insync`/SDK `Contract` 与 `Order`，不翻译成 Alpaca/CCXT 交集。实际 source 在 `services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:350-381,480-507`，SDK serialization 在 `packages/uta-broker-ibkr` 的 `order.ts:37-75` 与 `client/orders.ts:33-75,459-508`。MOC/MOO/LOC/LOO/REL、`percentOffset` 由各 native leaf 直接声明；sample 存在不等于当前账户/产品/时段已获许可。

`d_X` 先保存本次工作发生 `ω` 与 operation kind，再向 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts` 登记 order waiter，调用 void `client.placeOrder`，等待可关联的 observation。`a_X` 不把任意相同 orderId 的 openOrder callback 当作本次 operation；如果 callback 没有 operation evidence，结果是 `UnassociatedOrderObservation`，由 `consume_IbkrOrder` 进入观察/恢复，而不是自动提交相同订单。

```mermaid
sequenceDiagram
    participant Caller as IBKR order caller
    participant Prepare as IbkrPlace(B,X)
    participant Bridge as RequestBridge
    participant Client as IBKR client
    participant Consumer as Order observation consumer
    Caller->>Prepare: canonical conId, REL, qty=10, percentOffset=.05
    Prepare->>Prepare: validate native Contract/Order relation
    Prepare->>Bridge: register ω, operation kind, order identity context
    Prepare->>Client: void placeOrder(orderId, Contract, Order)
    Client-->>Bridge: openOrder/orderStatus callbacks
    Bridge->>Consumer: operation-associated or unassociated observation
    Consumer->>Consumer: distinguish response, status, fill, terminal evidence
```

### 4.2 modify、cancel、close 和保护

IBKR modify 先 `getOrder`、修改原 `Order`、再以同一 numeric orderId re-place；cancel 先登记 waiter，再调用 void `cancelOrder`，当前 adapter 可能合成 `Cancelled`。目标把 modify/cancel 的 operation kind、dispatch identity、native order identity 分开；同一个 numeric orderId 的 callback 不能被核心当成同一次操作。cancel 的 synthetic result 只可作为 local acknowledgement，除非后续 `orderStatus`/query 交付 remote observation；不能成为终态。

IBKR 当前 attached TP/SL 明确拒绝（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:480-507`）。目标安装的是 `Protection=Unsupported{reason}` 的 native leaf，不构造“无保护但成功”的订单。若未来真实 native contract 能表达 attached relation，应替换 `X.protection` 与相应 codec/consumer，而不是修改所有 Provider 的核心 `Order`。

IBKR 没有被 source 证明的原生 full-close helper。`closePosition`（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:561-585`）读取 positions 后构造反向 MKT/Day order；目标明确称为 `IbkrReverseClose{positionObservation, quantity}`，新 Order 进入自己的批准、dispatch 和 observation。完整 flat 只能在实际 position observation 与业务 criterion 满足时判定；不能把读后反向 order 当原生 close，也不能在未知结果后盲发补单。

### 4.3 查询、账户、持仓和报价消费者

`getOpenOrders`/`requestOpenOrders` 只覆盖当前 client，手工 TWS order 所需 `reqAllOpenOrders`/permId 未接线；`getOrder` 先查 open 再 completed，single-slot collector 的边界由 bridge 提供（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:759-839`，`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:231-307`）。目标 `IbkrOrderQuery` 把 current-client scope、open/completed route、end marker、timeout 和 native identity 交给 `assess`；不命中不能直接生成“订单不存在”。`permId`/`clientId` 丢失和 cancel-only 空 Contract/Order 是 observation identity gap，不由 numeric orderId 填平。

初始化目标把连接、account read、market data 与 write reach 分开：当前 sequence 会等待 handshake/currentTime、若未配置则选第一个 managed account、启动 account subscription、等待首个 download，再启动 heartbeat（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:76-229,384-476`）。`getAccount` 与 `getPositions` 消费 bridge 的 account cache；`updatePortfolio` 按 conId upsert/zero remove，`updateAccountValue` 保留 currency-qualified/BASE keys，而 accountName 当前丢失（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:521-678`）。NetLiquidation 优先于 reconstruction、FX rate 与 account scope 都是账户叶子的实际输入，不自动成为其它 Provider 的规则。

`getQuote` 的 snapshot early bid/ask 与 `tickSnapshotEnd` 是不同 data observations；option mark 的 bid/ask midpoint、缓存/null fallback 也由 position valuation consumer 分开消费（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:724-839`）。缺字段投影为 0、position freeze/session 和 overnight data 都不能反推 order permission。

### 4.4 直接声明的能力字段与同组替换

IBKR native place leaf 的长字段直接包括 canonical Contract/conId/routing、完整 native Order schema、native order type、其 required fields（如 REL 的 percentOffset）、account scope、当前连接/环境和该 leaf 的 callback/query observer。MOC/MOO/LOC/LOO/REL 的存在来自该声明与 source evidence；静态 capability 数组（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:872-879`）只作候选，不推断权限、session、paper/live 或 atomicity。

同组替换是：canonical conId ↔ bare STK convenience；REL ↔ MOC/LOC/其它 native order；place ↔ modify ↔ cancel；full-close 无 native leaf ↔ reverse-order close；attached protection refusal ↔ future native protection leaf；current-client listing ↔ manual/TWS listing；early bid/ask ↔ ordinary snapshot end。每次替换都必须更新 `e_X/a_X/consume_X`，尤其不能让一个静态 order type list 生成其它 route 的承诺。

**代表追溯身份：** `MAP-5F63915F5B`（routable contract）、`MAP-86EFC621F8`（native place）、`MAP-39D2A7D5F0`（modify）、`MAP-661D1A0287`（cancel）、`MAP-755E02823B`（close）、`MAP-7BA90560A5`（init/account readiness）、`MAP-444B5B305F`（order listing/query）、`MAP-DD39DF4F2F`（collected-order identity）、`MAP-0CE70CB540`（tick snapshot）、`MAP-9747579870`（quote snapshot）、`MAP-2992D9D142`（option mark）、`MAP-18B5B86E3E`（heartbeat）、`MAP-6D904561E8`（market clock）、`MAP-C44B9CCD9F`（static capability）、`MAP-3FBCE06D0D`（account projection）、`MAP-E39D85CC2A`（native error code classifier）、`MAP-69B1FD6A99`（provider config）。原始入口为 `docs/uta-effect-runtime-design/solutions/Ibkr/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:76-929`、`services/uta/src/domain/trading/brokers/ibkr/ibkr-contracts.ts:1-77`、`services/uta/src/domain/trading/brokers/ibkr/ibkr-types.ts:1-59`、`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:231-838` 和 `docs/uta-effect-runtime-design/solutions/Ibkr/analyses.json:2415-2437`。

---

## 5. IbkrBridge：callback 路由结果独立建模，Bridge 不是 Order HOF

### 5.1 目标 callback 构造与当前 source 的修正

Bridge 的业务输入不是另一个 Provider order schema，而是 IBKR callback 资源和它的关联上下文。当前 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:1-233` 同时拥有 reqId pending、orderId waiter、single-slot listing/currentTime 和 persistent account cache；目标保留这些不同资源，并为每次 request 建立 `ConnectionGeneration`/request identity。Bridge 提供的目标结果可形如：

```text
BridgeObservation =
  | ReqIdObservation{generation, reqId, kind, payload, endEvidence}
  | OrderCallback{generation, nativeOrderId, callbackKind, payload, association}
  | ListingObservation{generation, scope, rows, endEvidence}
  | AccountSnapshotOrDelta{generation, accountScope, payload, checkpoint}
  | SnapshotTick{generation, reqId, liveOrDelayed, fields, completion}
```

这不是要求 IBKR callback 自己带 operation tag；相反，当前 source 的关键缺陷是 callback 只有 numeric orderId，无法证明 place/modify/cancel。`requestOrder`（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:231-275`）登记 waiter，`openOrder`（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:738-798`）按同 id 解析并追加 listing，`orderStatus` 缓存 fill/avg 且只对 Cancelled 解析 waiter。目标在 `association` 中明确 `Associated(ω, operation)` 或 `Unassociated`; 后者交给上层 observation consumer，不直接完成原 operation。

```mermaid
flowchart TD
    Callback[IBKR callback] --> Kind{callback kind}
    Kind -->|reqId| Req[ReqId pending/collector]
    Kind -->|openOrder orderId| Order[OrderCallback with association evidence]
    Kind -->|orderStatus orderId| Status[status/fill observation]
    Kind -->|listing end| Listing[Listing collector and scope checkpoint]
    Kind -->|portfolio/account value| Account[account delta or snapshot cache]
    Kind -->|tick| Tick[snapshot collector]
    Order --> Assoc{operation association?}
    Assoc -->|yes| EffectConsumer[consume associated order result]
    Assoc -->|no| Recon[consume unassociated observation/reconcile]
    Status --> EffectConsumer
    Req --> DataConsumer[consume scoped data result]
    Listing --> DataConsumer
    Account --> DataConsumer
    Tick --> DataConsumer
```

### 5.2 四种路由及实际消费者

1. **reqId request/collector：** contract details、option params、account summary 等由 `request`/`requestCollector` 注册，以 end marker、timeout 和 request error 结束。消费者是 `IbkrBroker` 的 contract/account/data methods；它们不能直接产出 order transaction WAL。
2. **orderId waiter：** `IbkrBroker.placeOrder/modifyOrder/cancelOrder` 使用 `requestOrder`；目标在注册时捕获 operation kind 与 generation，回调没有证据时保存为 unassociated。`openOrder` 追加 listing 的副作用与 waiter resolve 也是两个结果。
3. **single-slot listing/currentTime：** `requestOpenOrders`/completed orders 与 currentTime 当前共享单槽；目标要么在解释器边界串行化，要么把冲突、超时、提前 end 明确交给 listing/time consumer，不能任意选一个 waiter 的结果。
4. **persistent account cache：** `updatePortfolio`/`updateAccountValue` 立即写 pending/live cache，`accountDownloadEnd` swap 并作为初始 checkpoint；`IbkrBroker.getAccount/getPositions` 消费 scoped snapshot/delta。`accountName` 被当前 bridge 忽略，目标不把无 accountName 的 row 当全局账户事实。

`updatePortfolio` 当前按 conId upsert、zero row remove、avgCost 按 multiplier 归一化；`updateAccountValue` 存 qualified currency 和 BASE precedence（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:521-678`）。目标保留 row、currency、generation、receivedAt、pending/live checkpoint；没有原生 sequence 时不伪造 stream order。`tickPrice/tickSize/tickString` 的 live/delayed、bid/ask early resolve 与 `tickSnapshotEnd`（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:682-734`）由 quote/option-position consumer 解释，缺字段不能在 Bridge 边界补零。

### 5.3 连接失败与能力字段

`waitForConnect` 的 `nextValidId`/managedAccounts/timeout、`rejectAll`、10089 request error、2100–2199 informational、1100 dead 和 1101/1102 restored 都是不同 `ConnectionObservation`。当前 source 在 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:130-229,397-517` 清 waiter/cache，但没有 generation fence；目标让 late callback 与新连接区分，且保留上层已发生的 DispatchStarted，不能因 cleanup 把 effect 伪造为未发生。

Bridge capability 不是“所有 callback 都支持”。每个路由 descriptor 直接关联 `generation/reqId/orderId/scope/end-marker/timeout` 等适用长字段，以及其实际 `IbkrBroker` 消费者；account snapshot 不要求具备 order operation 字段，order callback 也不从 account cache 反推。当前 bridge 可观察到的事实足以要求目标保留 generation/association/coverage 缺口，但不凭空声称 IBKR 原生提供 callback sequence、permId 或 clientId；这些缺字段必须进入 observation quality/identity gap。

同组替换是 reqId collector、orderId callback、single-slot listing、account delta/snapshot、live/delayed tick、dead/restored/error callback。它们由各自 request/decoder/consumer 实例化，Bridge 不成为一个了解所有 Order 行为的全局 HOF。

**代表追溯身份：** `MAP-2905EACC44`（handshake timeout）、`MAP-D932C26FEF`（10089 request-error routing）、`MAP-0DDC87F65C`（2104 informational）、`MAP-90AB7C4BFE`（dead/restored state）、`MAP-39C8BA9947`（request/collector registration）、`MAP-96642209F5`（order request APIs）、`MAP-EDE0047578`（order observation callbacks）、`MAP-CAF9BBFC26`（connection/identity state）、`MAP-C907FECB22`（batch collectors/caches）、`MAP-78A465AAC0`（resolution helpers）、`MAP-5E70703666`（rejectAll teardown）、`MAP-0FFE8EF06E`（snapshot-end completion）、`MAP-BEB6FE316A`（bid/ask early snapshot）、`MAP-02C7AD6770`（account-value delta）、`MAP-0DF25AB1B4`（position delta）、`MAP-CD565305A6`（zero-position removal）、`MAP-B4CCAF38F7`（BASE precedence）、`MAP-3A9EBFB7AC`（late BASE correction）、`MAP-A914DC7B3C`（position-cache upsert）、`MAP-47D85C4ABA`（account-summary map）、`MAP-812E5F3DBE`（option-chain collector）、`MAP-EA0EAB9AD4`（portfolio callback）、`MAP-BFAD7F58E4`（currentTime callback）。原始入口为 `docs/uta-effect-runtime-design/solutions/IbkrBridge/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:1-838`、`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:480-839` 与 `docs/uta-effect-runtime-design/solutions/IbkrBridge/analyses.json:2215-2240`。

---

## 6. Longbridge：suffix identity、response orderId 与数据降级各自进入消费者

### 6.1 目标调用构造：700.HK 数量市价单

选择有确定 suffix 的输入：

```text
B = {
  instrument: Longbridge 700.HK (HK/STK),
  accountScope: selected TradeContext account,
  side: Buy,
  intent: Open
}
X = {
  size: Quantity(100),
  pricing: Market,
  time: Day,
  protection: None
}
```

`v_LongbridgePlace` 先要求 suffix/catalog evidence 能唯一解析 700.HK，确认 quantity > 0，并检查 `X` 的 native type/TIF 组合。`e_X` 按真实 market route 将 HK MKT 编为 ELO，US MKT 编为 MO；LMT→LO、STP→MIT、STP LMT→LIT、TRAIL→TSMPCT、TRAIL LIMIT→TSLPPCT，TIF 依叶子映射 Day/GTC/GTD。当前 source 在 `services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:71-120,237-313`；`_tpsl` 被忽略，IOC/FOK/OPG 当前拒绝或无映射，因此目标不装一个“所有 TIF/保护都可用”的入口。

`d_X` 调用 TradeContext submit；`a_X` 只在 response 的 `resp.orderId` 真实存在时构造 `SubmitIdentity{nativeStringId}` 和 response observation，再交给 `consume_LongbridgeOrder`。**response orderId 缺失不填 0**：`0` 只能作为当前旧 `Order.orderId` compatibility projection，不能作为 native identity、submit fallback 或查询主键。

```mermaid
sequenceDiagram
    participant Caller as Longbridge order caller
    participant Prepare as LongbridgePlace(B,X)
    participant Trade as TradeContext
    participant Consume as Order observation consumer
    Caller->>Prepare: 700.HK, Buy, Quantity(100), MKT, Day
    Prepare->>Prepare: resolve suffix and encode HK MKT as ELO
    Prepare->>Trade: submitOrder(native request)
    Trade-->>Prepare: response with orderId or missing identity
    alt response orderId present
        Prepare->>Consume: New response observation with native string id
    else response orderId absent
        Prepare->>Consume: SubmitIdentityMissing; never synthesize 0
    end
    Consume->>Trade: later detail query by explicit requested/native id
    Trade-->>Consume: detail observation or scoped query failure
```

### 6.2 modify、cancel、close 与查询

Longbridge replace 需要 quantity，并可携带 price/trigger；目标把 required quantity 和 optional native fields 写入 `LongbridgeReplace`，未提供字段按该 leaf 的 retain 语义处理；当前 source 没有精确 clear contract，故不安装通用 `Clear`。cancel Promise 完成后的 Canceled 是 local acknowledgement，不能自动成为 remote terminal。`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:315-362` 的具体 response/异常应由 `a_X` 保留，而不是把所有异常压成一个状态。

Longbridge 的完整平仓没有被 source 证明为 native close；`closePosition` 读取 positions 后按 signed quantity 创建反向 MKT/Day order（`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:346-362`）。目标把它作为 `LongbridgeReverseClose{positionObservation, quantity}`，与任何未来的原生 full-close leaf 分开。broker lifecycle `close` 当前是 async no-op（`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:230-233`），这是资源释放证据缺失，不是持仓 flat 或订单 close 成功。

查询目标选择主书 §13.3 的 precise-ID 业务：`LongbridgeOrderQuery{requestedId, accountScope}` 只调用 detail endpoint；当前 `getOrders` 顺序读取给定 IDs，`getOrder` 异常返回 null，且没有 open-order listing（`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:613-713`）。目标 consumer `assess` 把 Found、native-proven absence（若该 detail contract 能充分证明）、Unavailable/TransportUnknown、ProtocolFailure 分开。`mapOpenOrder`（`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:696-712`）不复制 raw string id 到 `OpenOrder.orderId`，旧 numeric 0 永远不能反向授权 dispatch 或证明 absence。

### 6.3 identity、账户/持仓、报价和 FX 消费者

`services/uta/src/domain/trading/brokers/longbridge/longbridge-contracts.ts` 的 suffix table 与 `resolveSymbol`/`makeContract` 当前会对 bare/unknown symbol 推断 US/STK；目标 `LongbridgeInstrument` 要求 local/suffix/venue/currency/kind 的 identity evidence，SH 与 SZ、HK 与 US 保持 distinct。`services/uta/src/domain/trading/brokers/longbridge/longbridge-contracts.ts` 与 `services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:71-120` 是 resolver source；缺 suffix 或多义时 `v_X` 返回 Ambiguous/IdentityUnavailable，不再用 US fallback。

账户目标从 `accountBalance` 保留所有 currency buckets、account scope 和每项 native fields；无 FX 时不能只选 HKD/最大 netAssets 丢掉其它项。若 `FxService` 提供 USD cross-rate，`valueAccount` 逐项核对币种、方向、缓存时间和 provenance；cached/default/unknown 1:1 rate 只能产生 estimated/unknown valuation。当前折叠与 FX source 在 `services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:381-435`、`services/uta/src/domain/trading/brokers/longbridge/fx-service.ts:140-204`，unrealized PnL hardcode 0 不能当 native PnL。`Accounting` consumer 只有在所需账户值与 FX 证据齐备时输出总值，否则保留缺侧而不补零。

positions target 保留 stockPositions 的 channel/account scope，即便当前 adapter flatten 同 symbol 并丢弃 `accountChannel`；zero row 的含义由 source scope 决定。quote 与 staticInfo 并行读取：live quote 缺失、staticInfo 缺失、option/warrant multiplier 不可用分别形成 `MarkUnavailable`、`InstrumentMetadataUnavailable` 或 degraded valuation；当前 source 用 cost-as-mark、multiplier 1 等 fallback（`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:500-573`）只能作为需修正的 compatibility behavior。`getQuote` 的 quote/depth 与 session clock（`:683-761`）是独立数据消费者；depth 失败/缺 best price 不能补 empty/0 后宣称完整市场。

### 6.4 直接声明的能力字段与同组替换

Longbridge place leaf 的长字段直接包括 suffix/venue/jurisdiction/currency/kind identity、TradeContext account scope、quantity unit/lot、MKT route（HK ELO/其它 MO）、LMT/STP/TRAIL native extension、TIF variant、protection availability、response envelope/orderId decoder 和 detail-query observer。`services/uta/src/domain/trading/brokers/longbridge/longbridge-types.ts:76-90` 的 raw getter shape 不是运行时 schema；字段必须由 provider codec 解码后才能进入消费者。paper/live、accountBalance probe、quote permission 和 session reach 只在其实际叶子适用时声明，不由订单字段推导。

同组替换是：suffix-resolved STK ↔ ambiguous bare symbol；Quantity ↔（该 Provider 未证明的）Notional；HK MKT/ELO ↔ US MKT/MO；Day/GTC/GTD ↔ refused IOC/FOK/OPG；None ↔ ignored `_tpsl`/未来 protection leaf；submit response id ↔ detail raw id ↔ compatibility 0；native quote/multiplier ↔ derived/degraded valuation；channel-preserving positions ↔ flattened projection；reverse close ↔ future native full-close。每个替换都改变相应 `v/e/a/consume`，而不是改一个全局 `Order` status。

**代表追溯身份：** `MAP-4472AC0A90`（place response）、`MAP-878575E9EE`（TIF/quantity constraints）、`MAP-CAE41001D0`（place translation）、`MAP-D79C2F71F2`（limit price）、`MAP-CCB1983C80`（cancel）、`MAP-06A7A665B6`（close）、`MAP-CF32BE43EE`（symbol/suffix resolver）、`MAP-CB5B6AC097`（Contract construction）、`MAP-DE6DDE18C3`（native order shape/id）、`MAP-B6BFE850B2`（requested-id listing）、`MAP-C2165A9F8E`（order detail）、`MAP-7805D80DA1`（SDK fixture boundary）、`MAP-4DE673DCFE`（init/retry）、`MAP-ABF45B8D66`（init readiness specs）、`MAP-39CF059275`（lifecycle close no-op）、`MAP-044F075AE6`（position channels）、`MAP-06A331A1E5`（raw position）、`MAP-CB076F4422`（quote and quote-failure position path）、`MAP-AED659F1F2`（staticInfo failure）、`MAP-34C03E3ABF`（native quote/depth）、`MAP-1B0A73A8CA`（account balance）、`MAP-B6320BAFF1`（FX/base fold without FX）、`MAP-2EDFABE32A`（FX fold）、`MAP-FCDA99890A`（provider config）。原始入口为 `docs/uta-effect-runtime-design/solutions/Longbridge/entries.md`；当前 source 组合见 `services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:1-761`、`services/uta/src/domain/trading/brokers/longbridge/longbridge-contracts.ts`、`services/uta/src/domain/trading/brokers/longbridge/longbridge-types.ts:1-125`、`services/uta/src/domain/trading/brokers/longbridge/fx-service.ts:140-204` 与 `docs/uta-effect-runtime-design/solutions/Longbridge/analyses.json:3822-3838`。

---

## 7. 承接停止条件

这六个实例现在各自给出了可检验的目标输入、纯约束、native request 构造、IO/回调解释和实际结果消费者：

- Alpaca 的 quantity/notional、声明 Day/未知拒绝、PATCH retain、Bracket/OTO 和 full/partial close 由 Alpaca leaf 直接承接。
- CcxtCore 的 cash amount 先取得并冻结 quote，再纯换算数量；query 交给精确 `assess`，spot/derivative/account/data 读取保持不同消费者。
- CcxtVenues 把 Bitget 六 namespace、Bybit 四 lookup path、Hyperliquid reference-price IOC 与 derived mark 分别实例化。
- Ibkr 保留完整 native Contract/Order；Bridge callback 同 orderId 没有 operation evidence 时不完成本次操作，保护 refusal、reverse close 和 current-client listing 也不互相冒充。
- IbkrBridge 把 reqId、orderId、single-slot、account cache 和 tick callback 分成实际路由，generation/association/late callback 是针对当前缺陷的公共关系修正，而不是新的 Provider 特判表。
- Longbridge 以 suffix-resolved instrument、TradeContext response orderId、detail query、channel-preserving positions 和 provenance-aware valuation 形成独立程序；缺 response id 永不填 0。

这些文字仍是候选承接，不宣称当前代码已迁移或已完成 runtime conformance。整合时若某一具体 `v/e/d/a/consume` 不能闭合，应回到该 Provider 的原始 source 和代表 MAP，而不是用另一个 Provider 的字段、状态或 targetModel 索引强行补齐。