# 从结果续接构造交易责任，而不是增加一个交易计算原语

本稿只研究原始 UTA 的 Effect／Decision／交易承诺怎样构造。来源限于 `docs/uta-effect-runtime-architecture.md` §4–5、原用户要求、当前交易源码及为核对承诺而读取的 Provider 边界。没有读取被否定的 eventstream、event-flows、EF 派生或 `solutions/domain-contracts.ts`，没有修改仓库，没有运行代码、测试、build、lint、formatter、broker 或用户状态操作。以下等式是**新候选的构造记法与手工求值**，不是已存在的 API，更不是已实现或整项设计完成的声明。

目标不是保住原文的数据库比喻、状态枚举或四类动作联合，而是检验其中较强的承诺：发起金融副作用之前究竟批准了什么、保留了什么责任；返回后谁消费哪个结果；何时有资格认定目标完成；不知道远端发生了什么时还允许做什么。

## 1. 当前真实函数已经给出的限制

任务所指 `TradingGit.ts` 实际位于 `services/uta/src/domain/trading/git/TradingGit.ts`。

### 1.1 prepare 这个名字目前不等于原文的 prepare

当前 `TradingGit.commit(message)` 只在内存中读取 staging、生成 hash、保存 pending message，再返回 `prepared: true`；没有读取 before-image、构造补偿或调用持久回调（`:94–116`）。`beginWrite(expectedPendingHash)` 用内存 `inflightWrite` 和当前 hash 防止该对象内的冲突（`:241–248`）。这可以约束一次 push/reject 所针对的提案，却不是跨重启的批准、锁或远端写入前日志。

`executePush()` 对每项 operation 逐项 `await executeOperation(op)`，把返回交给 `parseOperationResult`；某项抛错仍继续下一项。全部解释完后才读取账户快照、追加本地 commit、调用 `onCommit`，随后清 staging（`:137–184`）。所以当前这组真实函数的关系是：先有远端副作用，再尝试形成和保存本地记录。`getGitState()` 或 `onCommit` 若失败，已经执行的远端操作不会因此消失；前者发生在本地 commit 形成前，后者发生在内存 commit 已追加但 staging 尚未清除处。此处是源码可推演的窗口，不是本轮注入故障得到的运行结果。

`exportState()/restore()` 只输出/恢复 commits 和 head，未包含 staging、pending hash 或尚未处理工作的责任（`:565–576`）。`TradingGitConfig` 的解释入口还是 `Operation -> Promise<unknown>`，持久回调为 optional（`git/interfaces.ts:77–80`）。不能把当前 callback 的存在直接当作目标原子存储的证据。

### 1.2 IO 返回、观察和业务结论已经是不同输入

`parseOperationResult` 通过 `raw.success === true` 判断调用成功，成功时另行映射 `orderState`；缺失或未识别的状态归为 `submitted`（`TradingGit.ts:929–976`）。push 的 `submitted` 集合实际上按 `success` 筛选，不按订单是否已经成交筛选（`:181–184`）。随后 `UnifiedTradingAccount.sync()` 才另外调用 `getOrder` 观察，空结果跳过；缺席于 open-order listing 也仍要确认，不能由缺席认定终态（`UnifiedTradingAccount.ts:827–914`）。这支持“返回值必须交给对应消费者”，不支持“返回成功就是任一金融判据成立”。

当前 `PlaceOrderResult` 只有 boolean 与 optional 的 orderId/error/execution/orderState/legs，四类 mutation 共用它；`IBroker` 没有在这些方法上提供远端事务、持久幂等键、否定查询完备性或条件更新保证（`packages/uta-protocol/src/types/broker.ts:170–180,524–529,568–584`）。这些保证不能从 TypeScript 的 Promise 推出来。

### 1.3 当前 guard 不能整体搬进 pure decide

`createGuardPipeline` 在每次解释 operation 时并行读取 positions 与 account，然后依次 check，返回第一项拒绝，否则调用 dispatcher（`guards/guard-pipeline.ts:13–36`）。两个并行读取不是已声明的同一远端版本快照；guard 通过也不锁住远端账户。`OperationGuard.check` 还允许 Promise（`guards/types.ts:11–15`）。

更具体地，`CooldownGuard.check` 直接读取 `Date.now()`，在允许时修改内存 `lastTradeTime`，此时 dispatcher 尚未执行（`guards/cooldown.ts:15–31`）。只把 check 的类型改名为 Decision，会把时钟和可变状态藏进纯函数。`MaxPositionSizeGuard` 计算当前持仓市值与新单估算值之和；无现持仓、无可用金额估计时直接允许（`guards/max-position-size.ts:18–44`）。所以它也不能被解释成已证明的账户总额度预留。

`UnifiedTradingAccount` 对指定数量的 close 在发送前再读当前 position 检查数量（`:180–193,565–595`）；这是有价值的晚期检查，但读与写之间仍可改变仓位。这个局限会直接影响下面的共享资源与 target-exposure 构造。

## 2. 最小公共关系：实际 h 的结果交给实际 resume

沿用 `local://uta-core-rework/core-expression.md` 的选定关系：`F<A,E,R>` 是原始 Effect；`S<X,E,R>` 是原始 Stream；受控性不是旁列于一次返回、连续产出的第三种交付形状。下文的 `+` 是和类型，`×` 是积，`*` 是有限序列。

对某个已安装操作 d，作者实际提供解释函数与消费者：

```text
h_d      : I_d -> F<A_d,E_d,R_d>
resume_d : K_d × Result<A_d,E_d> -> C

follow(d,i,k,resume_d) =
  mapDeclaredResult(h_d(i), result => resume_d(k,result))

Work<C,R> = exists I,A,E,K.
  (d : Operation<I,A,E,R>, i : I, k : K,
   resume : K × Result<A,E> -> C)

run(pack(d,i,k,resume)) = follow(d,i,k,resume)
```

`mapDeclaredResult` 是对成功／声明失败两支应用传入函数的记法；它不将 defect、进程丢失、interruption 伪装成一个 E，也不是自动重试。R 必须被解释环境真实提供，不能因装进存在包消失。

异构性存在于包内，而不是结果消费时丢失类型：读账户的 `A_account` 只能传给接账户结果的 resume；发送的 `A_send` 只能交给对应发送消费者；查询订单的 `A_observe` 又有自己的消费者。它们最后都生成该控制状态接受的 C，才可以共同进入：

```text
decide : State × C -> Result<Event* × WorkSpec*, Rejection>
evolve : State × Event -> State
next(s, es) = fold(evolve, s, es)
```

C/Event 是一个已构造领域决定的输入和／事实和，不是所有 Provider 动作的全局联合。组合两个决定可用实际和类型注入函数 `left/right` 保留各自输入，再在所需共享状态上写协调决定；不要求公共解释器认识订单名称。动态 d 的结果若要进入一个已知金融判据，必须有同安装族提供的实际纯转换 `A_d -> Result<B,En>`、合法基础积投影，或一项真实的有类型 IO 转换。仅发现 JSON schema 不会生成金融含义。

外部结果到达时执行的是 `decide(currentState, resume(k,result))`，**不是直接 append(resume(...))**。同一份合法解码的结果可以因当前修订、身份、已处理记录或已结束责任而不再产生领域事件。零事件／零工作是合法结果；消费进度的持久记录也不必伪造业务事件。因此原始 §5.1 的 `NonEmptyReadonlyArray<Event>` 是可修正候选，不是公共计算的必要性质。

## 3. 交易特化由哪些实际操作数组成

交易特化不是对 `h` 加一个 `transactional: true`。构造者必须提供那些 Effect 类型本身不表达的真实关系：哪种观察足够准备、批准绑定哪份程序、哪份证据满足目标、失败后允许承担哪种恢复损失。

### 3.1 先把 prepare 拆成可实际组合的函数

取一个具体交易构造 d。它有已安装的只读计算 `before_d`、私有 mutation 计算 `send_d`、纯编译函数 `build_d`：

```text
before_d : I -> F<B,Eread,Rread>
build_d  : I × B × Policy -> Result<P_d,Eprepare>
send_d   : N_d -> F<A_d,Esend,Rsend>

prepare_d(i, policy) =
  then(before_d,
       b => liftResult(build_d(i,b,policy)))(i)
```

其中 `then(f,k)(i)` 就是解释 f(i)，把实际 b 传给 k。`build_d` 只能处理作为输入取得的时间／身份／远端证据，不读取时钟、Provider 或数据库。若编译本身必须问 Provider，则另把该查询写成已声明的工作，结果通过另一 resume 进入当前决定；不能把它藏进 pure build。

P_d 是**该函数构造的关联包**：本次精确输入 i、完整 Provider binding 与构造版本、编译出的 N_d、使用的 before 证据 b、冻结的判据函数及参数、恢复目标及损失边界、依赖与资源限制。这里不是声称任意函数可序列化：持久形式保存必要参数和不可变安装版本，再由该版本找回实际函数。多处引用同一准备内容可保存引用，不需把整个计划复制到每个工作上下文。

`before_d` 的“只读”来自安装者可兑现的契约与解释权限隔离，不由 `F<B,E,R>` 单独推导。如果 N_d 的编译会在 Provider 预占额度或创建远端对象，那一调用本身就是 mutation，不能算进“prepare 无远端 mutation”的承诺。可以把它另构造为获批准的责任，也可以拒绝该 prepare 模式，不能偷偷扩大无副作用定义。

原文 §5.3 的 before-image、guard、precondition、编译、补偿资格等目的由上述实际 b 和 build 消费。它们不要求公共核心为 `Place/Modify/Cancel/Close` 各建分支。

### 3.2 让 state 决定何时生成这项异构工作

设当前状态持有提案修订 r，其准备请求输入是 i，工作身份由该 owner 与本地序号构造。具体消费者不是一句“准备完成事件”，而是：

```text
resumePrepare((owner,r,w), result) = InjectPrepareResult(owner,r,w,result)

prepareWork =
  pack(prepare_d, (i,policy), (owner,r,w), resumePrepare)
```

这里把 `prepare_d(i,policy)` 等价视为接受积输入的函数。`InjectPrepareResult` 是本领域 C 中那一支的实际构造函数。收到成功 P_d 的决定，先核对 r 仍是当前提案、w 确为此处产生且未消费；匹配才接纳该 P_d。旧修订的准备结果不替换新提案。准备失败的消费者处理其精确 Eprepare/Eread；若金融政策需要区别读取失败和纯编译拒绝，构造者在这两个边界显式加和标签，普通失败联合不自动记住阶段。

批准消费者必须核对：有权限的批准者、当前提案／准备引用、准备内容的完整指纹、批准政策及有效时间。该指纹绑定 i、d 的完整 binding、N_d、判据版本／参数、恢复目标／风险界限、依赖和资源预算，而不只是显示给人的 message。时间作为已取得输入进入决定；摘要算法也只是冻结内容的标识，不自动给出授权或金融正确性。

当这些条件和当前本地资源约束成立，才可计算：

```text
resumeSend((owner,r,step,w), result) =
  InjectSendResult(owner,r,step,w,result)

sendWork(P_d) =
  pack(send_d, P_d.nativeInput,
       (owner,r,step,w), resumeSend)
```

writer 接纳批准事实与该 work 后，私有 worker 才能解释 `send_d`。公共调用返回本地批准／接纳 receipt，并不暴露 `send_d` 的可直接调用句柄。若公共控制程序选择持续报告进度，进度仍由另一个 S 消费；CLI 退出不会解除已记录的金融责任。

上面只是一份构造的条件求值，不把 `Draft/Prepared/Queued/...` 固定为所有交易都必须经历的核心生命周期。无人工批准的政策可以由授权规则直接给出许可；准备后修改输入需要重新核对批准，不允许把原批准移植到新内容。

### 3.3 提前准备与发送前再检查不能混为原子保护

例如当前 close 的检查可以重构成 `readPosition` 工作及纯关系 `requestedQty <= abs(observedQty)`；如果本地政策要求它在发送前足够新，就由当前状态判断是否需要重新读取。批准后条件变差，可以停止发送／重新准备；不能默默改数量使旧批准继续有效。

但是：再次读取成功并不能证明读写之间仓位不变。若承诺“不增加相反方向敞口”，至少需要远端 reduce-only／条件版本写入等真实能力，或更弱且明确批准的风险语义。即使 UTA 对同资源加本地锁，也挡不住交易所成交、另一个交易终端或外部账户修改。

Cooldown 的纯构造同理：把 `now` 与持久的最近相关时间放入 State×Command，纯比较 `now-last >= interval`；究竟在批准、允许一次发送还是观察成交时更新 last，是该 guard 的业务政策，不由公共核心选择。现状是在允许检查时更新；若选另一时点，应明说契约改变，不能声称只是机械迁移。

## 4. 判据必须消费证据：一个订单的实际求值

令 P 为一个买入 10 个同一工具单位的计划，批准的目标是“该订单最终完整成交”，不是“发送成功”。假设本次安装提供以下**明确的新增组合前提**：发送结果能导出可恢复的订单关联；观察入口能按关联取得带远端版本的累计成交量与该状态的有效性；版本的比较规则及终态证据含义由 Provider 契约定义。当前 IBroker 类型本身不提供这套完整承诺。

在该前提下，写出实际后继：

```text
locate_d : A_d -> Result<OrderReference_d,ELocate>
observe_d : OrderReference_d -> F<O_d,Eobserve,Robserve>

onSendResult(k, Success(a)) = InjectSendResult(k, Success(a))

在当前 decide 内消费上述输入：
  ref = locate_d(a)
  ref 合法且当前责任仍需要观察时，产生
    pack(observe_d, ref, (owner,r,step,w2), resumeObserve)

resumeObserve(k, result) = InjectObservation(k,result)
```

`locate_d` 为真实安装函数，不是核心通过猜 orderId 字段反射生成。若返回 A_d 无法确定 ref，却可以按发送前保存的 client identity 查询，构造者使用那一实际观察入口；两条都没有，就不能承诺自动追踪该发送。

判据是纯函数，对其接受的证据视图求值：

```text
judge10(view) =
  if view 不是本次订单/单位/合法版本的可用观察:
    NeedEvidence
  else if view 具有本契约认可的完整成交证据，且累计量 = 10:
    Reached(view 的证据引用)
  else if view 具有不可再成交的终态证据，且累计量 < 10:
    Unreachable(view 的残余量与终态依据)
  else:
    NeedEvidence
```

这三个结果表达判据的求值，不是新的 Provider status 全集。若超额成交、交易撤销或更正是该来源可产生的合法事实，判据还必须消费相应证据并进入该计划的风险／更正处理；不能在 `>=10` 时偷把额外风险当完成。上式只在所声明的正常数量／终态域内成立，域外不得套用。

| 实际输入 | 纯消费和接下来的合法工作 |
|---|---|
| 当前提案 i=买10，准备工作返回 P | 当前 r 匹配才保存 P；不产生发送，除非批准条件同时成立 |
| 批准绑定当前 P，writer 提交批准及发送 work | worker 得到解释资格，运行一次 `send_d(P.nativeInput)` |
| 发送返回 ACK a，locate(a)=order-7 | ACK 成为新 Command；decide 保存可用关联并生成观察 work。`judge10` 没有得到成交证据，仍不成立 |
| 观察返回累计4、合法工作状态 | resumeObserve 交给当前决定；折叠证据后 `judge10=NeedEvidence`，允许后续观察，不允许重发原10 |
| 更后观察返回最终累计10 | `judge10=Reached`；writer 才提交与本次冻结判据一致的完成结论 |
| 替代分支：最终撤销，累计4 | `judge10=Unreachable`；不能宣布“全部成交”，而由已批准的风险／补偿政策决定残余4如何处理 |

若准备时选择的是“被 venue 接受”，消费者可以只要求契约足够强的 acceptance 证据，故完成时间不同。但“被网关收到”与“被 venue 接受”仍要区分，不能因为返回值叫 ACK 就替其增强语义。判据达到后，订单可能仍工作；本地该目标完成不等于远端订单消失。若产品仍承诺追踪成交／风险，责任必须保留或明确转交其他持久拥有者，不能把完成状态当作释放全部风险占用的依据。

真实代码恰好显示这个断点：IBKR `placeOrder` 注册 requestOrder、发送，再等待 bridge 返回（`IbkrBroker.ts:491–505`）；bridge 的 `openOrder` 会完成该等待，而成交数据在另一路 `orderStatus` 回调缓存（`request-bridge.ts:233–241,738–765`）。这证明当前 await 的结束不等于最终成交，不证明候选的版本／最终性保证已经存在。

## 5. 多动作不是把数组放进 transaction

### 5.1 先后依赖要连接结果，不只是等待前一个调用返回

普通函数顺序：

```text
then(h1,k)(i) = flatMap(h1(i), a1 => k(a1))
```

只保证 k 消费实际 A1。若 h1 返回 ACK，k 在 ACK 后执行；它不自动等待 h1 的金融判据。金融先后关系应由产生了判据证据的决定构造后继：

```text
nextInput : P1 × Evidence1 -> Result<I2,EDependency>

当 judge1(currentEvidence1) = Reached(proof1) 时：
  i2 = nextInput(P1,proof1)
  再构造 prepare2(i2) 的工作或启用已经准备且仍有效的第二工作
```

例如“撤掉旧工作单后再建立新单”若以“旧单已不可再成交”为依赖，cancel ACK 不满足；第一动作若最终成交而非撤销，`nextInput` 必须消费成交量，不能仍按原数量创建替代单。若业务只要求“请求已接纳后可投递第二请求”，可选择更弱的真实判据；这必须属于批准内容。

还有一个原始完整 prepare 不能跳过的问题：i2 若依赖未来才知道的价格／成交量，就不能声称当前已经冻结 i2。合法选择只有实际成立的构造：

- 当前批准一项有界 continuation：保存 nextInput 的不可变版本及参数，且 prepare 已证明**对所有获准输出范围**第二工作都满足资源、能力、恢复和风险要求。实现时只接受落在该范围的具体 i2。
- 无法给出上述证明，就等实际 Evidence1 到达后准备第二份具体计划，必要时取得新批准。前一个动作承担自身已发生的责任，不能仍把整组描述成预先证明的全或补偿。

这是组合前提的分叉，不是要求为“第二单”增加核心语法。任意依赖未来数据的闭包都能被 Effect 表达，不代表它能事先获得严格金融批准。

### 5.2 并发要区分计算互不等待与责任互不冲突

对两个异构工作 w1/w2，公共解释可并发运行；结果分别用原 resume1/resume2 生成 C，再由 writer 顺序消费。这个机制不要求 A1=A2，也不按结果数组位置关联动作。

但同时发起的合法性由一个**纯、具体的兼容关系**决定：

```text
compatible(s,w1,w2) =
  它们在当前 s 上均有资格，且联合使用满足声明的资源与风险限制

ready(s) = 在已记录且尚未消费的工作中，
           由本计划的依赖条件和 compatible 选出的有限可运行集合
```

`ready` 不是仅扫描“函数能否 rebind”；它还要消费当前批准、结果责任、依赖与共享资源占用。选择公平性／吞吐量可以是解释器政策，不能覆盖金融合法性。

需要结果到达顺序无关时，须真正具有归并律。例如本次独立订单的证据以各自已绑定身份保留；对不同身份 e1/e2，若领域折叠满足：

```text
merge(merge(s,e1),e2) = merge(merge(s,e2),e1)
judgePair(s) = (judge1(s.evidence1), judge2(s.evidence2))
```

才可以在该观察层声称乱序不改变最终判据。这个等式不意味着两笔远端 mutation 在价格、成交时点或账户风险上交换；不相交的本地证据槽也不能证明共享购买力独立。

### 5.3 共享资源不能只按 symbol 分区

候选例：同一账户同一币种可用预算100，两个计划的已证明最坏占用分别70与60。单项检查各自通过，但并发批准后的130不合法。资源状态需要让授权决定消费：

```text
admitBudget(available,reserved,cost) =
  if reserved + cost <= available then reserve(cost) else Reject
```

这是本金融决定的数值关系；币种和账户域必须一致，cost 必须真的是该政策认可的上界。对无价格上限的市价单，仅用当前报价乘数量不是此上界的证明。类型安全的数值加法也不能补出欠缺的价格风险政策。

writer 必须在同一原子决定中检查并保存所有相关资源占用、批准和 work。若两账户由互不协调的 writer 分别保存，就没有这里宣称的联合本地原子性；需要真实可用的共同提交边界，或降低为明确的分布责任，不能靠一个 batch ID 假装已协调。

顺序派发也不充分：当前代码等待订单一的调用结果后就发送订单二，broker 观察可能还未反映第一单占用。guard 每次重读不等于已加总在途责任。本地 reservation 可以处理 UTA 已接纳的占用，却不能证明另一个交易终端未花掉远端余额；远端仍可拒绝。

资源占用释放也由具体承诺决定：本地判据若只是 accepted，工作订单仍可能占用现金、持仓或风险预算。只能在证据证明释放或责任明确移交后释放，不把“事务完成”当作统一解锁时刻。

## 6. 乱序、失败与当前状态的动态消费

以下反例不需要恢复一张统一生命周期表。

1. **两项发送的 ACK 反序。** w2 的 A2 先到，resume2 把 owner/r/step2/w2 与 A2 组成 C；writer 只更新第二项证据。w1 后到进入第一项。按 `results[index]` 与原 actions 对齐会错配；存在包内的消费者与持久工作身份消除此假设。当前 `TradingGit` 顺序 for/await 令结果数组对应成立，但一旦改并发，不能把该偶然顺序当通用契约（`:141–155`）。
2. **观察成交早于发送 ACK 的本地消费。** 只有当发送前保存的身份可用于观察、且来源能按该身份交付时，此顺序才是可构造的。观察先令判据成立，迟到 ACK 只能补充关联／确认，不能把状态退回未完成。若身份必须从 ACK 取得，就不能假装该观察已经可运行；动态依赖会推迟观察工作的产生。
3. **旧快照后到。** 订单版本12的成交证据先到，版本11的工作状态后到。若 Provider 真提供可比较版本，具体 merge 拒绝用11覆盖12；若只给无版本快照，主机接收顺序不能证明远端新旧。此时只能按所选契约串行查询／采用可证明的单调事实／保留矛盾等待确认，不能发明一个通用“状态优先级”声称正确。
4. **同一错误形状来自不同阶段。** `before` 网络失败表明未执行 prepare 所需读取；发送后失联可能已经产生副作用；observe 失联不否认上次 ACK。若全折为同一个 `NetworkError` 再统一 retry，就丢失合法动作依据。要在边界显式构造阶段／执行不确定性的失败和，或让工作身份与解释上下文提供这段证据；普通 E1+E2 不自动保留来源。
5. **已批准计划收到旧修订结果。** 不能让旧工作改写新计划；但旧 mutation 若可能已执行，也不能简单丢弃。对应旧责任仍须记录该结果或追踪 unknown，并与新提案冲突约束协调。只有确定不曾发送的旧纯准备结果才可以不推进领域状态而结束消费。
6. **observer 缺席／空返回。** 当前 `getOrder -> null` 在 UTA sync 中是 continue，不是“没下过单”（`UnifiedTradingAccount.ts:870–872`）。候选也必须保留这个区分；否定存在需要查询范围、保留时限和一致性等真实承诺。

迟到的工作结果必须经当前决定，不是因为它不可信任解码，而是因为金融结论还依赖此刻的责任、修订与已有证据。只要结果的拥有者仍存在，就要给它确定归属；已经消费的同一结果不得再次生成发送／补偿工作。

## 7. 本地原子提交的准确能力

候选 writer 的关系是：

```text
consume(owner, inputIdentity, c) =
  在一个本地原子边界内：
    读取当前 State/Version/已消费输入/相关本地资源
    若 inputIdentity 已处理，取得原处理结果
    否则求 decide(State,c)
    保存接受的 events、工作描述、资源变更、输入消费记录及新 Version
  在确认持久结果后返回该本地结果
```

这不是把 `decide` 变成 IO；它是以 IO 解释一个纯决定。全部相关状态是否真在同一个提交边界，是部署／存储契约的前提。SQLite 是原始可用候选，不是由函数关系推出来的唯一实现；持久日志或其他存储若履行同一可验证原子／恢复契约，也不改变这些构造。

在存储确实履约、全部本地写入遵守同一 writer 的前提下，它可保证：

- 不出现“接纳了这次本地决定，却丢了其对应工作”的部分提交；或相反只产生 work 而未保存授权依据。
- 结果消费与后继工作在本地共同提交，重复消费相同输入不重复生成后继。
- 本地版本／资源约束在此提交边界串行化；重建状态只 fold 事件，不解释历史副作用。
- worker 只从已经持久接纳的工作取得解释机会；内存 Queue 只负责唤醒，不是责任来源。

它不能保证：

- 两家 venue 或一家 venue 的两笔普通请求具有原子可见性／隔离／全有全无。
- 本地回滚取消远端已经发生的成交、费用、时序或第三方观察。
- 远端 mutation 恰好执行一次；本地 work id 只有在 Provider 真按该 identity 去重时才有远端意义。
- 本地 commit 的调用者一定收到回执。提交成功而回执丢失时，调用方也要按输入 identity 查询／续接，不能创建一份新请求冒充重试。
- 本地 lease 到期证明旧 worker 未发送或不能再发送；失去租约与远端请求是否可见没有天然原子联系。

所以保留原文“先持久意图、后解释”的目标，但应限制“database transaction over remote managers”的比喻。`AllOrCompensate` 表达的是尝试满足目标、失败时承担补偿责任；它不是 ACID 的全局 rollback。原文 §5.6 已承认 Git／审批／HTTP 批量不自动原子（`:448–456`）；同样不能因本地换成 SQLite 就反向宣称远端原子。

## 8. 崩溃恢复：重绑、消费与执行资格是三种函数

持久步骤保存本次输入／消费者上下文、不可变构造版本与 binding。恢复首先重建函数关系：

```text
rebind(version,binding)
  : Result<exists I,A,E,K.
       InstalledStep<I,A,E,K,C,Rhost>, RebindFailure>

consumeStored(step, encodedRequest, encodedResult)
  : Result<C, DecodeFailure>

eligible(currentState, workEvidence, installedStep)
  : 当前这项工作是否允许解释，及应解释哪一具体工作
```

`rebind` 只找回 h、resume 与 codecs；`consumeStored` 解码已保存的 K/Result 并计算 resume，绝不调用 h；`eligible` 才使用当前责任证据决定是否可执行原 work，或者必须产生新的观察／恢复 work。函数找到了不等于副作用可以再做。

| 崩溃位置及恢复时真实证据 | 合法续接 |
|---|---|
| 本地决定／工作尚未持久接纳 | 不允许解释这项工作。用户请求是否接纳按其输入 identity 查清 |
| work 已接纳，且执行协调协议能证明从未跨越发送权限边界、没有旧执行者仍可能发送 | 当前决定可继续授予原工作执行资格；“数据库行是 ready”本身未必是这份证明 |
| 已进入可能调用远端的区域，但没有持久结果 | 保留 unknown 责任；重绑只为取得对应观察／解析能力，禁止自动重跑 send |
| 远端结果已持久保存，但 resume 尚未被决定消费 | 只运行 consumeStored，再由 writer 原子消费；不重新调用 Provider |
| 结果及后继工作已共同提交，worker 未看到确认 | 查已消费输入与后继工作记录，恢复已有责任；不再次生成一份后继 |
| 安装版本／binding／codec 不可恢复 | 显式保留无法重建的责任；不得改用当前同名默认实现、当前账户或当前订单参数 |

一个无法规避的反例：本地都只记录了同一“发送可能开始”。历史 H0 中进程在网络发送前退出；历史 H1 中 venue 接受请求后进程退出、未保存回执。恢复看到的本地记录相同。若恢复算法无条件重发，H1 可能重复下单；若无条件不发，H0 可能永不下单。**没有额外远端事实时，任何本地组合都不能同时保证不重复与最终执行。** 这不是再加一个核心状态名可以消除的信息缺口。

可解除这份不确定性的是真实操作数，例如 Provider 持久按 identity 去重并返回原结果，或能对完整 identity 查询并给出足够强的存在／不存在结论。还须明确 identity 的作用域、保留时限、参数一致性、过期行为；普通 `clientOrderId: string` 声明并不证明这些承诺。只有查询返回权威的“未执行且旧尝试不会随后生效”，或重发在该 Provider 契约下不会新建第二作用，才能重新授予发送资格。暂时 not-found、断线、lease 过期都不够。

当前真实反例更直接：IBKR bridge 的 requestOrder 到时删除等待并返回 NETWORK（`request-bridge.ts:233–240`），上层在已发送后把异常压成 `success:false,error`（`IbkrBroker.ts:495–505`），TradingGit 又把 false 变成 rejected（`:942–951`）。它没有保留“已调用 send 但远端结果未知”与“已被 venue 明确拒绝”的区别。新构造要保留该责任，而不是把这个 false 当成安全重试证据。此处为代码关系分析，并未对真实 broker 发起故障实验。

## 9. 补偿是新的目标计算，不是 inverse(h)

原文 §5.5 区分 Exact／StateRestoring／Economic／None，且指出 cancel 后 replace 丢失原 identity／queue priority（`:432–444`）。应保留这项语义差异，但类别名字不能代替实际恢复构造。

给定 before 证据 b、当前可用观察 z 和已批准损失边界 L，补偿需要实际函数：

```text
restoreTarget : B × Policy -> T
planRecovery  : B × Z × T × L -> Result<RecoveryWork*, Residual>
restored      : B × Z × T -> Result<RecoveryEvidence, NotYetOrResidual>
```

`RecoveryWork` 仍由相同的 pack(d,i,k,resume) 构造；每项结果进入当前 decide。它有自己的输入、远端不确定性和完成判据。`restored` 说明恢复的是精确身份、观察等价还是经济敞口，不通过一个 `rolledBack=true` 合并。超出授权 L 或没有合适能力时，返回保留风险责任的 Residual，不伪造恢复成功。

三个可直接算的差异：

- **未成交工作订单。** 恢复目标可以是“此订单不再有可成交余量”。cancel work 的结果必须给后继观察消费者，只有证明余量为零才满足目标；中途若成交4，撤单成功也未恢复到原始零持仓，须继续判断这份4的风险。
- **持仓恢复。** before exposure 为 q0，当前经认可的观察为 q，纯 `delta=q0-q` 得到需补偿的净变化；若 delta=0，零项 recovery work 合法。若允许经济恢复，可据 delta 构造新的交易和滑点边界，再观察 q 是否到达 q0。费用、时间、成交价格、税务／现金变化和原队列优先级未被该等式恢复；这些必须属于明确损失边界，不能叫精确 rollback。
- **改单恢复。** 回到原价格／数量的请求不自动恢复原队列位置；原单若已终结，也未必还可修改。`planRecovery` 必须在当前观察和 Provider 可用能力下重新构造，不预先保存一个永远可运行的“反向改单”。

恢复排序由真实依赖决定，而非一律倒序遍历数组。若 w2 的输入依赖 w1 的输出，恢复计划需要判定先撤销／收敛哪个效果才合法；若两项触及同一净持仓，更不能并发各自恢复各自 before-image。例如从0买5，再从5买3，分别把两个 before target 写成0和5，然后并发恢复，最终可能停在5。联合目标若是0，就要在当前已知 exposure8上构造受控的目标恢复，而不是并发两个互相冲突的“局部逆函数”。

未知的正向操作尤其不能立即做 opposite：H0 中原买10未发送，先补卖10会建立错误空头；H1 中原买10已成交，补卖10才可能抵消数量。除非所选远端能力对这种未知也能保持风险边界，否则先取得足够观察，或者保留人工／专门恢复责任。

`Scope` finalizer 只释放连接、锁句柄等本地资源，不会自动生成金融补偿；取消一个 Effect 不会撤销其远端作用。原始 §4 的界限仍然成立（`:301–311`）。

## 10. 差异很大的交易操作如何实例化同一关系

这里不是为每类业务增加 core branch，而是展示同一构造的不同实参及它们不能相互替代的含义。

### 10.1 同一“修改”可对接不同真实原生函数

IBKR 当前 `modifyOrder` 先 getOrder，合并字段，再用同一 numeric orderId 调用 placeOrder，并等待 bridge（`IbkrBroker.ts:509–542`）；Alpaca 当前调用 `replaceOrder`，返回结果中的新／当前 id（`AlpacaBroker.ts:349–367`）；CCXT 要先有 symbol、读取原订单，再调用 editOrder，返回 result.id（`CcxtBroker.ts:647–688`）。

可用同一个交易构造关系，但三个 d 的精确输入、before B、native N、A 和 locate 函数不同：

```text
modify_IBKR = construct(before_IBKR, build_IBKR, sendSameId,
                        locate_IBKR, judgeRequestedTerms, recover_IBKR)
modify_Alpaca = construct(before_Alpaca, build_Alpaca, replaceNative,
                         locate_Alpaca, judgeRequestedTerms, recover_Alpaca)
```

`construct` 是前文 prepareWork／sendWork／resume／decide 方程的封装记法，不是新语法。共享 `judgeRequestedTerms` 只有在两边均提供保持相同订单条款含义的真实投影时成立；identity 是否保留、原单是否消失、恢复是否丢优先级仍是各自关系，不能把它们藏在统一 success。若 Provider 没有条件版本更新，则 before 中记录版本也不能自动使 send 成为 CAS。

### 10.2 同一 exposure 目标可以来自原生 close 或反向订单

Alpaca full close 调原生 `client.closePosition(symbol)`，partial close 读取 position 后构造反向市价单（`AlpacaBroker.ts:381–412`）；IBKR close 也是读取 position 后构造反向单（`IbkrBroker.ts:561–584`）；CCXT close 只在衍生品路径传 `reduceOnly:true`，spot 不传（`CcxtBroker.ts:691–725`）。

令共同目标 `target(q0,requestedReduction)` 得到期望 exposure，后继消费实际 exposure 观察。三个 forward h 不必返回同一种 A，也不必伪装成同一种原生接口；只需各自真正构造能进入该目标判据的后继。如果某来源提供的 close 只能“尽力减少”而不保证严格不反向开仓，就不能将它安装到要求严格 reduce-only 的构造。当前源码传了 reduceOnly 参数也不是全 venue 履约证明，本稿不据此宣称其远端效果已验证。

### 10.3 原生组合订单与客户端多笔工作不能互相冒名

假设某 Provider 真提供“整个 group 由 venue 原子接纳”的操作 d_group，则它是一次 `F<A_group,E_group,R_group>`，其 A/O 须能产生该组原子接纳的证据；公共工作解释并不需要认识 bracket／spread 等业务名。其内部多腿仍由这个 Provider 的契约承担。

把普通 d1、d2 并发或顺序组合，只能得到两项结果的积及各自责任，不能生成不存在的 group 原子证据。尤其当前 IBKR 对 attached TP/SL 明确拒绝，而不是无保护地发送 entry（`IbkrBroker.ts:480–489`）；当前 `IBroker` mutation 签名也没有通用 native atomic group 承诺。不能从 `PlaceOrderResult.legs` 的存在推导“这组腿原子建立且原子成交”。若需要 native atomic，而没有对应 Provider 证据，该组合应在 prepare 时拒绝；不存在可由 UTA 核心补齐的保证。

## 11. 哪些需要进入公共核心，哪些不应进入

本轮没有发现必须新增一个与 Effect／Stream 并列的交易计算原语。单项、先后、异构并发、动态后继和补偿都能由现有函数应用、结果消解、纯决定／折叠及持久解释关系构造；没有因此证明未来所有金融协议都不需要新构造。

确实不可省略的两层是：

1. **公共持久解释要求。** 保持输入／结果／消费者关联；原子保存决定与工作及消费身份；历史 binding 重建；重绑与执行资格分开。它们不必只用于交易，也不强迫普通只读计算持久化。
2. **金融特化的真实操作数与责任。** before 的含义、批准范围、共享资源与风险限制、判据证据、远端未知解析、补偿目标及其损失边界。这些由已安装的交易构造和领域函数提供；不能从 schema、Effect 类型、database 标签自动生成。

原文的固定四动作 union／BrokerActionTypeMap 可以保留为某个具体安装族的封闭实现，但不适合作为全 UTA 未来扩展的核心全集（原文 `:524–548,593–644,748–802`）。要保留的是一个动作的输入、before、结果、观察、补偿与解释函数间的关联，而不是枚举本身。存在包＋实际消费者提供了另一项候选；未来新增操作提供其关联操作数，不要求修改公共调度器的全局 switch。

同样，NonEmpty 对“确有一项原生请求的非空 batch”可能是正确精化，但不应强加到所有 Decision events、所有恢复 work 或所有目标满足时的计算。数据库提供的本地原子语义值得要求；不能据此把所有金融责任固定成一张数据库事务状态表。

本稿所成立的结论是**有条件的构造关系**：若安装者提供正确的 I/A/E/B/O 关联、真实解释函数与消费者、判据和恢复语义，且持久解释边界履约，则每个真实结果能被送回其原决定，顺序／并发／恢复不会仅因类型擦除或错误重发规则丢失责任。它不替 Provider 创造幂等性、最终性、原子群组、完备观察或可逆性；缺失这些承诺时应限制或拒绝相应组合，而不是增加一个名称来宣称已经支持。

证据强度仅为本轮源码回查、上述明确函数构造及正反输入的手工求值。未运行任何验证命令，也未把研究稿写成实现验收记录。
