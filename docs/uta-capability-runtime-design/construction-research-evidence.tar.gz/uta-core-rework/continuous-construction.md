# 有限页与连续来源的计算组合

这份草稿只讨论“来源产生一个语义值，纯函数消费它，得到新的状态或输出”的计算构造。它不把来源先改写成一套全局交付消息，也不从一个通用对象推导出业务模块。允许使用的事实只有：原始用户对 Candle、News、实时 push/非实时 pull、跨语言来源和副作用边界的要求；当前仓库真实的 `bar-service`；原始 Effect 模型中关于 `Effect`、`Scope`、`Queue`、`Fiber` 和 finalizer 的定义。

## 1. 先把真实来源边界固定下来

原始 Effect 模型把副作用表示为：

```ts
type UtaEffect<A, E, R> = Effect.Effect<A, E, R>
```

其中预期失败是显式的失败类型；defect 和 interruption 不是业务失败。它还明确区分了几种能力：`Scope` 负责连接、订阅和 socket 的生命周期，`Queue` 负责有界接纳和唤醒而不是权威工作存储，`Fiber` 负责受监督的 worker/stream，finalizer 负责释放本地资源而不是业务补偿或回滚。这里的区别会直接影响连续求值的后继，不能用一个 `Result` 把它们抹平。

当前真实 `BarService` 是一个**有限 pull**：

```ts
getBars(ref: BarSourceRef, opts: GetBarsOpts): Promise<BarsResult>
```

`BarsResult` 的实际形状是：

```ts
type BarsResult = {
  bars: OhlcvBar[]
  meta: BarMeta
}
```

`OhlcvBar` 有 `date/open/high/low/close/volume`；`volume` 可以是 `null`，还保留一个开放扩展索引，但这个索引不是已经声明的业务语义。`BarMeta` 保存 `symbol/from/to/bars`，并在可用时保存 `source/sourceId/barId/provider/barCapability/asOf/isLatestActual/staleTradingDays`。

`bar-service.ts` 的行为不是抽象上的“有一个 bar 数组”而已：

- vendor 路径调用具体的历史/现货客户端，只保留四个 OHLC 字段都不为 `null` 的行，按 provider 返回的 `date` 字符串升序排列，最多保留 `MAX_BARS = 5000`，然后按 `count` 保留最近的行。vendor 日期不经过 UTA 的 `Date` 规范化，不能替 provider 猜时区。
- UTA 路径先通过 `has(sourceId)` 识别来源，取得账户并检查历史 K 线能力，再把 `interval/start/end/limit` 发送给 `getHistorical`；线上的字符串数字被映射为数值。
- UTA 的 `dateOf` 先对 wire timestamp 调用 `new Date(timestamp).toISOString()`。日线/周线（以及 UTC 午夜戳）输出 UTC 日期部分；日内输出去掉 `T` 和 `Z` 的 UTC `YYYY-MM-DD HH:mm:ss`。这条 UTA 路径的 UTC 归一化是已知事实，但它仍不提供日线交易日历，也不把 vendor 原始字符串变成同样的时间语义。
- 两条路径最后都排序、限长和 tail-truncate。`computeFreshness` 只比较最后一根 bar 的日期部分与请求锚点 `end/asOf/now` 的交易日差，产生 `isLatestActual` 和 `staleTradingDays`。这不是请求范围完整性、bar 已封口、远端可重放或没有修订的证明。
- 无效 `barId`、vendor barId 缺少 `assetClass`、UTA 来源不存在、UTA 来源没有声明历史能力都会失败；不能把这些失败改写成空数组。
- 成功的空数组仍然是成功的空数组：`from/to` 为空，`bars` 为 0；它不自动等价于“来源不可用”。

因此，有限构造可以直接以 `BarsResult` 为输入；连续构造需要一个额外安装的 `Stream<X,E,R>` 来源。当前 `BarService` 没有 push/stream 方法，仓库中也没有证据表明 `getBars` 已经提供连续交付。把重复 pull、轮询或某个 SDK callback 安装成 stream 是另一个明确的适配构造，不能在本文中把它假称为当前 bar-service 已有的 push。

为免把当前 HTTP `Promise` 误说成已实现的 Effect，下面把边界记为一个可被解释器抬升的函数：

```ts
type PullBars<R, E> =
  (ref: BarSourceRef, opts: GetBarsOpts) => UtaEffect<BarsResult, E, R>

type Continuous<J, X, E, R> =
  (query: J) => Stream<X, E, R>
```

`J` 是这项连续来源自己的、必须由安装者定义并解析的查询类型；它不是用 `unknown` 代替尚未研究的业务参数。`Continuous` 是所需的能力形状，不是当前 `BarService` 的事实声明。真正安装时，`J` 需要同时固定来源身份、订阅参数和该来源实际承诺的顺序、结束、修订与资源语义。

## 2. 最小计算构造：`source`、`step`、`output`

纯计算边界用一个显式的预期结果记法：

```ts
type PureResult<A, E> =
  | { readonly _tag: 'Ok'; readonly value: A }
  | { readonly _tag: 'Err'; readonly error: E }

type Step<S, X, O, E> =
  (state: S, input: X) => PureResult<{
    readonly state: S
    readonly outputs: readonly O[]
  }, E>

type Run<S, O> = Readonly<{
  state: S
  outputs: readonly O[]
}>
```

`Step` 不做 IO。它只消费已经构造好的 `X`，产生新 `S` 和本次产生的有限输出序列。输出序列而不是单个 `Emit/Skip` 是必要的：一根输入可能跨越窗口边界并关闭旧窗口、打开新窗口，或在一个明确的修订策略下产生多个局部结果。没有输出就返回空序列。`E` 是这一步真正能解释的预期业务/数据失败；defect 和 interruption 仍由外层 Effect 处理。

先定义纯求值本身：

```ts
run<S, X, O, E>(
  items: readonly X[],
  initial: S,
  step: Step<S, X, O, E>,
): PureResult<Run<S, O>, E>
```

`run` 按 `items` 的既定顺序逐项调用 `step`，把每次的 `outputs` 按顺序拼接，并返回最终 state 与输出序列。若调用者只需要折叠后的状态，可以明确投影：

```ts
fold<S, X, O, E>(
  items: readonly X[],
  initial: S,
  step: Step<S, X, O, E>,
): PureResult<S, E>
```

`fold` 运行同一个 `run`，只取其 `state`；它不强迫所有调用者收集或保存输出。需要输出的调用者使用 `run`，再把输出序列交给自己的纯构造或 Effect sink。

有限页的最终结果另由调用者提供，而且只在完整的 `run` 之后构造一次：

```ts
type Output<M, S, Y, E> =
  (meta: M, state: S) => PureResult<Y, E>

foldPage(
  page: { readonly items: readonly X[]; readonly meta: M },
  initial: S,
  step: Step<S, X, O, Es>,
  output: Output<M, S, Y, Eo>,
): PureResult<Y, Es | Eo>
```

`foldPage` 的语义是 `run(page.items, initial, step)` 成功后把最终 `state` 交给 `output(page.meta, state)`。它不会凭空再取下一页，也不会把 `meta.isLatestActual` 当作范围完整标记。需要逐项输出的有限消费者不调用 `foldPage`，而是直接调用 `run` 并消费 `outputs`。

连续 scan 只把来源形状换成逐项交付，并对每次 `step` 产生的整个输出序列按原顺序交付：

```ts
scan(
  source: Stream<X, Es, Rs>,
  initial: S,
  step: Step<S, X, O, Et>,
): Stream<O, Es | Et, Rs>
```

对每个实际交付的 `X`，scan 运行 `step`，保存新的 state，并逐项交付这次返回的 `outputs`。它不保证有限返回，也不替来源决定完成时间。正常来源结束时是否要把尚未封闭的状态变成输出，必须另外提供 `finishOpen : S -> PureResult<readonly O[], Ef>`；无限来源没有可到达的 finish。来源失败和 step 失败默认结束这个 stream，而不是悄悄继续；若业务要“记录这个输入并继续”，那是另一个显式的 `Step` 结果类型和策略，不是全局错误/结束消息。

组合的共同规则只有这些：实际的同一个 `X` 必须交给接受它的 `Step`；纯 `step/run/fold/output` 不能读取时钟、随机数、provider 或隐藏状态；`R`、来源失败和 step 失败不能被类型擦掉；finite fold 与 continuous scan 的终止承诺不能互换。至于状态保存什么、输出长什么样、失败后继续还是结束，都由操作数决定。

## 3. 从真实 `BarsResult` 构造 Candle，再做有限 fold

为了让 bar 的来源身份不在计算中丢掉，先在数据边界做一个窄的语义构造。它不是另造一个全局事件类型，而是把当前 page 的 source metadata 与一根已验证的 `OhlcvBar` 绑定：

```ts
type CandleVolume =
  | { readonly _tag: 'MissingVolume' }
  | { readonly _tag: 'KnownVolume'; readonly value: number }

type Candle = Readonly<{
  origin: Readonly<{
    source: 'vendor' | 'uta'
    sourceId: string
    barId: string
  }>
  date: string
  open: number
  high: number
  low: number
  close: number
  volume: CandleVolume
}>

makeCandle(meta: BarMeta, bar: OhlcvBar):
  PureResult<Candle, CandleDecodeFailure>
```

`makeCandle` 必须实际检查 `source/sourceId/barId/date` 是否存在，以及数值是否满足这个消费者的要求。当前 bar-service 会把 UTA wire 字符串用 `Number(...)` 转成 number，但源码本身没有在这个位置证明每一个转换结果都是有限数；如果消费者要求可计算的有限 OHLC，就在这个构造处拒绝 `NaN`/无穷值。`volume:null` 被保留为 `MissingVolume`，不能被改成 0。开放扩展字段只有在另有声明和解析器时才能进入 `Candle`；基础 close 消费者不能因为对象碰巧带有 `vwap` 就读取它。

一个实际的有限 fold 可以是“对这一页计算收盘统计”，而不是交易提交。为了不把空页和已有数据塞进一堆可空字段，状态先建成和类型：

```ts
type CloseStats =
  | { readonly _tag: 'Empty' }
  | { readonly _tag: 'NonEmpty'
      readonly count: number
      readonly firstDate: string
      readonly lastDate: string
      readonly minClose: number
      readonly maxClose: number
      readonly closeSum: number
      readonly knownVolumeBars: number
    }

type CloseObservation = Readonly<{
  date: string
  close: number
}>

type PageFreshness =
  | { readonly _tag: 'NotReported' }
  | { readonly _tag: 'Reported'
      readonly asOf: string
      readonly isLatestActual: boolean
      readonly staleTradingDays: number
    }

type CandlePageSummary = Readonly<{
  origin: Readonly<{ source: 'vendor' | 'uta'; sourceId: string; barId: string }>
  freshness: PageFreshness
  stats: CloseStats
}>
```

`CloseStats` 的初值、加法和输出函数是本业务的操作数：

```ts
initialCloseStats: CloseStats
stepCloseStats: Step<CloseStats, Candle, CloseObservation, CloseOrderFailure>
closeSummary: Output<BarMeta, CloseStats, CandlePageSummary, SummaryFailure>
```

`stepCloseStats` 读取 `Candle.date` 与 `Candle.close`，在 `date` 不早于上一根且 close 有限时更新计数、sum、min、max，并返回一个含单个 `CloseObservation` 的输出序列；不满足顺序或数值约束时返回 `CloseOrderFailure`。`closeSummary` 从 page meta 取得 source identity 和 freshness 字段：如果 `asOf/isLatestActual/staleTradingDays` 都存在就构造 `Reported`，否则构造 `NotReported`；这不会把未提供的 freshness 猜成当前。它可以为 `bars = 0` 定义 `Empty` 统计，也可以把空页拒绝为 `SummaryFailure`；二者是调用者的函数选择，不是 bar-service 或 Effect 自动推导。要得到 observations，调用者运行 `run`；要得到只含最终统计的摘要，调用者运行 `foldPage`，两者使用相同的 `stepCloseStats`。

这个 fold 的输入顺序有真实来源：`bar-service` 的 `finalize` 按 `date` 升序后再 tail-truncate。它不意味着任意连续来源都有同样顺序；连续版本必须另行声明顺序。它也不意味着 `count=60` 给出了任意 60 根历史的完整范围：当前实现会为 count-only 请求合成一个 bounded `start` 并传 `limit`，provider 仍可能缺行，`meta` 没有完整覆盖证明。若调用者要拼多页，必须给每次调用明确 `start/end`，并由状态中的业务键 `(barId, date)` 处理重复/边界；不能因两个 page 都是 `BarsResult` 就直接声称 fold 可拼接。

在没有失败、没有重复、page 边界保持全局升序、`step` 不依赖 page meta 的前提下，纯 `run` 才有如下连接律：

```text
run(xs ++ ys, s0)
  = let r1 = run(xs, s0)
        r2 = run(ys, r1.state)
    in { state: r2.state
       , outputs: r1.outputs ++ r2.outputs }
```

`fold` 只是对完整 `run` 的 state 投影，`output(meta,state)` 只在完整 page 处理后运行一次。这个连接律是对给定 `step` 和顺序的函数关系，不是 bar-service 已经提供的分页完整性保证。`asOf`、freshness 或来源能力改变时，最终输出也可能有意不同；因此 `meta` 不能被从 fold 中丢掉。

同样的 `run/fold/scan` 形状可以在一个**实际声明并解码过的 News 值**上使用：`X = News`，`S` 可以是去重状态或统计状态，`O` 可以是给展示者的文本。允许的原始输入只说明 News 是一种未来信息抽象，并没有在本文允许的证据中给出 News 的字段、来源顺序、去重键或修订协议。因此这里不把 Candle 的 `date/barId` 猜成 News 的字段，也不声称当前仓库有一个可直接接上的 News stream。若要实际安装，来源作者必须提供一个精确的 `NewsSource<J, News, NewsFailure, NewsRequirements>`，并明确 identity、排序/时间、正常结束、修订或部分值的表示；该契约满足后，具体 News `Step` 才能进入 `run` 或 `scan`。共同的是函数位置，不是业务字段或完成语义。

## 4. 连续 scan 的真实状态组合：固定来源的时间窗口

为了展示一个确实需要状态的组合，选择**单来源的 tumbling time window**，而不是把两个来源强行 join。窗口只消费固定 query 选出的一个 `barId`，因此不会把不同 source 的同名 symbol 混在一起。

窗口需要的操作数不是一句“按时间聚合”，而是：

```ts
type WindowClock =
  (candle: Candle) => PureResult<bigint, WindowTimeFailure>

type WindowConfig<A> = Readonly<{
  duration: bigint
  clock: WindowClock
  bucketStart: (instant: bigint) => bigint
  seed: A
  add: (aggregate: A, candle: Candle) => PureResult<A, WindowAggregateFailure>
  close: (aggregate: A, start: bigint, end: bigint) => WindowValue<A>
  onEnd: (open: OpenWindow<A>) => readonly WindowValue<A>[]
}>

type OpenWindow<A> = Readonly<{
  start: bigint
  end: bigint
  last: bigint
  aggregate: A
}>

type WindowState<A> =
  | { readonly _tag: 'Empty' }
  | { readonly _tag: 'Open'; readonly value: OpenWindow<A> }

type WindowValue<A> = Readonly<{
  source: 'vendor' | 'uta'
  sourceId: string
  barId: string
  start: bigint
  end: bigint
  aggregate: A
}>
```

`WindowClock` 是作者显式安装的时间解释函数，不是 `GetBarsOpts` 已经给出的字段。对 UTA 来源，`bar-service` 已经把 wire timestamp 通过 `Date` 和 `toISOString()` 归一到 UTC；日线输出仍只有 UTC 日期部分，所以 session/calendar 仍需另有解释。对 vendor 来源，`date` 是客户端原样提供并用于字符串排序的值，窗口必须获得该 vendor 的时区、日期格式和交易日历解释。`WindowClock` 必须捕获这些已取得的上下文，或者在信息缺失时返回 `WindowTimeFailure`；不能使用机器当前时间填空。

窗口 step 的实际求值如下：

1. 第一个 Candle 由 `clock` 得到 `t`，由 `bucketStart(t)` 得到 `[start,end)`，再用 `seed/add` 建立 `Open` 状态；没有输入就没有窗口输出。
2. 当后续 `t` 落在当前 `[start,end)` 内，`add` 更新聚合，`last` 更新为 `t`，本次返回空输出序列。若某个局部策略确实要发出中间值，就返回它需要的有限输出序列。
3. 当 `t >= end`，先用 `close` 产生当前窗口的输出序列，再以当前 Candle 开始新的窗口。若跨过多个空桶，默认不生成空桶输出；要填空桶必须另传 `fillEmpty` 函数，不能凭空产生一种 Gap 输入。
4. 在本窗口选定的严格递增来源契约下，`t <= last` 返回 `WindowTimeFailure`。这是这个窗口对来源的前提，不是所有 source 的普遍规律；另一种明确的来源契约可以提供 tie-breaker 或 revision 输入，并使用不同的状态结构。若真实来源提供修订，必须把修订号/版本作为 Candle 的精确输入并改用“按 `(barId,effectiveAt)` 保存可替换值”的另一种 `WindowState`；当前 `bar-service` 的 `OhlcvBar` 没有这样的修订证据，不能静默覆盖旧值。
5. 正常 source end 是否封出尚未跨边界的 Open，由 `onEnd` 明确选择返回空序列或一个/多个 `WindowValue`。取消和 interruption 不调用这个业务 finish，除非具体 stream combinator 明文承诺这一点。

所以窗口结果类型由 `A`、`close` 和来源 identity 操作数共同决定：`A` 是 close-sum 就得到数值摘要，`A` 是最高/最低所需的记录就得到另一种摘要，`A` 是保留 Candle 序列就需要有界序列状态。不存在一个对 Candle、News 和所有业务都正确的 `WindowState`。窗口的纯 step 只是状态转换；把 `WindowValue` 写 stdout、写本地决定或丢弃，都是不同的后继消费者。

### 来源修订和部分值的真实断点

当前有限 bar-service 的 vendor 路径会过滤 OHLC 为 `null` 的行，UTA 路径则直接把 wire 字段转数值；`volume` 可以是 null。它没有向 `BarsResult` 暴露“这是一根临时 bar”“这根 bar 修订了上一根”或“整个窗口已封口”的判别。如果连续 adapter 真的提供这些信息，输入必须扩成该 adapter 自己的精确值，例如带有 `revision` 和 `effectiveAt` 的 Candle，随后由窗口操作数决定替换、重算还是拒绝。不能先建立 `Correction`、`Gap` 或 `Terminal` 的全局家族再让所有来源填槽位。

如果来源只提供一个重复的 `(barId,date)`，而没有修订身份，最安全的严格窗口策略是把重复作为局部 `DuplicateOrUnordered` 失败；选择“后到值覆盖”也必须成为这个窗口函数的显式政策，并承认其结果不再可由当前 bar-service 证明。`isLatestActual = false` 只表示最后一根 bar 没到请求锚点；它不能单独触发封窗、撤销状态或重算。

## 5. 同一来源的两个不同后继

### 5.1 有限页：一次 pull，两个纯消费

有限 page 是值，不是订阅句柄。一次 `PullBars(ref, opts)` 成功后，可以在不再次访问 provider 的情况下把不可变的 `BarsResult` 交给两个纯构造：

```ts
const candles = decodePage(page)
const summary = candles.flatMap((items) =>
  foldPage(
    { items, meta: page.meta },
    initialCloseStats,
    stepCloseStats,
    closeSummary,
  ),
)
const lines = candles.flatMap((items) =>
  run(items, unitState, stepRender).map((result) => result.outputs),
)
```

`stepRender : Step<UnitState, Candle, Line, RenderFailure>` 和 `render : (candle: Candle) => Line` 是纯的，真正写 stdout 是外层：

```ts
writeLine: (line: Line) =>
  UtaEffect<void, StdoutFailure, StdoutRequirements>
```

这两个计算共享 source identity、bar 顺序、OHLC 解码规则和 `meta`；它们不共享“结果一定代表交易完成”的解释。如果摘要 fold 失败，stdout 仍可以选择消费已经通过 `makeCandle` 的值；如果 stdout 写失败，摘要的纯值也不会因此被改写。要不要把两个消费放进同一个 `Effect.all`，是输出调用者的并发/失败政策，不由 `Candle` 自动决定。

### 5.2 连续来源：一个生产者的显式广播，不能误写成两次消费

对连续值，两个独立的 `source(query)` 调用可能是两个 provider 订阅、不同的连接、不同的顺序和不同的资源；不能只因 query 相同就叫“同一来源”。如果业务确实要一个生产者把每个 Candle 都交给两个消费者，必须安装一个有明确语义的 broadcast/fan-out：每个分支都收到每个值，队列有界，慢分支的 backpressure/drop/fail 政策明确，Scope 的拥有者明确。`Queue` 的存在本身只说明有界接纳，不说明它是可恢复的来源存储。

假定这样的广播已经作为一个实际 stream 构造安装，则两个后继先分别执行自己的 `scan`，再把 scan 的输出交给 Effect sink：

```ts
const stdoutValues = scan(stdoutInput, unitState, stepStdout)
const stdoutBranch = each(stdoutValues, (line) => writeLine(line))

const decisionValues = scan(
  decisionInput,
  initialDecisionState,
  pureDecisionStep,
)
const decisionBranch = each(
  decisionValues,
  (notice) => consumeDecisionNotice(notice),
)
```

`stepStdout : Step<UnitState, Candle, Line, RenderFailure>`；`pureDecisionStep` 保留自己的 `TriggerState`，因此连续输入真正经过了状态更新而不是把纯函数当作无状态 callback。`consumeDecisionNotice` 可以是一个无 Broker 的本地输出 Effect；如果连本地输出也不要，则 `decisionValues` 本身就是纯决定结果流。

共同规则是：两者收到同一个已经解析的 `Candle`；两者都受同一来源 order/identity/partial-data 契约约束；两者都不能从 `Candle` 推导未声明的扩展字段；两者看到 source failure、结束或取消时都遵守广播和 Scope 的实际政策。

后果完全不同：

- stdout 分支的 `render` 是纯的，写入是一个可失败的外部输出；输出失败不把已经写出的行撤回。它可以只负责展示，不建立业务状态。
- 决策分支可以定义一个完全局部的纯状态：

  ```ts
  type TriggerState =
    | { readonly _tag: 'Armed'; readonly threshold: number }
    | { readonly _tag: 'Signalled'; readonly at: string; readonly close: number }

  type DecisionNotice = Readonly<{
    at: string
    close: number
    reason: 'threshold-reached'
  }>

  pureDecisionStep:
    Step<TriggerState, Candle, DecisionNotice, DecisionFailure>
  ```

  `pureDecisionStep` 可以在 `Armed` 且 `candle.close > threshold` 时返回 `Signalled` 和一个 notice，其他值返回更新后的同一状态并返回空输出序列。它没有 Broker write，也没有把 notice 说成订单接受或成交。重复输入、阈值单位和严格/非严格比较都是该函数自己的参数；不是 source 的统一消息种类。

如果以后要把 `Signalled` 写入本地持久状态，写入本身才是一个新的 Effect/持久边界。纯决定在内存中算出后被取消，可以没有持久后果；但一旦本地 writer 返回提交成功，随后取消订阅只会阻止未来输入，不能撤销已经提交的本地工作。更不能把“取消广播分支”“关闭 Scope”或“停止继续 scan”解释成对已写出 stdout、已保存决定或已发送外部动作的回滚。

如果一个分支失败，是否让共享 producer 停止、隔离失败分支、或等待其他分支排空，必须由 fan-out 这个实际资源组合说明。它不是 `step` 可以自行假定的全局规则。若没有可验证的广播构造，就应明确地运行两个独立 source subscription，而不是宣称两个消费者共享一次订阅。

## 6. 结束、失败、释放与后继

这些情况是连续计算中真正改变后继的地方：

| 实际输入/生命周期事实 | fold/scan 的直接后继 | 不能额外声称的事情 |
|---|---|---|
| `getBars` 的来源、权限、barId 或协议失败 | 外层 Effect 进入声明的 source failure；没有合法 page，`foldPage` 不运行 | 不能把失败变成空页，也不能构造 Candle 结论 |
| 成功 `BarsResult` 但 `bars=[]` | `output` 收到空 item 序列对应的 `Empty` state；输出由空页策略决定 | 不能从空数组推导来源不可用或范围完整 |
| page 内一个 Candle 解码或 step 失败 | 有限 fold 返回 step failure；连续 scan 在该点失败，除非 step 明确选择继续 | 不能让失败值隐式改变状态 |
| 有序输入跨越窗口边界 | 先输出已封闭窗口的有限输出序列，再以当前 Candle 建立下一个 Open | 不生成没有输入支撑的 Gap 值 |
| source 正常结束 | 只有来源契约允许时才运行 `finishOpen/onEnd`；随后正常结束 | 不把正常结束强制编码成业务消息 |
| source interruption/cancellation | Scope/finalizer 释放连接、订阅和本地队列；未来输入停止 | 不调用一个未承诺的业务 flush，不撤销此前输出/提交 |
| provider 真正提供 revision/partial 信息 | 以 adapter 的精确输入进入局部 `Step`，由它替换、重算或拒绝 | 不为所有来源发明全局修订/部分/终止族 |
| 同一值已被决定分支持久提交后取消订阅 | 只影响后续消费；恢复责任由该持久边界定义 | 取消不是撤销已提交工作 |

`Stream` 的资源释放属于 `Scope`；窗口状态是否可以在重启后恢复，属于另一个持久化构造。把 scan 放进 Fiber 并由 finalizer 关闭连接，不会自动把 `WindowState` 变成 crash-recoverable 状态；把值放进 bounded Queue，也不会自动成为权威工作存储。如果决定分支需要恢复，必须另有明确的持久 writer/reader，以及保存的 query、来源 binding、窗口状态和已消费位置；本文不把这些缺失字段假装存在。

## 7. 保持条件与不可自动统一的断点

### 可以保持的关系

1. **输入关系保持。** `BarService` 先把 provider/native wire 值构造成 `BarsResult`，`makeCandle` 再把已验证的基础值交给具体 `Step`；SDK 对象和开放扩展字段不越过边界。
2. **纯度保持。** `step/run/fold/output` 和窗口、阈值决定都是纯函数；`scan`/`each` 是驱动来源 IO 的 Effect 边界，stdout、provider、连接和本地提交留在解释边界。
3. **失败不伪成功。** source、decode、step、render 和 writer 是不同失败边界；未处理的失败不会被 `flatMap` 自动改写成“后继已完成”。
4. **形状不互换。** page fold 有有限的 provider 返回和明确的 page output；scan 逐项运行、可能无穷，并把结束/中断交回来源契约。一个无限来源不能靠 `collect` 假装成有限返回。
5. **状态由操作数决定。** close 统计、时间窗口、阈值决定分别需要不同的 `S`/`Y`；没有一个把 Candle、News、展示、决定和事务结论都装进的公共状态对象。

### 当前真实断点

- 当前 `bar-service` 只有有限 pull；连续 Candle source 尚未由这段真实服务证明，必须安装单独的 push/poll/SDK adapter，并记录其顺序、结束、修订、部分值和 Scope 语义。
- `BarMeta` 的 freshness 只说明最后 bar 到请求锚点的交易日差，不说明范围完整、bar final、可重放或没有 revision。窗口和决定不能从 `isLatestActual` 推导这些结论。
- UTA 的 wire timestamp 已通过 `Date`/`toISOString()` 归一成 UTC，不能把这条路径笼统说成完全未知；但日线只有 UTC 日期部分，vendor `date` 仍是 provider 字符串，交易日历、session 和 vendor 时区必须由作者显式提供的 `WindowClock` 取得，缺失时拒绝候选，不能读本机时钟填空。
- 当前 `OhlcvBar` 的开放扩展索引不等于一个已声明的扩展 schema；Candle 基础消费者只使用明确定义的字段。
- 当前允许的证据没有给出 News 的实际 source/字段/顺序/修订协议；News 只能在它自己的语义构造完成后进入相同的函数位置，不能从 Candle 结构猜出。
- 一个来源被两个连续消费者共享，需要真实 broadcast/fan-out 和 backpressure 语义；两次调用同一个 query 不是同一订阅。
- 纯状态存在于 scan 所在的进程/计算中；Scope finalizer、Queue、Fiber 都不提供自动的持久恢复，也不为已经提交的输出提供撤销。

这里的结论不是“所有来源都必须实现同一套连续协议”，而是：只要某个来源实际提供一个可解析的 `X`、一个有序/时间/修订契约和一个 `Stream` 生命周期，就可以把该 `X` 交给它自己的纯 `Step`、窗口或决定。契约没有提供的事实，就停在边界处；不通过新增消息家族、slot 派生或组件时序把缺失事实伪造出来。

## 8. 证据范围

- 原始用户输入：`local://uta-original-user-inputs.txt:65-95` 要求跨语言来源适配、Order 与高阶组合、Candle/News 等基础信息单元，以及 K 线的 pull/push 差异；`:180-190,205-210` 强调外部 provider 是黑箱 IO，类型/函数组合必须仍能描述预期状态流向。
- 真实 bar 类型：`src/domain/market-data/bars/types.ts:54-138`（`OhlcvBar`、`BarMeta`、`BarsResult`、`GetBarsOpts`、`BarSourceRef`）；`:143-169`（UTA bar gateway 和能力输入）。
- 真实 bar 计算：`src/domain/market-data/bars/bar-service.ts:111-190`（字段过滤、日期规范化、meta、freshness、排序/限长/tail）；`:193-274`（vendor/UTA finite fetch）；`:277-388`（source discovery、能力检查与路由）。
- 原始 Effect 模型：`docs/uta-effect-runtime-architecture.md:281-311`，仅取 `UtaEffect`、预期失败/defect 区分，以及 `Scope`/`Queue`/`Fiber`/finalizer 的副作用边界；没有把该文档的旧事务事件结构当作本构造的输入。

本文没有运行 build、lint、tests、formatter 或产品 runtime；它是基于上述真实边界的函数构造和手工求值草稿，不把未安装的 continuous adapter、broadcast、News source 或持久恢复实现说成已经存在。
