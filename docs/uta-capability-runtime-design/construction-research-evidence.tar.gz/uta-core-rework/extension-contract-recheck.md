# Extension contract recheck（只读调查材料）

## 0. 范围、证据层次与限制

本材料只做“扩展契约回查”，不修改仓库，不写设计正文，不运行 build/lint/tests/formatter/runtime，也不调用真实链、券商、relayer 或外部账户。它先读取了当前研究禁令与边界：`docs/uta-capability-runtime-design/current-research.md:56-127`；其中明确要求不能以业务详述、事件/章节/统计替代抽象论证（尤其 `:89-127`）。原始入口及其阅读层次见 `docs/uta-effect-runtime-design/solutions/index.md:5-16,57-63`：`analyses.json` 与 `entries.md` 必须同读，原始 question/closure 只作为调查恢复材料，历史详细设计、旧 EF/槽位和候选章节不自动成为当前架构。

本次五组有直接 `questions-closure.json` 的 `analyses.json` 均已完整读取；各组 `entries.md` 均至少核对 source-index/标题与本材料引用所需的原分析上下文，未把未展开的镜像正文当成当前源码事实。`MockBroker` 没有直接 question closure，故单独保留其 51 个分析 source ID/处置元数据，不伪造问题条目。

`questions-closure.json` 中的 `disposition` 只记录原调查当时的处置位置；本文重新回到当前源码核查，不把 closure 的 `resolution`、旧 `targetModel` 或 `design.md` 候选当成已接受实现。

### 原调查身份索引（仅结构核对，不是完成度）

| 组 | question closure 数量 | closure 处置概览 | 本次处理方式 |
|---|---:|---|---|
| Leverup | 21 | 均 `empirical-retained` | 下方逐条保留 ID、问题、处置及源码簇 |
| LeverupProtocols | 41 | `empirical-retained`/`integration-resolved`/`design-decided` 均不改写 | 下方逐条保留 ID、问题、处置及源码簇 |
| Catalog | 28 | 均 `empirical-retained` | 下方逐条保留 ID、问题、处置及源码簇 |
| LiveEvidence | 8 | 均 `empirical-retained` | 下方逐条保留 ID、问题、处置及源码簇 |
| TargetGaps | 5 | 均 `empirical-retained` | 下方逐条保留 ID、问题、处置及源码簇 |
| MockBroker | 无 `group: MockBroker` 的原始 closure 条目 | `coverage.json:1409-1465` 只有 51 个分析条目，`openQuestions: []`，13 retained/38 reframed；`ownership.json:1113-1172` 是分析 source ID 归属 | 不编造 51 个“原始问题”；列出全部分析 ID/处置，并列出 question-inputs 中明确提及 MockBroker 的跨组问题及其所属 closure |

## 1. 先给结论：真正需要补的扩展关系

这里的“缺口”是当前源码尚未给出、且会影响主书扩展契约的关系；不是把旧业务对象再分配到核心槽位。

### 1.1 模拟控制、普通查询、证据写入是三条不同值流

`MockBroker` 自己明说它是进程内 exchange，超出 `IBroker` 的控制面用于注入 mark/fill/外部转账/场外交易；routes/UI 不经 `placeOrder` 调这些控制方法（`services/uta/src/domain/trading/brokers/mock/MockBroker.ts:1-17`）。当前 HTTP 适配器只做 `resolveMock` 和方法调用：GET `/state` 返回快照，POST mark/tick/fill/cancel/deposit/withdraw/trade 直接改变同一进程内 map（`services/uta/src/http/routes-simulator.ts:103-223`）。这些 200/`ok:true`/`filled` 只是本地控制调用返回，不是已持久接受、远端执行或可恢复证据；当前源码也没有从这些管理控制返回值通往 `_assertCanCreateProposal` 或写授权的关系，所以管理控制不会自动授予交易批准（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:549-557,693-724`）。

普通 UTA 状态读取走另一条路径：`UnifiedTradingAccount._getState` 并行调用 `broker.getAccount/getPositions/getOrders`，再筛选 Submitted/PreSubmitted（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:157-177`）。当前 `UTAManager` 的 `onCommit` 只接 `createGitPersister`，健康变化才 append 通用 event log（`services/uta/src/domain/trading/uta-manager.ts:63-74`）；`src/core/event-log.ts:19-29,48-66,129-153` 的 JSONL 日志允许任意 type/payload，不能因存在 `seq` 就成为模拟控制或 UTA effect 的接受边界。

因此当前扩展契约需要明确：控制刺激的 scope/实例身份/来源/顺序/状态事实；查询结果的 completeness/freshness/unknown；证据 sink 的写入结果与冲突语义。三者不能互相升级（例如“模拟 fill”不能满足 LivePaper，`getSimulatorState` 不能证明 restart survival，HTTP 200 不能代替 effect receipt）。

### 1.2 relayer 请求、ACK、远端观察、finality 必须分层

LeverUp `placeOrder` 在一次调用内取 Pyth、构造金额/数量、签名并 POST，收到 `inputHash` 后立即在 process-local `orderTracking` 写入 `Submitted` 并返回（`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:213-317`）。之后 `getOrder` 才按本地 map 读取，并在仍 Submitted 时 GET status；网络异常被吞掉而保留旧状态（`:450-492`）。`RelayerClient` 的返回只有 `inputHash` 或 `executed/success/txnHash/reason`，没有 dedupe、retention、finality 或 absence/fencing 承诺（`services/uta/src/domain/trading/brokers/others/leverup/relayer-client.ts:42-93`）。`pollUntilExecuted` 的本地 timeout 甚至回 `{executed:false,success:false,reason:'poll timeout'}`，这不是远端拒绝或未发送的证据。

Reader 也是另一条读路径：REST 只请求 `page=0`，只保留 `status==='OPEN'`，链上只读 USDC balance/decimals（`reader-client.ts:24-110`）。所以“POST 被 relayer 接收”“链上已执行”“订单可查”“仓位完整”“交易已 final”必须分别由同一 provider declaration 的输入、结果、观察和失败/Unknown 关系表达，不能由 `IBroker` 的 `success/orderState` 布尔组合推断。尤其当前 `placeOrder` 收到 `inputHash` 就返回 `success:true` 与 `orderState.status='Submitted'`（`LeverupBroker.ts:276-313`）；`TradingGit.parseOperationResult` 只把 `Filled`/`Cancelled`/`Inactive` 映射为终态，其余状态统一映射为 `submitted`（`TradingGit.ts:929-977`），再由 `executePush` 放进成功/提交结果数组（`:141-184`）。因此这个值最多是“relayer submission response / 本地提交标识”，不能被命名或解释成通用 Order ACK，更不能当作链上执行、订单创建、成交或 finality 的证明；若响应含义未知，必须保留 Unknown。

### 1.3 动态 pack/catalog 需要包内自描述绑定，不是静态 preset 名称

当前 UI 目录是静态 `BROKER_PRESET_CATALOG`：`BrokerPresetDef` 携带展示字段、Zod form、fingerprint 和 `toEngineConfig`，但没有包内 capability tree/实际解释器/result/error codec（`packages/uta-protocol/src/brokers/preset-catalog.ts:37-98,497-588`）。序列化给前端的 `SerializedBrokerPreset` 只含展示字段与 schema（`packages/uta-protocol/src/brokers/presets.ts:18-71`），route 直接返回 `BUILTIN_BROKER_PRESETS`（`src/webui/routes/trading-config.ts:84-88`）。

实际构造链是 `getBrokerPreset → preset.zodSchema.parse → toEngineConfig → loadBrokerEngine → entry.configSchema.parse → entry.createBroker`（`services/uta/src/domain/trading/brokers/factory.ts:26-47`）；pack loader 的模块接口仅有 API/engine/configSchema/createBroker（`services/uta/src/domain/trading/brokers/registry.ts:23-33,113-123`）。安装 manifest 会检查 schema/api/engine/version/entry/contentId 字段与 package identity/path（`src/core/broker-packs.ts:30-38,123-172`），但本次 resolver 范围未见按 `contentId` 重算包内容的步骤；contentId 的非空存在不等于内容完整性已验。

这与当前主书的动态声明边界直接相接：先选定定义，再在包内解析/解释/编码，不将外部输入直接当内部业务值（`docs/uta-capability-runtime-design.md:627-639`）；目录来自最终定义并按真实路径生成 CLI，不维护只含名字的清单（`:1028-1078`）。真正缺的是一个固定外壳 + 包内自描述的绑定：定义 revision/package identity、输入/成功/失败编码、scope/service requirements、capability availability/authorization evidence、interpreter/result consumer 以及与运行资源的生命周期关系。静态 preset id、engine union、模块能 import 都不能自动补这些关系。

### 1.4 Live evidence sink 是显式证据操作，不是 broker read/write

`LivePaperEvidence` 只有 scenario/phase 和若干可选 contract/request/result/baseline/cleanup/note 字段；`recordLivePaperEvidence` 以 `runId` 文件名 append JSONL，固定写 `paper:true`、`broker:'ibkr'`，没有 sink sequence、writer identity、schema revision、concurrent append/conflict、digest 或 freshness/coverage 字段（`services/uta/src/domain/trading/__test__/e2e/live-paper-evidence.ts:6-38,40-86`）。注释禁止账户/凭据等私密 payload，但代码没有通用 redaction/完整性校验器。

这些 E2E 中的 raw broker/control 操作仍是证据产生动作，不是 UTA 定义的通用 effect：Bybit 测试直接通过 `(b() as any).exchange.createOrder` 并手动灌 `orderSymbolCache`（`services/uta/src/domain/trading/__test__/e2e/ccxt-bybit.e2e.spec.ts:186-230`）；OKX 测试按 Cash mode/51010、51205 分支 skip（`:163-228`）；IBKR 快照 timeout 也 skip（`ibkr-paper.e2e.spec.ts:270-299`）。这类结果可以保留为“本场景观察到的证据/缺口”，不能升级为 provider capability 或 live execution guarantee。

扩展契约至少要规定 evidence scope（run/account/instrument/provider）、source/provenance、as-of/freshness、coverage/completeness、observed outcome/Unknown、redaction、per-run sequence/digest/conflict 及不可因 evidence append 失败而重复外部 effect。

### 1.5 当前 TradingGit/JSON 持久层不是 §9 的 effect 接受边界

主书 §9 明确要求：状态事件、可恢复操作数和接受结果同一不可分边界；响应丢失按同一身份读原结果；恢复不能按当前默认配置重建；SQLite 只是候选关系的实现，库名不等于保证（`docs/uta-capability-runtime-design.md:1150-1192`）。当前 `TradingGit.executePush` 是先逐个 `executeOperation`，再 `getGitState`、构造内存 commit，最后调用 `onCommit`（`services/uta/src/domain/trading/git/TradingGit.ts:119-185`）。`onCommit` 的文件实现只是 `mkdir + writeFile(JSON.stringify(state))`，读取失败还会尝试 legacy path 并最终返回 undefined（`services/uta/src/domain/trading/git-persistence.ts:14-48`）。因此它没有把外部操作、dispatch identity、结果/Unknown、lease 与 durable acceptance 放在同一原子边界。

启动也没有 effect-journal admission gate：UTA 先 `createEventLog`、purge ephemeral UTAs、逐账户 init、启动 scheduler/poller，再暴露 `ok:true` health（`services/uta/src/main.ts:56-87,102-152`）。`purgeEphemeralUTAs` 会删除 `data/trading/<id>/`（`src/core/config.ts:797-821`），这正是不能在尚未分类 unfinished effect 时当作一般清理的边界。需要补的是 effect-specific acceptance/recovery/lease/result-consumption，而不是仅新增一个 dependency 或给 commit.json 换名字。

### 1.6 账户/秘密/授权也是扩展输入，不是 preset 展示属性

LeverUp config schema 和 `fromConfig` 仍直接接收 private key，实例保留它并以派生地址签名（`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:80-115,132-155`）；catalog 的 `writeOnlyFields` 只改变表单 JSON Schema（`packages/uta-protocol/src/brokers/preset-catalog.ts:457-467` 及 `presets.ts:47-53`），factory 仍把解析后的值送入 engine（`factory.ts:26-40`）。当前主书要求秘密不进公开描述/普通日志，历史恢复也不能仅因 shape 相容就换凭据/目标（`docs/uta-capability-runtime-design.md:1178-1184`）。因此 package-local extension descriptor 还要绑定 AccountScope/credential reference/generation/network-deployment evidence/authorization，而不应从“有 privateKey 字段”“mode=testnet”推断可写能力。

### 1.7 一个缺少的公共消费关系：发现结果没有被写提案绑定

这里存在一个可以沿当前公开调用链复现的契约缺口，而不是给旧对象分配新槽位：`searchTradeableContracts` 只把 broker 搜索返回的 `source`、`contract`、衍生类型和可选 asset class 组成 `ContractSearchHit`（`services/uta/src/domain/trading/contract-search.ts:27-64`）；它没有留下“该 native key 来自哪个已声明目录/版本/能力”的绑定。写入口 `stagePlaceOrder` 只校验数量/订单字段，随后从传入字符串解析 UTA id、调用 `broker.resolveNativeKey` 并把结果放进 staging（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:603-638,693-724`）。

以 LeverUp 为精确反例：`accountId|NOT-A-PAIR` 能通过 `parseAliceId` 的“存在 `|`”语法检查；`LeverupBroker.resolveNativeKey` 对未知 key 合成一个最小 `CRYPTO_PERP` contract，并明确把未知 pair 的错误推迟到 trade time（`UnifiedTradingAccount.ts:515-520,534-544`; `LeverupBroker.ts:535-546`）。于是 proposal 可以先携带这个看似类型正确的 contract，真正执行到 `placeOrder` 才因 `resolvePair` 失败返回 `Unknown LeverUp pair`（`LeverupBroker.ts:213-223`）。这证明“曾经搜到一个结果”、非空 native key、或 shape/asset-class 相容都没有形成公共的 discovery→catalog identity→proposal→interpreter 消费关系；该关系需要显式绑定并在提案/执行边界检查，不能靠 `resolveNativeKey` 的合成 fallback 补齐。

## 2. 当前源码→消费者链（按关系集中，不分配业务槽位）

| 关系 | 事实源（当前源码） | 现有消费者 | 真实未闭合处 |
|---|---|---|---|
| 模拟控制 vs 查询 | `MockBroker.ts:546-578,580-796`; simulator routes `:103-223` | Dev UI/API 调控制；UTA `_getState` `UnifiedTradingAccount.ts:157-177` 调普通 broker reads | 无控制事实的 scope/sequence/durable identity；控制返回不能升级为 effect evidence |
| relayer submit vs remote observation | `LeverupBroker.ts:213-317,450-492`; `relayer-client.ts:42-93` | placeOrder 返回 `inputHash`/Submitted；getOrder 之后查询 | 无跨重启 identity、dedupe/retention/finality/absence/fencing；不能把成功响应叫通用 Order ACK |
| protocol bytes vs deployed semantics | `eip712.ts:4-10,52-190`; `decimals.ts:4-55`; `pairs.ts:29-81`; `pyth.ts:14-72` | LeverUp broker sign/POST；reader parse | nested/flat、scale、collateral、pair registry、Pyth policy、chain/deployment evidence 未绑定 |
| preset/catalog vs runtime pack | `preset-catalog.ts:37-98,497-588`; `presets.ts:18-71`; `factory.ts:26-47`; `registry.ts:23-33,113-123` | UI preset route；factory pack loader | 无包内 definition revision/capability/interpreter/result/error/authorization binding |
| broker adapter vs native capability | Alpaca/CCXT/IBKR/Longbridge source ranges in §3.4 |各自 API/SDK bridge 与 E2E | wrapper shape/field presence 不证明环境、权限、幂等、lookup completeness、finality |
| live evidence sink vs runtime state | `live-paper-evidence.ts:6-86`; E2E specs | E2E records/diagnostic notes | 无 sequence/concurrency/conflict/digest/coverage contract；evidence append 失败不能重发外部 effect |
| TradingGit/commit JSON vs §9 acceptance | `TradingGit.ts:119-185`; `git-persistence.ts:14-48`; `event-log.ts:19-91` | onCommit JSON state；generic event log | 无同原子 effect input/capture/result/lease/recovery/lookup boundary |
| account/credential/auth vs catalog display | LeverUp config/factory; `preset-catalog.ts:457-467`; `factory.ts:26-40` | config form + broker constructor | writeOnly/mode/name 不构成 credential generation/account scope/authorization evidence |
| discovery result vs proposal/interpreter | `contract-search.ts:27-64`; `UnifiedTradingAccount.ts:515-544,603-724`; LeverUp `:213-223,535-546` | search consumer得到 hit；stage consumer重建 contract；place consumer再次 resolve pair | 无 discovery identity/version/definition binding；unknown key 可先进入 proposal、到执行才拒绝 |

## 3. 分组源码核查与逐条原始问题 ledger

下表中的“当前源码核查簇”只指向本节中对应的事实段；问题原文、ID、处置值和 closure 行号完整保留。簇不是新的业务对象或核心槽位。

### 3.1 MockBroker（直接 closure 缺失必须显式保留）

#### 原分析身份

本次完整读取 `docs/uta-effect-runtime-design/solutions/MockBroker/analyses.json` 的 51 个 mapping/analysis 条目，并核对 `coverage.json:1409-1465` 与 `ownership.json:1113-1172`；`entries.md` 仅核对其 source-index/标题位置及与下列事实直接相关的段落，未逐行展开其余镜像正文，不把未展开行当作已读问题或当前设计事实。覆盖事实仍是该组分析 51/51、有 0 openQuestions；其分析还指出 STP LMT 被实现为触发即成交（`MockBroker.ts:104-108,799-839`）、deposit 的 raw nativeKey 与 contract localSymbol 可能冲突（`:675-697,917-923`），以及控制、查询、provider capability 的边界。以下不是把这 51 个分析重写成“问题”，而是保留每个 source ID 及原分析处置位置：

| # | 分析 source ID | 分析处置 | 保留位置 |
|---:|---|---|---|
| 1 | `MAP-2807C05FCC` | `reframed` | `MockBroker/analyses.json` entry 1; `MockBroker/entries.md` `#MAP-2807C05FCC` |
| 2 | `MAP-74610A30AF` | `retained` | `MockBroker/analyses.json` entry 2; `MockBroker/entries.md` `#MAP-74610A30AF` |
| 3 | `MAP-50275FA75F` | `reframed` | `MockBroker/analyses.json` entry 3; `MockBroker/entries.md` `#MAP-50275FA75F` |
| 4 | `MAP-377A30A5EC` | `reframed` | `MockBroker/analyses.json` entry 4; `MockBroker/entries.md` `#MAP-377A30A5EC` |
| 5 | `MAP-5484E0ABE8` | `reframed` | `MockBroker/analyses.json` entry 5; `MockBroker/entries.md` `#MAP-5484E0ABE8` |
| 6 | `MAP-B20F6E5551` | `reframed` | `MockBroker/analyses.json` entry 6; `MockBroker/entries.md` `#MAP-B20F6E5551` |
| 7 | `MAP-BDF7756398` | `reframed` | `MockBroker/analyses.json` entry 7; `MockBroker/entries.md` `#MAP-BDF7756398` |
| 8 | `MAP-399D99B7AB` | `reframed` | `MockBroker/analyses.json` entry 8; `MockBroker/entries.md` `#MAP-399D99B7AB` |
| 9 | `MAP-BEE79BFA7C` | `reframed` | `MockBroker/analyses.json` entry 9; `MockBroker/entries.md` `#MAP-BEE79BFA7C` |
| 10 | `MAP-0DD83C8637` | `reframed` | `MockBroker/analyses.json` entry 10; `MockBroker/entries.md` `#MAP-0DD83C8637` |
| 11 | `MAP-E9E1A05333` | `retained` | `MockBroker/analyses.json` entry 11; `MockBroker/entries.md` `#MAP-E9E1A05333` |
| 12 | `MAP-B4C7FEA646` | `reframed` | `MockBroker/analyses.json` entry 12; `MockBroker/entries.md` `#MAP-B4C7FEA646` |
| 13 | `MAP-CDC7079D83` | `reframed` | `MockBroker/analyses.json` entry 13; `MockBroker/entries.md` `#MAP-CDC7079D83` |
| 14 | `MAP-ADE49309E9` | `retained` | `MockBroker/analyses.json` entry 14; `MockBroker/entries.md` `#MAP-ADE49309E9` |
| 15 | `MAP-47DB032F5A` | `retained` | `MockBroker/analyses.json` entry 15; `MockBroker/entries.md` `#MAP-47DB032F5A` |
| 16 | `MAP-0151919B70` | `reframed` | `MockBroker/analyses.json` entry 16; `MockBroker/entries.md` `#MAP-0151919B70` |
| 17 | `MAP-9DFD3B9879` | `reframed` | `MockBroker/analyses.json` entry 17; `MockBroker/entries.md` `#MAP-9DFD3B9879` |
| 18 | `MAP-D6BA46AF1A` | `retained` | `MockBroker/analyses.json` entry 18; `MockBroker/entries.md` `#MAP-D6BA46AF1A` |
| 19 | `MAP-0F7F332B24` | `reframed` | `MockBroker/analyses.json` entry 19; `MockBroker/entries.md` `#MAP-0F7F332B24` |
| 20 | `MAP-559086B869` | `reframed` | `MockBroker/analyses.json` entry 20; `MockBroker/entries.md` `#MAP-559086B869` |
| 21 | `MAP-26F708C6F8` | `reframed` | `MockBroker/analyses.json` entry 21; `MockBroker/entries.md` `#MAP-26F708C6F8` |
| 22 | `MAP-B4CEC1AF32` | `reframed` | `MockBroker/analyses.json` entry 22; `MockBroker/entries.md` `#MAP-B4CEC1AF32` |
| 23 | `MAP-1F7945D7FF` | `retained` | `MockBroker/analyses.json` entry 23; `MockBroker/entries.md` `#MAP-1F7945D7FF` |
| 24 | `MAP-8C05962CF7` | `reframed` | `MockBroker/analyses.json` entry 24; `MockBroker/entries.md` `#MAP-8C05962CF7` |
| 25 | `MAP-A20A4E0C8F` | `retained` | `MockBroker/analyses.json` entry 25; `MockBroker/entries.md` `#MAP-A20A4E0C8F` |
| 26 | `MAP-03B79FC368` | `reframed` | `MockBroker/analyses.json` entry 26; `MockBroker/entries.md` `#MAP-03B79FC368` |
| 27 | `MAP-46ED6C273F` | `reframed` | `MockBroker/analyses.json` entry 27; `MockBroker/entries.md` `#MAP-46ED6C273F` |
| 28 | `MAP-5FA8553583` | `reframed` | `MockBroker/analyses.json` entry 28; `MockBroker/entries.md` `#MAP-5FA8553583` |
| 29 | `MAP-F133CDF76E` | `reframed` | `MockBroker/analyses.json` entry 29; `MockBroker/entries.md` `#MAP-F133CDF76E` |
| 30 | `MAP-09ABC1ADD4` | `reframed` | `MockBroker/analyses.json` entry 30; `MockBroker/entries.md` `#MAP-09ABC1ADD4` |
| 31 | `MAP-5842AA2B07` | `reframed` | `MockBroker/analyses.json` entry 31; `MockBroker/entries.md` `#MAP-5842AA2B07` |
| 32 | `MAP-0BBDEA8E36` | `reframed` | `MockBroker/analyses.json` entry 32; `MockBroker/entries.md` `#MAP-0BBDEA8E36` |
| 33 | `MAP-C0D557E0BD` | `reframed` | `MockBroker/analyses.json` entry 33; `MockBroker/entries.md` `#MAP-C0D557E0BD` |
| 34 | `MAP-04B4087714` | `reframed` | `MockBroker/analyses.json` entry 34; `MockBroker/entries.md` `#MAP-04B4087714` |
| 35 | `MAP-BBC8C72572` | `retained` | `MockBroker/analyses.json` entry 35; `MockBroker/entries.md` `#MAP-BBC8C72572` |
| 36 | `MAP-202708E052` | `reframed` | `MockBroker/analyses.json` entry 36; `MockBroker/entries.md` `#MAP-202708E052` |
| 37 | `MAP-5D79D1084D` | `reframed` | `MockBroker/analyses.json` entry 37; `MockBroker/entries.md` `#MAP-5D79D1084D` |
| 38 | `MAP-FED35111E9` | `reframed` | `MockBroker/analyses.json` entry 38; `MockBroker/entries.md` `#MAP-FED35111E9` |
| 39 | `MAP-A3F1814B97` | `reframed` | `MockBroker/analyses.json` entry 39; `MockBroker/entries.md` `#MAP-A3F1814B97` |
| 40 | `MAP-AB61645548` | `retained` | `MockBroker/analyses.json` entry 40; `MockBroker/entries.md` `#MAP-AB61645548` |
| 41 | `MAP-B8A614D67A` | `reframed` | `MockBroker/analyses.json` entry 41; `MockBroker/entries.md` `#MAP-B8A614D67A` |
| 42 | `MAP-F0F4E26989` | `reframed` | `MockBroker/analyses.json` entry 42; `MockBroker/entries.md` `#MAP-F0F4E26989` |
| 43 | `MAP-89456D4461` | `reframed` | `MockBroker/analyses.json` entry 43; `MockBroker/entries.md` `#MAP-89456D4461` |
| 44 | `MAP-48652AA629` | `retained` | `MockBroker/analyses.json` entry 44; `MockBroker/entries.md` `#MAP-48652AA629` |
| 45 | `MAP-5729FF3D09` | `reframed` | `MockBroker/analyses.json` entry 45; `MockBroker/entries.md` `#MAP-5729FF3D09` |
| 46 | `MAP-67B9817A3D` | `reframed` | `MockBroker/analyses.json` entry 46; `MockBroker/entries.md` `#MAP-67B9817A3D` |
| 47 | `MAP-91432AF5F2` | `retained` | `MockBroker/analyses.json` entry 47; `MockBroker/entries.md` `#MAP-91432AF5F2` |
| 48 | `MAP-38E8988911` | `reframed` | `MockBroker/analyses.json` entry 48; `MockBroker/entries.md` `#MAP-38E8988911` |
| 49 | `MAP-150B8F86DC` | `retained` | `MockBroker/analyses.json` entry 49; `MockBroker/entries.md` `#MAP-150B8F86DC` |
| 50 | `MAP-CF5A1A7070` | `reframed` | `MockBroker/analyses.json` entry 50; `MockBroker/entries.md` `#MAP-CF5A1A7070` |
| 51 | `MAP-BF81183BD5` | `reframed` | `MockBroker/analyses.json` entry 51; `MockBroker/entries.md` `#MAP-BF81183BD5` |

`question-inputs.json` 中没有 `group: MockBroker` 条目（原始 450 条按其他组归属）。但有 10 条由其他组拥有、明确以 MockBroker/simulator 为问题对象；不能把它们改标为 MockBroker，以下给出原属 closure 身份：

| ID | 原归属组 | 原问题（逐字） | closure 处置位置 |
|---|---|---|---|
| `MAP-177DF827E5` | `CoreAccount` | MockBroker idempotency/absence evidence must be supplied by its interpreter contract; otherwise the crash case remains Unknown and requires reconciliation. | `CoreAccount/questions-closure.json:L6-L7` `integration-resolved` |
| `MAP-189E766E12` | `CoreAccount` | Native idempotency support of MockBroker is test-owned; absent evidence should keep Unknown unresolved. | `CoreAccount/questions-closure.json:L27-L28` `integration-resolved` |
| `MAP-C735359708` | `CoreAccount` | Adapter must define when null is definitive; the current MockBroker test does not. | `CoreAccount/questions-closure.json:L111-L112` `empirical-retained` |
| `MAP-5B98644210` | `CoreAccount` | Which broker avgCost fields are authoritative is adapter evidence; MockBroker behavior alone cannot upgrade it. | `CoreAccount/questions-closure.json:L153-L154` `empirical-retained` |
| `MAP-F54308897B` | `TradingJournal` | MockBroker ledger 的持久介质由主集成 slice 决定；必须独立于 SQLite UTA authority，具体实现未在本源文件中给出。 | `TradingJournal/questions-closure.json:L63-L64` `design-decided` |
| `MAP-2810B2FE69` | `RuntimeComposition` | The deployment mode source/admin principal is not shown here; absent an explicit Development/Test mode and authorization capability, simulator routes remain Disabled/NotFound. | `RuntimeComposition/questions-closure.json:L269-L270` `design-decided` |
| `MAP-A173AC5D0E` | `Polling` | 当前 MockBroker 没有持久化 remote ledger 或独立子进程协议；实现第一条 falsifier 时需实证选择‘测试进程内保留 broker、仅重启 worker’还是独立持久 broker actor，并记录该边界，不能假定 in-memory object 等价于远端持久性。 | `Polling/questions-closure.json:L6-L7` `design-decided` |
| `MAP-9A7B5853BF` | `Polling` | MockBroker 当前递增 order id 没有 venue-side idempotency；第一条测试只能验证 scheduler 的 stable identity/no-blind-retry，不能把该 mock 行为当作 native idempotency evidence。 | `Polling/questions-closure.json:L13-L14` `empirical-retained` |
| `MAP-F6CFDCE6F2` | `Polling` | MockBroker 的 `setMarkPrice` 是测试控制面，不证明真实 venue 的 order-status freshness 或 execution identity；真实 adapter acceptance 仍需分别取得。 | `Polling/questions-closure.json:L20-L21` `empirical-retained` |
| `MAP-5D07510B31` | `Polling` | 各 adapter 的 order-status retention、symbol-scoped lookup、listing freshness 和稳定 execution identity 尚未由统一 SPI 证明；无证据时必须落 Unknown/OperatorRequired，而不是由 MockBroker 的 getOrder null/递增 id 推断。 | `Polling/questions-closure.json:L55-L56` `empirical-retained` |

#### 当前源码事实（Mock-specific）

- `MockBroker` 的 `searchContracts/getContractDetails` 忽略输入，返回一个 generic AAPL-like contract；`getQuote/getHistorical/getMarketClock` 有默认 100、±0.01、固定 volume/now/always-open（`services/uta/src/domain/trading/brokers/mock/MockBroker.ts:259-273,479-517`）。这些是 fixture behavior，不是 catalog/quote/session/finality evidence。
- `placeOrder` 生成递增 process-local id；market 直接按 mark/default 100 成交，limit/stop 变 Submitted；`fillOrder` 可 partial/full，累计 qty/weighted average；这些 state 都只在 `_positions/_orders/_markPrices` map 中（`:185-208,278-324,579-621`）。
- `setPositions/setOrders/setAccountInfo` 直接 override maps/account；`resolveNativeKey` 未注册时还合成 STK Contract；`_buildContract` 对 secType/exchange/currency 等填默认值（`:533-544,637-663,858-913`）。
- `getCapabilities` 宣传 STP LMT，但 `_matchPendingOrders` 把 stop-limit 折叠成触发时 fill（`:519-520,799-839`）；这不是可供核心泛化的原子 stop-limit semantics。

由此 Mock 的实际扩展要求是：fixture 控制、普通 data reads、execution simulation、external stimulus 和 evidence/replay 分别声明 scope、identity、sequence、completeness 与 lifecycle；不让默认值、递增 id 或 map null 充当真实 provider 的幂等、absence、finality 或 durable source。

### 3.2 Leverup

#### 当前源码事实与簇

- **LU-1（relayer identity/status/retention）**：`LeverupBroker.ts:69-78,450-492` 的 `orderTracking` 只在进程内按 inputHash 记状态；`relayer-client.ts:42-72` 只有 hash/status shape，`:74-93` 本地超时不提供远端结论。对应“duplicate/idempotency/inputHash retention/status namespace/finality”问题。
- **LU-2（EIP-712 / Pyth / schema / finality）**：`eip712.ts:4-10,52-117,121-162` 明确 nested/flat 两种 primary type，salt 使用 `Date.now()+Math.random`；`LeverupBroker.ts:111-114,258-296` 运行时选择 mutable variant 后签名 POST。没有版本化 accepted schema/chain finality evidence。
- **LU-3（close relation）**：`LeverupBroker.ts:327-374` 忽略 `_quantity`、从 reader open positions 取第一条匹配 pair、close request 只有 positionHash/deadline/signature；partial-close 和 residual/terminal 状态不在当前契约。
- **LU-4（fee/valuation）**：`reader-client.ts:38-50` 只注释 margin/qty/entry 的 decimal 线索，fee strings 没有权威 units；`LeverupBroker.ts:378-410` 将 margin/fees 粗略合成为 net liquidation，并以 USD/0 PnL 返回。
- **LU-5（reader completeness）**：`reader-client.ts:80-90` 只读 `page=0` 且过滤 OPEN；`LeverupBroker.ts:416-448` 对未知 pair 静默 `continue`、把 entry 当 market、margin 当 marketValue、PnL 置 0。
- **LU-6（init/pair/write capability）**：`LeverupBroker.ts:132-150` 初始化只 RPC `getChainId`；`pairs.ts:29-81` 有静态 pair list/testnet alias；`LeverupBroker.ts:522-546` 静态 CRYPTO_PERP/MKT capability 与 unknown-key fallback。没有 reader/relayer health、scope/address/schema/deployment/credential authorization proof。
- **LU-7（quote/session）**：`LeverupBroker.ts:494-518` quote 只一条 Pyth value，bid/ask 复用，volume=0；clock always-open。没有 freshness/session/calendar evidence。

| # | 原始问题 ID | 原始问题（逐字） | 当时处置 | 处置位置 | 当前源码核查簇 |
|---:|---|---|---|---|---|
| 1 | `MAP-2FF2A5B544` | The relayer duplicate-submit/idempotency scope and inputHash retention horizon are not documented in the source and require native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L6-L7` | `LU-1` |
| 2 | `MAP-2FF2A5B544` | The accepted EIP-712 schema, chain finality, and semantic meaning of a Pyth binary update are not established by the local fixtures; absent evidence, the plan stops at Ack/Unknown and does not claim execution. | `empirical-retained` | `Leverup/questions-closure.json:L13-L14` | `LU-2` |
| 3 | `MAP-A2A0451C27` | Whether LeverUp's native close endpoint supports partial quantity is not evidenced by this source and must remain unavailable until a documented/empirical capability is captured. | `empirical-retained` | `Leverup/questions-closure.json:L20-L21` | `LU-3` |
| 4 | `MAP-B9BAFEC82F` | The source does not document the units for open/execution/funding/holding fee strings beyond their decimal encoding; keep their currency/scale unavailable until observed. | `empirical-retained` | `Leverup/questions-closure.json:L27-L28` | `LU-4` |
| 5 | `MAP-A3B8CD6164` | The relayer API's exact semantics for executed/success, status retention, and transaction finality are not evidenced by source; native conformance evidence is required. | `empirical-retained` | `Leverup/questions-closure.json:L34-L35` | `LU-2` |
| 6 | `MAP-B100B9C54C` | The source does not identify which primary type the live relayer accepts; schema capability remains unavailable until native protocol evidence is recorded. | `empirical-retained` | `Leverup/questions-closure.json:L41-L42` | `LU-2` |
| 7 | `MAP-50F0F7A825` | The source proves only bytes32 formatting; any relayer deduplication or salt-retention guarantee remains unavailable and cannot be inferred from local uniqueness. | `empirical-retained` | `Leverup/questions-closure.json:L48-L49` | `LU-1` |
| 8 | `MAP-D1A1D77A33` | The source comment does not provide a protocol version, accepted EIP-712 primary type, relayer idempotency/retention guarantee, status terminal semantics, chain finality rule, complete reader coverage, or fee units; all such manifest features must remain Unavailable/Unknown until independent native evidence is recorded. | `empirical-retained` | `Leverup/questions-closure.json:L55-L56` | `LU-6` |
| 9 | `MAP-5E91CFA930` | The source only proves an RPC chainId probe; reader/relayer health probes, scope-directory semantics, accepted schema, and address-set checks require separate evidence. Until then initialization can expose read-only/degraded capability but must not advertise write readiness. | `empirical-retained` | `Leverup/questions-closure.json:L62-L63` | `LU-6` |
| 10 | `MAP-5EDC8088C6` | Source does not establish the live collateral/token mapping, leverage semantics, or zero TP/SL protocol meaning for every listed pair; keep unavailable until native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L69-L70` | `LU-6` |
| 11 | `MAP-6786905A37` | The live accepted schema variant and protocol version are not documented; this remains unavailable until external/native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L76-L77` | `LU-2` |
| 12 | `MAP-AFEC8DA518` | Relayer duplicate-submit behavior, inputHash retention, and lookup guarantees are absent from the source; native evidence is required before retry/idempotency claims. | `empirical-retained` | `Leverup/questions-closure.json:L83-L84` | `LU-1` |
| 13 | `MAP-B53E29D3CC` | Native partial-close support and close status/finality semantics are not present in this source; remain unavailable pending native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L90-L91` | `LU-3` |
| 14 | `MAP-123F8DBC3D` | Fee currency/scale and a reliable net-liquidation source are not documented in this file; native observation is required. | `empirical-retained` | `Leverup/questions-closure.json:L97-L98` | `LU-4` |
| 15 | `MAP-0233341AE8` | REST pagination consistency and exact fee/PnL units are not evidenced; retain raw fields and require native evidence before valuation claims. | `empirical-retained` | `Leverup/questions-closure.json:L104-L105` | `LU-5` |
| 16 | `MAP-5D7C69A184` | Relayer status retention, namespace listing, and terminal/finality semantics are unavailable from source and need native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L111-L112` | `LU-1` |
| 17 | `MAP-481A2438E0` | The source contains no bid/ask/volume feed and no verified freshness, session, or finality policy; those fields stay unavailable and stale observations cannot authorize writes. | `empirical-retained` | `Leverup/questions-closure.json:L118-L119` | `LU-7` |
| 18 | `MAP-47A0790F1B` | No LeverUp venue calendar/session source is present; MarketSession remains Unknown and write admission is blocked until a versioned calendar/evidence source exists. | `empirical-retained` | `Leverup/questions-closure.json:L125-L126` | `LU-7` |
| 19 | `MAP-4AD307691B` | Per-instrument deployment support and accepted schema evidence are absent; static CRYPTO_PERP/MKT labels cannot become usable capability without context. | `empirical-retained` | `Leverup/questions-closure.json:L132-L133` | `LU-6` |
| 20 | `MAP-96C363D9C7` | The live relayer's accepted primary schema is undocumented; variant selection remains unavailable until evidence is collected. | `empirical-retained` | `Leverup/questions-closure.json:L139-L140` | `LU-2` |
| 21 | `MAP-BC7663242A` | The reader API's pagination consistency, total-page guarantees, and fee-unit semantics are not established by this source; keep completeness/valuation conservative until native evidence. | `empirical-retained` | `Leverup/questions-closure.json:L146-L147` | `LU-5` |

### 3.3 LeverupProtocols

#### 当前源码事实与簇

- **LP-1（scale/unit/rounding）**：`decimals.ts:4-32,34-55` 固定 QTY=10、PRICE=18、USDC=6，以 ROUND_DOWN 转换；`reader-client.ts:27-50` 只有部分字段注释，未给 fee/PnL/timestamp authority；`LeverupBroker.ts:238-255,378-410` 以 USD/1x 及 raw fee 假设消费它们。
- **LP-2（Pyth schema/policy）**：`pyth.ts:16-23,31-47,54-72` 将 Hermes JSON 直接 cast 成接口，返回 binary 与 local parsed price/publishTime；没有 response version、payload bound、conf/age/exponent/negative/rate/timeout policy。
- **LP-3（collateral/protection/close）**：`LeverupBroker.ts:235-255` 固定 USDC/LVUSD、1x、0 protection；`:327-374` close 只送 positionHash，不带 quantity；`eip712.ts:99-117` 仅有 nested/flat close schema。
- **LP-4（deployed EIP-712/schema）**：`eip712.ts:4-10,52-117` 同时暴露 conflicting variants；本仓库没有 deployed contract bytecode/domain acceptance 或 schema library binding。仅能证明本地 codec shape。
- **LP-5（salt/idempotency/status/finality）**：`eip712.ts:121-124` salt 非 durable；`relayer-client.ts:42-93` 无 idempotency/retention/finality/absence semantics；`LeverupBroker.ts:450-492` 只查 process-local tracking。
- **LP-6（credential/secret/auth integration）**：`types.ts:10-22` 与 `LeverupBroker.configSchema/fromConfig` 接收 raw privateKey；relayer request `:13-40,95-105` 无 auth/header config；当前无 credential service/account directory/Trader Agent authorization API。
- **LP-7（pairs/network/catalog/deployment）**：`pairs.ts:29-81` 静态 mainnet 列表、testnet=mainnet；`types.ts:24-60` 固定 chain/address/URL；没有 authoritative registry revision、per-instrument jurisdiction/session/leverage/fee metadata、testnet endpoint/pair evidence。
- **LP-8（connection/cursor/block/runtime integration）**：`ReaderClient`/`RelayerClient` 是具体 classes，没有共享 Connection Layer descriptor；reader 只 page=0，源码无 cursor beyond page/size 和 stable block reference，也没有把 runtime service names 作为 provider declaration。
- **LP-9（closed retention）**：reader 只 fetch open positions，当前无 closed-row/history endpoint 或 retention guarantee。

| # | 原始问题 ID | 原始问题（逐字） | 当时处置 | 处置位置 | 当前源码核查簇 |
|---:|---|---|---|---|---|
| 1 | `MAP-63F62A28BF` | Authoritative scales for non-USDC collateral and every high-leverage pair are not present here; obtain them before advertising capability. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L6-L7` | `LP-1` |
| 2 | `MAP-93BB15270F` | The deployed contract rounding rule is not established here; compatibility policy needs protocol evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L17-L18` | `LP-1` |
| 3 | `MAP-CA68AA9D2A` | Units for REST fields beyond qty/price require authoritative response evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L28-L29` | `LP-1` |
| 4 | `MAP-B6898CEF97` | Future product scales require deployed catalog evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L39-L40` | `LP-1` |
| 5 | `MAP-EB598077BB` | Exact confidence/freshness thresholds are market policy decisions. | `design-decided` | `LeverupProtocols/questions-closure.json:L50-L51` | `LP-2` |
| 6 | `MAP-98D8B226B2` | Whether LVUSD or another collateral is accepted per network is not established here. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L61-L62` | `LP-3` |
| 7 | `MAP-A8F11986D4` | Canonical primary types and relayer acceptance are unavailable in this repository and block write capability. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L72-L73` | `LP-4` |
| 8 | `MAP-351C6A94E7` | Exact schema library and sealed-byte storage are shared integration choices. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L83-L84` | `LP-4` |
| 9 | `MAP-73F74DC466` | Deployed code/domain acceptance is external evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L94-L95` | `LP-4` |
| 10 | `MAP-518E08C180` | Deployed primary type and zero-protection semantics are unavailable and block this capability. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L105-L106` | `LP-3` |
| 11 | `MAP-6E2E6F9904` | No evidence identifies canonical primary type or legitimate multi-version deployment. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L116-L117` | `LP-4` |
| 12 | `MAP-A9DB1F677B` | Close schema and partial-close semantics are unavailable here. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L127-L128` | `LP-3` |
| 13 | `MAP-12314DC5A5` | Relayer/contract salt idempotency is not proven here. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L138-L139` | `LP-5` |
| 14 | `MAP-2D927BE0BD` | Concrete credential service API is outside this source. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L149-L150` | `LP-6` |
| 15 | `MAP-6D6A28953D` | Exact sealed signature redaction/storage is a shared integration contract. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L160-L161` | `LP-6` |
| 16 | `MAP-CAE8A402AD` | Close schema and partial semantics require venue evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L171-L172` | `LP-3` |
| 17 | `MAP-14017B6DD3` | Concrete secret-store and Trader Agent authorization APIs are outside source. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L182-L183` | `LP-6` |
| 18 | `MAP-7B2ED6A111` | Final symbol names and composition module are shared integration decisions. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L193-L194` | `LP-7` |
| 19 | `MAP-6528AEB1B4` | Jurisdiction/session/leverage/fee metadata is not present here; catalog owner must supply it. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L205-L206` | `LP-7` |
| 20 | `MAP-D33182231F` | Authoritative list, addresses, and revision are absent; complete mainnet capability is blocked. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L216-L217` | `LP-7` |
| 21 | `MAP-ACD640430F` | Authoritative testnet pair addresses and endpoint contract are absent. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L227-L228` | `LP-7` |
| 22 | `MAP-902BBDA309` | Allowed user-facing alias policy is unspecified; default to canonical symbols. | `design-decided` | `LeverupProtocols/questions-closure.json:L238-L239` | `LP-7` |
| 23 | `MAP-6690E83E34` | On-chain pair/feed registry evidence is outside pairs.ts. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L249-L250` | `LP-7` |
| 24 | `MAP-970DB739F5` | Hermes response version and maximum safe payload size require verified adapter policy. | `design-decided` | `LeverupProtocols/questions-closure.json:L260-L261` | `LP-2` |
| 25 | `MAP-C5F7182D33` | Rate/timeout/size limits and collateral feed requirements need market-data policy. | `design-decided` | `LeverupProtocols/questions-closure.json:L271-L272` | `LP-2` |
| 26 | `MAP-6966FD8244` | Age/confidence/exponent thresholds and negative policy are market configuration. | `design-decided` | `LeverupProtocols/questions-closure.json:L282-L283` | `LP-2` |
| 27 | `MAP-A94BD9AD27` | Exact Connection Layer interface is shared integration work. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L293-L294` | `LP-8` |
| 28 | `MAP-4996C21AA2` | Fee/PnL units and timestamp semantics are comments only; authoritative API examples are needed. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L304-L305` | `LP-1` |
| 29 | `MAP-6CE514231C` | Whether API has cursor semantics beyond page/size is undocumented. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L315-L316` | `LP-8` |
| 30 | `MAP-D8D93BC61D` | Effect runtime service names are shared integration choices. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L326-L327` | `LP-8` |
| 31 | `MAP-68B42E34DB` | Closed-row retention window is external reader API fact. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L337-L338` | `LP-9` |
| 32 | `MAP-1F4643BAB5` | Stable block reference acquisition is integration detail. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L348-L349` | `LP-8` |
| 33 | `MAP-2B8DD3E4BD` | Actual live/testnet USDC decimals require chain evidence. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L359-L360` | `LP-1` |
| 34 | `MAP-D8B1941723` | Exact relayer status semantics are not documented; acceptance evidence must define mapping. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L370-L371` | `LP-5` |
| 35 | `MAP-339E61F930` | Relayer idempotency/deduplication behavior is unproven. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L381-L382` | `LP-5` |
| 36 | `MAP-25EDC2AA39` | Unknown inputHash semantics are not specified; preserve Unknown. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L393-L394` | `LP-5` |
| 37 | `MAP-96515A5FA2` | Relayer finality/retention and schedule are operational policies. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L404-L405` | `LP-5` |
| 38 | `MAP-A283DD30CA` | Additional relayer headers/authentication are not shown; configuration must provide them without hardcoding secrets. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L415-L416` | `LP-6` |
| 39 | `MAP-09A529447A` | Credential service and account-directory APIs are outside types.ts. | `integration-resolved` | `LeverupProtocols/questions-closure.json:L426-L427` | `LP-6` |
| 40 | `MAP-B24803E3AD` | Deployment bytecode/version evidence is not in type declaration. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L436-L437` | `LP-7` |
| 41 | `MAP-7DDADCCAD1` | Correct testnet URLs/service evidence are absent and block testnet writes. | `empirical-retained` | `LeverupProtocols/questions-closure.json:L447-L448` | `LP-7` |

### 3.4 Catalog

#### 当前源码事实与簇

- **CAT-1（adapter-specific idempotency/lookup/completeness）**：catalog 仅选择 engine；各 adapter 实际不同。Alpaca `placeOrder` 调 `createOrder` 并把 legs 在 place 时返回（`AlpacaBroker.ts:271-347`），CCXT order id→symbol 只在 process map，cancel/modify 依赖它（`CcxtBroker.ts:228-233,613-689`），IBKR place/modify/cancel 使用 request bridge/waiter（`IbkrBroker.ts:480-555`），Longbridge `getOrder` catch 后直接 null（`LongbridgeBroker.ts:613-629`）。这些实现不能由 preset wrapper 升级成跨 venue idempotency/retention/absence guarantee。
- **CAT-2（environment/scope/credential/account evidence）**：preset `isPaper` 默认只看 mode 字符串，E2E setup 的 `hasCredentials` 只按字段 presence/IBKR true 判断（`preset-catalog.ts:102-106`; `setup.ts:27-47`）；真实 adapter 各自 probe 不同：Alpaca `getAccount` (`AlpacaBroker.ts:157-203`)、Longbridge `accountBalance` (`LongbridgeBroker.ts:180-227`)、IBKR TWS account subscription (`IbkrBroker.ts:182-223`)、CCXT required credentials/markets (`CcxtBroker.ts:311-398`)。port/mode/field presence 不是 authenticated environment/permission/scope evidence。
- **CAT-3（dynamic custom fields/extensions）**：`BrokerPresetDef` 的 `zodSchema`/`toEngineConfig`/`fingerprintFields` 是用户表单和 identity adapter；serialized preset 不携带 runtime interpreter/capability/error/availability binding。CCXT Custom 允许许多 optional credential/options fields（`preset-catalog.ts:294-333`; `CcxtBroker.ts:163-215`），不能从“可传递 Record”获得 native plan semantics 或 write authorization。
- **CAT-4（legacy identity/migration）**：`deriveUtaId` 只按 preset fingerprint fields canonicalize/hash（`preset-catalog.ts:541-579`）；legacy migration 依据 old `type/brokerConfig` 映射 preset（`src/core/config.ts:609-701`），sealed account storage 负责凭据文件而非 effect history (`:704-782`)。旧 id 可作 lookup/migration evidence，不是新 effect identity 或 native idempotency proof。

| # | 原始问题 ID | 原始问题（逐字） | 当时处置 | 处置位置 | 当前源码核查簇 |
|---:|---|---|---|---|---|
| 1 | `MAP-9AD9951502` | The source does not document whether Alpaca native order submission is idempotent across process restart; adapter must use order identity/reconcile-before-retry until evidence is recorded. | `empirical-retained` | `Catalog/questions-closure.json:L6-L7` | `CAT-1` |
| 2 | `MAP-607170E22C` | Alpaca API endpoint/account response fields proving environment and trade permission are not present in this wrapper source; broker adapter evidence must define them. | `empirical-retained` | `Catalog/questions-closure.json:L13-L14` | `CAT-2` |
| 3 | `MAP-6496594BF0` | Native Alpaca idempotency/lookup horizon and exact partial-fill recovery evidence remain unavailable in this source range. | `empirical-retained` | `Catalog/questions-closure.json:L20-L21` | `CAT-1` |
| 4 | `MAP-B40F4C1C42` | Exact idempotency scope and completeness/retention horizon differ by exchange and are not established by this wrapper source; each adapter must record evidence before allowing resend. | `empirical-retained` | `Catalog/questions-closure.json:L27-L28` | `CAT-1` |
| 5 | `MAP-F3151B31E7` | Required credential subsets and account/sub-account selector semantics are exchange-specific and need per-pack evidence. | `empirical-retained` | `Catalog/questions-closure.json:L34-L35` | `CAT-2` |
| 6 | `MAP-9D3DC42AC9` | Idempotency and full pagination guarantees vary per CCXT exchange; no generic resend permission can be designed without adapter evidence. | `empirical-retained` | `Catalog/questions-closure.json:L41-L42` | `CAT-1` |
| 7 | `MAP-1E5FD0A690` | TWS/Gateway environment evidence and callback completeness are not established by this wrapper; coordinate with IBKR implementation evidence before permitting automatic resend. | `empirical-retained` | `Catalog/questions-closure.json:L48-L49` | `CAT-2` |
| 8 | `MAP-C4C40BAECB` | Which TWS/Gateway endpoint metadata definitively proves paper versus live must be supplied by the IBKR adapter evidence. | `empirical-retained` | `Catalog/questions-closure.json:L55-L56` | `CAT-2` |
| 9 | `MAP-3392948A39` | Native IBKR idempotency and complete query/late-callback retention horizons require empirical adapter evidence. | `empirical-retained` | `Catalog/questions-closure.json:L62-L63` | `CAT-1` |
| 10 | `MAP-AE59785B88` | Chain finality and relayer idempotency evidence are unavailable in this wrapper range; automatic resend stays disabled until verified. | `empirical-retained` | `Catalog/questions-closure.json:L69-L70` | `CAT-1` |
| 11 | `MAP-2564A889E7` | Whether the relayer exposes a stable signer/account identity and idempotency key is empirical and must be recorded before resend. | `empirical-retained` | `Catalog/questions-closure.json:L76-L77` | `CAT-1` |
| 12 | `MAP-50C8158380` | Relayer receipt retention, chain finality horizon, and deterministic replayability need real adapter evidence. | `empirical-retained` | `Catalog/questions-closure.json:L83-L84` | `CAT-1` |
| 13 | `MAP-75B61EBF36` | Longbridge endpoint/account region evidence and idempotency horizon require adapter experiments. | `empirical-retained` | `Catalog/questions-closure.json:L90-L91` | `CAT-1` |
| 14 | `MAP-1986FE3044` | Exact Longbridge region and supported-currency payload fields must be established by adapter SDK evidence. | `empirical-retained` | `Catalog/questions-closure.json:L97-L98` | `CAT-2` |
| 15 | `MAP-E52D407CDC` | Longbridge order idempotency, token refresh semantics, and listing completeness remain empirical. | `empirical-retained` | `Catalog/questions-closure.json:L104-L105` | `CAT-1` |
| 16 | `MAP-601F6E2834` | Per-exchange credential requirements and extension fields remain empirical; absent evidence the typed codec rejects them or keeps them outside write capability. | `empirical-retained` | `Catalog/questions-closure.json:L111-L112` | `CAT-3` |
| 17 | `MAP-E745F1370E` | Which broker responses encode environment is empirical and delegated to each adapter/live-evidence design. | `empirical-retained` | `Catalog/questions-closure.json:L118-L119` | `CAT-2` |
| 18 | `MAP-EBB7846E5F` | Current source does not establish Binance Demo API response/account identity or idempotency horizon; adapter evidence required. | `empirical-retained` | `Catalog/questions-closure.json:L125-L126` | `CAT-1` |
| 19 | `MAP-BB8EAF65B0` | OKX API mode/sub-account and idempotency evidence are not present in this catalog source. | `empirical-retained` | `Catalog/questions-closure.json:L132-L133` | `CAT-2` |
| 20 | `MAP-6E3C5642E6` | Exact Bybit endpoint/account evidence and idempotency scope require adapter experiments. | `empirical-retained` | `Catalog/questions-closure.json:L139-L140` | `CAT-2` |
| 21 | `MAP-2F4E92A2AE` | Vault/API-wallet semantics and native idempotency/finality evidence require adapter experiments. | `empirical-retained` | `Catalog/questions-closure.json:L146-L147` | `CAT-1` |
| 22 | `MAP-B9545FA731` | Bitget account-mode endpoint and idempotency evidence are unavailable in this source. | `empirical-retained` | `Catalog/questions-closure.json:L153-L154` | `CAT-2` |
| 23 | `MAP-F62E863C78` | Credential requirements, native plan semantics, and observation completeness remain unavailable until a concrete exchange is selected and empirically profiled; UnverifiedExchange stays query-only/unsupported until then. | `empirical-retained` | `Catalog/questions-closure.json:L160-L161` | `CAT-3` |
| 24 | `MAP-2862195456` | Which exact Alpaca account response fields are the authoritative environment and account-scope evidence must be fixed by the adapter pack contract. | `empirical-retained` | `Catalog/questions-closure.json:L167-L168` | `CAT-2` |
| 25 | `MAP-DE2769E2F7` | The exact IBKR handshake/account-summary fields for environment evidence are adapter-owned and must be specified before implementation. | `empirical-retained` | `Catalog/questions-closure.json:L174-L175` | `CAT-2` |
| 26 | `MAP-42A8E8BFCC` | Which Longbridge endpoint and response fields prove environment, account scope, and token expiry must be fixed in the pack contract. | `empirical-retained` | `Catalog/questions-closure.json:L181-L182` | `CAT-2` |
| 27 | `MAP-FA8441EFDE` | Exact LeverUp chain ID, contract, and Trader Agent observation fields are adapter evidence still to be specified. | `empirical-retained` | `Catalog/questions-closure.json:L188-L189` | `CAT-2` |
| 28 | `MAP-F45EE8D4C7` | Legacy git/sealed account vectors must be captured from existing records before migration; old deriveUtaId output remains lookup-only and never new identity authority. | `empirical-retained` | `Catalog/questions-closure.json:L195-L196` | `CAT-4` |

### 3.5 LiveEvidence

#### 当前源码事实与簇

- **E-1（venue result/trigger/bracket/mode/timeout）**：Bybit E2E 直接 raw createOrder + cache seed（`ccxt-bybit.e2e.spec.ts:186-230`）；其 TP/SL 读取允许缺失仅记 NOTE（`:140-180`）；Hyperliquid 先 place 后 position/query（`ccxt-hyperliquid.e2e.spec.ts:97-166`）；OKX 按 51010/51205 和 dust residual 分支（`ccxt-okx.e2e.spec.ts:104-228`）；IBKR quote timeout skip（`ibkr-paper.e2e.spec.ts:270-299`）。这些是 evidence scenarios，不是统一 capability.
- **E-2（listing namespace/coverage）**：CCXT raw diagnostic 单独 query spot/perp open/closed、market.id/symbol、since behavior（`ccxt-raw-diagnostic.e2e.spec.ts:76-148`）；不能以一个列表返回宣称全 namespace/full coverage。
- **E-3（sink append concurrency/order）**：`live-paper-evidence.ts:40-86` 以 runId 文件 append JSONL，调用者在 `ibkr-paper.e2e.spec.ts:148-214` 等处记录；没有 append sequence/import order/conflict contract。

| # | 原始问题 ID | 原始问题（逐字） | 当时处置 | 处置位置 | 当前源码核查簇 |
|---:|---|---|---|---|---|
| 1 | `MAP-4D4A864108` | The source does not prove whether the Bybit adapter returns parent-linked TP/SL legs for this request; acceptance must obtain a venue capability/observation fixture before claiming bracket confirmation. | `empirical-retained` | `LiveEvidence/questions-closure.json:L6-L7` | `E-1` |
| 2 | `MAP-E5356E684D` | The source does not establish whether the venue trigger query exposes a stable native identity after cache invalidation; adapter observation coverage is required. | `empirical-retained` | `LiveEvidence/questions-closure.json:L21-L22` | `E-1` |
| 3 | `MAP-A60C86B58F` | The source does not prove Hyperliquid execution/fill latency or stablecoin normalization across all account modes; live acceptance must supply observed execution and currency-policy evidence. | `empirical-retained` | `LiveEvidence/questions-closure.json:L35-L36` | `E-1` |
| 4 | `MAP-FBF3A41608` | The exact OKX dust/minimum-balance threshold is venue/account dependent; retain policy configuration and observe residual rather than hard-code a universal threshold. | `empirical-retained` | `LiveEvidence/questions-closure.json:L49-L50` | `E-1` |
| 5 | `MAP-7DAC2704FB` | The adapter must empirically map OKX account-mode error codes beyond the observed 51010 text before classifying additional variants as non-fatal capability refusal. | `empirical-retained` | `LiveEvidence/questions-closure.json:L62-L63` | `E-1` |
| 6 | `MAP-B5990574ED` | The diagnostic source does not establish complete spot/perp namespace coverage; catalog probe must report Partial/Unavailable until adapter pagination evidence exists. | `empirical-retained` | `LiveEvidence/questions-closure.json:L76-L77` | `E-2` |
| 7 | `MAP-FFA9030D49` | The source observes a TWS snapshot timeout pattern but does not prove quote request behavior for every TWS/Gateway version; acceptance must preserve an explicit unavailable branch. | `empirical-retained` | `LiveEvidence/questions-closure.json:L91-L92` | `E-1` |
| 8 | `MAP-C2F022975E` | The source does not prove concurrent JSONL append/import ordering; evidence sink acceptance must establish sequence/conflict handling under concurrent writers. | `empirical-retained` | `LiveEvidence/questions-closure.json:L105-L106` | `E-3` |

### 3.6 TargetGaps

#### 当前源码事实与簇

- **TG-1（effect restoration/idempotency）**：`TradingGit.ts:119-185` 先 broker effect 再 commit/persist；`git-persistence.ts:27-48` 只有 JSON state + legacy fallback；`UnifiedTradingAccount.ts:844-980` sync/observe 依赖 broker listing/getOrder，不能在 restart 后恢复一个 durable effect identity/result unknown。
- **TG-2（storage dependency/implementation availability）**：`services/uta/package.json:7-34` 没有 Effect/sql/sqlite-node/better-sqlite3；当前 `event-log.ts:1-10,19-91` 是通用 JSONL journal，`git-persistence.ts` 是 commit JSON。主书 `docs/uta-capability-runtime-design.md:1186-1192` 明确 SQLite 仍是候选关系的实现，不是已切换事实。
- **TG-3（external paper/package evidence）**：E2E setup 只按 paper/mode/field presence、TCP reachability 和 30s init filter（`setup.ts:25-138`），`docs/uta-live-testing.md:34-47,222-319` 把 live/demo acceptance 明确列为需要真实账户的验证层；Docker/package 只声明 Node/pnpm/artifact/OS dependency closure（`Dockerfile:11-65,67-170`; root `package.json:101-131`），未执行本次的 paper availability、session/entitlement、native retry/absence 或 packaged ABI runtime proof。

| # | 原始问题 ID | 原始问题（逐字） | 当时处置 | 处置位置 | 当前源码核查簇 |
|---:|---|---|---|---|---|
| 1 | `NOTE-5-4` | Which real broker/action combinations have empirically proven restoration and idempotency guarantees remains adapter-specific acceptance evidence; unproven capabilities are unavailable, not assumed. | `empirical-retained` | `TargetGaps/questions-closure.json:L6-L7` | `TG-1` |
| 2 | `NOTE-7-1` | Exact compatible Effect/sql/sqlite-node/better-sqlite3 semver and native binary build/ABI evidence are absent from the current UTA manifest; first storage slice must lock and execute them before availability claims. | `empirical-retained` | `TargetGaps/questions-closure.json:L13-L14` | `TG-2` |
| 3 | `NOTE-9-1` | Each broker's native idempotency horizon, complete lookup namespaces and absence/fencing proof require real broker evidence; without it retry capability is ReconcileBeforeRetry only. | `empirical-retained` | `TargetGaps/questions-closure.json:L20-L21` | `TG-1` |
| 4 | `NOTE-18-1` | Current paper account availability, venue session/entitlements and concrete native retry/absence evidence are empirical and intentionally not queried during this design-only assignment. | `empirical-retained` | `TargetGaps/questions-closure.json:L27-L28` | `TG-3` |
| 5 | `NOTE-18-2` | Release-supported OS/architecture matrix and packaged native ABI load results must be supplied by the packaging execution slice; this assignment has inspected manifest/bundle/Docker contracts but does not fabricate executed distribution evidence. | `empirical-retained` | `TargetGaps/questions-closure.json:L34-L35` | `TG-3` |

## 4. 未解决范围与不作的推断

1. 本文没有外部请求；LeverUp chain/deployment/EIP-712 accepted primary type、relayer duplicate/retention/finality、reader pagination/fee units、各 venue environment/permission/idempotency/absence，仍只能标为当前源码没有证据的 Unknown/Unavailable。`integration-resolved`/`design-decided` 只是原 closure 的处置元数据，不是本文观察到的外部事实。
2. 本文没有把 Mock map、递增 order id、`getOrder(null)`、静态 engine/preset、mode 字符串、E2E 直接 broker probe、通用 event-log 或 commit.json 解释为 provider-native guarantee。
3. 本文没有选择 SQLite/Effect/单 writer/某个 durable mock venue，也没有把旧 event-flows、旧 EF/槽位、legacy-accommodation targetModel、旧实验或某个业务对象改写成新的核心定义。主书 §3–5、§8–9 的关系是当前约束；业务例子仅作为各自源码消费者的反例/证据，未混入核心。
4. 未读/未验证内容：没有执行任何外部账户、真实 UI/CLI、relayer、RPC、pack install/import 或并发写入实验；因此不声称 evidence sink ordering、远端最终性、ABI load 或 restart behavior 已成立。本材料也没有声称对仓库所有非这六组源码完成全局审计。
5. MockBroker 的直接 closure 缺失已单独标出；若 Main 需要将其与 CoreAccount/TradingJournal/Polling 的交叉问题合并，必须沿其所属 closure ID 继续回查，而不能创建虚假的 MockBroker question ledger。

## 5. 原始材料索引

- 当前研究边界：`docs/uta-capability-runtime-design/current-research.md:56-127`。
- 原始调查入口和“原文/候选设计/问题 closure”边界：`docs/uta-effect-runtime-design/solutions/index.md:5-16,47-63`。
- 六组逐项原文：
  - `docs/uta-effect-runtime-design/solutions/MockBroker/entries.md` + `analyses.json` + `reviews.json` + `design.md`；结构/覆盖 `coverage.json:1409-1465`，source ownership `ownership.json:1113-1172`。
  - `.../Leverup/entries.md` + `analyses.json` + `questions-closure.json`（closure ledger 下表）。
  - `.../LeverupProtocols/entries.md` + `analyses.json` + `questions-closure.json`。
  - `.../Catalog/entries.md` + `analyses.json` + `questions-closure.json`。
  - `.../LiveEvidence/entries.md` + `analyses.json` + `questions-closure.json`。
  - `.../TargetGaps/entries.md` + `analyses.json` + `questions-closure.json`。
- 当前源码核心链：`MockBroker.ts`; `routes-simulator.ts`; `UnifiedTradingAccount.ts`; `LeverupBroker.ts`; `relayer-client.ts`; `reader-client.ts`; `eip712.ts`; `decimals.ts`; `pairs.ts`; `pyth.ts`; `preset-catalog.ts`; `presets.ts`; `factory.ts`; `registry.ts`; `broker-packs.ts`; `live-paper-evidence.ts`; `TradingGit.ts`; `git-persistence.ts`; `event-log.ts`; `services/uta/src/main.ts`。
