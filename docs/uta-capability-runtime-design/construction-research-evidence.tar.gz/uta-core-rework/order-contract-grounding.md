# Order 独立研究稿：旧 UTA 单次下单/撤单结果的真实语义

> 状态：静态源码审计材料，不是核心抽象设计，也不宣称设计完成。本文只把 Order 作为一个独立业务实例，用来检验“意图经过组合、派发、返回、后续观察”这条关系；不把 Order 字段、券商政策或本稿候选结论加入核心抽象。

## 0. 范围、事实层级与来源

本稿先按要求读取 `docs/uta-capability-runtime-design/current-research.md:56-127`。该段要求把抽象构造与业务实例分开，并禁止以旧事件流或业务细节填补核心定义；本稿没有读取旧 `event-flows`，也没有改动源码、测试或设计文件。

UTA 的 owner guide 是 `docs/README.md:37-38`：

- `docs/uta-effect-runtime-architecture.md` 是受保护的目标架构与源码映射入口；
- `docs/uta-capability-runtime-design.md` 是方法论与适应性研究入口。

行为事实以当前源码为准：`docs/uta-effect-runtime-architecture.md:1-10` 明确标注目标架构尚未成为当前实现，迁移完成前 current code/runtime behavior authoritative；其边界还明确指出 broker 拥有远端订单/执行事实和 venue-specific acceptance/fill behavior，UTA 不得仅凭本地意图推断远端确认（`docs/uta-effect-runtime-architecture.md:107-113`）。

`docs/uta-effect-runtime-mapping/coverage.md:8-16` 把 `services/uta/src`、`packages/uta-protocol/src`、broker packs 和 UTA client 列为审计范围，并将 `packages/ibkr` 标为下层 SDK，仅通过 UTA adapter 的调用范围评估。`docs/uta-effect-runtime-design/solutions/index.md:3-16` 说明逐项调查是输入材料，不是完整设计，也不表示其中候选解释已经成为裁决。因此下文把 solutions 的 `MAP-*` 只当导航/来源索引；具体行为均重新以当前源码核对，不采纳 entries 中的 targetModel 作为既成事实。

## 1. 调用表面：哪些入口真的会派发

### 1.1 Web/API 单次入口

UTA 服务把 `createTradingRoutes(tradingCtx)` 挂在 `/api/trading`（`services/uta/src/main.ts:154-168`）。单次下单和撤单的完整路径因此是：

- `POST /api/trading/uta/:id/wallet/place-order`（`services/uta/src/http/routes-trading.ts:563-576`）；
- `POST /api/trading/uta/:id/wallet/cancel-order`（`services/uta/src/http/routes-trading.ts:594-606`）。

撤单输入 schema 只要求非空字符串 `orderId` 与非空 `message`（`routes-trading.ts:56-59`）。路由调用 `runOneShot`，而 `runOneShot` 对成功直接返回 `PushResult`，对 stage/commit/push 异常分别映射为 400/400/500（`routes-trading.ts:61-78`）。`executeOneShotOrder` 的实质是 `stage → commit → push`，并把 push 结果原样作为成功结果（`services/uta/src/domain/trading/order-entry.ts:1-73`）。所以这个入口不是“记录一个请求”；它在一次 HTTP 请求内取得了真实 broker mutation 的执行路径。

撤单 staging 本身没有读取目标订单、状态、版本或存在性，只调用 `_assertCanCreateProposal()` 后 `git.add({ action: 'cancelOrder', orderId })`（`services/uta/src/domain/trading/UnifiedTradingAccount.ts:769-772`）。下单 staging 则在本地校验并把字符串数值构造为 native `Order`，然后进入 Git staging（`UnifiedTradingAccount.ts:693-725`）。

### 1.2 AI 工具入口不同

不要把工具层的 `placeOrder`/`cancelOrder` 当成单次派发：它们的描述和实现都是 stage（可选 commit），明确要求随后 `tradingPush`（`src/tool/trading.ts:633-678`、`725-739`）。`tradingPush` 默认只返回待人工审批的操作；只有 `allowAiTrading()` 开启时才调用 `uta.push`（`src/tool/trading.ts:760-807`）。因此“公共单次 HTTP 路径”和“AI 工具先 stage、后 push”是两个不同的 caller contract。

## 2. 共同返回层：`success`、`status` 与数组名不是同一个事实

`IBroker` 的 `placeOrder`/`cancelOrder` 都返回通用 `PlaceOrderResult`：`success`、可选 `orderId`、可选 `orderState`/`error`（`packages/uta-protocol/src/types/broker.ts:170-180`）。这个类型没有规定 `success` 是“本地发送成功”、 “远端接受”、还是“远端已到终态”。

`TradingGit.executePush` 对每个 operation 调用 `config.executeOperation`；抛异常时也只是形成一条 `{success:false,status:'rejected'}` 结果，然后继续做 `getGitState`、追加 commit、`onCommit`，最后按布尔值分桶：`rejected = !r.success`，`submitted = r.success`（`services/uta/src/domain/trading/git/TradingGit.ts:129-185`）。

`parseOperationResult` 只读取 `raw.success === true`；成功时另行把 IBKR-style `orderState.status` 映射为：`Filled → filled`、`Cancelled → cancelled`、`Inactive → rejected`、其他（含缺失/未知）→ `submitted`（`TradingGit.ts:929-977`）。所以这些组合均可由旧实现产生：

| 结果形状 | 旧实现含义 |
|---|---|
| `success:true` + `status:submitted` | operation handler 返回成功，但只表示其 adapter 自己认可的某个点；不等于 fill。 |
| `success:true` + `status:cancelled` | 进入 `submitted[]`，因为数组按 `success` 分桶；`cancelled` 只是独立映射字段。 |
| `success:true` + `status:rejected` | 仍进入 `submitted[]`；例如 `orderState.status = Inactive`。 |
| `success:false` | 进入 `rejected[]`，不保留 broker 结果里的 `orderId`；错误通常已被 adapter 或 guard 压成字符串。 |

因此 `submitted[]` 是“operation result 的 success=true 集合”，不是“所有远端订单已提交集合”；`status` 也是 adapter 返回状态的投影，不是一个统一的完成承诺。`packages/uta-protocol/src/types/git.ts:58-77,119-125` 只声明了这些字段和数组，不补充它们的证据等级。

还有一个 caller 层重要分支：broker 返回 `{success:false}` 或 guard 返回 `{success:false,error}` 时，`executePush` 仍拿到一个正常 raw result，形成 `PushResult.rejected[]`；只要后续 `getGitState`/`onCommit` 没抛异常，`runOneShot` 仍返回 HTTP 200 的 PushResult，而不是 push phase 500（`TradingGit.ts:141-184`、`routes-trading.ts:69-78`）。真正让 one-shot 返回 phase `push`/500 的是 `uta.push` 自身抛异常，例如 push 前置检查或 push 后置 state/commit 回调失败。

## 3. IBKR：下单结果到底等到什么

IBKR broker pack wrapper 直接导入当前 `services/uta` 的 `IbkrBroker`（`packages/uta-broker-ibkr/src/index.ts:1-8`）；registry 将 workspace entry 指向该 pack（`services/uta/src/domain/trading/brokers/registry.ts:44-50,98-110`）。所以以下不是孤立的旧文件猜测，而是当前加载路径上的 adapter 实现。

### 3.1 `placeOrder`

`IbkrBroker.placeOrder` 的顺序（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:480-507`）：

1. 拒绝未实现的附带 TP/SL；
2. 检查已知连接状态、解析可路由 contract；
3. 用 `requestCurrentTime` 做紧邻写操作的 liveness probe（`IbkrBroker.ts:148-163`）；
4. 取得 native `orderId`；
5. 注册 `bridge.requestOrder(orderId)`；
6. 调用 `client.placeOrder(...)`；该 SDK 方法返回 `void`，只在内部把 wire send 异常转成 `wrapper.error`（`packages/ibkr/src/client/orders.ts:18-39,774-778`）；
7. 等待 bridge Promise；解析成功后返回 `success:true`、`orderId` 和 callback 带来的 `orderState`。

`requestOrder` 的 Promise 以 orderId 为 key，默认超时后删除 waiter 并报 NETWORK error（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:231-242`）。当前 bridge 的 `openOrder` callback 会把同 orderId 的 collected `{contract,order,orderState}` 直接 resolve（`request-bridge.ts:738-748`）；它不检查这是 place、modify 还是 cancel，也不检查 `orderState.status`。因此 IBKR place 的 `success:true` 最小可证事实是：本地已经调用了 void SDK 后，bridge 收到了一个被其路由到该 orderId waiter 的 callback，并非独立的同步 send-acceptance 或终态确认。

`orderStatus` 只在 status 为 `Cancelled` 时也 resolve order waiter；其他状态仅缓存正的 filled/avgFillPrice（`request-bridge.ts:750-777`）。因此一个 `Submitted` `openOrder` 可以让 place 成功；一个 callback 中的 `Filled` 状态可以被映射为 `status:filled`，但该 callback 本身仍不是 UTA 独立定义的终态证据，也没有返回 execution/fill data。若只收到 Filled `orderStatus` 而没有使 waiter resolve 的 `openOrder`，从这段 bridge 代码不能得出 place Promise 已完成。

### 3.2 `cancelOrder`

`IbkrBroker.cancelOrder`（`IbkrBroker.ts:545-558`）的关键顺序是：

1. liveness probe；
2. `parseInt(orderId, 10)`；
3. 注册同一个 `bridge.requestOrder(numericId)` waiter；
4. 调用 `client.cancelOrder(...)`，其签名和实现都是 `void`（`packages/ibkr/src/client/orders.ts:18-21,780-818`）；
5. `await promise` 后**丢弃 promise resolved value**；
6. 新建 `OrderState`，本地写入 `status = 'Cancelled'`，返回 `success:true`。

这里的成功不是“观察到 cancel 的终态”。它至少表示在 liveness probe 通过后发起了 cancel 调用，并且 orderId waiter 以某种允许的 callback/error 规则结束；`Cancelled` 状态由 adapter 在 await 之后合成，不来自 resolved `CollectedOpenOrder`。

bridge 的两个具体成功分支：

- 如果 waiter 存续期间收到同 orderId 的 `openOrder`，`request-bridge.ts:738-744` 会立即 resolve；即使该 callback 的 `orderState.status` 是旧的 `Submitted`，cancel adapter 也照样合成 `Cancelled`。
- 如果先收到 `orderStatus(orderId, 'Cancelled', ...)`，`request-bridge.ts:768-776` 会用空的 `Contract`/`Order` 加 `Cancelled` state resolve；cancel adapter 同样丢弃这个值并再合成一个本地 `Cancelled`。

源码因此确认了“同 orderId 的 `Submitted` openOrder 可以满足 cancel waiter”这一条件分支；源码**没有**确认 TWS/Gateway 在真实取消时序中一定会发出这样的旧 `Submitted` callback。是否会发生、发生概率和 callback 排列必须靠真实 IBKR 运行证据，本文不把它写成已证实的生产时序。

失败分支也不能直接按远端事实理解：bridge timeout、connection loss 或 request-specific error 会 reject waiter（`request-bridge.ts:381-395,477-517`），IBKR adapter 将其 catch 成 `{success:false,error}`（`IbkrBroker.ts:556-558`）。随后 Git 层通常把它放入 `rejected[]`，而不是产生 `Unknown`；如果 cancel wire 已经到达而回调/连接在之后丢失，当前代码没有一个结果位表达“远端可能已接受但本地不知道”。`EClient.requireConnected` 自身也只是向 wrapper 报错并返回 false（`packages/ibkr/src/client/base.ts:260-267`），并不提供同步 send receipt。

## 4. 一个完整静态分支：HTTP one-shot 撤单到 IBKR 再返回

以下用 `orderId = "42"` 仅作为分支标记，不代表实际运行或把该字段加入核心模型。

```mermaid
sequenceDiagram
    participant Caller as HTTP caller
    participant Route as /api/trading route
    participant UTA as UnifiedTradingAccount
    participant Git as TradingGit
    participant Guard as guard/dispatcher
    participant IBKR as IbkrBroker
    participant Bridge as RequestBridge
    participant TWS as EClient/TWS

    Caller->>Route: POST /uta/:id/wallet/cancel-order {orderId:42,message}
    Route->>UTA: stageCancelOrder(42)
    UTA->>Git: add cancel operation
    Route->>UTA: commit(message), then push(hash)
    Git->>Guard: executeOperation(cancelOrder)
    Guard->>IBKR: cancelOrder(42)
    IBKR->>Bridge: requestOrder(42)
    IBKR->>TWS: cancelOrder(42) [void]
    alt matching openOrder(42, Submitted) arrives first
        TWS-->>Bridge: openOrder(42, status=Submitted)
        Bridge-->>IBKR: resolve waiter
        IBKR-->>Git: success=true, synthetic Cancelled
    else orderStatus(42, Cancelled) arrives first
        TWS-->>Bridge: orderStatus(42, Cancelled)
        Bridge-->>IBKR: resolve waiter with empty objects
        IBKR-->>Git: success=true, synthetic Cancelled
    else timeout, error, or connection loss
        Bridge-->>IBKR: reject waiter
        IBKR-->>Git: success=false, error
    end
    Git-->>UTA: PushResult (success bucket or rejected bucket)
    UTA-->>Route: PushResult, unless push-level exception
    Route-->>Caller: HTTP 200 PushResult or phase=push HTTP 500
```

对应源码关系是：

1. 路由只校验 `orderId`/`message`，然后 stage cancellation（`routes-trading.ts:594-605`）；
2. one-shot 把 stage、commit、push 绑在同一次请求内（`order-entry.ts:44-73`）；
3. UTA dispatcher 对 `cancelOrder` 直接调用 broker（`UnifiedTradingAccount.ts:180-203`）；若 guards 存在，guard rejection 在 broker mutation 前返回 `{success:false,error}`（`services/uta/src/domain/trading/guards/guard-pipeline.ts:13-36`）；
4. IBKR 分支按上节 waiter 规则结束；
5. `TradingGit` 将 IBKR `success:true + synthetic Cancelled` 解析为 `status:'cancelled'`，然后因 success=true 放入 `submitted[]`；因此常见成功返回是 HTTP 200 且 `submitted` 中有 `status:'cancelled'` 的条目，而非一个“cancel confirmed”专门结果；
6. timeout/error 的 `{success:false}` 一般仍形成 HTTP 200 的 `PushResult.rejected[]`，只要 push 后 state snapshot 和回调没有再抛异常；不能用 HTTP 200 作为远端成功判据；
7. 如果 broker 调用已经改变远端，而 `executePush` 随后的 `getGitState`（`TradingGit.ts:157-159`）或 `onCommit`（`TradingGit.ts:171-179`）失败，one-shot 会走 `phase:'push'`/500，且清理 staging 的代码尚未执行。这说明 caller 的 500 也不证明 broker 没有发生 mutation。

## 5. 撤单后的“异步观察”并没有接回这个 cancel 结果

`UnifiedTradingAccount.sync` 只从 `git.getPendingOrderIds()` 开始（`UnifiedTradingAccount.ts:844-865`）。`getPendingOrderIds` 先从最新 commit 向旧 commit 扫描，每个 orderId 只保留最新 `result.status`；只有最新状态为 `'submitted'` 的订单才进入 pending（`services/uta/src/domain/trading/git/TradingGit.ts:692-748`）。

这产生一个具体的旧行为：

- 之前 place 结果为 order 42 / `submitted` 时，42 会被列入待观察；
- 本次 cancel 只要得到 `success:true`，即便它来自 `Submitted` `openOrder`，commit result 也会是 order 42 / `cancelled`；
- 新 commit 成为 head 后，42 不再进入 `getPendingOrderIds()`，所以普通 `sync()` 不会再为这次 cancel 自动安排 `getOrder` 观察；
- `IbkrBroker.getOrder` 自身确实能通过 open listing 后再查 completed listing（`IbkrBroker.ts:759-785`），但这只是独立查询，没有把结果与刚才的 cancel dispatch/版本绑定，也不会修正已经产生的 synthetic cancel result。

因此“cancel result 返回 cancelled”与“以后观察到 order 42 的远端终态”是两条未连接的旧关系。若 cancel 之后出现晚到 fill，当前 cancel result 已经把该 order 从普通 pending 集合移除；是否还有其他显式查询或外部观察路径，不能从这个 `sync` 路径推成已覆盖。

## 6. 不同 broker 的同名状态不能横向等价

以下是实际 adapter 分支的最小对照。`success:true` 一栏描述该 adapter 代码等待的返回点；`Cancelled` 一栏特别区分“远端返回状态”与“本地合成状态”。

| Adapter | place `success:true` 等到什么 | place `status` 来源 | cancel `success:true` 等到什么 | cancel 的 `Cancelled` 来源 |
|---|---|---|---|---|
| IBKR | void `EClient.placeOrder` 调用后，orderId waiter 被 `openOrder`（或特殊 `orderStatus(Cancelled)`）resolve（`IbkrBroker.ts:480-507`；`request-bridge.ts:231-242,738-777`） | callback 的 `OrderState`；未知/缺失在 Git 层默认 `submitted`（`TradingGit.ts:969-977`） | void `EClient.cancelOrder` 后同一个 orderId waiter resolve | adapter 丢弃 callback 值，本地新建 `OrderState('Cancelled')`（`IbkrBroker.ts:545-555`） |
| Alpaca | `client.createOrder` Promise resolve（`AlpacaBroker.ts:327-345`） | raw response status 映射；`new/accepted` 为 Submitted，`filled` 为 Filled，`canceled/expired/replaced` 为 Cancelled（`AlpacaBroker.ts:338-342`；`alpaca-contracts.ts:42-72`） | `client.cancelOrder` Promise resolve | 本地新建 Cancelled，未读取 cancel response 或 follow-up order（`AlpacaBroker.ts:370-378`） |
| CCXT | override/default `createOrder` Promise resolve（`CcxtBroker.ts:563-624`） | raw CCXT status 映射；`open` 为 Submitted、`closed` 为 Filled、`canceled/cancelled` 为 Cancelled、未知为 Submitted（`CcxtBroker.ts:618-624`；`ccxt-contracts.ts:36-52`） | override/default cancel Promise resolve；symbol 来自进程内 cache（`CcxtBroker.ts:628-645`） | 本地新建 Cancelled；未做后续 `fetchOrder`（`CcxtBroker.ts:639-643`） |
| Longbridge | `tradeCtx.submitOrder` Promise resolve并取得 id（`LongbridgeBroker.ts:303-312`） | **固定**本地 `New`→Submitted，不从 submit response 观察终态（`LongbridgeBroker.ts:304-309`） | native `tradeCtx.cancelOrder` Promise resolve | 本地 `makeOrderState(15 /* Canceled */)`（`LongbridgeBroker.ts:337-343`） |
| Mock | 内部订单状态变更；MKT 在 fixture 内同步 fill，非 MKT 置为 Submitted（`MockBroker.ts:278-325`） | 内部状态 | 仅当内部订单存在且为 Submitted 才变更为 Cancelled，否则 false（`MockBroker.ts:357-366`） | Mock 内部状态，属于模拟器自身终态，不可外推为外部 venue 证据 |
| Leverup | relayer 返回 `inputHash` 后立刻 track 并返回（`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:296-315`） | 本地 tracking 初始 Submitted；`getOrder` 后续轮询 relayer，executed 后变 Filled/Inactive（同文件 `460-491`） | 不支持，固定 `success:false`（`LeverupBroker.ts:323-325`） | 不适用 |

由此可准确解释同名状态：

- `submitted` 可能是 IBKR 的 callback `Submitted`、Alpaca/CCXT 的 provider response 映射、Longbridge 的本地 `New`、Leverup 的 relayer tracking 状态，或 Mock 的 limit fixture 状态；这些都不是同一种“远端确认”。
- `cancelled` 可能是 Mock 的内部状态变更，也可能只是 Alpaca/CCXT/Longbridge/IBKR 在 SDK Promise resolve 后本地合成的状态。尤其 IBKR 还可能由同 orderId 的 `Submitted` `openOrder` 间接触发。
- 因此不能把 `status` 字符串、`success` 布尔值、`submitted[]` 数组名任一项单独提升为跨 provider 的终态或确认协议。

## 7. Existing solutions 映射的定位结果

已重新核对的相关 mapping entry（仅作来源导航；entries 中的 targetModel/accepted 文字不被本稿当作当前实现）：

| 主题 | 映射 ID | 指向的当前源范围 | 本稿用途 |
|---|---|---|---|
| route schema | `MAP-3CBE1C6172` | `routes-trading.ts:13-60` | 确认 legacy `orderId/message` 与可选字段输入形状 |
| one-shot place | `MAP-52CB0F382D` | `routes-trading.ts:557-576` | 确认同一 HTTP 请求 stage→commit→push |
| one-shot phase/HTTP | `MAP-75C6D069F1` | `routes-trading.ts:61-78` | 确认 operation rejected 与 push-phase exception 的区别 |
| one-shot cancel | `MAP-AC5E619E59` | `routes-trading.ts:594-606` | 确认撤单也走同一立即 push 路径 |
| Git push/result | `MAP-2DD4753D43` | `TradingGit.ts:119-185` | 确认逐 operation 执行、snapshot、commit、按 success 分桶 |
| Git status projection | `MAP-1A49DD8DEE` | `TradingGit.spec.ts:291-387` | 作为索引交叉核对 `success` 与 `status` 分离；最终仍以生产 `TradingGit.ts` 为准 |
| IBKR place | `MAP-86EFC621F8` | `IbkrBroker.ts:478-507` | 定位 void SDK + callback waiter 的 place 语义 |
| IBKR cancel | `MAP-661D1A0287` | `IbkrBroker.ts:545-559` | 定位 synthetic Cancelled 分支 |
| IBKR bridge request | `MAP-96642209F5` | `request-bridge.ts:233-275` | 定位 orderId 单 waiter 与 timeout |
| IBKR bridge callbacks | `MAP-EDE0047578` | `request-bridge.ts:738-798` | 定位 openOrder resolve、Cancelled resolve、fill cache |
| Alpaca place/cancel | `MAP-CFEE6FFFEA` / `MAP-D276945617` | `AlpacaBroker.ts:273-347` / `370-379` | 对照 provider response 与 local cancel state |
| CCXT place/cancel | `MAP-D8B89D3086` / `MAP-B3682B35F1` | `CcxtBroker.ts:563-626` / `628-645` | 对照 raw status 与 synthetic cancel |
| Longbridge place/cancel | `MAP-4472AC0A90` / `MAP-8387D189AE` | `LongbridgeBroker.ts:269-313` / `337-344` | 对照固定 New 与 synthetic Canceled |
| Mock place/cancel | `MAP-50275FA75F` / `MAP-5484E0ABE8` | `MockBroker.spec.ts:83-158` / `203-229` | 只作为模拟器内部状态的对照 |

## 8. 本业务实例得到的结论与边界

### 已由源码确定

1. Web one-shot place/cancel 是 `stage → commit → push` 的真实 mutation 入口；AI tools 的同名方法则是 stage-only，不能混称。
2. 旧 UTA 的 `PlaceOrderResult.success` 没有跨 broker 的统一承诺；`TradingGit.submitted[]` 只由 `success === true` 决定。
3. IBKR place 的成功等待 bridge callback，而不是 void SDK 的同步返回；callback 被当作 operation success，但不是独立 terminal/fill 证明。
4. IBKR cancel 丢弃 waiter 的 resolved value，统一合成本地 `Cancelled`；匹配 `openOrder`（包括 `Submitted`）和 `orderStatus('Cancelled')` 都可结束 waiter。
5. 多个外部 adapters 在 cancel SDK Promise resolve 后本地合成 `Cancelled`；Mock 是内部状态突变的例外，Leverup 是“提交后持续轮询”的例外。
6. 一个成功 cancel result 的 `status:'cancelled'` 会让该 order 不再进入 `getPendingOrderIds()`，所以普通 `sync()` 不会自然承接此次 cancel 的异步确认。
7. operation-level failure 通常落在 HTTP 200 的 `rejected[]`；push-level snapshot/callback exception 才映射 one-shot phase push/500，故 HTTP code 也不是远端 outcome。

### 本次没有声称已确定

- TWS/Gateway 实际是否、何时会在 cancel waiter 存续期间发出旧 `Submitted` `openOrder`；这是 callback timing 的运行事实，不由静态分支证明。
- 各券商 SDK 在“cancel Promise resolve”后是否已经终态、是否仍可能晚到 fill；当前 adapter 没有做统一 follow-up observation，provider-specific 语义需要独立运行证据。
- 任何 runtime/e2e 结果。本文按任务约束未运行 build、lint、tests 或 broker 验证。

本稿只把这些事实作为一个 Order 实例对已有组合关系的反例/见证：调用、返回、状态投影和后续观察并非同一事件。它没有向核心抽象添加 Order 字段、cancel 政策、provider 分支或旧 Recipe/槽位/EF。
