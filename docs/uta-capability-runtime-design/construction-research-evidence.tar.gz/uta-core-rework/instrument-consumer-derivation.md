# Instrument：发现结果、目录观察与提案目标的独立消费推导

这是独立业务实例研究，不是公共核心的新增类型目录，也不宣布整体抽象成立。全文区分现有源码事实、目标构造和按源码允许条件展开的动态反例。未调用 Broker、未运行代码或任何 validation/build/lint/tests/formatter/runtime，未编辑 repo。文中的示例响应与时间顺序是设计反例，不冒称实盘观察。

研究前已实际读取 `current-research.md:56–127` 与 `local://uta-current-failure-extract.txt`，其中第236–268行原始派工参数全文另以 raw 读取；相关 owner guide 为 `docs/README.md`、`docs/project-structure.md`、`docs/market-data-architecture.md`。当前读取的主书 Instrument 位于 `docs/uta-capability-runtime-design.md:1083–1101`（§6.3，章节正在调整），只展开选中后读取数据，没有把发现的不同结果、目录状态、选中引用到提案的实际连接讲完。以下不采用旧 solutions/targetModel/designed 作目标权威。

## 从实际消费者看，旧路径并不是“搜索返回可交易 Instrument 列表”

### IBKR 的有限返回有不同的后继

`IbkrBroker.searchContracts` (`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:233–287`) 解释一次 `reqMatchingSymbols`。普通 conId 行直接保留；无 conId 的 CASH 货币家族在内部再解释 `contractDetailsQuery`，可用请求里的 `.USD` 后缀限定币种；该内部展开失败被记录后变成 `[]`。BOND issuer 目录保留给调用者，其 nativeKey 为 `issuer:…`。此外，没有 conId/issuerId 的其他行仍可保留。因此不能仅依据一行有 aliceId，就把它视为已唯一核定、远端可交易的对象。

一个股票 conId 既可以作为股票目标，也可以作为衍生品展开的 underlying。这里不是全域互斥的“leaf 或 hub”：issuer 是非交易目录；股票是对象，同时有派生发现入口。`derivativeSecTypes` 是调用者决定下一步的提示，不是已取得该衍生品合约。

实际展开由 `UnifiedTradingAccount.expandContract` (`UnifiedTradingAccount.ts:1157–1177`) 检查该 Broker 是否实现入口、aliceId 语法及所属 UTA；把 nativeKey 原样交 Broker，刻意不先调用会拒绝 issuer 的 `resolveNativeKey`。返回的具体 contracts 才逐个被打上所属 UTA 的 aliceId。

`IbkrBroker.expandContract:391–475` 的三种实际求值：

- issuer 输入：查询 BOND/issuerId，将 coupon/maturity 加到返回对象的显示信息，按 maturity 排序，返回 `kind:'contracts'`、前 limit 项及裁切前长度。expiry/right/strike/secType 在此分支不参与过滤；只有 limit 参与。
- 数字 conId、`secType=FUT` 或提供 expiry：先取 underlying details，再用 `u.symbol`、`u.currency`、所选 family 构造另一项 details 查询；OPT 设 exchange=SMART；expiry/right 进入查询，strikeMin/Max 在响应后过滤；按到期、strike、right 排序，最后裁切。这里 `total` 是**本次返回的 details 经本地 strike 过滤之后、裁切之前的长度**。
- 数字 conId、OPT 无 expiry：解释 `reqSecDefOptParams`，返回 `optionGrid`。empty grid 仍是该结果分支，附 no-chain hint。非空按 SMART 优先排序，附“选 expiry 再 expand”的提示。right、strikeMin/Max、limit 在此分支没有实施缩小 grid。

limit 被钳制为1到200，默认60；没有 cursor/offset。`total` 不证明交易所全部对象已枚举，不证明账户有交易权，也不证明存在下一页。超过200时现有“raise limit”提示存在不可兑现的部分；目标只保留已观察的范围计数、实际裁切界限和可实施的缩小查询，不要求新增通用分页。

### HTTP、SDK、Agent 各自消费了什么

共享 `packages/uta-protocol/src/types/broker.ts:190–222` 把 `kind` 写成两值联合，但 `contracts/total/grid` 都是 optional；因此类型本身允许 contracts 分支缺 contracts/total。`OptionGridEntry` 声明 exchange/tradingClass/multiplier/expirations/strikes，没有声明 callback 返回的 underlyingConId。

HTTP `services/uta/src/http/routes-trading.ts:330–341` 取 body.aliceId/filters 直接调用账户展开，原样 JSON 返回；失败压成500和字符串。`src/services/uta-client/UTAAccountSDK.ts:169–175` 传输同一输入，泛型标注返回 ContractExpansion，没有附加选择/资格计算。

Agent 工具 `src/tool/trading.ts:503–554` 是实际的分支消费者：contracts 分支返回 source、total、compact contracts、hint；另一分支返回 source、投影过的 grid、hint。它丢掉 `kind`，用 `?? []` 把缺数组化为空数组；grid 投影明确丢 underlyingConId。它没有自动执行 hint，没有自动选择 expiry，没有循环展开，更没有在得到 leaf 时自动创建提案。当前消费者是下一次 Agent 调用。

`compactContract` (`src/tool/trading-compact.ts:72–93`) 保留 aliceId、显示名、类型、币种、exchange、expiry、strike/right/multiplier 的部分显示信息，但不保留 tradingClass、primaryExchange、ContractDetails.underConId。此投影可以服务简洁显示，却不能反过来充当精确 option-family 选择的全部证据。

### 搜索聚合与 UI 中也有实际丢失

`services/uta/src/domain/trading/contract-search.ts:27–64`（任务给出的“searchTradeableContracts27–64”实际位于此文件，不是 LeverupBroker）规范化查询后，默认只取 asVendor 非 false 的 UTA；显式 source 可以选不同集合。它并发搜索，**跳过每个 rejected 结果**，只返回 fulfilled 的行。`routes-trading.ts:149–164` 的 count 等于这份最终数组长度。`UTAAccountSDK.ts:197–209` 再从 flat rows 过滤 source。

Agent 的 `searchContracts` (`src/tool/trading.ts:219–275`) 也采用 fulfilled-only 聚合；给 `|issuer:` 打 `expandable:true`，保留 derivativeSecTypes；全部失败仍可能返回“No contracts found”。这不是“全部账户已证明无匹配”。Broker 已经吞掉的局部失败（如 CASH 内联展开）甚至不能由聚合器的 allSettled 恢复。

`ui/src/components/market/TradeableContractsPanel.tsx:35–47,66–98,129–178` 将结果显示、最多先显示3项，点击 Show more 只是展开**已经返回的数组**，不是调用 Broker 的 expandContract。每个有 aliceId 的行都生成 order 链接，包括 issuer 行，没有 Hub→leaf UI 消费。`UTADetailPage.tsx:174–185` 按账户 canTrade 打开预填 aliceId 的下单表单；它检查的是账户政策，不是该行是不是目录。

`OrderEntryDialog.tsx:343–425` 的 picker 按当前账户搜索并过滤 source；选择结果后保存 aliceId。手贴含 `|` 的输入、或初始 aliceId 可以绕过搜索：初始值被包成显示行，不代表发生了发现。`PlaceForm:141–191` 最终只把 aliceId、条款及必要 subAccountId 发给 placeOrder，未复制显示 symbol；one-shot route `routes-trading.ts:557–575` 执行既有 stage/commit/push 组合。目标需修正“目录可直接下单”的 UI/Agent 语义，不必禁止精确 id 的直接输入。

## 目录的返回值不能抹掉它自己的观察依据

### 旧实现确实不同，不能统一成 refresh 成功=新鲜完整

`services/uta/src/main.ts:39,130–141` 每6小时向已解析账户发起 refreshCatalog，各自 catch/log；没有等待整轮完成，也没有目录版本/来源 as-of 的公开返回。`UnifiedTradingAccount.ts:1186–1196` 对不实现 refreshCatalog 的 Broker 直接返回。Alice SDK 的 `refreshCatalog` (`UTAAccountSDK.ts:351–354`) 更是明确的 no-op，连 HTTP 都不发。故对统一 `Promise<void>` 做一次成功包装，不能制造 `Refreshed` 事实。

Alpaca (`AlpacaBroker.ts:140–143,178–184,217–256`)：

- catalog 初值 null。账户连接成功后异步启动刷新，不 await；第一次搜索可能发生在刷新未完成时。
- getAssets({status:'active'}) 完成后保留 `tradable !== false` 的条目并替换 catalog/map；tradable 缺失也被保留，不是每项都有显式 true。
- 读取失败不改变已有 catalog。null 表示尚未得到一份成功缓存，不能由 null 区分 in-flight 与 first failure；这些结果目前只在日志中分别出现。
- catalog 为 null 时，任意非空 pattern 被大写后合成为一条 STK 候选。这是保留旧 ticker 输入能力的本地 echo，不是目录命中。已加载时以 symbol/name fuzzy rank 返回。

CCXT (`CcxtBroker.ts:386–415,419–488`)：init 必须成功 loadMarkets 且数量非零才标 initialized；search/refresh 要求 ensureInit。refresh 调用 `loadMarkets(true)`；本次只从 OpenAlice 适配器源码核定调用关系，没有把依赖内部的失败原子性当作已验证事实。shared Broker 契约 `broker.ts:513–522` 要求失败保留旧缓存；CCXT 包内部是否完全兑现，不能由 wrapper 没写清空赋值推出。

CCXT 搜索只纳入 active 不为 false、base/quote 存在、报价为 USDT/USD/USDC 的候选；marketToContract 转换失败的条目被 warning 后跳过。Alpaca、CCXT 所用 `fuzzy-rank.ts:79–99` 只保留正分、排序后前50项，不返回裁切前计数。因此一次搜索50行也不证明恰好只有50个命中，更不证明 catalog 完整或今天仍可交易。

Leverup (`LeverupBroker.ts:169–208,535–546`) 使用内置 network pair 表搜索；找不到 nativeKey 时仍合成最小 Contract。其 pair 表 `pairs.ts:29–34,62–75` 明说列表不全，testnet 直接引用 mainnet 表。这里能核定的是**代码如此选择表**，不是实际远端网络目前支持这些地址。不能把“表里有”或者“符号能解码”提升为远端可交易。

Longbridge 是另一个不能归入“先加载完整目录再搜索”的实际入口。`brokers/longbridge/LongbridgeBroker.ts:235–265` 的 search 直接 `echoContractDescription(pattern)`，不调用远端；后者 (`longbridge-contracts.ts:147–150`) 只调用 makeContract。`makeContract:33–42` 保留原 native localSymbol，parseLbSymbol 对无后缀输入取 US 语义 (`51–56`)。这不证明该证券存在，但构成既有直接输入能力。真正 getContractDetails 才调用 staticInfo；无返回或任意捕获失败都变成 null，不能把这个 null 解释成已经证明“证券不存在”。

Longbridge `resolveSymbol:67–91` 优先保留带点的 localSymbol，再保留 aliceId 中带点的 native key；没有这些信息才从 symbol/currency 推后缀。CNY/CNH 在该 fallback 中固定推 SH，不能恢复原 SZ。注意 `.SG` 在实际代码中有独立 SGD 分支，不能根据注释的概括把所有后缀都说成会合并。有限目标是保留实际选中的 suffix/native key，不增加“所有 echo 都必须先取得目录 ready 或历史命中”的前提。

### 目标：先给这项业务自身一个能被消费的目录观察

以下是目标表达，不是声称旧源码已输出这些类型。只让拥有本地 catalog 的业务解释器保存它自己的状态；IBKR server search 不需要被塞进目录刷新状态机。

本地目录拥有者使用封闭的业务状态，直接区分有没有可搜索的 snapshot：

```text
CatalogView =
  Unloaded
  | InitialLoading(attempt)
  | InitialLoadFailed(attempt, error)
  | Ready(snapshot)
  | Refreshing(snapshot, attempt)
  | RefreshFailed(snapshot, attempt, error)
```

snapshot 是这份本地内容及实际取得的证据，包含发布它的刷新观察；completedAt 仅是本地完成观察时间，不是交易所 as-of，不自带 complete/fresh=true。前三个分支没有 snapshot，后三个分支持有真实 snapshot；不存在“刷新成功但没有发布任何目录”的成功状态。关键不是状态数量，而是搜索函数实际读到哪份内容，以及失败后什么仍然成立。

一次实际刷新工作 `refreshAlpaca` 的成功返回候选目录内容，不直接等于“搜索世界已完整”。目录拥有者消费本次 Outcome：成功时发布 snapshot 并成为 Ready；初次失败成为 InitialLoadFailed；已有 snapshot 时失败成为 RefreshFailed，保留同一份 snapshot。只有实施了刷新并收到了该结果的拥有者能构造新的 Ready；SDK no-op 和未支持刷新分别表示 NotExposed/NotApplicable，不进入这个成功分支。Refreshing 时允许搜索继续取旧 snapshot；前三个无目录分支则按 Alpaca 的旧直接输入能力返回 `ConstructedTickerHint`，而不是假造 `CatalogHit`。

本实例的搜索成功结果分别携带依据：`CatalogMatch(ref, snapshotObservation)`、`ConstructedTickerHint(localRef, constructionBasis)` 或 `ServerMatch(ref, queryObservation)`。Alpaca 的 constructionBasis 说明该次无目录，Longbridge 的则说明此入口原本只做 echo；不能把它们都解释成等待目录加载。它们不组成所谓可交易性等级；这里只解释“这个返回值由什么产生”。非空结果不能消除 refresh 失败，空结果不能消除 source 失败。对于聚合，显式消费每个成功/失败 Outcome，并把 source 归属保留下来；可以继续展示健康来源，但不能将失败分支映射为无匹配。保持 Broker 局部子查询失败时，也须在该 Broker 自己的发现结果保留那项范围缺口，外层不能凭空推断。

目录更新和搜索交错的具体含义是：搜索开始消费某份 snapshot 后，用该份内容完成其有限排名；刷新后来发布的新 snapshot 不回写已经返回的结果，不让旧选择悄悄指向另一对象。需要“现在目录里还有没有这项”的消费者可以另构造精确 membership 查询；提案本身不因所有目录都必须有 revision 而被迫等待。main 的异步 interval 不证明只有一次 in-flight；目标若宣称刷新按开始序更新，则必须由该目录拥有者提供串行化或明确接纳顺序。此稿只承诺结果关联其实际被发布的观察，不凭完成时间声称上游版本更新；上述单次活动状态由该目录拥有者串行解释实际刷新工作，搜索读取不等待刷新完成，不改变六小时业务调度为每单刷新。

### 动态轨迹：Alpaca 加载失败与成功，改变搜索依据而非允许交易的身份

下述时间是符号轨迹，非已运行日志。

1. t0：账户连接完成，后台刷新 A 已启动，状态为 InitialLoading(A)。搜索 `AAPL` 消费这一无目录分支，产生 ConstructedTickerHint(`AAPL`)；没有等待 A，不将其记录成目录里已发现 AAPL。
2. t1：A 失败。状态变为 InitialLoadFailed(A,e)。再次搜索仍可返回本地 ticker hint，但消费者能同时看到尚未加载与最近失败，不得输出“目录完整，没有其他对象”。
3. t2：后来刷新 B 成功发布一份 catalog C；状态为 Ready(C)，C 携带该次成功观察。搜索按 C 排序，如果命中则返回 CatalogMatch。如果本次 catalog 是空数组，搜索返回基于 C 的零匹配，不回退到 hint；这是旧源码 null 与 loaded-empty 的实际区别。
4. t3：刷新 D 失败，状态为 RefreshFailed(C,D,e)。搜索仍消费 C，同时保留失败观察；不是刷新失败后全盘禁搜，也不是无标识地宣称最新。
5. 用户已经拥有 `alpaca-paper|AAPL`，可以直接构造意图并请求创建提案，不必复现上述发现历史或为每单刷新 catalog。该提案只声明其目标与条款；是否可提交、远端接受及成交由交易特化的后续实际计算决定。

这个轨迹需要有限计算的成功/失败消费者与本地状态更新；没有提出新的公共“目录事件流”机制。

## 为不同返回实际构造后继，不把 hint 当执行协议

以下业务表达沿候选 F/then 的一次求值关系展开，但 F/then 不是免检前提。`pure` 只产生值或后继，不在构造时执行 Broker IO。

### 把目录引用、对象引用、查找提示分开交给不同函数

为本业务声明：`IssuerRef(scope,issuerId)` 只接受展开；`ExactInstrumentRef(scope,nativeIdentity)` 接受该命名空间的对象解析；`SymbolHint(scope,query)` 接受查找或该 Provider 明确支持的直接构造。scope 含实际 UTA/Provider 命名空间；Leverup 等还必须对应真实 network。显示 label 不在 target 身份里。

一个引用是可表示的，不证明已存在；一条目录记录是被观察过的，不证明账户能交易。远端对**本次 target、action、terms、account**的确认也不是永久 `Tradable=true`。本稿不发明一个所有 Provider 都有的 canTrade endpoint：不存在此只读承诺时保持未核定，等待实际允许的 prepare/submit 结果，不能把 getQuote 成功或 catalog membership 改名成交易资格。

IBKR 的发现行可构造为 issuer directory、精确对象及其可展开 family、或尚未核定的 hint。把三种消费者写实：issuer 行形成一次 `expandIssuer(ref,limit)`；股票精确引用可进入该股票提案，也可另构造 option/futures 发现；optionGrid 本身无 InstrumentRef，不得进入提案；unqualified hint 要经过 Provider 明确的解析/选择，不能由显示字符串自行升级。

### IBKR 有限浏览计算及依赖选择

`browseIBKR(request)` 返回精确和类型，其有限结果是 `ContractBatch(context, leaves, batchMatchCount, appliedLimit, truncation)` 或 `OptionParameters(context, grids)`。必需数组不 optional；缺字段是边界契约失败，不变成空结果。context 保存本次 source、underlying/issuer、实际请求；truncation 只说明本批返回是否被 limit 切掉。hint 可以保留作辅助文字，但决定后继的依据是分支及真正支持的输入。

业务请求也要按可实施条件分别声明：issuer + limit；underlying + option-grid；underlying + options-expiry/right/range/limit；underlying + futures-expiry/limit 等。既有 FUT right/strike 的含义没有被核定为有用契约，不因统一 filters 可携带它们就宣传支持；无 expiry 的 OPT grid 请求不接受“已经实施的 right/range 过滤”这一承诺。这样修正 silent-ignore，不是逼核心认识这些参数。

对固定的“按选定 expiry 找叶子再创建提案”表达，实际操作数必须包含：

```text
p = browseIBKR(GridRequest(underlyingRef))
k(gridResult) =
  chooseExpiryAndRange(gridResult, callerChoice) 成功得到 nextRequest 时，
  then(browseIBKR(nextRequest), batch => selectReturnedLeaf(batch, exactChoice))
program = then(p, k)
```

这里 callerChoice 来自明确的完整外层输入或另一次真实选择计算，不能从 hint 字符串自动生成。若用户尚未选 expiry，则本次有限调用返回 OptionParameters 后结束；下一次调用携带前次选中的真实 context 和新选择，再构造后继。多次有限调用的发生关系不要求一个长期运行、等待人类的核心对象。

`selectReturnedLeaf` 要求所选 exact identity 在本次 batch 中唯一，并返回那一项及其 scope；0项返回 NotInReturnedBatch，多个同身份冲突返回 Ambiguous。显式选择某个已返回 leaf，不要求本批完整。反之，“取所有合约”“不存在匹配”或“全市场最优”需要额外完整性前提，有限前200项不能支持；不自动补一个循环去追不存在的 cursor。

### 精确 option-family 选择不是仅保存 underlying 的名字

源码反例的触发位置非常具体：grid 行有 exchange/tradingClass/multiplier；第二次叶子查询 `IbkrBroker.ts:435–442` 却只使用 u.symbol/currency、OPT/SMART、expiry/right。`details.map(d => d.contract)` 又丢掉 underConId。工具进一步丢 tradingClass。故“选某一 grid，再拿相同 expiry 的第一项”没有建立选中族到 leaf 的关系；相同 symbol/expiry 不足以替代它。

目标区分两项真实可实现的承诺，而不是把弱承诺改名：

- **浏览衍生合约**：保持旧一次有限展开能力，但返回的是本次查询结果。用户再根据实际叶子的精确身份选择；不宣称叶子一定属于前次挑中的某个 grid。
- **选定精确族后取得其成员**：函数显式接受 `FamilySelection(underlyingRef, tradingClass, multiplier, venueSelection)` 与 expiry/right/range 等操作数；本次解释必须将适用的字段传到实际原生查询，并消费返回的 membership 证据。仓库原生载体已经有 Contract.tradingClass 与 ContractDetails.underConId (`packages/ibkr/src/contract.ts:137,211`)，contract-details decoder 也读取它们 (`packages/ibkr/src/decoder/contract.ts:307,320–321`)；不能在得到证据前先投影掉。

精确族消费者至少实际比较 underlying identity、tradingClass、multiplier，并核对明确的 venueSelection 是否被实现和证实。缺 underConId、缺必需属性、原生不支持所选 venue 或其意义不能核定时，返回 FamilyMembershipUnverified/UnsupportedFamilySelection；不以空字符串、0、相同 symbol 或 SMART 优先排名通过检查。场所路由与合约族身份不可机械视作同一字段；尚未核定的 exchange 语义必须留为不满足，而不是发明相等式。

该目标保留现有细节返回后再构造 Contract 的路线，而不是声明当前 expand API 已有精确族能力。它只要求精确族这项函数的实现承担真实参数与返回证据；没有要求所有 Instrument 搜索都做这一步。

### 动态轨迹：grid、族信息丢失与正确的有限续接

设实际来源某次返回两行 grid，二者 expiry 有交集，但 tradingClass 或 multiplier 不同。这是边界类型允许的反例，不声称某个实盘 underlying 今天恰有这两行。

1. p 完成，得到该次 OptionParameters；此时没有叶子 id，没有提案。
2. 调用者选 grid G2、expiry e。旧输入只能携带 expiry/right/range，后继 q 以 underlying symbol 重新查；若 q 返回属于 G1 的叶子 L1，单凭相同 expiry 不能判定为 G2 成员。先按第1项下单会消费错误目标，F 的类型顺序没有自动修复信息丢失。
3. 目标精确族表达保存 G2 的真实 FamilySelection。q 返回 details 后，member(G2,L1) 根据不同 tradingClass/multiplier 返回不匹配；不会求值 makeProposal(L1,terms)。若字段缺失，返回未核定，也不自动改为“同 symbol 即可”。
4. q 返回充分证实属于 G2 的 L2，selectReturnedLeaf 选中其实际 conId，才构造 target 为该 conId 的提案；grid 仅用于发现/验证，真正提案不使用 grid 参数拼一个未返回的 conId。
5. p 失败时 q 不构造；q 失败时叶子选择和提案不构造。empty grid 是有限成功结果，由其业务消费者返回 NoOptionParameters；不会自己安排无限重试。

“expirations × strikes”是可展示的参数轴，不证明每个笛卡尔积组合都是存在的合约。缺具体 conId 时不能直接从轴创建精确 InstrumentRef。

### 动态轨迹：issuer 总数与截断只影响此次选择范围

若某次 issuer details 返回240个对象，limit=60 时返回前60与 batchMatchCount=240；再请求 limit=300，旧实现实际仍只返回前200。目标展示 appliedLimit=200、该批有40项未返回，不承诺“下一页”或“raise limit还能全部看到”。用户选中已返回第17项，得到其真实 conId，可以继续该对象的提案；用户要比较全部240项，则本接口的组合前提不成立。这里不阻塞前一种合法用法，也不为后一种要求擅造分页能力。

## 引用到提案：持有身份与显示，不得在消费时重新猜目标

### 现有路径提供的保留和真实反例

`UnifiedTradingAccount.contractFromAliceId:534–544` 检查 UTA scope 并调用该 Broker 的 resolveNativeKey；issuer 被 IBKR `resolveNativeKey:898–918` 拒绝，因此哪怕 UI 暴露 order link，issuer 也不能按该路径落入可提交的 leaf。跨 UTA source override 同样会在此拒绝。

Agent `placeOrder` (`src/tool/trading.ts:633–678`) 从 source 或 aliceId 选账户，把相同参数交 SDK；`UTAAccountSDK.ts:299–303` 只发 stage 请求。`stagePlaceOrder:693–724` 先检查 keyless/条款，构造 Contract 与 Order，最后 git.add。实际 dispatcher (`UnifiedTradingAccount.ts:180–199`) 后来才将 op.contract/op.order 交 Broker。发现成功、stage 成功和 Broker 动作成功是三个不同事实。

这里有两个源码可达的目标替换反例，应修正而非当作旧能力必须保留：

**display symbol 覆盖身份。** 工具 `trading.ts:649` 将 symbol 描述为“display only”，但 stage 在解析 aliceId 后执行 `contract.symbol=params.symbol` (`UnifiedTradingAccount.ts:697–698`；close 也有744–745)。Alpaca `resolveNativeKey:624–625` 先按 nativeKey 造 Contract；`alpaca-contracts.ts:33–38` 随后直接读 contract.symbol，`AlpacaBroker.placeOrder:273–281` 把它放进实际原生订单。因此输入 aliceId=`alpaca-paper|AAPL` 且 symbol=`MSFT` 可以在保持 aliceId 字符串不变的同时把实际订单 target 构造为 MSFT。此处只证明可达构造，不声称已实盘提交。

**精确 CCXT key 消失后退回 base 猜测。** `CcxtBroker.resolveNativeKey:1311–1325` 对未知精确 key 产生只含 localSymbol 与 base symbol 的骨架，无 secType/currency。下游 `ccxt-contracts.ts:123–140` 找不到 localSymbol 后尝试 symbol，再调用 resolveContractSync；后者 `156–176` 在没有 secType/currency 时纳入该 base 的活跃稳定币报价市场，唯一候选即接受。它不是注释所说的必然 loud failure。`CcxtBroker.placeOrder:513–515,603–611` 把该推导出的 ccxtSymbol 交原生订单函数。

### 目标提案构造与真正的组合前提

`buildIntent(selectedRef, terms, display)` 是纯业务构造，目标只由 selectedRef 给出，display 不能写入 target 的原生关键字段。`bindForProposal(accountContext,intent)` 是真实有限计算：核对 scope、所用操作定义和所需账户/子账户参数，使用该 Provider 的精确引用解释器取得实际需要的 target 数据；只有这项操作确实需要 IO 时才执行相应读取。成功后把**同一个被选中的目标**及条款交创建提案计算，不获得外部发送权。

```text
selected = selectReturnedLeaf(batch, selectedIdentity)
intent   = buildIntent(selected.ref, suppliedTerms, suppliedDisplay)
p        = bindForProposal(actualAccountContext, intent)
proposal = then(p, boundIntent => createProposal(boundIntent))
```

函数输入不要求 catalogRevision、每单 refresh 或搜索 receipt。精确手输 id、持仓所得 id、先前选定 id 都是合法入口，但依然要接受真实语法/范围/操作约束。`SymbolHint` 可以另由显式查询产生候选；它不能在精确引用解释失败后悄悄替代原 `ExactInstrumentRef`。

Provider 必须保留的不变式是：解释 `ExactInstrumentRef` 后的实际 native target，仍与该引用所指对象一致。若当前元数据缺失，消费者可以读精确详情、按 Provider 明确允许的精确 key 直达，或返回 ExactTargetUnavailable；不能重新按 base/symbol 搜到“唯一另一个”然后继续同一提案。新增查询候选是另一项发现结果，需要明确重新选择/创建意图，而不是原提案的自动修复。

选中的 native identity 不是同一账户里永不改变的 schema/权限承诺。准备和发送仍需各自当下条件。对于必须消费当前市场 metadata 的 CCXT 操作，发送前解析得到的 target 仍必须满足上述 identity 关系；仅在 staging 时检查、到发送时又允许 fallback，不能保持它。该要求是目标保真，不是强制每单从远端刷新整个目录。

### 动态轨迹：CCXT 删除一个精确 key，不应变成另一市场订单

设 t0 的 catalog 含 perp key `BTC/USDT:USDT`；调用者选择并保留该精确 aliceId。t1 的刷新发布内容中该 key 不存在，但只剩同 base 的一个活跃 spot `BTC/USDT`。此具体市场集合仅为源码反例输入。

- 旧轨迹：t2 staging 通过 resolveNativeKey 得骨架 `{localSymbol:'BTC/USDT:USDT',symbol:'BTC'}`；t3 dispatch 的 contractToCcxt 发现精确 key 不在表，再按 BTC 搜到唯一 spot，ccxtSymbol 成为 `BTC/USDT`。后继即使类型正确，也没有消费原选中的对象。
- 目标轨迹：t2 的输入是 ExactRef，不进入 SymbolHint 分支；若实现依赖当前表而表没有精确 key，返回 ExactTargetUnavailable。后继 createProposal 不运行；若较早已接纳提案，则相同身份核对发生在其真正消费当前 metadata 的位置，禁止重解释为 spot。用户仍可以另选 spot 并创建另一意图，但该事实不能倒写成原 perp 选择成功。
- t1 若是刷新失败、旧表仍被保留，最多说明本地仍知道该 key；不能宣称远端仍挂牌。允许后续针对该精确 key 的实际操作产生拒绝/不可用，不因 stale 就重定向。

### 动态轨迹：Leverup 可构造、表中已知与远端支持并不相等

精确 id 中的未知 pair key 可以经 `resolveNativeKey:535–546` 合成 Contract，当前 stage 的本地条款与 scope 检查也可能通过。但实际 place `LeverupBroker.ts:213–223` 再调用 resolvePair，找不到就返回失败，尚未执行其后229起的 Pyth 读取/签名路径。目标可以较早把它作为 UnresolvedLocalRef 返回，也可以允许一个明确标示未核定目标的待处理意图；不能表示成“该 pair 已可交易的提案”。

对于已知 pair，place 使用表里的 pairBase/Pyth feed 和配置 network 的 chainId/relayer (`LeverupBroker.ts:138–149,230–246,269–279`)。testnet 复用 mainnet 表这一事实说明，本地命中不足以证明该网络的地址有效。这里目标是保留实际 network+pair 身份和未核定事实，不伪造一次远端可交易认证；远端行为未测，不给测试网成功或失败的运行结论。

### 动态轨迹：Longbridge echo 直接构造与后缀保真

输入 `000001.SZ` 时，echo 只构造包含该 localSymbol 的本地 Contract；没有远端发现事件，但精确的 SZ 目标仍可被保留并进入意图。若调用者选择读取 details，则后继把 `000001.SZ` 原样交 staticInfo；有充分返回才形成那次详情观察，null 只保留该旧入口实际缺少详情的结果，不代替远端可交易判定。创建提案不普遍要求先运行这次 details。

反向删除 suffix 只留下 symbol=`000001`、currency=CNY 后，再按现有 currency fallback 重建，会得到 `.SH`，不是恢复 `.SZ`。目标 ExactRef 消费者不能采用这条丢失信息的后继；保留原 native key，或在真实输入本来就是 hint 时要求实际选择。这里修的是选中目标在转换中被改变，不是禁止 echo、无目录来源或直接输入。

## 对核心候选能带回什么，不能带回什么

这些实例要求的公共关系是已有有限计算结果到实际后继的关联、和类型的穷尽消费、纯积构造保存上下文，以及声明失败作为值被状态拥有者消费。目录 refresh、option family、selected reference 与 proposal 都应留在这一独立业务表达中；本次没有发现必须向核心增加 Hub/Grid/CatalogRevision/Tradability 或统一发现工作流的反例。

但“用 F/then 类型接得上”不够。若 p 返回的关键 family/identity 被投影掉，k 用同形 symbol 查询另一个对象，则它已不是承诺的那个消费者。修复地点是业务函数输入、原生边界的实际转换与选择证据，不是让核心按 Broker 名称做特殊保护。相同来源也不能替代相同对象；相同 D 输出形状不能替代保真编译。跨语言公开声明可描述精确请求/结果分支，却不能从 hint 文本、SDK 的 void 成功或 Contract 类默认值生成不存在的证据。

本稿明确不保证：Broker 搜索或列表全局完整；成功刷新后的远端时效；options grid 笛卡尔积均存在；选中某 grid 后旧 expiry API 保持其精确族；同 symbol 跨 Provider 等价；目录中有即远端可交易；账户 canTrade 即某品种有权限；提案接纳即提交/成交；中断一次发现即撤销以前提案。没有把这些未知统一变成交易前置拒绝，也没有把失败恢复、分页、目录版本化或额外远端认证强制引入每一张订单。
