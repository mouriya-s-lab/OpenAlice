# 小范围候选：结果如何成为后继计算的输入

这是可质询的核心构造研究，不是主书修订、用户失败判定的复审或整项设计完成声明。本轮只读取契约、构造函数关系及手工推演，不编写/执行代码，不运行 build、lint、formatter、tests 或产品 runtime。被用户否定的 event-flows、主书第16章、EF分类、slot到frame的派生及其关联时序全部排除，不作为输入、骨架、反例基准或可保留成果。已经读过的当前候选段落只用于辨認被比较的主张，不为本稿构造担保。

## 先给关键构造

本稿选择的关系是：**Effect 的一次结果由具体后继函数消费；连续结果由 Stream 的逐项消费者消费；纯 Decision/Evolution 决定哪些输入足以改变领域状态；持久解释器只在本地决定提交后解释已记录的工作，并把该工作的精确结果交回原消费者。** 不是先把全部动作放进一个成功结果容器，也不要求所有计算都经过 Decision。

以下为目标类型/函数关系记法，不声称存在同名 UTA SDK。`Result<A,E>` 的成功分支承载 A，预期失败分支承载 E；defect 与 interruption 不伪装成 E。`+` 是类型联合，`×` 是积，`*` 是有限序列；箭头为函数类型而非流程图。普通 Effect.flatMap 不自动给同形失败补上阶段标签；若消费者需要阶段区别，作者须在那一计算边界显式构造带阶段的失败和。

```text
F<A,E,R> = Effect.Effect<A,E,R>
S<A,E,R> = Stream.Stream<A,E,R>

h : I -> F<A,E,R>
k : A -> F<B,E2,R2>
then(h,k)(i) = Effect.flatMap(h(i), k)
then(h,k) : I -> F<B,E + E2,R + R2>

observe : J -> S<X,Ex,Rx>
each(observe(j), consume) : F<void,Ex + Ec,Rx + Rc>
  where consume : X -> F<V,Ec,Rc>
```

`then` 连接一次返回；`each` 在每次有效产出后消费，但不能声称无限源最终返回 V。生产者、逐项消费、流终止是不同的时间事实。数据产生快于消费时必须选择顺序/并发与反压政策，这不由 `X` 的字段决定。

### 异构工作的结果续接，必须实际构造

先取一个已经构造的操作 d，其精确输入 I、成功 A、预期失败 E 和解释函数 h 属于同一个定义；取业务上下文 K 的一个值 c，以及作者实际写出的纯函数：

```text
resume : K × Result<A,E> -> Command
follow(d,i,c,resume) =
  interpret d at i;
  if Success(a), return resume(c, Success(a));
  if declared Failure(e), return resume(c, Failure(e)).
```

这是普通 Effect 的错误消解与 map/flatMap；不是把 `resume` 交给 schema 推导。`follow` 的产物是一个 `F<Command,never,R>`，其中 `never` 只表示这里已把声明失败转成 Command，不表示不会 defect、取消或失去进程。若某类失败应该使外层计算失败，就让 resume 返回一个 Effect 或只消费指定失败，不强迫统一吞掉失败。

关键是隐藏不同工作的**中间类型**，不隐藏它们的对应关系。不同工作可以分别返回 A1、A2，而分别传入 `resume1 : K1 × Result<A1,E1> -> Command` 与 `resume2 : K2 × Result<A2,E2> -> Command`。两项构造最后都产生 Command，故能够进入同一纯决定；解释器无须知道 A1/A2 的业务名，也不需要全局 `Order | Candle | News` switch。

它的存在类型关系可写成：

```text
Work<Command,R> = exists I,A,E,K.
  (d : Operation<I,A,E,R>, i : I, c : K,
   resume : K × Result<A,E> -> Command)

run : Work<Command,R> -> F<Command,never,R>
run(pack(d,i,c,resume)) = follow(d,i,c,resume)
```

`pack` 是解释这项关系的记法，实施可以直接保存构造出的 Effect 闭包，不必新增运行时 Work AST。不同 R 由静态联合保留；外部进程操作在安装边界封装原生资源，主机剩下精确的 transport/权限/Scope 要求。**不能靠 existential 把未满足的 R 擦掉。**

### Decision/Evolution 的位置

```text
decide : State × Command -> Result<Event* × WorkSpec*, Rejection>
evolve : State × Event -> State

candidate(s,c) = decide(s,c)
next(s,events) = fold(evolve,s,events)
```

这里 Event 是这一个业务状态机接受的事实，Command 是进入它的精确输入和，WorkSpec 是它允许发起的工作描述；三者不是全 UTA 消息全集。本文使用有限序列而不固定初版示例的 nonempty：消费一个尚未命中条件的数据可以产生零个事件、零项工作；只读后继也可以产生工作而不改变业务状态。持久消费是否需要另记处理位置，是恢复承诺的要求，不是凭空制造一个业务事件的理由。真正持久的工作必须被记录，但工作记录不必冒充领域状态变化。

`resume` 将外部结果构造成下一 Command，而不是直接构造已经提交的 Event。于是即使完成结果的解码成功，当前 State 仍可以因版本、已关闭或条件不足拒绝改变。纯 `evolve` 不重放 IO；对历史 Event 的重建也不重新执行 WorkSpec。

运行中消费者可以维护局部状态并串行调用这组函数。承诺持久控制时，writer 在当前状态/版本上决定并原子写入 events 与 work；worker 只解释已写入工作；结果通过 `resume` 再成为一项新的决定输入。没有持久承诺的数据消费无需交易 WAL。

### 哪些 continuation 能重建

任意 `A -> Effect<B>` 不能自动保存和恢复。对持久工作的**具体安装族**，安装者必须提供以下真实操作数：

```text
makeStep(d, inputCodec, resultCodec, contextCodec, resume)
encodeRequest : I × K -> EncodedRequest
encodeResult  : Result<A,E> -> EncodedResult
rebind        : StepVersion
              -> Result<exists I,A,E,K.
                   InstalledStep<I,A,E,K,Command,Rhost>, RebindFailure>
resumeStored  : InstalledStep × EncodedRequest × EncodedResult
              -> Result<Command, DecodeFailure>
```

`makeStep` 捕获现有 d、h 与 resume，并为其可编码的输入、结果和上下文登记一个不可变构造版本。**rebind 只找回函数与解码器，不运行 h。** `resumeStored` 用同一构造解码 i/c 和已保存结果，再调用 `resume(c,result)`；它不再次调用 Provider。泛型签名表示绑定内的关系，实际可用存在包保持这些中间类型，不向调用者声称编译器已知任意动态 I/A。

工作现在是否允许执行，由当前决定及工作消费状态决定，不由“函数已重绑”决定。可以据充分的未执行证据执行原工作；已经保存结果则只恢复结果消费；远端可能已执行但结果未取得时，由拥有该责任的决定构造观察/解析的新工作。第三种不能退回第一种。结果存储与业务消费之间如果发生崩溃，恢复消费须核对该结果是否已在本地决定中处理，不能重复产生后继工作。

若 d 是动态选中的，编码请求保存本次完整 binding；重绑解析的是该 binding，不是目录中当前同名定义。动态结果怎样进入实际的 resume，见后面的正面构造。没有历史构造、原 binding 或必需上下文时，恢复显式失败并保留原工作责任；不得改用当前默认值续跑。

这是针对持久外部工作的一项构造要求，不声称当前代码已有通用 outbox/重绑实现；也不引入可序列化任意程序、通用表达式语法或自动工作流编译器。

## 两个真正不同的候选

### A：保留一次返回与连续产出的原有计算，统一结果续接

A 就是上述构造。通用规则为函数应用、Effect 结果续接、Stream 逐项消费、纯状态折叠。声明为这些计算提供可检验的外边界；持久性为所选消费者增加提交与重绑。事务动作仍是 IO，但它的准备、批准、发送和观察由私有解释边界限制，不能因 `Effect<Receipt>` 和普通查询都有返回值就把发送句柄对外开放。

A 不预设 `Pull | Push | Controlled` 必须三选一。由上面的消费方式自然得到：一个有限返回出口；一个由作用域拥有的连续交付出口；一个持久接纳返回值还可成为后续查询或连续观察的输入。受控性约束谁能解释哪些工作、何时能解释以及重启后谁继续负责，并不从输出的有限/连续形状推出。这里不继承现有三分作安装协议；公共出口须从实际构造出的程序和所承诺的解释权产生。金融交易的控制政策也不能由这种区别扩张为所有管理写入的统一事务。

### B：以一次交互同时拥有逐项产出和最终返回为原语

```text
Interaction<Yield,Return,E,R>
onReturn : Interaction<X,A,E,R> × (A -> Interaction<X,B,E2,R2>)
        -> Interaction<X,B,E + E2,R + R2>
onYield  : Interaction<X,A,E,R> × (X -> F<void,E2,R2>)
        -> Interaction<never,A,E + E2,R + R2>
```

有限调用可没有 Yield；持续订阅可以持续 Yield 而没有可达的成功 Return；交易可以 Yield 进展而最终 Return 满足判据的结论。这与 A 的区别不是改名：**公开契约以一个交互的身份同时绑定进展和最终结论，并区分由哪条输出启动后继。** 它能更直接表示“进展已交付而主计算仍未结束”，但构造者必须先决定一次交互何时结束、多个消费者共享哪个生命期，接纳成功与成交完成是否属于同一个交互。

B 可用既有 Effect 流/通道能力作为实现材料，不必发明 UTA 通用语言；然而当前目标没有要求普通 CLI 接纳必须一直保持同一个交互到业务结案。若强制这样做，CLI 退出与持久业务责任必须再次拆开；若允许交互返回持久 handle，则又需要 A 的独立后继观察。故本稿选择 A，不以 B 不能表达为理由，而以**不提前绑死计算结束、交付结束和业务结案**为理由。只有某项实际协议确实拥有独立的 yield 与最终 return 契约时，才在那一边界局部使用 B。

## 声明、解释函数和动态后继怎样实际取得

### 一个声明构造两种消费者，而非描述反射函数

设 `σ ⊢ A` 表示 schema σ 的解码结果是 A。构造一个有限能力时，作者提供 schema 操作数和实际 h：

```text
define(σI, σA, σE, access)(h)
  where h : I -> F<A,E,R>

invoke(define(...)(h), i) = 在 access 通过后解释保存的 h(i)
describe(define(...)(h)) = 从保存的 σI/σA/σE 编码边界描述
```

这是一个构造器的两种消费，不存在分别传给 invoke 和 describe 的第二套类型定义。它**不会生成 h 的业务实现**；h 是本地作者提供的函数，或由外部进程解释器构造的函数。access 是被实际执行的权限计算，不是静态 R 中有连接就默认授权。描述能说明输入/返回/失败及声明的访问要求，不能凭 `Effect<A,E,R>` 推导任意 h 是只读，也不能反射出它未声明的业务承诺。

跨语言解释器的函数体关系是：

```text
foreign(d)(i) =
  encode using d.input(i);
  exchange with d's installed process/binding;
  decode success using d.success, or failure using d.failure.
```

交换失败与解码违约是主机解释失败，不混入 Provider 尚未返回的领域失败。每个成功/失败都在所选 d 的解释作用域中解码；SDK 原生对象不越过这条边界。外部作者负责 native 输入构造与输出转换，主机负责契约解码和把结果送入保存的后继。原生代码可以是任何语言；以上函数不读取或猜测原生实现。普通动态发现不会让已编译 TypeScript 增加一个新类型成员。

### 动态 A 有三条可实际构造的消费，不以一句“安装族相容”替代

**第一条：AI/展示本来要消费完整动态结果。** 对发现的 d，调用入口把输入按 d 解码，输出得到 `Certified(d,A)`。其内部保留经该 schema 验证的编码值；展示消费者可直接使用 d 的结果描述编码/展示它。此时实际函数为：

```text
resumeDynamic(c, Success(a)) = returnToCaller(c, certifyAt(d,a))
resumeDynamic(c, Failure(e)) = returnFailureToCaller(c, certifyFailureAt(d,e))
```

这两个函数只依赖调用归属和 d 的编码器，不访问未知 A 的某个字段。它们可以真正构造；但它们的结论仅为“这个计算返回了这个声明结果”，不是“订单成交”。`returnToCaller` 是普通出口消费，不强制产生持久消息。

**第二条：声明本身由已知基础值与未知扩展积构成。** 以用户明确要求的 Candle 为例，外部声明构造 `σX = product(σCandle, σExtra)`；product 同时给出 parser、公开结构和总投影 `π : X -> Candle`。π 的实际算法是取积的基础分量，并保留基础约束；不是检查任意 JSON 里碰巧有个 close 字段。使用嵌套积可避免字段覆盖；使用平铺扩展则须由构造器检查不相交。

```text
pθ(candle) = candle 满足本次所需数据有效性
             且 DecimalCompare(candle.close, θ) > 0

resumeCandle(context, x) = consumeReading(context, π(x))
```

`pθ` 是消费者作者写的纯业务函数，θ 是实际配置；`DecimalCompare` 按声明的单位/decimal 值工作。π 由 product 构造，pθ 不由 schema 发明。新增 Extra 不改变这个消费者；如果业务改用 Extra.vwap，就不再是假装基础投影足够，必须声明并取得那个输入关系。

**第三条：A 完全异构，目标业务却确实需要一个已知 B。** 必须有一项实际转换；单凭发现 schema 不能产生它。可用已安装的纯 `n : A -> Result<B,En>`，也可用与 d 同时安装的第二项计算 `v : A -> F<B,Ev,Rv>`。例如 native ACK 需由 Provider 进程解释时，v 的本地函数体就是“按同一 d 的结果编码 A，调用已安装的解释入口，按 B 的 schema 解码”。UTA 构造：

```text
normalized(i) = Effect.flatMap(foreign(d)(i), foreign(v))
resumeKnown(c, Success(b)) = consumeKnownObservation(c,b)
```

v 的输入声明直接引用 d 的输出声明，而不是复制一份近似字段表；v 的业务实现由适配作者提供。这样原始 A 不必统一，主机也不伪造对 A 的理解。若 v 需要 IO，这项 IO 确实出现在计算关系和失败/R 中，不在纯 decide 中偷调它。若没有 n/v 或合法基础投影，完整动态结果仍能交给 AI，但不能进入一个要求已知 B 的自动判据；这是不满足组合前提，不是 Provider 黑箱阻止了全部内部设计。

### 同一个外层 HOF 生成具体 CLI，而非再手写命令参数

以下由作者提供的 Order 基本语义单元、该来源的条款声明和扩展构造 d，不先假定各 Provider 共享 quantity/pricing 字段、原生接口或 SDK 类型：

```text
σOrder(d) = product(σOrderBase, σTerms(d), σExtra(d))
d = define(σOrder(d), σNativeReturn(d), σNativeFailure(d), access)(foreignHandler)

retainWhen(d, source, π, σTriggerConfig, predicate,
           makeQuestion, ask, answers, answerRule)
  input = product(σOrder(d), σSourceInput, σTriggerConfig, σRecipient)
  output = σIntentAdmissionReceipt
  failure = sum(输入/权限/本地持久接纳的声明失败)
  h(i,j,config,recipient) =
    writer.admit(decision constructed from the captured operands,
                 saved d binding, i, j, config, recipient)
```

`σTerms(d)` 完全由该声明作者选择。例如一个来源实际选择 `quantity × sum(market, limit × price)`，另一个可选择不同大小/定价条款；这只是实例，不能要求所有来源具有这两种定价方式。`σExtra(d)` 同样不是可随意写入的 map，而是作者的具体 schema。product 给出解析、结构描述及基础投影；foreignHandler 的实际本地函数体是上面的 encode/exchange/decode，Provider 内部再适配原生 SDK。整个构造不重写一份 `ProviderFooOrder`，也不把 TS 类型跨语言传递。

这里 d 是供受控解释器持有的私有操作数，不因 define 就自动成为可调用的公共目录叶子。AI 看到的是外层能力引用的 Order/Terms 声明和支持说明；挂载 wrapped 不暴露 d 的 native handler。准备、批准及发送权限不是由目录可见性授予。

上面的公共边界和 h 是同一 HOF 捕获并生成的关联，不是通用“槽位主对象”。input 里的订单和来源请求分别直接引用 d 和 source 的输入声明；有限 receipt 来自本地提交成功后的实际返回构造。`answers` 也是被捕获的具体计算，不能在解释时找一个未声明的全局回复源。π 来自 source 结果的基础积投影；predicate、makeQuestion、answerRule 是作者显式传入且下节给出求值的纯函数。它们的输入分别对接 source 的基础值、ask 的输入与 answers 的输出，连接处需要的类型关系在构造时保持，不靠事后介绍词补齐。

writer.admit 保存接纳决定需要的 i/j/config/recipient 及构造版本；该次成功只返回本地接纳 receipt，不解释 d 的 native 发送函数。后续 source、ask 和 answers 的解释来自已捕获操作数的重绑，且分别服从来源订阅、投递和持久控制的消费资格。主体、接收者和策略的业务选择由实际输入及作者函数提供，不从 schema 默认值推导。

令 `wrapped = retainWhen(...)`。挂载者提供路径，CLI 的目录叶子和参数 schema 都只消费 `describe(wrapped)`；CLI 的运行消费者也只调用 `wrapped`。所以若 d 新增必填 `session`，同一次积构造就让该叶子的实际输入与 CLI 描述同时要求 session；若 pricing 选择 limit，同一和结构要求 price。调用者没有给 session 时解析失败，不替其选择交易时段。没有注册 option/cancel 定义，就不会生成 option/cancel 叶子；能力缺席不是一次调用返回“未支持”的万能动作分支。

动态 CLI 可以把复杂积/和以经过该 schema 校验的结构化参数交给叶子；不要求预编译每个扩展字段的 TypeScript。AI 从同一个描述取得 schema 并构造输入，或经显式的一步问答补齐输入。有限的机器交互协议是稳定的，实际叶子与字段是这次已安装声明计算出的结果。

同一个规则也可公开普通有限数据计算和连续交付计算。后者复用 σCandle 的产出描述，并由逐项输出消费者写 stdout；它不是把整个流塞进一次有限 JSON 返回。一个任意自由闭包没有这组公共边界操作数时，仍可用于内部 Effect 程序，但不能自动成为已完整自描述的 CLI 能力。

## 用同一组构件手工贯通：数据引发保留订单决定

这不是先起消息名字再连组件。下面先固定真实操作数，然后按函数求值推演；行间的先后是本次观测顺序，不制造所有实现都必须服从的网络总序。

### 操作数来自哪里

1. 发现所得 d 的输入是 `OrderBase × Terms × Extra(d)`。AI 按具体 schema 给出 i；解析保存整个 i，业务函数只通过积投影读基础语义。Extra 不被裁掉，也不会在后续解释时换成当前默认值。d 的原生发送实现仍只在有资格的交易解释边界可用，本例不取得该资格。
2. `source(j) : S<X,Es,Rs>` 实际提供 Candle 扩展结果；X 有前述总基础投影 π。j 的品种/窗口/订阅参数来自用户或一项明确输入构造，不由输出 schema 倒猜。`pθ` 的具体政策为“消费本次范围内有效的收盘值，首次严格大于 θ 时询问是否保留”；本例 θ=100。只比较阈值不需要推测前值，不冒充 crossing 策略。
3. `ask : Question -> F<DeliveryReceipt,Ea,Ra>` 是外部投递计算；它的成功承诺是对方接受了问题，不是 AI 已回答。`answers(q) : S<Answer,Eb,Rb>` 是该问题的回复消费。Question 包含原意图引用和依据；Answer 的具体可用选择为保留原意图或放弃，保留规则及收件人由调用输入绑定。
4. 作者给出的纯函数包括：`makeQuestion(i,x,q,recipient)` 直接构造 ask 的输入：以 q 标识问题、以 recipient 指定接收者、以原 i 的身份和精确声明值说明待保留对象、以 x 说明触发依据；`answerRule(i,Keep)=Retained(i)`，`answerRule(i,Discard)=ClosedWithoutSending(i)`。二者没有调用 d。问题标识从这份控制状态持有的意图身份与本次序号构造，不在纯函数里读取时钟或随机数。凡需 now 的判断，now 作为已经取得的输入进入。
5. `resumeAsk((intentRevision,q), result)` 将精确投递结果和其原上下文交给这个决定的输入构造；`resumeAnswer((intentRevision,q), answer)` 同样交给这个决定。这里的两个具体函数只是构造 `decide` 所需的积/和输入，不声称外部结果已成为持久事实。

### 两条连续计算不是凭空已经运行

HOF 捕获的 producer 和纯后继可以直接构造以下 Effect 程序；writer.consume 是当前控制状态的解释边界，令其收到纯输入，运行 decide/evolve 并提交，**不是全局事件总线**：

```text
consumeSource(j, owner, context) =
  each(source(j),
       x => writer.consume(owner, resumeCandle(context,x)))

consumeAnswers(q, owner, context) =
  each(answers(q),
       a => writer.consume(owner, resumeAnswer(context,a)))
```

两者只用了先前已给出的 each，result 的每次消费是上述实际 callback，不需要将 X/Answer 先转成统一交付帧。它们的生产者绑定、j/q、owner 及纯消费者构造版本是可编码工作输入；Scope、连接和 writer 服务由安装好的解释函数获取，不写进输入。

t0 的接纳决定还产生一项“运行 consumeSource(j,owner,context)”的工作。提交以后，UTA 的该工作拥有者在自己的 Scope 内解释它，调用 source(j) 取得来源并安装上面的 each 消费者，t1 才有输入可被消费。j 从 HOF 的 `σSourceInput` 分量解析；来源新增必填 session 时，外层同一输入构造和 CLI 同时要求它，缺失就不能得到这项合法工作。后台 each 长时间存在不意味着 writer 的一次事务一直打开。

t2 的决定产生两个已关联到 q 的实际工作：`consumeAnswers(q,owner,context)` 与 `follow(ask,Q,context,resumeAsk)`。提交后，两个工作的解释拥有者分别取得回复源与运行投递计算。本例选择如下明确的 Ask/Answers 组合契约：**双方使用同一个由提问方给定的 q；问答所有者保留 q 的回复；answers(q) 能读出该问题已保存的回复并继续等待新回复，直到声明的保留边界。** 因此先启动哪项工作不决定回复能否被消费；甚至 ask 本地结果晚于回复也可推演。它是这组外部操作数须履行的契约，不是 schema 或 Stream 自动保证，更不声称当前 Alice 已经实现。

只有瞬时、不可回读回复的接入不满足该对偶：那时必须另提供“获取已安装回复订阅”的有限计算，得到确实可观察的订阅后才解释 ask；不能仅 fork 一个冷 Stream 就宣称监听已就绪。若业务要求重启后仍能回答，瞬时订阅还不足以承担该持久承诺。这里把不能统一的条件放在实际 Ask/Answers 操作数上，不恢复既定 EF 状态表。

Scope 属于这些具体工作及控制拥有者，解释器在不再消费对应输入时释放所拥有的订阅；控制状态不因此被删除，已投递问题或订单也不被 Scope finalizer 撤销。重复的超阈值输入进入 decide 时，当前状态已不再是“首次等待触发”，不会再产生第二份问题工作。

### 求值顺序和可观察结果

| 时刻/已有输入 | 实际函数计算 | 所得值、状态与下一计算 |
|---|---|---|
| t0，CLI 提供 i、j、θ=100、收件人 | wrapped.h 调用纯接纳决定，连同 consumeSource 工作提交后才返回；工作拥有者随后打开 Scope 解释 source(j) 与 each | 状态为等待(i,θ)，保留 j 与构造关联；返回“本地已保存这份未开始意图”的 receipt。没有解释 d 的发送；CLI 此次有限调用结束不删除等待状态 |
| t1，source 给出有效 x1，其 π(x1).close=99 | `each` 的消费者调用 `p100(π(x1))=false`，再在当前等待状态运行 decide | 仍为等待(i,100)，没有问题、没有发送、没有后继工作。普通展示消费者可同时显示 x1；不需为了显示而提交交易事件 |
| t2，source 给出有效 x2，其 π(x2).close=101 | `p100(π(x2))=true`；`makeQuestion(i,x2,q,recipient)` 得到 Q；decide 提出保留 Q，以及 consumeAnswers 和 follow(ask) 两项工作 | writer 原子接受“正在等待 q 的回答”及实际工作；随后工作拥有者解释回复消费和投递。pure evolve 已使状态具有 q 与原 i 的关联；此决定本身没有执行 ask，也没有发送订单 |
| t3，worker 得到执行该 ask 工作的合法性后解释 `follow(ask,Q,(revision,q),resumeAsk)`；外部返回 DeliveryReceipt r | `resumeAsk((revision,q),Success(r))` 得到下一决定输入；decide/evolve 只记该问题已被外部接纳 | 状态仍等待 q 的回答。一个只关心投递的调用消费者可以成功返回 r；需要“是否保留”结论的消费者尚不能返回 Retained 或 Closed |
| t4，answers(q) 实际产出 Keep | `each` 消费该 Answer，经 `resumeAnswer` 进入当前 decide；q 与意图修订匹配时计算 `answerRule(i,Keep)=Retained(i)` | 接受对应事实后 evolve 保存原 i 为保留状态。没有 Broker 发送工作；Extra(d) 仍在 i 内。放弃分支则计算 ClosedWithoutSending(i)，不是补偿一个从未发送的订单 |

**返回值计算成功但期待外部结果未成立**就在 t3：`ask` 的返回类型 A 是 DeliveryReceipt；等待后继的输入 B 是 Answer。`then(ask, r => display(r))` 已完成；`then(ask, r => consume answers(r.question))` 还要获得 B 才能完成保留判断。第二式只有在回复可从该引用完整观察时才可直接这样运行；持久形式在发起 ask 前已经保存了 q 的回复归属，不把迟注册的临时订阅当作必然不会漏回复。

这也说明“同样都是结果消费”为什么不等于“同样成功含义”：两个程序消费相同 A，选择不同 k。核心没有一个默认的 `success => fulfilled` 转换。原始交易成功判据同理：选择 accepted 的消费者与选择 fully-filled 的消费者不能由同一 ACK 自动得到相同结论。

### 改变顺序会怎样，而不是把表当作固定协议

- 回复先于 ask 的本地返回被消费：q 已在 t2 提交，reply 可先使状态成为 Retained(i)。随后 ask 返回进入 decide 时，不能把已完成的决定退回等待。解释函数返回顺序不决定业务事实的唯一可能顺序。
- ask 返回声明失败：`resumeAsk(...,Failure(e))` 仍是真实可计算的输入；状态记录投递未成功及未解决责任，不伪造 Keep、Discard 或发送。是否再次投递由实际投递契约和业务决定选择，不由 `flatMap` 自带重试。
- x2 或回复属于另一意图/另一问题：它仍可以是合法解码结果，但不是当前决定所等待的输入；decide 不推进当前状态。一次 Effect 成功不是对任意状态机有效的许可。
- 本地在 t3 保存结果后、消费结果前崩溃：只重绑 resume 并消费保存的 r；不再运行 ask。若无法确定 ask 是否已经送达，选择可查询该问题的工作或显式保留未决，不以重绑成功证明可重发。
- 来源修订、缺失或失去本次谓词要求的有效性：必须由所选数据契约和谓词说明这些输入是否可用、已有依据如何解释。本例没有由 source 合同证明的不可变/完整数据时，就不能宣称其结论永久有效；可构造更保守的拒绝/重新询问消费者，但不把统一 frame 家族补回来。

普通非事务 K 线消费只替换后继：`each(source(j), x => stdout(encodeX(x)))`。历史 K 线则是 `then(fetch(j), page => stdout(encodePage(page)))`；有限页还可由纯 fold 消费。它们共用 Candle 的基础/扩展构造和 Effect/Stream 消费规则，不调用上述接纳决定、ask 或订单 writer。把连续源 collect 到无限数组不是“统一 Push/Pull”；把轮询称作原生 push 也不是等价变换。

## 与真实输入的关系、条件及证明强度

- 原用户在 `local://uta-original-user-inputs.txt:65–95` 要求跨语言 Provider、声明计算 CLI、Order 加扩展、统一基础 Candle 的两种交付及数据触发保留决定；`:180–190,205–210` 要求黑箱 IO 的类型与函数组合，不因未知动作而停止内部表达。本稿的边界、续接和场景均直接由这些要求约束。
- 初版 `docs/uta-effect-runtime-architecture.md:283–311` 已将 UtaEffect 等同 Effect，并明确 Scope/Queue/finalizer 与持久事务/补偿不同；`:317–338` 给出 Decision/Evolution 的纯关系；`:403–430` 区分持久意图、解释、观察及冻结成功判据。这些是被保留的原始关系，不引用被否定的新事件流。
- 真正旧实现 `services/uta/src/domain/trading/git/TradingGit.ts:141–184,929–976` 在解释操作后消费返回值，`success:true` 与具体 status 分开，未知/缺失 status 甚至会被映为 submitted。`services/uta/src/domain/trading/UnifiedTradingAccount.ts:844–914` 后续另取 broker 观察才形成终态更新。它直接反驳“调用成功已给出所有后继业务结论”，但这些旧错误折叠及字符串状态不成为新核心要求。
- `src/domain/market-data/bars/bar-service.ts:221–234,262–274` 实际将 Provider 结果转换并返回 BarsResult，没有先进入交易提交。这支持非事务数据后继的独立消费，而不证明旧数据具有本稿选择的全部有效性契约。

组合能保证的是：连接处同一个实际 A 被交给接受 A 的函数；明确处理的失败不会伪造成成功；相应 R 不被擦除；纯决定不执行 IO；持久重绑不等于重发。基础积投影若保持 B 的含义，则任何只依赖 B 的纯函数满足 `f(π(b,x)) = f(b)`；这不证明扩展 Provider 的副作用、顺序和数据质量与原来源相同。

不能自动统一的语义是：一次返回/无限产出的终止条件，投递接纳/业务决定的完成判据，读取可重复/远端写入未知时的恢复资格，原始数据/带修订数据的可用性，以及 CLI 退出/持久责任结束。它们分别由交付、业务函数或持久解释政策提供真实操作数。没有这些操作数时，不能以 schema、命名或同一个泛型填上承诺。

本轮证明形式仅为来源回查、显式构造和上述正反顺序的手工求值；没有编译、运行或真实 Provider 证据，不把历史归档的执行结果冒充本轮验证。Effect 的 API 层仅沿原始 UtaEffect 与既有 flatMap/Stream 消费关系；额外文档检索出现版本混杂，未据其 v4 签名对 v3 作实现断言。
