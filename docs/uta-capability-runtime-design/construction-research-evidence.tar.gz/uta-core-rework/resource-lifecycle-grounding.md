# UTA 旧 broker resource/lifecycle grounding

> 这是一份源码事实核查，不是新协议提案。未修改源码、未调用真实 broker、未运行测试或验证命令。

## 1. 入口、owner 与已读范围

从 `docs/README.md:36-38` 进入 UTA 两份 owner/设计入口；与本题直接相关的现行 owner 指向是 `docs/broker-packs.md:1-6`（Alice 拥有可选 Broker Pack 的安装、激活、runtime loading 契约），而不是把 Pack 行为提升成 UTA 核心。旧交易域指南 `services/uta/src/domain/trading/README.md:5-13` 仍把每个 UTA 描述为拥有 Broker，并规定 AI 只通过 UTA，不直接碰 Broker。

当前进程边界必须分开看：

- Alice 当前在 `src/main.ts:139-156` 构造的是 `UTAManagerSDK`；`src/services/uta-client/index.ts:4-13` 明确说该 SDK 替代 Alice 进程中的旧 `UTAManager`，并且 Alice 不再持有 broker connection，UTA 持有。
- UTA 进程在 `services/uta/src/main.ts:56-65` 构造真正的 `UTAManager`。因此下面的 `UTAManager`/`UnifiedTradingAccount` 是 broker 所在进程的实际 owner；`UTAManagerSDK` 只是 HTTP/restart 适配器。
- 既有映射已指出本次需要重核对的同一组事实：`MAP-C764A73F05`（`reconnectUTA`）、`MAP-A52D6896E9`/`MAP-997D4009EE`（`closeAll`）、`MAP-6474FE1FB1`（Map/Set live handle）、以及 `IbkrBridge` 的 listener/teardown mappings。下文只以当前源码为证据，不把这些映射中的目标模型当作当前实现。

## 2. Pack 安装/替换由 Alice 负责，UTA 只解析并在新进程加载

### 2.1 安装与 active pointer

`src/core/broker-packs.ts:1-4` 的模块注释直接规定：Alice 安装并激活 immutable release，UTA 只解析。实际安装函数 `src/services/broker-packs/installer.ts:76-145` 的顺序是：

1. 建立 `<engine>/.install.lock`，创建 staging 目录；
2. 读取精确版本/平台 catalog，选 asset，验证版本、API、平台/glibc 与大小限制；
3. 下载到 staging，校验 SHA-256，解包并验证 package name/version/entry；
4. `activateImmutableRelease` 把完整 release 放入 `releases/`；
5. 写临时 `active.json`，最后用 `rename` 原子替换 pointer；
6. `finally` 删除 staging 与 lock。

`activateImmutableRelease` 位于 `src/services/broker-packs/installer.ts:175-212`：同 content release 复用；已有 corrupt release 不原地覆盖，而创建新的 `-repair-...` release 后再换 pointer。`docs/broker-packs.md:83-101` 也明确说 UTA 不运行 package manager、pointer 替换前失败保留旧 active release、不要覆盖 Windows 进程可能仍打开的文件。

UI 安装入口 `src/webui/routes/trading-config.ts:162-170` 负责调用 installer；安装成功后只调用 fire-and-forget `notifyUTAReload()`。该函数 `src/webui/routes/trading-config.ts:25-37` 只记录重启失败/未 ready，不把 HTTP 响应阻塞到新 UTA 完成。

### 2.2 UTA 看到 replacement 的方式

`services/uta/src/domain/trading/brokers/registry.ts:52-67` 用进程内 `Map<BrokerEngine, Promise<BrokerEngineEntry>>` 缓存 engine load；`services/uta/src/domain/trading/brokers/registry.ts:69-110` 对非 Mock engine 解析 active Pack、动态 import、验证 API/engine/configSchema/createBroker。active pointer 的读取和 release 校验在 `src/core/broker-packs.ts:86-135`。

因此 replacement 不是运行中的 broker 实例热切换：active pointer 变更后由 `src/services/broker-packs/auto-updater.ts:49-77` 在安装完一个或多个旧 Pack 的 replacement 后调用 `triggerUTARestart()`；`services/uta/src/main.ts:1-10` 直接写明 broker config 变更走 Guardian SIGTERM/respawn，无 in-process hot reload。`src/services/uta-supervisor/restart-trigger.ts:4-10,63-81` 规定写 control flag、等待 Guardian 重启、以新的 `startedAt` 判断新进程。

`clearBrokerEngineCache()` 只有 `services/uta/src/domain/trading/brokers/registry.ts:52-56` 的定义；本次仓内搜索没有找到调用点。因此不能把 active pointer 原地变更解释成同进程 engine cache 自动切换；实际设计依赖进程重启销毁旧 cache。

## 3. 选定的真实分支：UTA 进程内 `UTAManager.reconnectUTA`（旧 manager 路径）

这条分支的 HTTP 入口是 UTA 侧 `services/uta/src/http/routes-trading.ts:219-224`，其调用 `ctx.utaManager.reconnectUTA(id)`。它与 Alice 侧的 `UTAManagerSDK.reconnectUTA` 不同；后者在 `src/services/uta-client/UTAManagerSDK.ts:171-184` 只触发 whole-UTA Guardian restart。为了不混淆，本节追踪真正直接持有 broker 的 UTA manager。

### 3.1 实际顺序

`services/uta/src/domain/trading/uta-manager.ts:82-123` 的顺序是：

1. 以 raw `utaId` 检查 `reconnecting` Set；重复请求立即返回失败。
2. 先 `readUTAsConfig()`，所以重新读取配置失败时，旧 UTA 尚未移除。
3. `removeUTA(utaId)`：从 `entries` 删除旧 UTA，然后 best-effort `await uta.close()`。
4. 在 freshly-read config 中寻找同一 id；找不到则返回成功并保持 removed 状态。
5. 找到时调用 `initUTA(cfg)`。
6. `initUTA` 在 `services/uta/src/domain/trading/uta-manager.ts:61-79` 中依次 `createBroker`、加载该账户 Git state、构造 `UnifiedTradingAccount`、`add(uta)`；构造函数已启动异步 broker connect，但 `initUTA` 本身不等待 connect。
7. `reconnectUTA` 再 `await uta.waitForConnect()`，成功后按 preset engine 可能注册 CCXT tools，返回 success；异常只被转换成 `{ success: false, error: string }`。

`createBroker` 的边界在 `services/uta/src/domain/trading/brokers/factory.ts:27-47`：preset schema parse → `toEngineConfig` → `loadBrokerEngine` → engine config parse → Pack 的 `createBroker`。所以 manager 持有的是已构造的 `IBroker`，不是 Pack release 文件本身。

### 3.2 旧 UTA 的订阅与释放顺序

`UnifiedTradingAccount` 构造函数 `services/uta/src/domain/trading/UnifiedTradingAccount.ts:141-155` 把 manager 给出的 `onHealthChange` 保存到自身，并通过可选的 `broker.setConnectionStateListener` 注册一个闭包；随后在 `:211-222` 启动 fire-and-forget `_connect()`，`waitForConnect()` 在 `:226-229` 仅返回这个原始 Promise。

旧实例被移除时，`removeUTA` 先删 Map 再 close（`services/uta/src/domain/trading/uta-manager.ts:125-131`）。UTA 的 close 顺序是：

```ts
// services/uta/src/domain/trading/UnifiedTradingAccount.ts:1253-1261
this.broker.setConnectionStateListener?.(null)
if (this._recoveryTimer) {
  clearTimeout(this._recoveryTimer)
  this._recoveryTimer = undefined
  this._recovering = false
}
return this.broker.close()
```

在选定的 IBKR adapter 分支，`IbkrBroker.close()` 是 `services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:225-229`：停止 heartbeat、停止 account subscription、调用 `client.disconnect()`。subscription cancel 的实际请求在 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:341-347`，即先把本地 `accountSubscribed_` 置 false，再对同一个 account code 发 `reqAccountUpdates(false, ...)`。

`EClient.disconnect()` 在 `packages/ibkr/src/client/base.ts:229-235` 将连接状态设为 disconnected，调用 `Connection.disconnect()`，调用 wrapper 的 `connectionClosed()`，然后 reset client。底层 TCP `Connection.disconnect()` 在 `packages/ibkr/src/connection.ts:84-93` 先把 socket 设为 null、destroy socket，再同步调用 wrapper；socket 的后续 `close` 事件看到 null 后不再重复调用 wrapper（`packages/ibkr/src/connection.ts:49-58`）。

### 3.3 连接状态 callback 的实际 owner

接口只给一个可选的单 callback：`packages/uta-protocol/src/types/broker.ts:490-498` 的 `IBroker.setConnectionStateListener(listener | null)`。IBKR adapter 只是转发给 bridge（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:165-167`），bridge 内部也只有一个可覆盖的 nullable 字段（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:100-111`）：

```ts
private connectionStateListener: ((event: BrokerConnectionStateEvent) => void) | null = null

setConnectionStateListener(listener: ((event: BrokerConnectionStateEvent) => void) | null): void {
  this.connectionStateListener = listener
}
```

IBKR 的事件来源与含义：

- `RequestBridge.markDead()` 在 `services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:464-470` 置 dead 并同步发 `{ state: 'dead' }`；`connectionClosed()` 在 `:477-484` 调 `markDead()`、`rejectAll()`、拒绝握手 waiter。
- 错误 502/504/1100 走 dead，1101/1102 只发 `restored`（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:488-505`）。
- `IbkrBroker.init()` 在 account subscription 首次 ready 后才 `markAlive()` 并启动 heartbeat（`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:213-219`）。`markAlive()` 只有此前确实 dead 才发 `alive`（`services/uta/src/domain/trading/brokers/ibkr/request-bridge.ts:471-475`）。
- UTA 收到事件后的处理是 `services/uta/src/domain/trading/UnifiedTradingAccount.ts:334-351`：`alive` 直接 return；`restored` 只 `nudgeRecovery()`；`dead` 才把 reach 设为 `down`、失败数设为 offline threshold 并启动/维持 recovery。

## 4. 旧 callback 能否到达新实例：结论分两层

### 4.1 运输层 connection-state callback：在正常 close 顺序下不会直接到达新 UTA

close 首先执行 `broker.setConnectionStateListener(null)`（`UnifiedTradingAccount.ts:1253-1255`），而 bridge 的 listener 是可变单槽字段（`request-bridge.ts:100-111`）。因此随后 IBKR `client.disconnect()` 引发的 `connectionClosed()` 即使发生，也只会让旧 bridge `markDead/rejectAll`，不会再调用旧 UTA 的 `_onBrokerConnectionState`。新 UTA 在 `initUTA` 中得到的是新 broker；IBKR 构造函数每次都新建 `RequestBridge` 与 `EClient`（`IbkrBroker.ts:125-131`），新 listener 不在旧 bridge 上。已读代码没有发现旧 bridge 能直接取得新 UTA listener 的路径。

### 4.2 异步 UTA continuation：旧状态仍可能在 replacement 后被观察

这里没有同等的取消/代次栅栏：

- `_connect()` 在构造函数中 fire-and-forget（`UnifiedTradingAccount.ts:211-222`）；`close()` 不取消或 await `_connectPromise`，只清理当前 recovery timer 再调用 broker close（`UnifiedTradingAccount.ts:1253-1261`）。
- `_connect()` 在 `_attemptReach()` 结束后仍会修改旧对象的 `_currentReach`/`_connecting`，并在 `:354-393` 发 `_emitHealthChange()`；`onHealthChange` 由 manager 在 `uta-manager.ts:71-74` 绑定为 `eventLog.append('account.health', { accountId: utaId, ...health })`。
- 因此若 close 与旧的初次连接/恢复 continuation 交错，旧 UTA 可能在新 UTA 已用同一 `utaId` 注册后继续向 EventLog 写一个没有 generation 的旧 health record。这个回调不是对新 UTA 对象方法的直接调用，但观察面上的 account id 相同，源码没有 active-generation/CAS 检查来区分它。
- 同理，`close()` 清掉 timeout 不能中断已经开始执行的 recovery callback；`_scheduleRecoveryAttempt` 的 async timer body 在 `UnifiedTradingAccount.ts:482-504` 没有 closed/generation guard。当前源码只证明“待触发 timer 可被 clear”，不证明 in-flight continuation 会停止。

所以准确结论不是“旧回调一定污染新实例”，也不是“close 已经完全隔离”：**旧 IBKR transport callback 在 listener 先置 null 后不能直接调到新 UTA；旧 UTA 自己尚未取消/代次隔离的 async continuation 仍可能在 replacement 后产生同 id 的旧 health side effect。** 未对这个交错做运行实验，以上是源码可达性判断。

## 5. 失败处理与可见后果

### 5.1 `reconnectUTA` 分支

- 配置重读发生在 remove 前（`uta-manager.ts:89-93`）；读取失败会走 `:116-121` 的 catch，旧实例仍在。
- 配置中没有同 id 时，旧实例已经被 remove，函数在 `:95-98` 返回 success（表示 removed/disabled），不会创建 replacement。
- `removeUTA` 在 `:129-130` 先删 Map，再吞掉 `uta.close()` rejection；所以 close 失败不向 caller 暴露，也不保留旧 Map handle。
- Pack 缺失/损坏会在 `createBroker` 的 `loadBrokerEngine` 阶段失败：`registry.ts:78-110` 把 resolver/import 错误包装为 `BrokerPackUnavailableError`。此时旧 UTA 已被 remove，新 UTA 尚未 add，manager catch 返回失败。
- 如果 `initUTA` 已经完成并在 `:78` add 了新 UTA，而 `waitForConnect()` 随后因初次连接失败 reject，则 manager catch 只返回失败并清理 `reconnecting` Set（`uta-manager.ts:100-121`），没有再次 `removeUTA`。旧实例已 gone，新实例仍留在 `entries`，其 `_connect()` 会依照 `UnifiedTradingAccount.ts:384-393` 启动 recovery；这不是“replacement 成功”，而是“失败的新实例留在 manager 中继续恢复”。

### 5.2 whole-process shutdown 分支（当前生产 reload 的收口）

UTA 进程的 SIGINT/SIGTERM handler 在 `services/uta/src/main.ts:179-192` 清 catalog timer、停止 snapshot scheduler、关闭 HTTP server、`await utaManager.closeAll()`、关闭 EventLog，最后 `process.exit(0)`。`closeAll` 本身在 `services/uta/src/domain/trading/uta-manager.ts:309-314` 对当前 Map 中所有 UTA 并发调用 `close()`，`Promise.allSettled` 后无条件 clear Map。Alice 侧的 `UTAManagerSDK.closeAll()` 则是 no-op，并在 `src/services/uta-client/UTAManagerSDK.ts:71-79` 明确把 SIGTERM close 责任放回 UTA。

这给出当前 Pack replacement 的进程级事实：旧进程的内存 callback/bridge 与新进程隔离；但旧进程 shutdown 仍没有等待 `_connectPromise`、order-sync worker 或所有 broker observation 完成（本次只追 broker/health 这一支），而 `process.exit` 是最后的进程终止边界。`closeAll` 的并发、吞错、clear 语义已有映射记录，不能从它推出 durable resource-release 或未完成交易分类保证。

## 6. “Connected/alive” 不自动代表可写许可

必须区分三个已有标签：

1. `BrokerConnectionStateEvent.state = 'alive'` 的协议语义在 `packages/uta-protocol/src/types/broker.ts:416-426`：adapter 自己完成 reconnect/readiness handshake 后才可发 alive；`restored` 只是重试提示。
2. `UTAReach = 'connected'` 的定义在 `packages/uta-protocol/src/types/broker.ts:370-381`：仅表示 broker reachable + public market data；`readable` 才表示 private account read 工作。文档明确写着 writing 不是 reach level。
3. 实际写入 gate 在旧 UTA 中并不等同于上面任一标签：dispatcher 只在 `UnifiedTradingAccount.ts:180-199` 调 `_assertCanMutateAccount` 后直调 broker write；`_assertCanMutateAccount` 在 `:557-563` 只阻止 `readOnly`，`push` 在 `:793-801` 只额外拒绝 `_disabled` 和 `health === 'offline'`。

这意味着源代码不能证明 “alive/connected ⇒ writable”，也不能反向证明 connected/degraded 会被所有写路径禁止。源码只显示 funded writable UTA 在 `broker.init()` 成功但 `broker.getAccount()` 失败时，`_attemptReach()` 返回 `'connected'`（`UnifiedTradingAccount.ts:302-310`），`_connect()` 将其视为低于 target 的 recovery 状态（`:378-393`），而 `push()` 的当前 gate 只检查 `_assertCanMutateAccount`、`_disabled` 与 `health === 'offline'`（`UnifiedTradingAccount.ts:557-563,793-801`）。private-read 是否是某项业务写入的必要前提、以及具体 adapter 是否另行拒绝写入，不由这段旧 manager/UTA 代码裁定，本次也未实测。因此这里的结论只是不从 Connected/alive 标签推导写许可，不向核心增加 readable/healthy 前置。

此外，初始连接期间 `BrokerHealthInfo.status` 可能仍是 optimistic healthy，真正区分“尚未 ready”的字段是 `connecting`（`packages/uta-protocol/src/types/broker.ts:392-413`；`UnifiedTradingAccount.ts:148-155,354-366`）。UTA `/__uta/health` 更只是进程 probe：`services/uta/src/main.ts:147-152` 返回 `ok/startedAt/utas`，没有 account reach 或 write capability；`src/services/uta-supervisor/health.ts:3-5,32-42` 只轮询该 HTTP 200。因此 supervisor ready、alive、connected、healthy 均不可单独替代写入授权。

## 7. 明确未调查/不能泛化的边界

- **共享连接/共享 broker：** 正常 manager replacement 每次 `createBroker`，IBKR constructor 每次 new bridge/client（`factory.ts:27-47`；`IbkrBroker.ts:125-131`）。但 `IBroker` 只有单个 nullable listener，`RequestBridge` 没有 subscriber 集合或 ref-count；IBKR `init` 的注释还提到“UTA re-wrapping a shared broker”（`IbkrBroker.ts:183-190`）。本次没有找到一个实际 manager-level shared-client owner 分支，故不能声明共享连接安全；若同一 broker 被两个 UTA 复用，后一次 setter 会覆盖前一次，任一 close 置 null 的风险仅是代码推导，未作运行实验。
- **多账户/FA：** `RequestBridge.managedAccounts()` 只保留 `accounts[0]`（`request-bridge.ts:454-457`）；`IbkrBroker.init()` 选择配置的单个 `accountId` 或该首个账户，并只启动一个 `reqAccountUpdates`（`IbkrBroker.ts:207-216`）。adapter README 明确写当前实现假设一个 TWS connection 一个 account，FA 多账户需 `reqAccountUpdatesMulti`（`services/uta/src/domain/trading/brokers/ibkr/README.md:93-101`）。本报告没有把多账户连接所有权外推到全系统。
- **其他 broker 的物理释放：** 本次 callback/teardown 主路径只完整追了 IBKR。Alpaca、CCXT、Longbridge、LeverUp 的当前 `close()` 分别是 no-op 或依赖 SDK/GC（`AlpacaBroker.ts:205-207`、`CcxtBroker.ts:400-402`、`LongbridgeBroker.ts:230-233`、`LeverupBroker.ts:157-159`）；这些不等于已经证明它们没有资源，只说明不能拿 IBKR 的 socket teardown 顺序泛化给所有 adapter。仓内 callback listener 实现只找到 IBKR adapter，其他 adapter 是否有各自 SDK 内部生命周期不在本次已读范围。
- **Guardian watcher 内部：** 本次读取了 restart-trigger 的调用契约和 UTA SIGTERM handler，没有进一步展开 `scripts/guardian` 的 watcher/child escalation 实现。因此“新进程与旧进程隔离”依赖操作系统进程边界这一事实；Guardian 的每个异常/重试分支不在本报告保证范围。
- **交易中/未知远端结果：** 本次只追 broker connection、account subscription、health callback 和 manager replacement；没有把 broker close、process exit 或 finalizer 解释成业务补偿、远端撤单或 Unknown outcome 结论。

## 8. 给 Main 的最小裁决材料

1. **安装 owner：** Alice installer 下载、校验、immutable release、原子替换 active pointer；UTA registry 只 resolve/import，Pack replacement 依赖 Guardian whole-process restart（`installer.ts:76-145`、`registry.ts:69-110`、`auto-updater.ts:49-77`）。
2. **选定 manager 分支：** `reconnectUTA` 是 remove-before-verify：删 Map → `UTA.close` 先取消 connection-state listener、清 recovery timer、再 `broker.close` → 构造新 broker/UTA 并 add → await 新 `_connect`（`uta-manager.ts:82-131`、`UnifiedTradingAccount.ts:141-155,211-229,1253-1261`）。
3. **IBKR callback owner：** UTA 安装单 listener；IBKR bridge 保存单槽 callback；close 先置 null，随后 disconnect 的 `connectionClosed` 只清 bridge/pending waiter，正常顺序下不直接调新 UTA（`IbkrBroker.ts:165-167,225-229`、`request-bridge.ts:100-111,341-347,477-484`）。
4. **实际缺口（仅描述当前代码边界，不作业务裁定）：** old `_connectPromise`/in-flight recovery 没有 cancel/await/generation fence；旧 continuation 仍可能把同 `accountId` health 追加到 EventLog。`closeAll` 还并发吞错后清 Map。
5. **权限边界：** `alive`/`connected`/supervisor health 不是可写证据；旧 push gate 的实际检查是 disabled/offline/readOnly，源码没有展示由这些标签自动推导写权限的逻辑。private-read 是否为某业务写入的必要前提及 adapter 的额外拒绝，需在各自业务/adapter 边界另行核查（`UnifiedTradingAccount.ts:302-310,557-563,793-801`）。
