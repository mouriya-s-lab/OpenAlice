# CCXT 公开数据与 Mock 模拟器：独立业务消费者推导

## 0. 研究边界

本稿只做设计研究，不修改仓库、不运行 build、lint、test、formatter 或运行时验证。先核对了 `docs/uta-capability-runtime-design/current-research.md:56-127`、`local://uta-current-failure-extract.txt` 的本轮约束和 `docs/README.md:36-38` 的 owner guide；源码证据来自当前本地 checkout。

`current-research.md:115-117` 给出的边界是：核心只论抽象类型、构造、动态语义和公共关系；业务类型、业务构造和业务输入流必须在独立业务实例中论证。本稿把 **CCXT 公开数据** 与 **Mock 模拟器** 当作两个独立实例，仅检验它们是否能各自落到候选的 `Definition/D`、结果后继和跨进程求值关系。主书 §4.1、§7 的 Definition、可运输 D 和公开目录只是待反证候选，不能替代下面的实际 source/consumer 证据。

旧 event stream 整体不作为输入。本稿不引入全局事件族、统一模拟器消息或订单生命周期；Mock 的 `externalTrade` 等只按现有业务实例的直接状态控制解释。模拟器不需要准确复刻所有真实 venue 语义，必须保留的是它作为可测试控制面的实际含义，并且不能把未知 mark 伪称为真实成本。

## 1. 先按实际调用链定位两个断点

### 1.1 UTA 与 Alice 是两个 owner

`docs/project-structure.md:28-44` 将 Guardian、Alice、UTA 分开：Alice 拥有 Web UI、ToolCenter 和文件状态；UTA 拥有 broker 连接、账户状态、staged/committed trading operation、snapshot/FX/execution。这个划分直接决定“同进程函数存在”不等于“Alice 消费者可调用”。

UTA 启动时创建自己的 `ToolCenter`，初始化账户后调用 `utaManager.registerCcxtToolsIfNeeded()`（`services/uta/src/main.ts:58-88`）。注册实现只在 UTA 进程的 `UTAManager` 中将 CCXT provider tools 放入这个本地 center（`services/uta/src/domain/trading/uta-manager.ts:133-140`）。它没有 HTTP tool route，也没有把这些定义加入 Alice 的 ToolCenter。

Alice 启动时注册的是 `createTradingTools(utaManager, ...)`（`src/main.ts:240-251`）。Alice 的 `UTAManagerSDK.registerCcxtToolsIfNeeded()` 是 no-op（`src/services/uta-client/UTAManagerSDK.ts:52-61`），而 `UTAAccountSDK` 目前只代理已经存在的 account、quote、bars、contract 等 route（`src/services/uta-client/UTAAccountSDK.ts:126-224`）。它没有 `getFundingRate` 或 `getOrderBook`；SDK 的 `contractFromAliceId` 还明确抛 `NotImplementedInSDK`，因为没有对应 route（`:359-364`）。因此当前 CCXT tool 的关系不是“漏列一个名称”，而是没有从 Alice ToolCenter 到 UTA provider method 的实际求值路径。

### 1.2 Mock 有 UI 路径，但没有 Alice agent 路径

UTA 将 `/api/simulator` 挂在 UTA 进程，是因为 route 必须直接取得 UTA 内的 MockBroker（`services/uta/src/main.ts:154-168`）。Alice WebPlugin 将 `/api/simulator` 直接代理到同一个 UTA carrier（`src/webui/plugin.ts:245-256`）。UI API 有完整的 `listUtas/state/setMarkPrice/tickPrice/fillOrder/cancelOrder/externalDeposit/externalWithdraw/externalTrade` 调用（`ui/src/api/simulator.ts:70-95`），`useSimulatorState` 轮询 state，并让每个按钮执行后刷新 state（`ui/src/pages/simulator/useSimulatorState.ts:67-128`）。这证明 UI→BFF→UTA→Mock 的关系实际存在。

但 Alice 的 `UTAAccountSDK` 没有任何模拟器控制方法，Alice 的 `src/tool/trading.ts:613-628` 只有另一个含义不同的 `simulatePriceChange` AI tool。故当前 god-view 控制只能由 UI/直接 route 消费，不是 Alice agent 的公开能力。这里不能仅以“已有 simulator route”推断 AI 已获得该能力。

## 2. CCXT 公开数据实例：从 provider method 到跨进程消费者

### 2.1 现状的实际构造与断裂

CCXT tool factory 当前构造两片 provider-specific tool：

- `getFundingRate` 输入是 `aliceId` 和可选 `source`，先调用 `manager.resolve(source)`，然后要求同一个 UTA 同时具有 `getFundingRate` **和** `getOrderBook`；解析 `aliceId` 后调用 `broker.getFundingRate(contract)`，最后返回 `{source: id, ...result}`（`services/uta/src/domain/trading/brokers/ccxt/ccxt-tools.ts:20-65`）。
- `getOrderBook` 输入也是 `aliceId`、可选 `source`，另有 `limit` 的 1–100 校验和默认 20；调用 `broker.getOrderBook(contract, limit ?? 20)`（`:68-95`）。

CCXT 的旧业务值类型是 `FundingRate`（必有 `fundingRate:number`、`timestamp:Date`，`nextFundingTime` 和 `previousFundingRate` 可缺省）以及由 `[price, amount]` 组成的 `OrderBook`（`services/uta/src/domain/trading/brokers/ccxt/ccxt-types.ts:55-75`）。它们含有 IBKR `Contract`，这可以留在 UTA 内部兼容旧 adapter，但不能把 `Contract` 对象当作跨进程公共值。

实现直接调用 CCXT：`getFundingRate` 以统一 symbol 调 `fetchFundingRate`，把缺失 `fundingRate` 替成 `0`、缺失 provider timestamp 替成 `Date.now()`（`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:1330-1351`）；`getOrderBook` 调 `fetchOrderBook`，将每个缺失的 price/amount 替成 `0`，缺失 timestamp 也替成本地 `Date.now()`（`:1354-1375`）。`IBroker` 公共协议只包含 quote、bars、account/order reads 等，并未包含这两个 provider-specific method（`packages/uta-protocol/src/types/broker.ts:553-610`）。

`services/uta/src/domain/trading/brokers/ccxt/ccxt-tools.spec.ts:71-150` 的测试是在 UTA 进程内直接构造 UTA 和 broker spy，检查 `aliceId` 映射、`source`、bid 数量和 funding rate；它没有证明 Alice route、wire decoder、目录发现或跨进程调用存在。`routes-trading.ts` 也没有 funding/orderbook route（对该文件搜索无匹配）；现有 SDK 也没有相应 method。因此这两个 tool 在当前版本最多是 UTA-local/in-process consumer。

### 2.2 独立业务定义：公共数据，不把 CCXT 类型塞进核心

如果保留候选的 Definition/D 关系，CCXT 业务实例应自行提供完整的定义和 adapter，而不是让核心认识 `FundingRate`、`OrderBook`、perpetual 或 CCXT。可以先由业务作者给出下面这些精确业务值：

```text
PublicSource = AutoIfExactlyOne | Explicit(providerId)

PublicInstrument = {
  providerId,
  nativeSymbol,
  marketKind: Spot | Perpetual | Future | Other
}

FundingRequest = {
  source: PublicSource,
  instrument: PublicInstrument
}

FundingObservation = {
  instrument,
  rate: ProviderDecimal,
  previous: Absent | Present(ProviderDecimal),
  nextFundingAt: Absent | Present(Instant),
  sourceTime: ProviderTime | MissingProviderTime,
  observedAt: Instant,
  temporalQuality: ProviderTimed | ObservedOnly
}

OrderBookRequest = {
  source: PublicSource,
  instrument: PublicInstrument,
  depth: Depth(1..100)
}

OrderBookObservation = {
  instrument,
  bids: [OrderBookLevel],
  asks: [OrderBookLevel],
  sourceTime: ProviderTime | MissingProviderTime,
  observedAt: Instant,
  temporalQuality: ProviderTimed | ObservedOnly
}
```

这里的 ADT 是 **CCXT public-data instance 的业务类型**，不是核心新增字段。`ProviderDecimal` 的精度/尺度应由该安装 profile 和 provider contract 给出，不能在核心里把所有市场的精度猜成同一个数。`PublicInstrument` 的 `providerId + nativeSymbol + marketKind` 也不是把裸 symbol 提升成全局身份；它明确保留交易所和市场族，避免同名 spot/perp 被误合并。

对应的业务定义可以写成：

```text
fundingDefinition : Definition<FundingRequest,
                               FundingObservation,
                               FundingFailure,
                               CcxtPublicRuntime>
orderBookDefinition : Definition<OrderBookRequest,
                                  OrderBookObservation,
                                  OrderBookFailure,
                                  CcxtPublicRuntime>
```

若最终保留 F，则它们只是两个独立的 `F<A,E,R>` 实例；若 F/Definition 候选被后续反证淘汰，下面的实际 source→consumer 关系仍成立。核心不能从“有 `fetchFundingRate` 方法”反射出公共定义；只有业务安装者提供描述、边界解析、adapter、结果编码和消费权限后，才有可公开叶子。

### 2.3 动态求值路径

一次 CCXT 公开数据调用必须由同一个业务定义关联输入、结果、失败和动态 provider binding。实际路径应是：

```mermaid
sequenceDiagram
    participant AliceTool as Alice ToolCenter
    participant AliceSDK as Alice typed client
    participant UTA as UTA public-data boundary
    participant Resolver as CCXT market resolver
    participant CCXT as CCXT exchange adapter
    AliceTool->>AliceTool: 解析完整 FundingRequest 或 OrderBookRequest
    AliceTool->>AliceSDK: 调用定义关联的 typed leaf
    AliceSDK->>UTA: 编码输入、调用关联、服务认证
    UTA->>Resolver: 按 source 选择唯一 provider 并解析 nativeSymbol
    Resolver-->>UTA: PublicInstrument 或结构化解析失败
    UTA->>CCXT: 用已解析市场调用 fetchFundingRate/fetchOrderBook
    CCXT-->>UTA: provider payload 或 provider failure
    UTA->>UTA: 按同一业务定义校验数值、身份、时间和覆盖
    UTA-->>AliceSDK: 成功 observation 或精确 failure
    AliceSDK->>AliceTool: 同一定义解码并投影为工具结果
```

需要特别区分两种 identity：旧 `aliceId`（`accountId|nativeKey`）可以在 Alice 边界作为兼容输入提示，但其解析必须在 UTA 内完成；不能调用 Alice SDK 当前必抛的 `contractFromAliceId`。目标公共结果应携带 provider/native instrument identity，`source` 是路由与 provenance，不应被误当成私有账户授权。对于完全公共 endpoint，业务不应为了复用账户 API 而强迫调用者先取得私有 account state。

动态步骤的前提不是“定义名字存在”，而是：

1. `source` 为 `Explicit` 时必须命中该 provider；`AutoIfExactlyOne` 只有在恰有一个符合该 operation 的 provider 时成立。当前 `resolveCcxtOne` 要求 funding 与 orderbook 两个方法同时存在，这会让“只有 funding 的 provider”连 funding 也不可见；目标应按叶子独立判断 capability。
2. provider catalog 必须把 native symbol 解析为该 provider 的市场。`CcxtBroker.resolveNativeKey` 对未知 key 会返回骨架 Contract，并把真正失败留给下游（`CcxtBroker.ts:1311-1325`）；公共定义不能把这个骨架当作已解析的可用 instrument。
3. funding 只能在业务声明允许的市场族（通常是 perpetual）上调用。spot `BTC/USDT` 和 perpetual `BTC/USDT:USDT` 即使 symbol 前缀相同，也必须是两个不同的 instrument 选择；错误市场族是 `WrongInstrumentKind`，不能静默 fetch。
4. UTA 的 keyless/data tier 当前配置说明只承诺 quote/bars/search（`src/core/config.ts:466-473`），CCXT init 注释也只列 public `loadMarkets/fetchOHLCV/fetchTicker`（`CcxtBroker.ts:311-315`）。因此 keyless 是否能看到 funding/orderbook 不能由“公开 endpoint”这个名字推定，必须在业务 capability declaration 中明确加入；没有叶子就不生成占位命令。

### 2.4 旧行为的保留与必要修正

下面保留的是已有消费者真正使用的含义，不是为修复而抄一份旧对象：

| 现状 | 具体消费者可观察到的行为 | 目标保留/修正 |
|---|---|---|
| `aliceId` 选择 contract | tool 输入来自 `searchContracts`，旧函数在 UTA 内解析 account 与 native key | 兼容边界可接受旧提示；公共定义内部改用已解析 `PublicInstrument`，不跨进程传 `Contract`，解析失败显式返回 |
| `source` 自动选择 | 单一 CCXT source 可自动使用；多个 source 返回 `Multiple CCXT accounts` | 保留唯一时自动选择和多项时拒绝；但按 funding/orderbook 分开判定 capability，不用另一叶子绑架本叶子 |
| depth | orderbook tool 允许 1–100，缺省 20，并把 limit 传给 CCXT | 这段默认和范围进入 `Depth` 构造；超出范围在 fetch 前拒绝，不截断成另一请求 |
| previous/next funding | provider 可能没有这两个字段 | 用 `Absent/Present` 保留；不能补造上一次或下一次时间 |
| funding rate 缺失 | 当前 `null` 被转成数值 `0` | 不能把缺失变成中性 funding。rate 缺失应是 `MalformedProviderPayload`/`UnavailableRate`；否则“rate 小于阈值”的调用者会把未知当成零 |
| provider timestamp 缺失 | 当前 `Date.now()` 使响应看起来像刚由 provider 产生 | 保留本地 `observedAt` 作为收到时间，但 `sourceTime=MissingProviderTime`、`temporalQuality=ObservedOnly`；不得把本地时间称为 provider 时间或 freshness 证明 |
| orderbook level 缺失 | `[100, null]` 被映射成 `[100, 0]` | 不产生可执行外观的零数量 level。默认整本结果因 payload malformed 而失败；若将来 provider 确实允许 partial book，必须由独立业务契约明确 `Partial` 及覆盖，而不是静默丢行 |
| “sorted by price” 的描述 | tool 描述声称 bids/asks sorted，但 `CcxtBroker.getOrderBook` 只 map，不排序、不验证（`:1361-1370`） | 不能继续把文档当实现证据。目标要么在 adapter 中实际排序并声明成本，要么验证 provider 顺序并把不满足者拒绝；否则只能诚实声明 provider order |
| provider failure | tool 只 catch `contractFromAliceId`，broker promise rejection 直接上抛 | 在 UTA/public leaf 边界把解析、provider、transport、malformed、stale/unknown-time 分成结构化失败；Alice client 不以任意 `request<T>` cast 成成功值 |

时间例子说明为什么 `observedAt` 与 `sourceTime` 必须分开：若 provider 没有 timestamp，旧代码在本地 12:01 收到上一条 09:00 的 book 时写成 12:01；目标只能说“12:01 观察到一个没有 provider 时间的结果”，不能据此通过要求“最近一分钟内更新”的策略。这个选择由 CCXT 业务定义承担，核心只保留同一值声明/编码/调用关联。

## 3. Mock 模拟器实例：控制面、状态读写与假设性读取分开

### 3.1 状态 owner 与两个不同的“simulation”含义

`MockBroker` 的状态直接由 `_positions`、`_orders`、`_markPrices`、`_contractRegistry`、`_cash` 等 instance-owned map 持有（`services/uta/src/domain/trading/brokers/mock/MockBroker.ts:164-215`）。其控制方法明确写在 `IBroker` 之外，route 通过 `instanceof MockBroker` 缩窄；普通 `IBroker` holder 不会看见 god-view 方法（`:546-552`）。这是一条已经存在的业务隔离，不应把模拟器 controls 加入公共 `IBroker`，也不应把它改写成全局事件流。

当前有两类不同计算：

- **假设性 PnL 读取**：`UnifiedTradingAccount.simulatePriceChange` 交给 `TradingGit.simulatePriceChange`（`UnifiedTradingAccount.ts:983-985`）。它读 `config.getGitState()`，计算 `currentState/simulatedState/summary`，不调用 place/fill/deposit 等 Mock control，也不写 mark map 或 Git commit（`services/uta/src/domain/trading/git/TradingGit.ts:753-897`）。它是 `HypotheticalRead`，不是交易写入。
- **Mock 控制写入**：`setMarkPrice`、`tickPrice`、`fillOrder`、`cancelPendingOrder`、`externalDeposit`、`externalWithdraw`、`externalTrade` 直接改变 MockBroker 的内存状态（`MockBroker.ts:554-755`）。它们是 dev/test scenario control；成功不能被解释为真实 venue ACK、Alice order commit 或远端账户写入。

因此“simulation”一词不能决定权限或核心构造；必须看该具体函数是否读假设状态，还是写 Mock owner 的 state。

### 3.2 state read：快照是 projection，不是完整账本

`GET /api/simulator/uta/:id/state` 调 `getSimulatorState()`（`services/uta/src/http/routes-simulator.ts:116-121`）。它返回 `cash`、各 native key 的 `markPrices`、带 `avgCostSource` 和 derivative metadata 的 positions，以及仍为 `Submitted` 的 pending orders（`MockBroker.ts:757-796`）。测试以 cash `50000`、mark `BTC=80000` 证明该 snapshot 的实际 JSON（`services/uta/src/http/simulator.spec.ts:58-73`）。

这个 read 只观察该 UTA 进程内的 Mock instance：不返回 realized PnL、已取消/已完成订单、逐笔 fill history、contract registry 或 call log。它不是持久 authority；`ephemeral` Mock 配置会在启动时清掉相关数据（`src/core/config.ts:458-465`），而 UI 的 event log 只是最多 50 条的浏览器内动作记录（`useSimulatorState.ts:20-29,109-128`）。目标公开定义应把它称作 simulator projection，并声明重启/进程替换后的存续边界，不能把一次快照称成完整交易日志。

### 3.3 mark 与 tick：mark 写入同时可能推进 pending order

`setMarkPrice(nativeKey, price)` 将 Decimal 写入 `_markPrices`，然后运行 `_matchPendingOrders`，返回被填充的 order ids（`MockBroker.ts:554-563`）。匹配规则是业务实例自有的：LMT BUY 在 `price <= limit`，LMT SELL 在 `price >= limit`，STP BUY/SELL 分别越过 aux，触发时按 mark price fill（`:799-839`）。

这不是单纯“修改一个展示字段”：例如测试先放一个 BUY LMT `79000`，将 BTC mark 设成 `80000` 时仍有一个 pending order；再次设成 `79000`，响应 `filled` 含该 order id，pending 变空并出现 position（`services/uta/src/http/simulator.spec.ts:88-120`）。因此目标 control result 至少必须让“mark changed”和“哪些 pending 被推进”可观察，不能把它伪装成普通 `IBroker.getQuote`。

`tickPrice` 需要已有 mark，按 `current * (100 + deltaPercent) / 100` 计算新 mark，再委托 `setMarkPrice`，所以也可能自动填单（`MockBroker.ts:565-573`）。UI 目前只消费 ±1%、±5% 的 tick 和 exact set（`ui/src/pages/simulator/ActionPanel.tsx:75-121`、`MarkPrices.tsx:76-101`）。目标可以保留这种快速推进的控制含义，但输入边界应由 simulator 业务定义承诺 finite/合法价格；若没有旧 mark，应交付 `MissingMark`，不能用假 mark 继续算。

### 3.4 fill 与 cancel：直接修改控制 state，不经过交易写入协议

`fillOrder` 只接受当前 `Submitted` order；数量默认剩余总量，显式数量必须大于零且不超过剩余量；价格优先取显式值、当前 mark、limit，最后才是代码中的 synthetic `100` fallback（`MockBroker.ts:580-621`）。partial fill 减少 pending quantity 并累计 quantity-weighted average；完整 fill 进入 `Filled`，现金按 `BUY => -qty*price*multiplier`、`SELL => +...` 变化。UI 的 fill 表单正是发送可选 price/qty（`ui/src/pages/simulator/PendingOrders.tsx:72-107`）。

目标保留“可手动给 pending order 一个 fill（可 partial）”的测试用途，但必须将价格来源标清：`SyntheticFallback(100)` 不是 observed mark、provider quote 或真实成本。如果目标不想保留该 fallback，应把价格改成必填/显式 simulator policy，而不是继续把 100 填入 `avgCost` 后宣称真实。无论采用哪一个业务选择，fill 都只代表 Mock owner 的 state transition，不代表 `TradingGit.push`、broker cancel/ACK 或 venue settlement。

`cancelPendingOrder` 直接把内部 order 置为 `Cancelled`（`:623-628`），跳过 `IBroker.cancelOrder` 和交易日志幂等语义。目标应把它命名/描述为 simulator force-control；正常 venue cancel 仍走独立的 `VenueWrite` 定义。这样既保留 UI 用取消 pending scenario 的能力，也不把两个不同 owner 的关系压成同一公共动作。

### 3.5 deposit、withdraw、external trade：三种外部状态控制

这三项不是普通 Alice order：

- `externalDeposit` 要求正数量；已有 position 增加数量并标成 `avgCostSource='wallet'`；新 position 使用当前 mark，若没有 mark 则使用 Decimal `0`，现金不变（`MockBroker.ts:666-698`）。测试在先设 `BTC=80000` 后 deposit `1.0093`，看到 quantity `1.0093`、`avgCost=80000`、`avgCostSource=wallet`（`services/uta/src/http/simulator.spec.ts:130-149`）。因此当未知 mark 时，目标绝不能把 `avgCost=0` 解释成真实零成本；应在业务结果中表达 `CostBasis = Unknown` 或 `UnpricedExternalBalance`，只有确实观察到 mark 才可表达 `ObservedMark(80000)`。
- `externalWithdraw` 从已有 native key 减数量，数量不超过持有量时保留 position，减到非正则删除，现金不变（`MockBroker.ts:700-711`）。它是模拟 transfer-out/burn，不能等同 normal close order；是否允许 overshoot、输入正性等属于该 simulator control 的边界契约，不能由公共核心自动补语义。
- `externalTrade` 先检查数量为正；无现仓时 BUY 开 long、SELL 开 short，均以给定 price 建 position 并标成 wallet source；有现仓时调用 `_applyFill`，现金按 side 和 multiplier 变化（`MockBroker.ts:713-755`）。测试以 cash `100000`、BUY `0.5 BTC @60000` 得到 avgCost `60000`、wallet source、现金 `70000`（`simulator.spec.ts:152-173`）。它允许无现仓 SELL 开空，正是“用户在 exchange app 手动交易”的控制含义；这与 Alice 普通 `_applyFill` 对无仓 SELL 的拒绝不同（`MockBroker.ts:917-965`），目标应保留这项业务差异，而不是强行统一。

直接 route 只调用 Mock method 并返回 `{ok:true}`；它不会在同一响应内执行 UTA wallet reconcile。之后若通过 `UnifiedTradingAccount.getPositions()` 读取 wallet-source position，UTA 才会在 `getPositions` 后执行 `_reconcileWalletPositions`，必要时记录 reconcile commit 并重算 cost basis（`UnifiedTradingAccount.ts:1026-1030,1040-1105`）。所以“control 成功”“broker state changed”“Alice ledger 已有 reconcile 记录”是三个不同观察点，不能在 route 的 `{ok:true}` 中合并声称。

### 3.6 `simulatePriceChange`：实际无 venue write 的假设性结果

`TradingGit.simulatePriceChange` 先从 `getGitState()` 取得 equity、cash、unrealized PnL 和 positions（`:753-762`），随后按每个 position 算新价格、multiplier-aware PnL 和 summary（`:818-895`）。实际可推演的 fixture 在 `services/uta/src/domain/trading/git/TradingGit.spec.ts:1029-1087`：long AAPL quantity `10`、avgCost `150`、current mark `160`，`-10%` 得 `simulatedPrice=144`、`unrealizedPnL=-60`；改用 `@200` 得 `unrealizedPnL=500`。这些只是返回值变化，函数不改 Mock `_markPrices`、position、cash 或 pending order。

它还明确区分 symbol-level change 与 `all`：对普通 AAPL 位置，`AAPL -5%` 会移动股票行；同 symbol 的 OPT 行不把股票价格硬套到 option，而是保留自身价格并在 `worstCase` 说明排除；`all +10%` 则按每个 position 的自身 mark，包含 derivative，并按 multiplier 计算（`TradingGit.ts:778-815,839-879`；测试 `TradingGit.spec.ts:969-1019`）。这说明该业务函数已有具体的输入/状态/结果关系，但不应把 `symbol`、`avgCost` 或 derivative policy 提升成核心类型。

它的输入解析当前接受 `@positive` 绝对值或以 `%` 结尾的相对值（`TradingGit.ts:899-925`），失败返回 `success:false` 与原始结果形状。这个业务函数应保持“假设读取”的性质；输入边界、symbol identity 和 derivative policy 由该 simulator/portfolio 实例声明。

## 4. 只读、公开读取、假设读取和控制写入必须分开

当前权限路径把几个不同关系压成了一个 `readonly` 判断，因而直接制造了一个真实消费者矛盾：

- UTA 的 per-account `keyless`/`readOnly` tiers 是 data/account/trading（`UnifiedTradingAccount.ts:233-243`）。keyless 只可 public data，funded readOnly 可 stage/commit 本地 proposal，但 `_assertCanMutateAccount` 会阻止 broker-side dispatch/push（`:549-563,793-797`）。
- 全局 `readonly` 的文案是“连接 UTA 做 account analysis，但阻止 venue-mutating broker writes”（`src/services/trading-mode.ts:53-73`），而 `allowAiTrading` 只控制 AI 是否可 push（`src/core/config.ts:242-249`）。
- 但 Alice `UTAAccountSDK.simulatePriceChange` 先调用 `assertVenueWritable()`，再 POST route（`src/services/uta-client/UTAAccountSDK.ts:343-348,385-388`）；BFF 的 `isVenueMutation` 也把 `/simulate-price`、`/api/simulator/*` 全部判作 mutation（`src/webui/routes/trading-proxy.ts:124-129,193-206`）。所以一个被 AI 描述成 “dry run, READ-ONLY” 的工具（`src/tool/trading.ts:613-628`）在全局 readonly 下会在 Alice 本地被拒绝，根本到不了 UTA。现有 proxy spec 只证明 wallet push 被 block、stage 被允许（`src/webui/routes/trading-proxy.spec.ts:40-65`），没有证明 hypothetical route 在 readonly 可用。

这不是要往核心增加一个固定业务权限 enum，而是每个独立定义必须给出自己的访问关系。当前两实例至少需要如下区别：

| 具体关系 | CCXT public data | `simulatePriceChange` | Mock state/control | 普通 UTA trading |
|---|---|---|---|---|
| 主要效果 | 读取 provider public observation | 读取当前 account/Git state，返回假设结果 | 读或直接修改 Mock instance state | 修改真实/接入 broker account |
| 适合的访问面 | `PublicRead` | `HypotheticalRead` | `SimulatorRead` / `SimulatorControl` | `AccountRead` / `ProposalWrite` / `VenueWrite` |
| 全局 readonly 是否应因“venue write”而拒绝 | 否，前提是 leaf/capability 可用 | 否；当前 SDK/proxy 的拒绝是错误分类 | 不能自动等同 venue write；应要求显式 simulator-control 授权 | 是，push/dispatch 仍拒绝 |
| keyless | 只有声明了该 public leaf 才可用 | 没有 private positions 时不能假定可用 | 不适用 CCXT/keyless | 不能 stage proposal |
| 成功含义 | provider observation 已解码 | 本次假设结果已计算 | Mock control 已改变/读取 instance state | 需另有真实 broker/ledger 语义 |

因此目标的动态访问判断应按“定义已安装、当前 capability/health 可履行、本次主体有该定义权限”三件事分别作出：

1. `funding-rate`、`order-book` 是 CCXT 业务的 public leaves；它们是否公开由 UTA 返回的真实 descriptor/capability 决定，而不是由核心或 `IBroker` 方法名猜测。
2. `simulate-price` 应从 global `isVenueMutation` 与 SDK `assertVenueWritable` 中分离；仍需 account-read 或 portfolio-state 的真实可用性，失败时交 `AccountReadUnavailable`/`HypotheticalUnavailable`，不伪造零状态。
3. Mock `state` 是独立 simulator read；`mark/tick/fill/cancel/deposit/withdraw/trade` 是 simulator control write。它们可以继续只允许 dev/test UI，也可以授权某个明确的 simulator actor，但不能借用 `VenueWrite` 或把“pro mode”当作充分授权。现有 BFF 只有 loopback host trust、没有 Alice↔UTA interprocess auth（`src/webui/routes/trading-proxy.ts:1-13`）；这是目标安全边界待履行的前提，不是当前已完成的权限证明。
4. `stage/commit` 是本地 proposal relation；`push` 和 broker dispatch 才是 `VenueWrite`。Mock `externalTrade` 即使改变 cash/position，也不能进入真实 venue write gate；它模拟的是外部来源，正是控制面与普通交易 pipeline 不同的地方。

错误也不应靠现有字符串判断。每个业务叶子至少要区分 `InvalidInput`、`NotInstalled/CapabilityUnavailable`、`InstrumentNotFound/WrongKind`、`ProviderUnavailable`、`MalformedProviderPayload`、`Forbidden(scope, operation)` 和 `UnknownSourceTime` 等结构化结果。特别是：

- readonly 下拒绝 `push` 应是 scope=venue 的结构化拒绝；
- 未授权的 Mock control 应是 scope=simulator 的结构化拒绝；
- `simulatePriceChange` 不应返回 readonly/venue-write denial；
- funding rate 缺失、unknown mark 或 synthetic fill price 不应被编码成正常 numeric zero。

## 5. 哪些关系可以回到核心，哪些必须留在实例

可以反复使用、但还需接受主书候选反证的公共关系只有这些：

- 一个最终公开定义同时关联输入解析、成功/失败解码、编码、描述和实际解释入口；目录只消费真正安装且可见的叶子，不维护另一份“有名称但没有调用”的表。
- 远端调用按同一定义编码输入、保存本次 call correlation、解析本次结果；不跨进程传 SDK object、`Contract` instance 或任意 `request<T>` cast。
- 有限结果交给有限消费者；假设性读取和 simulator control 各有自己的 owner、输入、结果及权限。它们都可能经过 HTTP，但 IO 相同不产生共同订单协议。

必须留在独立业务实例的内容包括：

- CCXT 的 perpetual/spot 判别、native symbol、funding schedule、book level、provider timestamp/precision，以及“缺失数据是否可部分交付”；
- Mock 的 mark matching、partial fill、wallet-source cost basis、无现仓 SELL 开空、synthetic fallback 和 in-memory snapshot；
- global readonly 与某个业务 leaf 的访问策略。

实际反例证明不能仅按名字补机制：Alice ToolCenter 看不到 UTA-local CCXT tools；`UTAAccountSDK.contractFromAliceId` 没有 route；simulator UI 能修改 Mock 但 Alice agent 没有 SDK/tool；一个被描述为 dry-run 的 route 又被 BFF 当作 venue mutation。若这些连接没有对应的 descriptor、typed route、decoder、consumer 和权限边界，宣称“已暴露”“已只读”“已可恢复”都不成立。

仍需业务作者/安装 profile 明确而不能由本稿臆造的事实有：每个 CCXT venue 是否提供可信 source timestamp、book level 的完整性/排序承诺及 decimal precision；公共 instrument resolver 如何将 search result 转成 provider identity；Mock control 是 UI-only 还是授予受限 AI actor；以及非 Mock broker 的 hypothetical capability 是否真的安装（`routes-trading.ts:241-258` 的注释称 every broker，但 catch 分支又按 non-mock simulate failure 处理，需以实际安装者核对）。这些是业务契约待履行，不是向核心添加字段或全局消息的理由。

本稿的结论是：两个断点都能由独立业务定义得到具体的 source→consumer→result 关系，但它们要求不同的 identity、状态 owner、访问权限和失败语义。核心若要保留候选 Definition/D，只应承接这条值/描述/调用关联；不能把 CCXT 数据类型或 Mock 控制状态并入核心，也不能用一个 event stream 抹平二者差异。

## 6. 证据索引

- Owner 与进程边界：`docs/project-structure.md:28-44`；`docs/README.md:36-38`。
- 研究边界：`docs/uta-capability-runtime-design/current-research.md:56-127`。
- 候选公共关系（仅待反证）：`docs/uta-capability-runtime-design.md:609-657,1140-1200`。
- CCXT tool/adapter/type：`services/uta/src/domain/trading/brokers/ccxt/ccxt-tools.ts:20-95`；`CcxtBroker.ts:1311-1375`；`ccxt-types.ts:55-75`。
- CCXT process exposure：`services/uta/src/main.ts:58-88`；`uta-manager.ts:133-140`；`src/main.ts:240-251`；`UTAManagerSDK.ts:52-61`；`UTAAccountSDK.ts:126-224,343-388`。
- Mock state/control：`MockBroker.ts:164-215,546-839`；`routes-simulator.ts:1-15,103-223`；`simulator.spec.ts:58-208`。
- Mock UI consumer：`ui/src/api/simulator.ts:70-95`；`useSimulatorState.ts:67-128`；`ActionPanel.tsx:75-275`；`src/webui/plugin.ts:245-256`。
- Hypothetical read：`TradingGit.ts:753-925`；`UnifiedTradingAccount.ts:983-1030`；`src/tool/trading.ts:613-628`。
- Permission/proxy：`src/services/trading-mode.ts:53-73`；`src/core/config.ts:242-249,458-476`；`src/webui/routes/trading-proxy.ts:1-13,124-206`。
