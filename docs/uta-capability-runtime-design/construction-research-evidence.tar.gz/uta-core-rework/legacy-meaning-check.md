# UTA 旧能力实质承接核验

状态：只读设计核验稿，不是整体通过或实现完成报告。本文只把当前源码的实际控制流、当前 UTA 主书和刚替换的承接册放在一起检查；不采用旧 solutions 的 `targetModel`、`closure` 或处置标签作为结论依据，也不复活旧 eventstream、EF、slots。

## 1. 证据边界

已先读取 `docs/uta-capability-runtime-design/current-research.md:56-127`、`local://uta-current-failure-extract.txt:236-334` 和 `local://uta-original-user-inputs.txt`。原始目标明确要求：第三方来源可以完全不同，UTA 以自己的抽象适配不同 SDK/进程；能力应尽量暴露给 AI；Order 之外还必须能承接 News、Candle、Instrument 等数据能力（`local://uta-original-user-inputs.txt:63-90`），而“其他部分更多是数据、不需要事务”的边界见 `:93-96`。

因此本稿只问两件事：

1. 旧的实际消费者是否仍能在当前设计中找到同一项有意义的输入、解释和结果消费关系；
2. 若当前设计主动改正旧的错误默认，是否明确给出了新的结果消费者，而不是把能力静默删掉。

没有运行 build、lint、test、formatter、服务、Broker 或外部调用；下面的反例是由源码分支和公开调用链构造的，不是运行结果。

## 2. 已确认的缺口或错误

### 2.1 IBKR hub→leaf 合约扩展没有进入当前公共设计消费链

**源码事实与消费者。** `UnifiedTradingAccount.expandContract` 不是普通详情读取：它在 `services/uta/src/domain/trading/UnifiedTradingAccount.ts:1157-1177` 检查可选的 broker 扩展、验证 UTA 所有权、把 hub native key 和 `ExpandContractFilters` 交给 broker，并给返回 Contract 重新盖 Alice 身份。协议边界也已实际写出 filters 及两种结果：`packages/uta-protocol/src/types/broker.ts:505-522` 声明可选 expansion/refresh 能力，`packages/uta-protocol/src/types/broker.ts:181-223` 声明 expiry/right/strike/secType/limit 以及 `contracts` / `optionGrid` / `total` / `hint`。

IBKR 的实现不是一个名字别名：`services/uta/src/domain/trading/brokers/ibkr/IbkrBroker.ts:384-475` 处理三类真实路径：`issuer:eXXX` 返回债券 leaves；numeric conId 无 expiry 返回期权参数 grid；带 expiry 或 `secType=FUT` 返回具体期权/期货月份，并在结果中保留过滤、总数和提示。它已有实际 AI、HTTP、SDK 消费者：`src/tool/trading.ts:503-554` 暴露 hub/underlying、expiry/right/strike/secType/limit 并把每个 leaf 的 Alice ID交回后续 `getQuote`/`placeOrder`；`services/uta/src/http/routes-trading.ts:330-341` 提供 `/contract/expand`；`src/services/uta-client/UTAAccountSDK.ts:169-175` 转发同一调用。

**当前设计的断点。** 主书 Instrument 目前只构造“选择候选→取得 `InstrumentRef`→读取该商品数据” (`docs/uta-capability-runtime-design.md:1083-1101`)；承接册对 IBKR 只写保留 contract details、option 参数、quote/history (`docs/uta-capability-runtime-design/legacy-accommodation.md:117-125`)。这没有说明目录型 issuer、期权 grid、具体 leaves、过滤和 `total/hint` 怎样进入当前公开定义，也没有把返回 leaf 的身份交给交易后继。

**可构造反例。** 用户从 IBKR 搜到 issuer 或 numeric underlying 后调用已有 `expandContract` 工具。真实调用需要先执行 expansion 才能得到可交易债券/具体期权/期货月份；只有当前 Instrument 的“选定商品后读取数据”关系时，最多能保留一个 hub/underlying，无法生成这批 leaf，也不能表达 grid→再次指定 expiry 的第二次读取。说“保留 contract details/option params”不能替代这一实际 consumer。

**需要闭合的关系。** 将 expansion 作为 provider 的数据能力（不是交易事务）写入最终定义：明确 hub/directory 与 leaf 的区别、grid 与 concrete-contract 两个结果分支、filters/total/hint、空结果与不支持/失败的区别；每个返回 leaf 必须保留同一来源和 native identity，后继 quote/order 消费该 identity。当前实现已有路由和函数，缺的是它在新设计中的公共消费关系。

### 2.2 catalog refresh、初始加载和失败保留没有进入搜索设计

**源码事实与消费者。** UTA 进程确实拥有 catalog 刷新责任：`services/uta/src/main.ts:130-141` 每 6 小时遍历 UTA 并调用可选 `refreshCatalog`；`services/uta/src/domain/trading/UnifiedTradingAccount.ts:1186-1195` 对可枚举 provider 调用刷新，对 server-side search provider no-op。Alpaca 的初始化在账户 probe 成功后异步启动首次 refresh (`services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:157-203`)；`refreshCatalog` 只替换 active、tradable assets，失败保留旧 cache (`:217-233`)；cache 尚未有值时 `searchContracts` 返回一个 echo candidate (`:235-256`)。CCXT 的刷新则是显式 `exchange.loadMarkets(true)` (`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:404-415`)。搜索实际由 `services/uta/src/domain/trading/contract-search.ts:27-64`、`services/uta/src/http/routes-trading.ts:144-165` 和 `src/tool/trading.ts:219-275` 消费。

**当前设计的断点。** 主书的目录原则只说明“安装定义→可见目录→CLI/help/调用闭包” (`docs/uta-capability-runtime-design.md:1140-1157`)；承接册的 Catalog 只说明 preset、schema、fingerprint、factory 和“真实安装 definition” (`docs/uta-capability-runtime-design/legacy-accommodation.md:193-199`)。没有说明首次加载中、refresh 失败后继续使用旧 cache、6 小时刷新、CCXT market reload、IBKR server-side search 之间的可观察结果及其搜索 consumer。

**可构造反例。** 在 Alpaca `init` 的 account probe 已成功但 detached catalog refresh 尚未返回时，`searchContracts("AAPL")` 走 echo branch；若 refresh 失败，之前 cache 是否保留；六小时后新上市/下市又会改变候选。CCXT 同一搜索则依赖 `loadMarkets(true)` 的市场表，IBKR 不需要本地 enumerating cache。若公开定义只有“search 返回候选”，它无法告诉选择函数这个候选是已验证 listing、旧 cache 还是 provisional echo，也无法说明 refresh 失败应返回 unavailable 还是继续展示旧结果。

需要闭合的关系（仅限搜索结果语义，不推出 proposal 前置）。为每个搜索定义注明 EnumeratingCatalog/SearchingCatalog、首次加载、刷新拥有者、失败时 stale-retention，以及 provisional/unknown 如何到达 AI 与后续 details/order consumer；不要求每单 refresh 或绑定 catalog revision 才能形成 proposal。

### 2.3 discovery result 没有绑定到 proposal/interpreter，LeverUp 可先接受未知 identity

**源码事实。** `searchTradeableContracts` 只把 broker 返回的 `source`、Contract、derivative 类型和 asset class 组成 hit (`services/uta/src/domain/trading/contract-search.ts:27-64`)。`parseAliceId` 只检查 `|` 并切出 native key (`services/uta/src/domain/trading/UnifiedTradingAccount.ts:515-520`)；`stagePlaceOrder` 先验证订单字段，再调用 `contractFromAliceId`，最后把重建的 Contract 放进 staging (`services/uta/src/domain/trading/UnifiedTradingAccount.ts:603-638,693-724`)。

LeverUp 的 resolver 明确保留了一个危险分支：已知 pair 才返回完整 Contract，未知 key 则合成最小 `CRYPTO_PERP`，并把错误推迟到 trade time (`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:535-546`)。真正 place 时才通过 `resolvePair` 拒绝未知 pair (`services/uta/src/domain/trading/brokers/others/leverup/LeverupBroker.ts:213-223`)。

**可构造反例。** 输入 `accountId|NOT-A-PAIR`：它通过 `parseAliceId` 的 separator 检查；`stagePlaceOrder` 取得一个看似类型正确的 `CRYPTO_PERP` Contract 并把 proposal 放入 Git；到了 place，`resolvePair` 找不到 pair，才返回 `Unknown LeverUp pair`。这里没有任何 runtime 假设：每一步都是当前源码的确定分支。

**当前设计的断点。** 承接册说“发现取得 D，choose 取得 s，s 进入提案并由解释函数消费同一 s” (`docs/uta-capability-runtime-design/legacy-accommodation.md:9-17`)；主书 Instrument 只覆盖候选选择后读取数据 (`docs/uta-capability-runtime-design.md:1083-1101`)，没有把 discovery hit 的身份/来源/定义关联落实到 write proposal。当前 `resolveNativeKey` 的合成 fallback 仍可把任意非空 string 变成 proposal input。

需要闭合的关系（Main 裁决限定）。当前源码把合法 separator 加任意 native key 送入 staging，未知 key 的错误延后到实际 resolve/place；新的设计需要明确 resolve 的 IO-dependent result 和 unresolved proposal 如何消费。ExactRef 可以直接输入，不要求每单重新 discovery、refresh 或携带 catalog revision；这里只确认 delayed unknown-identity failure，不外推“曾发现”是 proposal 前置。

### 2.4 Longbridge 搜索返回的是 echo guess，却被公开搜索描述成 leaf

**源码事实与消费者。** `LongbridgeBroker.searchContracts` 不查询完整证券目录，只对非空 pattern 返回 `echoContractDescription` (`services/uta/src/domain/trading/brokers/longbridge/LongbridgeBroker.ts:235-243`)。该 helper 通过 `makeContract` 建 Contract；无后缀的 bare ticker 默认走 `.US` (`services/uta/src/domain/trading/brokers/longbridge/longbridge-contracts.ts:33-42,45-56`)。反向解析虽然优先 `localSymbol`/Alice native key，但没有它们时会从 currency 推 suffix，并明确注明 SH/SZ、SG/HK 是有损/歧义 fallback (`longbridge-contracts.ts:59-91`)。只有后续 `getContractDetails` 才调用 `staticInfo`，未知 suffix 或 lookup 失败返回 null (`LongbridgeBroker.ts:246-265`)。然而 AI 搜索描述把结果称为可交易 LEAVES (`src/tool/trading.ts:219-229`)。

**可构造反例。** 搜索 bare `700` 时，search 没有 network/staticInfo 证据，`makeContract("700")` 生成默认 US 语义；同一 helper 注释已说明 bare ticker 可能对应带市场后缀的对象，且 `700.HK` 是合法形式。后续 details 才可能发现该 guess 不适用。对 CNY bare ticker，currency fallback 还固定 SH 胜过 SZ (`longbridge-contracts.ts:84-90`)，不能把唯一来源对象从一个字符串推回来。

**当前设计的断点。** 承接册要求“选择有明确市场后缀的输入” (`docs/uta-capability-runtime-design/legacy-accommodation.md:137-145`)，主书要求前段解析“实际返回候选”并取得唯一 `InstrumentRef` (`docs/uta-capability-runtime-design.md:1083-1101`)，但没有说明 Longbridge echo 不是 verified candidate，也没有修正搜索工具把它直接标为 leaf 的消费含义。

需要闭合的关系（不把静态合法性等同于可交易）。echo 应在 projection 中标明 provisional/ambiguous，后续详情/resolve 结果必须可被 AI 消费；bare ticker/suffix 的语法合法不证明 tradeable。ExactRef 可直接输入，不要求每个 proposal 先完成 catalog refresh；但不能把 echo guess 直接描述为已验证 leaf。

### 2.5 CCXT 原生数据能力在跨进程边界没有公开 consumer，缺失字段的旧 fallback 也未给替代结果

**公开路径缺口。** CCXT 的两个非订单能力实际定义在 UTA 侧 `services/uta/src/domain/trading/brokers/ccxt/ccxt-tools.ts:20-95`：`getFundingRate` 和 `getOrderBook` 都先用 UTA 的 `contractFromAliceId`，再调用 broker。UTA 进程在 `services/uta/src/main.ts:58-65,88` 建立自己的 ToolCenter，并由 `services/uta/src/domain/trading/uta-manager.ts:133-139` 注册这些工具；这是 UTA 内部对象。Alice 进程则在 `src/main.ts:244-251` 向自己的 ToolCenter 注册 `createTradingTools(UTAManagerSDK, ...)`，`src/services/uta-client/UTAManagerSDK.ts:52-61` 对 `registerCcxtToolsIfNeeded` 明确 no-op。当前 `routes-trading.ts` 没有 funding/depth 路由，Alice `UTAAccountSDK` 也没有这两个方法（它只提供 generic account/query 方法，`src/services/uta-client/UTAAccountSDK.ts:119-123,126-223`）。因此静态调用链中，UTA local ToolCenter 没有进入 Alice 的 MCP/CLI ToolCenter。

**可构造反例。** 在 split 后，Alice 的 `createTradingTools` 仍可以暴露 generic `getQuote`，但 AI 不能从 Alice ToolCenter 得到 UTA 侧注册的 `getFundingRate`/`getOrderBook`；仅保留 UTA 本地注册不能满足原始目标“能力暴露给 AI”。现有 UTA 内部 e2e/直接 factory 调用只能证明 in-process consumer 存在，不能证明跨进程公开 consumer。

**结果语义缺口。** 即使把公开入口补上，当前 CCXT adapter 还把缺失值折叠成看似正常数值：`getFundingRate` 将缺 rate 置 `0`、缺时间置 `Date.now`，`getOrderBook` 将缺 level price/amount 置 `0`、缺时间置 `Date.now` (`services/uta/src/domain/trading/brokers/ccxt/CcxtBroker.ts:1330-1375`)。承接册已经明确禁止不可定价/缺 funding/depth/time 补 native zero/now (`legacy-accommodation.md:103-105`)，Accounting 也禁止本地 now 冒造 as-of (`legacy-accommodation.md:47-55`)。这属于可观察行为改变，不是“删掉错误字段”即可完成：新 provider leaf 必须把 missing/unavailable/unknown 交给具体 AI projection，否则原来的两个数据能力仍没有等价 consumer。

### 2.6 模拟 preview 与 Mock 管理控制是两项不同能力，当前承接没有把边界落实到跨进程消费者

**两条实际路径。** 只读价格 preview 由 `TradingGit.simulatePriceChange` 读取 Git state、执行 Decimal 估值并返回 `currentState/simulatedState/summary` (`services/uta/src/domain/trading/git/TradingGit.ts:751-897`)，协议结果在 `packages/uta-protocol/src/types/git.ts:194-246`；AI tool 在 `src/tool/trading.ts:613-628`，UTA route 在 `services/uta/src/http/routes-trading.ts:241-257`。相反，开发模拟器的 mark/tick/fill/cancel/deposit/withdraw/external-trade 是 Mock-only 管理控制：路由入口在 `services/uta/src/http/routes-simulator.ts:105-223`，挂载在 `services/uta/src/main.ts:164-168`，状态突变在 `MockBroker.ts:559-621,665-723`。

**当前断点及反例。** 承接册 `legacy-accommodation.md:149-157` 只构造 mark 触发撮合和手工 fill，`legacy-accommodation.md:227-233` 只泛称 simulator route 需切换；主书仅说“模拟环境刺激”应由各自 owner 实例化 (`docs/uta-capability-runtime-design.md:1186-1190`)，没有给 preview 的结果/输入关系。两项请求的可观察后果相反：`/api/trading/.../simulate-price` 不应改远端或 Mock 持仓，而 `/api/simulator/.../mark-price` 会触发 matcher 并改变持仓/现金；若只保留一个“simulation”叶子，preview 可能被误当作状态 mutation，管理控制也可能被误当成 read-only 数据。

另外，Alice preview SDK 在 POST 前调用 `assertVenueWritable` (`src/services/uta-client/UTAAccountSDK.ts:343-349`)，该 guard 在 `:385-388` 会阻止 read-only/keyless。可是 UTA 本体 `UnifiedTradingAccount.ts:983-985` 的 preview 直接委托 Git，AI tool 也把它描述成 READ-ONLY (`src/tool/trading.ts:613-628`)。因此一个只读/公共数据源会在跨进程 preview 到达 UTA 前被拒绝，而 Mock 管理控制又应当继续保持独立的开发权限。

**需要闭合的关系。** 明确两个不同 definition：AccountScope-bound read-only valuation preview（带当前 exposure、hypothetical price、missing/uncertain result）与 Mock-only/admin simulator mutation（带 simulator instance、管理权限、序列和状态 owner）。只读 preview 不应复用 venue-write guard；若决定移除 production preview，必须把 AI tool、HTTP route 和 SDK consumer 一并改为明确 unavailable/新 owner，不能由“保留模拟”一句话覆盖。

### 2.7 跨账户 equity/portfolio 的 FX 缺失政策与现有公开 consumer 相反

**源码事实与消费者。** `/api/trading/equity` 实际调用 `UTAManager.getAggregatedEquity` (`services/uta/src/http/routes-trading.ts:137-142`)；manager 对 keyless 账户直接排除，对 unhealthy/读取失败账户保留 health row、不给 totals 加值，并对非 USD 值调用 FxService (`services/uta/src/domain/trading/uta-manager.ts:203-267`)；SDK 和 wire shape 分别在 `src/services/uta-client/UTAManagerSDK.ts:155-158` 与 `packages/uta-protocol/src/types/manager.ts:21-36`。另一个 AI consumer 是 `getPortfolio`，它取 `/fx-rates` 后在 `src/tool/trading.ts:344-363` 把缺少的非 USD rate 当 `1`；整个 FX 请求失败也在 `:350-358` 被吞掉，随后仍以空 lookup 计算。

**当前设计的断点。** 主书 13.4 选定的程序要求所有必要 account/FX 事实进入 `a,b` 后才输出总值，并明确缺侧不补金额、不可隐式 carry-forward (`docs/uta-capability-runtime-design.md:1761-1784`)；承接册也禁止失败账户用 0 或本地 now 冒充 (`legacy-accommodation.md:47-55`)。但它没有把 `/equity` 的逐账户 health/partial row 投影，或 `getPortfolio` 的 FX 请求失败，接到新的 `value` consumer。

**可构造反例。** 一个健康 USD 账户和一个 EUR 账户同时被查询，FX service 暂时失败：现有 `getPortfolio` 仍会用 rate=1 计算 EUR 的美元百分比，且不一定产生 warning；`/equity` 则可能输出 USD totals，同时保留 EUR 账户的 zero-value/unhealthy row。当前设计的 Missing 分支要求不把缺侧金额算进总值，但没有说明这些现有公开结果要变成逐账户 `Unavailable`、整个 aggregate 不可用，还是允许带明确 coverage 的 partial。若不定义，既无法保留旧 consumer，也无法证实修正后的 no-fallback 语义已传到 AI。

## 3. 可以确定已经保留的关键关系

以下不是“所有实现都完成”，而是当前主书/承接册的具体构造与当前源码至少在关系方向上相符。

### 3.1 账户身份、keyless/read-only 与进程健康已经分开

`UnifiedTradingAccount` 的 account options 和 keyless/read-only flags 位于 `services/uta/src/domain/trading/UnifiedTradingAccount.ts:41-55,82-90`；manager aggregate 明确跳过 keyless、对 unhealthy 返回 `info:null` (`services/uta/src/domain/trading/uta-manager.ts:205-220`)，HTTP private read 在 offline 时返回 503 并 nudge recovery，而不是把 UTA 进程判死 (`services/uta/src/http/routes-trading.ts:97-124,269-280`)。启动也逐账户隔离失败 (`services/uta/src/main.ts:76-88`)，健康端口和账户叶子可用性分开 (`:147-168`)。这与承接册 `legacy-accommodation.md:13-17` 以及主书的 Runtime/Account 论证一致。

具体构造是：keyless 账户仍可作为公共搜索/行情 source，但不会进入 `/equity` private totals；funded read-only 可以被选中并读取，但写入入口另受权限控制。这个关系保留的是范围与权限差异，不是已经证明所有 broker health 或 secret 注入都可用。

### 3.2 多钱包写入目标不再按产品 kind 猜测

主书 13.8 (`docs/uta-capability-runtime-design.md:1814-1841`) 和承接册 `legacy-accommodation.md:13-17` 已明确 `s` 进入提案/route；因此“selector 未进入当前 Operation durable schema”只是旧源码风险，不能作为新稿“未保留”的缺口。

### 3.3 交易日志、外部观察和结果消费没有被冒称为同一事实

源码把 `stagePlaceOrder` (`services/uta/src/domain/trading/UnifiedTradingAccount.ts:693-724`)、`sync` (`services/uta/src/domain/trading/UnifiedTradingAccount.ts:827-951`) 和 `external observation` (`services/uta/src/domain/trading/UnifiedTradingAccount.ts:953-981`) 分成不同控制流；承接册 TradingJournal 也保留这条分轨 (`docs/uta-capability-runtime-design/legacy-accommodation.md:19-27`)。

这项保留是实质性的：一次 place 的本地结果、后续 getOrder 的观察和外部订单导入分别进入不同后继；它没有把旧 eventstream 作为前提，也没有宣称 native finality 或完整 absence 已统一。

### 3.4 Decimal、币种和带符号成本核算的核心算式仍有真实输入关系

`position-math.ts:22-64` 仍以 quantity、marketPrice、avgCost、multiplier、long/short 计算 market value/PnL；`cost-basis.ts:94-133` 逐 commit 消费 filled quantity/price，并对现货卖穿零的旧语义做出明确限制。主书 13.4-13.5 (`docs/uta-capability-runtime-design.md:1761-1821`) 保留 FX 的 `a→pairs→b→value`，以及 Flat/Open、带符号数量和穿零例；承接册 `legacy-accommodation.md:47-55` 也明确不把不同币种直接相加、不用 0 补失败、不把余额估计叫真实成交。

实际手工构造“多2@100、再买3@110、再卖6@120”时，目标程序得到空头1、均价120，而旧现货 WAC 会清零；这证明当前文本保留的是输入/顺序/状态关系，不只是保留 `Decimal` 类型名。税务 FIFO、split、衍生品保证金和真实 fill completeness 仍不能由此推出。

### 3.5 快照、轮询和资源释放的边界被分别指出

承接册以实际快照和轮询路径分别记录查询可见性、提交后观察和资源释放 (`docs/uta-capability-runtime-design/legacy-accommodation.md:57-75`)；当前 UTA 的 sync/observation 入口对应 `services/uta/src/domain/trading/UnifiedTradingAccount.ts:827-981`。这段只保留这些边界，不把 catalog refresh 或 revision 变成 proposal 前置。

这些关系可确定保留“读取成功、保存成功、查询可见、轮询完成、资源释放”不是一个 boolean；不能因此声称 SQLite atomicity、跨重启 cursor 或 native order coverage 已实现。

### 3.6 Provider 原生参数和 close 分支没有被压成交集

Alpaca full close 与 partial reverse 的真实分支在 `services/uta/src/domain/trading/brokers/alpaca/AlpacaBroker.ts:381-413`；CCXT close 只对 CRYPTO_PERP/FUT 加 reduceOnly (`CcxtBroker.ts:691-726`)；IBKR 仍直接保留 native Contract/Order fields，Longbridge 仍按 suffix 和 SDK enum 映射 (`LongbridgeBroker.ts:71-120,271-313`)。主书 13.1-13.2 (`docs/uta-capability-runtime-design.md:1695-1739`) 与承接册 `legacy-accommodation.md:85-145` 对这些差异的结论一致：Promise 完成不等于成交，partial reverse 不等于 native close，unsupported attachment/TIF 不能静默忽略。

这说明 Provider leaf 的输入和后续观察关系确实留在业务/adapter 侧，而不是被一个全局 Order 字段交集替代；但 expansion、catalog、cross-process data tools 等缺口仍不能由这项保留覆盖。

## 4. 本轮明确未断言的范围

- 没有对 24 个旧组逐条重新设计，也没有把原始 mapping 数量、链接或 `solutions` 的历史 disposition 当覆盖证明。
- 没有访问真实 Alpaca/CCXT/IBKR/Longbridge/LeverUp venue，因此没有宣称 idempotency、分页完整性、order absence、finality、session、权限、部署 schema 或 live/paper 语义成立。
- 没有验证 UTA↔Alice 的 Bearer/service principal、请求取消、响应 schema 解码和 secret 注入；当前主书本身把它们列作目标而不是实现事实 (`docs/uta-capability-runtime-design.md:1192-1220`)。
- 没有检查未在上述证据链中出现的 UI/Telegram/Workspace 调用者是否仍消费旧方法；已列出的 AI tool、HTTP route、SDK、UTA local ToolCenter 是本稿实际核验到的消费者。
- 本稿不判定当前 UTA 设计整体通过。它只证明若干关系已被保留，同时给出上面每条能由当前源码构造的未闭合消费链。

### 4.1 Main 整合裁决

- 接受本稿以源码构造的具体缺口：IBKR expansion、catalog refresh/search consumer、discovery→proposal 的未知 identity 延迟失败、Longbridge echo/歧义、CCXT 原生 data tools 的跨进程公开与 fallback、preview 与 Mock 管理控制的分离、以及 aggregate/portfolio 的 FX consumer policy。
- 不把 catalog-ready、refresh 或 catalog revision 统一设为 proposal 前置；ExactRef 可以直接输入，实际 resolve 可以依赖 IO，也不要求每单重新 refresh。
- “曾被发现”不作为 proposal 的普遍前置条件；但静态 separator/语法合法也不证明 tradeable，未知 native key 延后到 place 才失败仍是已确认的 identity-consumer 缺口。