import ts from "typescript";
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";

const root = dirname(fileURLToPath(import.meta.url));
const specimen = join(root, "specimen");
const target = join(specimen, "type-cases.ts");
const original = await readFile(target, "utf8");
const expected = original.split("\n").flatMap((line, index) => line.includes("@ts-expect-error") ? [{ line: index + 2, contract: line.replace(/^.*@ts-expect-error\s*/, "") }] : []);
if (expected.length === 0) throw new Error("No negative contracts declared");
const withoutSuppression = original.replaceAll("@ts-expect-error", "negative-case-disabled");
const options = { noEmit: true, strict: true, target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.NodeNext, moduleResolution: ts.ModuleResolutionKind.NodeNext, skipLibCheck: true };
const host = ts.createCompilerHost(options);
const defaultGetSourceFile = host.getSourceFile.bind(host);
host.getSourceFile = (filename, languageVersion, onError, shouldCreateNewSourceFile) => resolve(filename) === target
  ? ts.createSourceFile(filename, withoutSuppression, languageVersion, true)
  : defaultGetSourceFile(filename, languageVersion, onError, shouldCreateNewSourceFile);
const files = ts.sys.readDirectory(specimen, [".ts"], ["node_modules"]);
const program = ts.createProgram(files, options, host);
const diagnostics = ts.getPreEmitDiagnostics(program).map((diagnostic) => ({
  file: diagnostic.file?.fileName ?? null,
  line: diagnostic.file && diagnostic.start !== undefined ? diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start).line + 1 : null,
  code: diagnostic.code,
  message: ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"),
}));
const missing = expected.filter((item) => !diagnostics.some((diagnostic) => diagnostic.file === target && diagnostic.line === item.line));
const unrelated = diagnostics.filter((diagnostic) => diagnostic.file !== target || !expected.some((item) => item.line === diagnostic.line));
const result = { expectedContracts: expected, diagnostics, missing, unrelated, sourceUnchanged: (await readFile(target, "utf8")) === original };
await writeFile(join(root, "negative-type-evidence.json"), `${JSON.stringify(result, null, 2)}\n`);
if (missing.length || unrelated.length || !result.sourceUnchanged) throw new Error("Negative type-contract evidence is incomplete");
console.log(JSON.stringify({ status: "passed", contracts: expected.length, diagnostics: diagnostics.length, sourceUnchanged: result.sourceUnchanged }));
