import { spawn } from "node:child_process";
import { mkdtemp, readdir, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const output = await mkdtemp(join(root, "verification-run-"));
const sources = (await readdir(join(root, "specimen"))).filter((file) => file.endsWith(".ts")).map((file) => join("specimen", file));
if (sources.length === 0) throw new Error("Missing evidence sources");
const commands = [
  { name: "python-version", command: "python3", args: ["--version"] },
  { name: "typecheck", command: process.execPath, args: ["node_modules/typescript/bin/tsc", "--noEmit", "--strict", "--target", "ES2023", "--module", "NodeNext", "--moduleResolution", "NodeNext", "--skipLibCheck", ...sources] },
  { name: "negative-types", command: process.execPath, args: ["check-negative-types.mjs"] },
  { name: "transport-runtime", command: process.execPath, args: ["--import", "tsx", "specimen/run.ts"] },
  { name: "reader-mutations", command: process.execPath, args: ["--import", "tsx", "specimen/reader-mutations.ts"] },
  { name: "composition-runtime", command: process.execPath, args: ["--import", "tsx", "specimen/composition.ts"] },
  { name: "diagrams", command: process.execPath, args: ["check-diagrams.mjs", "documents/chapter-16.md", "documents/event-flows.md"] },
];
const records = [];
for (const entry of commands) {
  const result = await new Promise((resolve, reject) => {
    const child = spawn(entry.command, entry.args, { cwd: root, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "", stderr = "";
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", reject);
    child.on("close", (code, signal) => resolve({ code, signal, stdout, stderr }));
  });
  await writeFile(join(output, `${entry.name}.stdout`), result.stdout);
  await writeFile(join(output, `${entry.name}.stderr`), result.stderr);
  records.push({ ...entry, code: result.code, signal: result.signal, stdout: `${entry.name}.stdout`, stderr: `${entry.name}.stderr` });
  console.log(`${entry.name}: exit=${result.code}`);
  if (result.code !== 0) {
    console.error(result.stdout);
    console.error(result.stderr);
    break;
  }
}
const passed = records.length === commands.length && records.every((record) => record.code === 0);
await writeFile(join(output, "manifest.json"), `${JSON.stringify({ node: process.version, passed, records }, null, 2)}\n`);
await writeFile(join(root, "latest-verification.json"), `${JSON.stringify({ directory: output, passed }, null, 2)}\n`);
console.log(JSON.stringify({ directory: output, passed }));
if (!passed) process.exitCode = 1;
