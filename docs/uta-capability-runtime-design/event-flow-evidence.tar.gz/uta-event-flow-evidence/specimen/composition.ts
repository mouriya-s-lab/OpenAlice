import { stdout } from "node:process";
import { z } from "zod";
import {
  baseFeedDeclaration,
  candleBaseSchema,
  feedFailureSchema,
  richCandleAt,
} from "./source.js";
import {
  baseFeedDefinition,
  baseFeedEventSchema,
  FeedControlMachine,
  type BaseFeedEvent,
} from "./types.js";

const memberKeySchema = z.enum(["left", "right"]);
type MemberKey = z.output<typeof memberKeySchema>;

const memberPhaseSchema = z.enum(["active", "terminal"]);
const outerPhaseSchema = z.enum(["active", "terminal"]);
const revisionSchema = z.number().int().nonnegative();

/**
 * This is the only partial-result failure declaration in this specimen.  Its
 * failure is the source declaration's failure schema, not the feed's
 * recoverable ItemFailure payload.
 */
export const memberOutcomeSchema = z.strictObject({
  member: memberKeySchema,
  sourceBinding: z.literal(baseFeedDeclaration.binding),
  terminal: z.literal("Failed"),
  failure: feedFailureSchema,
});
export type MemberOutcome = z.output<typeof memberOutcomeSchema>;

const memberEventSchema = z.strictObject({
  tag: z.literal("MemberEvent"),
  member: memberKeySchema,
  event: baseFeedEventSchema,
});

export const partialResultSchema = z.strictObject({
  tag: z.literal("Partial"),
  revision: revisionSchema,
  quality: z.literal("partial"),
  closedMembers: z.array(memberOutcomeSchema).min(1),
});
export type PartialResult = z.output<typeof partialResultSchema>;

const outerCompletedSchema = z.strictObject({
  tag: z.literal("Completed"),
  revision: revisionSchema,
});

const outerFailedSchema = z.strictObject({
  tag: z.literal("Failed"),
  revision: revisionSchema,
  member: memberKeySchema,
  sourceBinding: z.literal(baseFeedDeclaration.binding),
  failure: feedFailureSchema,
});

const outerCancelledSchema = z.strictObject({
  tag: z.literal("Cancelled"),
  revision: revisionSchema,
  member: memberKeySchema,
  reason: z.string().min(1),
});

/** Outputs are merge records, not source FeedEvent tags. */
export const mergeOutputSchema = z.discriminatedUnion("tag", [
  memberEventSchema,
  partialResultSchema,
  outerCompletedSchema,
  outerFailedSchema,
  outerCancelledSchema,
]);
export type MergeOutput = z.output<typeof mergeOutputSchema>;

export const mergePolicySchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("fail-fast") }),
  z.strictObject({ tag: z.literal("partial-on-failure") }),
]);
export type MergePolicy = z.output<typeof mergePolicySchema>;

const mergeRejectionCodeSchema = z.enum([
  "unknown-member",
  "outer-terminal",
  "invalid-event",
  "binding-mismatch",
  "missing-start",
  "duplicate-id-conflict",
  "out-of-order",
  "duplicate-start",
  "after-terminal",
  "unknown-correction-target",
  "unknown-retraction-target",
  "invalid-gap-range",
]);
type MergeRejectionCode = z.output<typeof mergeRejectionCodeSchema>;

const acceptedTraceEntrySchema = z.strictObject({
  step: z.number().int().nonnegative(),
  result: z.literal("accepted"),
  member: memberKeySchema,
  event: baseFeedEventSchema,
  evolution: z.enum(["advanced", "duplicate"]),
  memberPhase: memberPhaseSchema,
  outerPhase: outerPhaseSchema,
  emitted: z.array(mergeOutputSchema),
});

const rejectedTraceEntrySchema = z.strictObject({
  step: z.number().int().nonnegative(),
  result: z.literal("rejected"),
  member: memberKeySchema.nullable(),
  event: baseFeedEventSchema,
  code: mergeRejectionCodeSchema,
  detail: z.string().min(1),
  outerPhase: outerPhaseSchema,
  emitted: z.array(mergeOutputSchema),
});

export const mergeTraceEntrySchema = z.discriminatedUnion("result", [
  acceptedTraceEntrySchema,
  rejectedTraceEntrySchema,
]);
export type MergeTraceEntry = z.output<typeof mergeTraceEntrySchema>;

export const compositionTraceSchema = z.strictObject({
  tag: z.literal("MergeCompositionTrace"),
  traceVersion: z.literal("merge-v1"),
  source: z.strictObject({
    bindingLabel: z.literal(baseFeedDeclaration.bindingLabel),
    binding: z.literal(baseFeedDeclaration.binding),
    revision: z.literal(baseFeedDeclaration.revision),
  }),
  scenarios: z.strictObject({
    leftCompletesFirst: z.array(mergeTraceEntrySchema),
    defaultFailure: z.array(mergeTraceEntrySchema),
    partialFailure: z.array(mergeTraceEntrySchema),
    lastMemberFails: z.array(mergeTraceEntrySchema),
    allMembersFail: z.array(mergeTraceEntrySchema),
  }),
});
export type CompositionTrace = z.output<typeof compositionTraceSchema>;

type FeedFailure = z.output<typeof feedFailureSchema>;
type ChildLifecycle =
  | { readonly tag: "awaiting-start" }
  | { readonly tag: "active" }
  | { readonly tag: "completed" }
  | { readonly tag: "failed"; readonly failure: FeedFailure }
  | { readonly tag: "cancelled"; readonly reason: string };

type OuterLifecycle =
  | { readonly tag: "active"; readonly revision: number }
  | { readonly tag: "completed"; readonly revision: number }
  | { readonly tag: "failed"; readonly revision: number; readonly member: MemberKey; readonly failure: FeedFailure }
  | { readonly tag: "cancelled"; readonly revision: number; readonly member: MemberKey; readonly reason: string };

function sourceForMember(member: MemberKey): string {
  switch (member) {
    case "left":
      return "composition-source-left";
    case "right":
      return "composition-source-right";
  }
}

function memberForSource(source: string): MemberKey | null {
  switch (source) {
    case "composition-source-left":
      return "left";
    case "composition-source-right":
      return "right";
    default:
      return null;
  }
}

function eventIdentity(member: MemberKey, eventId: string, sequence: number) {
  return {
    eventId,
    binding: baseFeedDeclaration.binding,
    bindingLabel: baseFeedDeclaration.bindingLabel,
    source: sourceForMember(member),
    generation: "g1",
    partition: "candles",
    sequence,
    lineage: {
      sourceBinding: baseFeedDeclaration.binding,
      sourceEventId: eventId,
      operators: [],
    },
  };
}

function dataPayload(member: MemberKey, index: number) {
  const rich = richCandleAt(index, `composition-native-${member}-${index}`);
  return candleBaseSchema.strip().parse(rich);
}


function started(member: MemberKey, sequence: number, eventId: string): BaseFeedEvent {
  return baseFeedEventSchema.parse({
    ...eventIdentity(member, eventId, sequence),
    tag: "Started",
  });
}

function data(member: MemberKey, sequence: number, eventId: string, index: number): BaseFeedEvent {
  return baseFeedEventSchema.parse({
    ...eventIdentity(member, eventId, sequence),
    tag: "Data",
    payload: dataPayload(member, index),
  });
}

function completed(member: MemberKey, sequence: number, eventId: string): BaseFeedEvent {
  return baseFeedEventSchema.parse({
    ...eventIdentity(member, eventId, sequence),
    tag: "Completed",
  });
}

function failed(member: MemberKey, sequence: number, eventId: string, failure: FeedFailure): BaseFeedEvent {
  return baseFeedEventSchema.parse({
    ...eventIdentity(member, eventId, sequence),
    tag: "Failed",
    failure: feedFailureSchema.parse(failure),
  });
}

function lifecycleIsTerminal(lifecycle: ChildLifecycle): boolean {
  switch (lifecycle.tag) {
    case "awaiting-start":
    case "active":
      return false;
    case "completed":
    case "failed":
    case "cancelled":
      return true;
  }
}

function phaseOfLifecycle(lifecycle: ChildLifecycle): z.output<typeof memberPhaseSchema> {
  switch (lifecycle.tag) {
    case "awaiting-start":
    case "active":
      return "active";
    case "completed":
    case "failed":
    case "cancelled":
      return "terminal";
  }
}

function phaseOfOuter(lifecycle: OuterLifecycle): z.output<typeof outerPhaseSchema> {
  switch (lifecycle.tag) {
    case "active":
      return "active";
    case "completed":
    case "failed":
    case "cancelled":
      return "terminal";
  }
}

/**
 * A deliberately finite two-member consumer.  Each member has its own
 * FeedControlMachine and lifecycle; the outer lifecycle is policy-owned.
 */
export class MergeConsumer {
  readonly #policy: MergePolicy;
  readonly #leftMachine: FeedControlMachine<typeof baseFeedDefinition>;
  readonly #rightMachine: FeedControlMachine<typeof baseFeedDefinition>;
  #leftLifecycle: ChildLifecycle = { tag: "awaiting-start" };
  #rightLifecycle: ChildLifecycle = { tag: "awaiting-start" };
  #outerLifecycle: OuterLifecycle = { tag: "active", revision: 0 };

  constructor(policy: MergePolicy) {
    this.#policy = mergePolicySchema.parse(policy);
    this.#leftMachine = new FeedControlMachine(baseFeedDefinition);
    this.#rightMachine = new FeedControlMachine(baseFeedDefinition);
  }

  consume(raw: unknown, step: number): MergeTraceEntry {
    const event = baseFeedEventSchema.parse(raw);
    const member = memberForSource(event.source);
    if (member === null) {
      return this.rejected(step, event, null, "unknown-member", event.source);
    }

    const outerLifecycle = this.#outerLifecycle;
    if (outerLifecycle.tag !== "active") {
      return this.rejected(step, event, member, "outer-terminal", outerLifecycle.tag);
    }

    const acceptance = this.machineFor(member).accept(event);
    if (acceptance.tag === "rejected") {
      return this.rejected(step, event, member, acceptance.code, acceptance.detail);
    }

    if (acceptance.evolution === "duplicate") {
      return mergeTraceEntrySchema.parse({
        step,
        result: "accepted",
        member,
        event,
        evolution: "duplicate",
        memberPhase: phaseOfLifecycle(this.lifecycleFor(member)),
        outerPhase: phaseOfOuter(this.#outerLifecycle),
        emitted: [],
      });
    }

    const revision = outerLifecycle.revision + 1;
    this.#outerLifecycle = { tag: "active", revision };
    this.applyAdvancedEvent(member, event);
    const emitted = this.emitAdvancedEvent(member, event, revision);
    return mergeTraceEntrySchema.parse({
      step,
      result: "accepted",
      member,
      event,
      evolution: "advanced",
      memberPhase: phaseOfLifecycle(this.lifecycleFor(member)),
      outerPhase: phaseOfOuter(this.#outerLifecycle),
      emitted,
    });
  }

  consumeAll(events: readonly BaseFeedEvent[]): readonly MergeTraceEntry[] {
    const trace: MergeTraceEntry[] = [];
    for (let index = 0; index < events.length; index += 1) {
      const event = events[index];
      if (event === undefined) throw new Error(`missing event at ${index}`);
      trace.push(this.consume(event, index));
    }
    return trace;
  }

  private machineFor(member: MemberKey): FeedControlMachine<typeof baseFeedDefinition> {
    switch (member) {
      case "left":
        return this.#leftMachine;
      case "right":
        return this.#rightMachine;
    }
  }

  private lifecycleFor(member: MemberKey): ChildLifecycle {
    switch (member) {
      case "left":
        return this.#leftLifecycle;
      case "right":
        return this.#rightLifecycle;
    }
  }

  private setLifecycle(member: MemberKey, lifecycle: ChildLifecycle): void {
    switch (member) {
      case "left":
        this.#leftLifecycle = lifecycle;
        return;
      case "right":
        this.#rightLifecycle = lifecycle;
        return;
    }
  }


  private applyAdvancedEvent(member: MemberKey, event: BaseFeedEvent): void {
    switch (event.tag) {
      case "Started":
        this.setLifecycle(member, { tag: "active" });
        return;
      case "Completed":
        this.setLifecycle(member, { tag: "completed" });
        return;
      case "Failed":
        this.setLifecycle(member, { tag: "failed", failure: event.failure });
        return;
      case "Cancelled":
        this.setLifecycle(member, { tag: "cancelled", reason: event.reason });
        return;
      case "Data":
      case "Correction":
      case "Retraction":
      case "Gap":
      case "SnapshotEnd":
      case "ItemFailure":
        return;
    }
  }

  private failedOutcomes(): readonly MemberOutcome[] {
    const outcomes: MemberOutcome[] = [];
    const left = this.failedOutcome("left");
    if (left !== null) outcomes.push(left);
    const right = this.failedOutcome("right");
    if (right !== null) outcomes.push(right);
    return outcomes;
  }

  private failedOutcome(member: MemberKey): MemberOutcome | null {
    const lifecycle = this.lifecycleFor(member);
    if (lifecycle.tag !== "failed") return null;
    return memberOutcomeSchema.parse({
      member,
      sourceBinding: baseFeedDeclaration.binding,
      terminal: "Failed",
      failure: lifecycle.failure,
    });
  }

  private emitAdvancedEvent(member: MemberKey, event: BaseFeedEvent, revision: number): readonly MergeOutput[] {
    const emitted: MergeOutput[] = [
      memberEventSchema.parse({ tag: "MemberEvent", member, event }),
    ];
    switch (event.tag) {
      case "Failed":
        if (this.#policy.tag === "fail-fast") {
          this.#outerLifecycle = { tag: "failed", revision, member, failure: event.failure };
          emitted.push(outerFailedSchema.parse({
            tag: "Failed",
            revision,
            member,
            sourceBinding: baseFeedDeclaration.binding,
            failure: event.failure,
          }));
        } else {
          emitted.push(partialResultSchema.parse({
            tag: "Partial",
            revision,
            quality: "partial",
            closedMembers: this.failedOutcomes(),
          }));
        }
        break;
      case "Cancelled":
        this.#outerLifecycle = { tag: "cancelled", revision, member, reason: event.reason };
        emitted.push(outerCancelledSchema.parse({
          tag: "Cancelled",
          revision,
          member,
          reason: event.reason,
        }));
        return emitted;
      case "Completed":
        break;
      case "Started":
      case "Data":
      case "Correction":
      case "Retraction":
      case "Gap":
      case "SnapshotEnd":
      case "ItemFailure":
        return emitted;
    }
    if (this.#outerLifecycle.tag === "active" && lifecycleIsTerminal(this.#leftLifecycle) && lifecycleIsTerminal(this.#rightLifecycle)) {
      this.#outerLifecycle = { tag: "completed", revision };
      emitted.push(outerCompletedSchema.parse({ tag: "Completed", revision }));
    }
    return emitted;
  }

  private rejected(
    step: number,
    event: BaseFeedEvent,
    member: MemberKey | null,
    code: MergeRejectionCode,
    detail: string,
  ): MergeTraceEntry {
    return mergeTraceEntrySchema.parse({
      step,
      result: "rejected",
      member,
      event,
      code,
      detail,
      outerPhase: phaseOfOuter(this.#outerLifecycle),
      emitted: [],
    });
  }
}

function completionScenario(): readonly MergeTraceEntry[] {
  const events: readonly BaseFeedEvent[] = [
    started("left", 0, "completion-left-start"),
    started("right", 0, "completion-right-start"),
    data("left", 1, "completion-left-data-0", 0),
    data("right", 1, "completion-right-data-0", 1),
    completed("left", 2, "completion-left-completed"),
    data("left", 3, "completion-left-after-terminal", 2),
    data("right", 2, "completion-right-data-1", 2),
    completed("right", 3, "completion-right-completed"),
  ];
  return new MergeConsumer({ tag: "fail-fast" }).consumeAll(events);
}

function defaultFailureScenario(): readonly MergeTraceEntry[] {
  const leftFailure = failed(
    "left",
    1,
    "failure-left-failed",
    feedFailureSchema.parse({ tag: "source-disconnected", generation: "g1" }),
  );
  const events: readonly BaseFeedEvent[] = [
    started("left", 0, "failure-left-start"),
    started("right", 0, "failure-right-start"),
    leftFailure,
    data("right", 1, "failure-right-after-outer-failed", 0),
  ];
  return new MergeConsumer({ tag: "fail-fast" }).consumeAll(events);
}

function partialFailureScenario(): readonly MergeTraceEntry[] {
  const leftFailure = failed(
    "left",
    1,
    "partial-left-failed",
    feedFailureSchema.parse({ tag: "source-disconnected", generation: "g1" }),
  );
  const events: readonly BaseFeedEvent[] = [
    started("left", 0, "partial-left-start"),
    started("right", 0, "partial-right-start"),
    leftFailure,
    data("left", 2, "partial-left-after-terminal", 0),
    data("right", 1, "partial-right-data-0", 1),
    completed("right", 2, "partial-right-completed"),
  ];
  return new MergeConsumer({ tag: "partial-on-failure" }).consumeAll(events);
}

function outputRecords(trace: readonly MergeTraceEntry[]): readonly MergeOutput[] {
  const outputs: MergeOutput[] = [];
  for (const entry of trace) {
    if (entry.result === "accepted") outputs.push(...entry.emitted);
  }
  return outputs;
}

function countOutput(trace: readonly MergeTraceEntry[], tag: MergeOutput["tag"]): number {
  let count = 0;
  for (const output of outputRecords(trace)) {
    if (output.tag === tag) count += 1;
  }
  return count;
}

function requireInvariant(condition: boolean, detail: string): void {
  if (!condition) throw new Error(`composition invariant failed: ${detail}`);
}

function checkCompletionScenario(trace: readonly MergeTraceEntry[]): void {
  requireInvariant(countOutput(trace, "Completed") === 1, "left completion cannot close the outer merge");
  requireInvariant(countOutput(trace, "Failed") === 0, "completion scenario has no failure");
  let leftCompletedEntrySeen = false;
  let rightDataAfterLeftCompleted = false;
  let leftDataAfterTerminalRejected = false;
  for (const entry of trace) {
    if (entry.result === "accepted" && entry.member === "left" && entry.event.tag === "Completed") {
      leftCompletedEntrySeen = true;
      requireInvariant(entry.outerPhase === "active", "outer remains active after left Completed");
      requireInvariant(!entry.emitted.some((output) => output.tag === "Completed"), "no premature outer Completed");
    }
    if (leftCompletedEntrySeen && entry.result === "accepted" && entry.member === "right" && entry.event.tag === "Data") {
      rightDataAfterLeftCompleted = true;
    }
    if (entry.result === "rejected" && entry.member === "left" && entry.code === "after-terminal") {
      leftDataAfterTerminalRejected = true;
    }
  }
  requireInvariant(rightDataAfterLeftCompleted, "right remains live after left completion");
  requireInvariant(leftDataAfterTerminalRejected, "post-terminal left data is rejected");
}

function checkDefaultFailureScenario(trace: readonly MergeTraceEntry[]): void {
  requireInvariant(countOutput(trace, "Failed") === 1, "default child failure closes outer exactly once");
  requireInvariant(countOutput(trace, "Completed") === 0, "failed outer never upgrades to Completed");
  let typedFailureSeen = false;
  let postTerminalRejected = false;
  for (const entry of trace) {
    if (entry.result === "accepted" && entry.member === "left" && entry.event.tag === "Failed") {
      typedFailureSeen = entry.emitted.some((output) => output.tag === "Failed");
    }
    if (entry.result === "rejected" && entry.code === "outer-terminal") {
      postTerminalRejected = true;
    }
  }
  requireInvariant(typedFailureSeen, "child Failed is present in the outer failure output");
  requireInvariant(postTerminalRejected, "live right is rejected after fail-fast outer terminal");
}

function checkPartialFailureScenario(trace: readonly MergeTraceEntry[]): void {
  requireInvariant(countOutput(trace, "Partial") === 1, "partial declaration is emitted once");
  requireInvariant(countOutput(trace, "Completed") === 1, "partial mode completes after the live member closes");
  requireInvariant(countOutput(trace, "Failed") === 0, "partial mode does not emit fail-fast outer Failed");
  let typedPartialSeen = false;
  let rightDataAfterFailure = false;
  let leftDataAfterTerminalRejected = false;
  for (const entry of trace) {
    if (entry.result === "accepted" && entry.member === "left" && entry.event.tag === "Failed") {
      requireInvariant(entry.outerPhase === "active", "partial member failure leaves outer active");
      typedPartialSeen = entry.emitted.some((output) => {
        if (output.tag !== "Partial") return false;
        const outcome = output.closedMembers[0];
        return outcome !== undefined && outcome.member === "left" && outcome.failure.tag === "source-disconnected";
      });
    }
    if (entry.result === "accepted" && entry.member === "right" && entry.event.tag === "Data") {
      rightDataAfterFailure = true;
    }
    if (entry.result === "rejected" && entry.member === "left" && entry.code === "after-terminal") {
      leftDataAfterTerminalRejected = true;
    }
  }
  requireInvariant(typedPartialSeen, "Partial carries the declared typed source failure");
  requireInvariant(rightDataAfterFailure, "partial mode preserves the live right member");
  requireInvariant(leftDataAfterTerminalRejected, "partial mode rejects post-terminal member data");
}

export async function run(): Promise<CompositionTrace> {
  const leftCompletesFirst = completionScenario();
  const defaultFailure = defaultFailureScenario();
  const partialFailure = partialFailureScenario();
  const failure = feedFailureSchema.parse({ tag: "source-disconnected", generation: "g1" });
  const lastMemberFails = new MergeConsumer({ tag: "partial-on-failure" }).consumeAll([
    started("left", 0, "last-left-start"),
    started("right", 0, "last-right-start"),
    completed("right", 1, "last-right-complete"),
    failed("left", 1, "last-left-fail", failure),
  ]);
  const allMembersFail = new MergeConsumer({ tag: "partial-on-failure" }).consumeAll([
    started("left", 0, "both-left-start"),
    started("right", 0, "both-right-start"),
    failed("left", 1, "both-left-fail", failure),
    failed("right", 1, "both-right-fail", failure),
  ]);
  requireInvariant(countOutput(lastMemberFails, "Completed") === 1, "last Failed must close an all-terminal partial merge");
  requireInvariant(countOutput(allMembersFail, "Completed") === 1, "two Failed members must close a partial merge");
  const partials = outputRecords(allMembersFail).filter((output) => output.tag === "Partial");
  requireInvariant(partials.at(-1)?.closedMembers.length === 2, "all source failures remain in the final partial result");
  checkCompletionScenario(leftCompletesFirst);
  checkDefaultFailureScenario(defaultFailure);
  checkPartialFailureScenario(partialFailure);
  return compositionTraceSchema.parse({
    tag: "MergeCompositionTrace",
    traceVersion: "merge-v1",
    source: {
      bindingLabel: baseFeedDeclaration.bindingLabel,
      binding: baseFeedDeclaration.binding,
      revision: baseFeedDeclaration.revision,
    },
    scenarios: {
      leftCompletesFirst,
      defaultFailure,
      partialFailure,
      lastMemberFails,
      allMembersFail,
    },
  });
}

export async function main(): Promise<number> {
  const trace = await run();
  stdout.write(`${JSON.stringify(trace)}\n`);
  return 0;
}

if (process.argv[1]?.endsWith("/composition.ts")) {
  void main().then(
    (exitCode) => {
      process.exitCode = exitCode;
    },
    (error: unknown) => {
      console.error(error);
      process.exitCode = 1;
    },
  );
}
