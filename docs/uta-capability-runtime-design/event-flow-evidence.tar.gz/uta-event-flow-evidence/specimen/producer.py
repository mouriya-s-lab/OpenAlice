#!/usr/bin/env python3
"""Independent transport producer for the bounded event specimen."""

from __future__ import annotations

import argparse
import json
import sys


def identity(binding: str, binding_label: str, source_binding: str, adapter_binding: str, partition: str, sequence: int, event_id: str) -> dict[str, object]:
    return {
        "eventId": event_id,
        "binding": binding,
        "bindingLabel": binding_label,
        "source": "fixture",
        "generation": "g1",
        "partition": partition,
        "sequence": sequence,
        "lineage": {
            "sourceBinding": source_binding,
            "sourceEventId": event_id,
            "operators": [{"kind": "input-adaptation", "binding": adapter_binding, "version": "native-symbol-v1"}],
        },
    }


def candle(index: int, native_event: str, close: str | None = None) -> dict[str, object]:
    return {
        "source": "fixture",
        "generation": "g1",
        "instrument": {"source": "fixture", "nativeId": "BTC-USD"},
        "interval": "1m",
        "openedAt": f"2026-09-09T00:0{index}:00.000Z",
        "open": "100",
        "high": "103",
        "low": "99",
        "close": close if close is not None else str(101 + index),
        "volume": {"amount": "2.50", "unit": "base-asset", "evidence": "fixture-volume-v1"},
        "timezone": "UTC",
        "session": "continuous",
        "adjustment": "unadjusted",
        "finality": {"tag": "provisional", "reason": "source has not closed interval"},
        "revision": {"tag": "original", "id": f"revision-{index}"},
        "vwap": "101.25",
        "trades": 4 + index,
        "nativeEvent": native_event,
    }


def correction_candle(index: int, native_event: str) -> dict[str, object]:
    value = candle(index, native_event, close="104")
    value["revision"] = {"tag": "correction", "id": f"revision-{index}-correction", "replaces": f"revision-{index}"}
    return value


def event(binding: str, binding_label: str, source_binding: str, adapter_binding: str, partition: str, sequence: int, event_id: str, tag: str, **fields: object) -> dict[str, object]:
    body = identity(binding, binding_label, source_binding, adapter_binding, partition, sequence, event_id)
    body["tag"] = tag
    body.update(fields)
    return {"kind": "transport", "protocol": 1, "binding": binding, "slot": "feed", "payload": body}


def build_records(binding: str, binding_label: str, source_binding: str, adapter_binding: str) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []

    def emit(partition: str, sequence: int, event_id: str, tag: str, **fields: object) -> None:
        records.append(event(binding, binding_label, source_binding, adapter_binding, partition, sequence, event_id, tag, **fields))

    emit("source-a", 0, "a-start", "Started")
    emit("source-b", 0, "b-start", "Started")
    emit("source-c", 0, "c-start", "Started")
    emit("source-a", 1, "a-data-0", "Data", payload=candle(0, "a-event-0"))
    emit("source-b", 1, "b-data-0", "Data", payload=candle(1, "b-event-0"))
    emit("source-c", 1, "c-data-0", "Data", payload=candle(2, "c-event-0"))
    emit("source-a", 2, "a-snapshot-end", "SnapshotEnd", snapshotId="snapshot-a", continuation="tail-a")
    emit("source-a", 3, "a-correction", "Correction", replaces="a-data-0", payload=correction_candle(0, "a-event-0-correction"))
    emit("source-b", 2, "b-gap", "Gap", fromSequence=2, toSequence=3, reason="source-b reconnect without replay")
    emit("source-a", 4, "a-retraction", "Retraction", retracts="a-correction", reason="fixture correction withdrawn")
    emit("source-b", 3, "b-snapshot-end", "SnapshotEnd", snapshotId="snapshot-b", continuation=None)
    emit("source-a", 5, "a-gap", "Gap", fromSequence=5, toSequence=6, reason="source-a sequence hole")
    emit("source-a", 6, "a-item-failure", "ItemFailure", failure={"tag": "recoverable-item-failure", "itemId": "a-item-1", "reason": "one item was malformed"})
    emit("source-b", 4, "b-cancelled", "Cancelled", reason="consumer cancellation after snapshot")
    emit("source-c", 2, "c-failed", "Failed", failure={"tag": "source-disconnected", "generation": "g1"})
    emit("source-a", 7, "a-completed", "Completed")
    records.insert(7, records[3])
    return records


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binding", required=True)
    parser.add_argument("--binding-label", required=True)
    parser.add_argument("--source-binding", required=True)
    parser.add_argument("--adapter-binding", required=True)
    args = parser.parse_args()
    for record in build_records(args.binding, args.binding_label, args.source_binding, args.adapter_binding):
        sys.stdout.write(json.dumps(record, separators=(",", ":")) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
