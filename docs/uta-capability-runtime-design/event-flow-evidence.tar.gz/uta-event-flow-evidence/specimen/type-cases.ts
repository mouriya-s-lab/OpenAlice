import { z } from "zod";
import {
  candleBaseSchema,
  richCandleSchema,
} from "./source.js";
import {
  baseFeedEventSchema,
  controlledStageEventSchema,
  richFeedDefinition,
  richFeedEventSchema,
} from "./types.js";
import type {
  BaseFeedEvent,
  ControlledStageEvent,
  RichFeedEvent,
} from "./types.js";

type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;
type Assert<T extends true> = T;

type RichData = Extract<RichFeedEvent, { tag: "Data" }>;
type BaseData = Extract<BaseFeedEvent, { tag: "Data" }>;
type BaseStarted = Extract<BaseFeedEvent, { tag: "Started" }>;
type PreparedStage = Extract<ControlledStageEvent, { slot: "prepared" }>;
type AckStage = Extract<ControlledStageEvent, { slot: "ack" }>;

declare const richData: RichData;
declare const baseData: BaseData;
declare const baseStarted: BaseStarted;
declare const preparedStage: PreparedStage;
const forgedDefinition = {
  bindingLabel: richFeedDefinition.bindingLabel,
  binding: richFeedDefinition.binding,
  payload: richFeedDefinition.payload,
  failure: richFeedDefinition.failure,
  schema: richFeedEventSchema,
};

// @ts-expect-error Feed definitions are factory-owned; a same-shaped object cannot supply its own schema.
const forgedRichDefinition: typeof richFeedDefinition = forgedDefinition;

type RichPayloadIsSourceOutput = Assert<Equal<RichData["payload"], z.output<typeof richCandleSchema>>>;
type BasePayloadIsSourceOutput = Assert<Equal<BaseData["payload"], z.output<typeof candleBaseSchema>>>;
type RichHasNativeEvidence = Assert<Equal<RichData["payload"]["nativeEvent"], string>>;
type BaseHasNoRichEvidence = Assert<Equal<keyof BaseData["payload"] extends keyof z.output<typeof candleBaseSchema> ? true : false, true>>;

// @ts-expect-error The projected base payload does not claim rich-only vwap evidence.
type BaseVwapMustNotExist = BaseData["payload"]["vwap"];
// @ts-expect-error The projected base payload does not claim the native event field.
type BaseNativeEventMustNotExist = BaseData["payload"]["nativeEvent"];
// @ts-expect-error Same-shaped Started events still carry distinct binding label/digest identities.
const richFromSameShapeBase: RichFeedEvent = baseStarted;
// @ts-expect-error A base event binding is not interchangeable with the adapted rich binding.
const richFromBase: RichFeedEvent = baseData;
// @ts-expect-error A terminal event cannot be used as a Data payload event.
const dataFromTerminal: RichData = { ...richData, tag: "Completed" };
// @ts-expect-error A prepared slot cannot be assigned to an acknowledgement slot.
const ackFromPrepared: AckStage = preparedStage;
// @ts-expect-error A stage event is not a Feed event.
const feedFromStage: RichFeedEvent = preparedStage;

export const exactRichSchema: z.ZodType<RichFeedEvent> = richFeedEventSchema;
export const exactBaseSchema: z.ZodType<BaseFeedEvent> = baseFeedEventSchema;
export const exactStageSchema: z.ZodType<ControlledStageEvent> = controlledStageEventSchema;
