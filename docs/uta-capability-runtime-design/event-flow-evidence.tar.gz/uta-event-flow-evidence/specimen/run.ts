import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { z } from "zod";
import {
  adapterBinding,
  adaptedRichFeedBinding,
  adaptedRichFeedBindingLabel,
  controlledBinding,
  controlledBindingLabel,
  richFeedBinding,
} from "./source.js";
import { controlledStageEventSchema, transportRecordSchema } from "./types.js";

interface ChildResult {
  readonly code: number;
  readonly stdout: string;
  readonly stderr: string;
}

function runChild(command: string, args: readonly string[], input: string | undefined, cwd: string): Promise<ChildResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, stdio: ["pipe", "pipe", "pipe"] });
    const stdout: Buffer[] = [];
    const stderr: Buffer[] = [];
    child.stdout.on("data", (chunk: Buffer) => stdout.push(chunk));
    child.stderr.on("data", (chunk: Buffer) => stderr.push(chunk));
    child.once("error", reject);
    child.once("close", (code) => resolve({ code: code ?? 1, stdout: Buffer.concat(stdout).toString("utf8"), stderr: Buffer.concat(stderr).toString("utf8") }));
    child.stdin.end(input ?? "");
  });
}

function stageTransport(event: z.output<typeof controlledStageEventSchema>): string {
  return `${JSON.stringify(transportRecordSchema.parse({ kind: "transport", protocol: 1, binding: controlledBinding, slot: "controlled", payload: event }))}\n`;
}

async function feedInput(directory: string): Promise<string> {
  const producerPath = join(directory, "producer.py");
  const producer = await runChild("python3", [
    producerPath,
    "--binding", adaptedRichFeedBinding,
    "--binding-label", adaptedRichFeedBindingLabel,
    "--source-binding", richFeedBinding,
    "--adapter-binding", adapterBinding,
  ], undefined, directory);
  if (producer.code !== 0) throw new Error(`producer failed: ${producer.stderr}`);
  return producer.stdout;
}

async function runNegativeTransportCases(directory: string, feed: string): Promise<{
  readonly crossBindingRejected: boolean;
  readonly crossSlotRejected: boolean;
  readonly outOfOrderRejected: boolean;
}> {
  const lines = feed.trim().split("\n");
  const first = lines[0];
  const data = lines.find((line) => line.includes("\"eventId\":\"a-data-0\""));
  if (first === undefined || data === undefined) throw new Error("producer omitted required negative-case frames");
  const crossBinding = await runChild(
    process.execPath,
    ["--import", "tsx", join(directory, "cli.ts"), "project"],
    `${first.replace(adaptedRichFeedBinding, "wrong-binding")}${String.fromCharCode(10)}`,
    directory,
  );
  const crossSlot = await runChild(
    process.execPath,
    ["--import", "tsx", join(directory, "cli.ts"), "project"],
    `${first.replace('"slot":"feed"', '"slot":"controlled"')}${String.fromCharCode(10)}`,
    directory,
  );
  const outOfOrder = await runChild(
    process.execPath,
    ["--import", "tsx", join(directory, "cli.ts"), "project"],
    `${first}${String.fromCharCode(10)}${data.replace('"sequence":1', '"sequence":0')}${String.fromCharCode(10)}`,
    directory,
  );
  return {
    crossBindingRejected: crossBinding.code === 2 && crossBinding.stdout.includes("\"code\":\"binding-mismatch\""),
    crossSlotRejected: crossSlot.code === 2 && crossSlot.stdout.includes("\"code\":\"slot-mismatch\""),
    outOfOrderRejected: outOfOrder.code === 2 && outOfOrder.stdout.includes("\"code\":\"out-of-order\""),
  };
}

async function runStage(directory: string, journal: string): Promise<ChildResult> {
  const prepared = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "prepared", eventId: "stage-prepared", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 0,
    payload: {
      intent: {
        account: "fixture-account", instrument: { source: "fixture", nativeId: "BTC-USD" }, side: "buy", quantity: "1.25",
        pricing: { tag: "limit", price: "99.50" }, session: "regular", postOnly: true, clientReference: "event-stage",
      },
      compiler: "fixture-compiler-v1", planDigest: "plan-1",
    },
  });
  const filled = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "observation", eventId: "stage-filled", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 1,
    payload: { tag: "filled", externalId: "venue-1", quantity: "1.25", averagePrice: "99.50" },
  });
  const transportUnknown = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "observation", eventId: "stage-transport-unknown", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 2,
    payload: { tag: "transport-unknown", reason: "connection lost after conclusive observation" },
  });
  const ack = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "ack", eventId: "stage-ack", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 3,
    payload: { tag: "accepted", externalId: "venue-1" },
  });
  const input = `${stageTransport(prepared)}${stageTransport(filled)}${stageTransport(transportUnknown)}${stageTransport(ack)}${stageTransport(ack)}`;
  return runChild(process.execPath, ["--import", "tsx", join(directory, "cli.ts"), "stage", "--journal", journal], input, directory);
}

async function runStageNegative(directory: string): Promise<{ readonly wrongRevisionRejected: boolean; readonly ackBeforePreparedRejected: boolean }> {
  const ack = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "ack", eventId: "early-ack", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 0,
    payload: { tag: "accepted", externalId: "venue-1" },
  });
  const prepared = controlledStageEventSchema.parse({
    recordKind: "event", domain: "controlled", binding: controlledBinding, bindingLabel: controlledBindingLabel,
    slot: "prepared", eventId: "negative-prepared", intentRevision: "intent-1", attemptId: "attempt-1", sequence: 0,
    payload: {
      intent: {
        account: "fixture-account", instrument: { source: "fixture", nativeId: "BTC-USD" }, side: "buy", quantity: "1.25",
        pricing: { tag: "limit", price: "99.50" }, session: "regular", postOnly: true, clientReference: "negative-stage",
      },
      compiler: "fixture-compiler-v1", planDigest: "plan-negative",
    },
  });
  const wrongRevision = controlledStageEventSchema.parse({
    ...ack, eventId: "wrong-revision", intentRevision: "intent-2", sequence: 1,
  });
  const early = await runChild(process.execPath, ["--import", "tsx", join(directory, "cli.ts"), "stage"], stageTransport(ack), directory);
  const revision = await runChild(process.execPath, ["--import", "tsx", join(directory, "cli.ts"), "stage"], `${stageTransport(prepared)}${stageTransport(wrongRevision)}`, directory);
  return {
    wrongRevisionRejected: revision.code === 2 && revision.stdout.includes("\"code\":\"wrong-revision\""),
    ackBeforePreparedRejected: early.code === 2 && early.stdout.includes("\"code\":\"missing-prepared\""),
  };
}

export async function main(): Promise<number> {
  const directory = fileURLToPath(new URL(".", import.meta.url));
  const evidenceDirectory = process.env.UTA_EVENT_EVIDENCE ?? join(directory, "event-evidence");
  await mkdir(evidenceDirectory, { recursive: true });
  const journal = join(evidenceDirectory, "events.ndjson");
  await rm(journal, { force: true });
  const feed = await feedInput(directory);
  await writeFile(join(evidenceDirectory, "producer.ndjson"), feed, "utf8");
  const negativeCases = await runNegativeTransportCases(directory, feed);
  const stageNegativeCases = await runStageNegative(directory);
  if (!negativeCases.crossBindingRejected || !negativeCases.crossSlotRejected || !negativeCases.outOfOrderRejected || !stageNegativeCases.wrongRevisionRejected || !stageNegativeCases.ackBeforePreparedRejected) {
    throw new Error(`negative case failed: ${JSON.stringify({ negativeCases, stageNegativeCases })}`);
  }
  await writeFile(join(evidenceDirectory, "negative-cases.json"), JSON.stringify({ negativeCases, stageNegativeCases }), "utf8");
  const feedCli = await runChild(process.execPath, ["--import", "tsx", join(directory, "cli.ts"), "project", "--journal", journal], feed, directory);
  await writeFile(join(evidenceDirectory, "feed-cli.ndjson"), feedCli.stdout, "utf8");
  if (feedCli.code !== 0) throw new Error(`feed CLI failed: ${feedCli.stderr}`);
  const stageCli = await runStage(directory, journal);
  await writeFile(join(evidenceDirectory, "stage-cli.ndjson"), stageCli.stdout, "utf8");
  if (stageCli.code !== 0) throw new Error(`stage CLI failed: ${stageCli.stderr}`);
  const reader = await runChild(process.execPath, ["--import", "tsx", join(directory, "reader.ts"), journal], undefined, directory);
  await writeFile(join(evidenceDirectory, "reader.json"), reader.stdout, "utf8");
  if (reader.code !== 0) throw new Error(`reader failed: ${reader.stderr}`);
  const summary = z.json().parse(JSON.parse(reader.stdout.trim()));
  const persisted = await readFile(journal, "utf8");
  const finalSummary = {
    tag: "event-type-specimen-complete",
    reader: summary,
    negativeCases,
    stageNegativeCases,
    stageObservationBeforeAck: stageCli.stdout.includes("stage-filled") && stageCli.stdout.indexOf("stage-filled") < stageCli.stdout.indexOf("stage-ack"),
    journalLines: persisted.trim().split("\n").filter((line) => line.length > 0).length,
    evidenceDirectory,
  };
  await writeFile(join(evidenceDirectory, "summary.json"), JSON.stringify(finalSummary), "utf8");
  process.stdout.write(`${JSON.stringify(finalSummary)}\n`);
  return 0;
}

if (process.argv[1]?.endsWith("/run.ts")) {
  main().then((status) => {
    process.exitCode = status;
  }, (error: unknown) => {
    process.stderr.write(`${error instanceof Error ? error.message : "non-Error failure"}\n`);
    process.exitCode = 2;
  });
}
