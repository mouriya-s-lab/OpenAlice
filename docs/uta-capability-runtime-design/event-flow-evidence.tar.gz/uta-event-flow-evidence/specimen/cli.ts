import { appendFileSync, closeSync, fsyncSync, openSync } from "node:fs";
import { createInterface } from "node:readline";
import { stdin, stdout } from "node:process";
import { z } from "zod";
import {
  adaptedRichFeedBinding,
  adaptedRichFeedBindingLabel,
  baseFeedBinding,
  baseFeedBindingLabel,
  controlledBinding,
} from "./source.js";
import {
  baseFeedJournalRecordSchema,
  diagnosticRecordSchema,
  FeedControlMachine,
  projectRichEventToBase,
  richFeedEventSchema,
  richFeedJournalRecordSchema,
  adaptedRichFeedDefinition,
  baseFeedDefinition,
  StageControlMachine,
  stageJournalRecordSchema,
  transportRecordSchema,
  type JournalRecord,
  type TransportRecord,
} from "./types.js";

const optionSchema = z.strictObject({
  journal: z.string().min(1).optional(),
});

type Mode = "project" | "stage";

function parseOptions(args: readonly string[]): z.output<typeof optionSchema> {
  const journalIndex = args.indexOf("--journal");
  if (journalIndex < 0) return {};
  const journal = args[journalIndex + 1];
  return optionSchema.parse({ journal });
}

function appendRecord(path: string | undefined, record: JournalRecord): void {
  if (path === undefined) return;
  const descriptor = openSync(path, "a");
  try {
    appendFileSync(descriptor, `${JSON.stringify(record)}\n`, "utf8");
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

function emit(value: z.output<typeof diagnosticRecordSchema> | JournalRecord): void {
  stdout.write(`${JSON.stringify(value)}\n`);
}

function parseWireLine(line: string): TransportRecord {
  return transportRecordSchema.parse(JSON.parse(line));
}

function feedProject(journal: string | undefined, line: string, richMachine: FeedControlMachine<typeof adaptedRichFeedDefinition>, baseMachine: FeedControlMachine<typeof baseFeedDefinition>): boolean {
  const wire = parseWireLine(line);
  if (wire.slot !== "feed") {
    emit({ kind: "diagnostic", code: "slot-mismatch", detail: `expected feed, received ${wire.slot}` });
    return false;
  }
  if (wire.binding !== adaptedRichFeedBinding) {
    emit({ kind: "diagnostic", code: "binding-mismatch", detail: wire.binding });
    return false;
  }
  const accepted = richMachine.accept(wire.payload);
  if (accepted.tag === "rejected") {
    emit({ kind: "diagnostic", code: accepted.code, detail: accepted.detail });
    return false;
  }
  if (accepted.evolution === "duplicate") return true;
  const richEvent = richFeedEventSchema.parse(accepted.event);
  const richRecord = richFeedJournalRecordSchema.parse({
    kind: "event",
    domain: "feed-rich",
    bindingLabel: adaptedRichFeedBindingLabel,
    binding: adaptedRichFeedBinding,
    slot: "feed",
    event: richEvent,
  });
  appendRecord(journal, richRecord);
  emit(richRecord);

  const projected = baseMachine.accept(projectRichEventToBase(richEvent));
  if (projected.tag === "rejected") {
    emit({ kind: "diagnostic", code: `projection-${projected.code}`, detail: projected.detail });
    return false;
  }
  if (projected.evolution === "duplicate") return true;
  const baseRecord = baseFeedJournalRecordSchema.parse({
    kind: "event",
    domain: "feed-base",
    bindingLabel: baseFeedBindingLabel,
    binding: baseFeedBinding,
    slot: "feed",
    event: projected.event,
  });
  appendRecord(journal, baseRecord);
  emit(baseRecord);
  return true;
}
function stageAccept(journal: string | undefined, line: string, machine: StageControlMachine): boolean {
  const wire = parseWireLine(line);
  if (wire.slot !== "controlled") {
    emit({ kind: "diagnostic", code: "slot-mismatch", detail: `expected controlled, received ${wire.slot}` });
    return false;
  }
  if (wire.binding !== controlledBinding) {
    emit({ kind: "diagnostic", code: "binding-mismatch", detail: wire.binding });
    return false;
  }
  const outcome = machine.accept(wire.payload);
  if ("tag" in outcome) {
    emit({ kind: "diagnostic", code: outcome.code, detail: outcome.detail });
    return false;
  }
  if (outcome.evolution === "duplicate") return true;
  const record = stageJournalRecordSchema.parse(wire.payload);
  appendRecord(journal, record);
  emit(record);
  return true;
}
export async function main(args: readonly string[]): Promise<number> {
  const operation = args[0];
  const mode: Mode | undefined = operation === "stage" ? "stage" : operation === "project" ? "project" : undefined;
  if (mode === undefined) {
    emit({ kind: "diagnostic", code: "usage", detail: "project|stage [--journal path]" });
    return 2;
  }
  const options = parseOptions(args.slice(1));
  const richMachine = new FeedControlMachine(adaptedRichFeedDefinition);
  const baseMachine = new FeedControlMachine(baseFeedDefinition);
  const stageMachine = new StageControlMachine();
  const lines = createInterface({ input: stdin, crlfDelay: Infinity });
  let rejected = false;
  for await (const line of lines) {
    if (line.trim().length === 0) continue;
    const accepted = mode === "project"
      ? feedProject(options.journal, line, richMachine, baseMachine)
      : stageAccept(options.journal, line, stageMachine);
    if (!accepted) rejected = true;
  }
  return rejected ? 2 : 0;
}

const invoked = process.argv[1];
if (invoked !== undefined && invoked.endsWith("/cli.ts")) {
  main(process.argv.slice(2)).then((status) => {
    process.exitCode = status;
  }, (error: unknown) => {
    emit({ kind: "diagnostic", code: "cli-failure", detail: error instanceof Error ? error.message : "non-Error failure" });
    process.exitCode = 2;
  });
}
