import { spawnSync } from "node:child_process";
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { journalRecordSchema, type JournalRecord } from "./types.js";

interface Mutation {
  readonly name: string;
  readonly expectedError: string;
  readonly change: (record: JournalRecord) => JournalRecord;
}
const directory = fileURLToPath(new URL(".", import.meta.url));
const evidence = join(directory, "event-evidence");
const records = (await readFile(join(evidence, "events.ndjson"), "utf8")).trim().split("\n").map((line) => journalRecordSchema.parse(JSON.parse(line)));
const mutations: readonly Mutation[] = [
  {
    name: "base-value", expectedError: "base payload changed",
    change: (record) => record.domain === "feed-base" && record.event.tag === "Data"
      ? { ...record, event: { ...record.event, payload: { ...record.event.payload, close: "999999" } } } : record,
  },
  {
    name: "source-lineage", expectedError: "source lineage changed",
    change: (record) => record.domain === "feed-base" && record.event.tag === "Data"
      ? { ...record, event: { ...record.event, lineage: { ...record.event.lineage, sourceEventId: "wrong-source-event" } } } : record,
  },
  {
    name: "correction-reference", expectedError: "correction target changed",
    change: (record) => record.domain === "feed-base" && record.event.tag === "Correction"
      ? { ...record, event: { ...record.event, replaces: "wrong-target-event" } } : record,
  },
];
const results = [];
for (const mutation of mutations) {
  const mutated = records.map(mutation.change).map((record) => journalRecordSchema.parse(record));
  if (JSON.stringify(mutated) === JSON.stringify(records)) throw new Error(`No mutation applied: ${mutation.name}`);
  const path = join(evidence, `${mutation.name}.ndjson`);
  await writeFile(path, `${mutated.map((record) => JSON.stringify(record)).join("\n")}\n`);
  const child = spawnSync(process.execPath, ["--import", "tsx", join(directory, "reader.ts"), path], { cwd: directory, encoding: "utf8" });
  if (child.error) throw child.error;
  const rejected = child.status === 2 && child.stderr.includes(mutation.expectedError);
  results.push({ name: mutation.name, rejected, code: child.status, stdout: child.stdout, stderr: child.stderr });
  if (!rejected) throw new Error(`Reader accepted or misclassified ${mutation.name}: ${child.stderr}`);
}
await writeFile(join(evidence, "reader-mutations.json"), `${JSON.stringify(results, null, 2)}\n`);
console.log(JSON.stringify({ schemaValidCorruptionsRejected: results.length, results }));
