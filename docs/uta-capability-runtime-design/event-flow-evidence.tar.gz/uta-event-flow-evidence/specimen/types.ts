import { z } from "zod";
import {
  adapterBinding,
  adapterDeclaration,
  adaptedRichFeedBinding,
  adaptedRichFeedBindingLabel,
  baseFeedBinding,
  baseFeedBindingLabel,
  baseFeedDeclaration,
  controlledBinding,
  controlledBindingLabel,
  controlledStageDeclaration,
  feedFailureSchema,
  feedSourceDeclaration,
  projectRichCandleToBase,
  recoverableItemFailureSchema,
  richCandleSchema,
} from "./source.js";

const eventLineageSchema = z.strictObject({
  sourceBinding: z.string().min(1),
  sourceEventId: z.string().min(1),
  operators: z.array(z.strictObject({
    kind: z.enum(["input-adaptation", "structural-projection"]),
    binding: z.string().min(1),
    version: z.string().min(1),
  })),
});

function eventIdentitySchema<L extends string>(bindingLabel: L, bindingDigest: string) {
  return z.strictObject({
    eventId: z.string().min(1),
    binding: z.literal(bindingDigest),
    bindingLabel: z.literal(bindingLabel),
    source: z.string().min(1),
    generation: z.string().min(1),
    partition: z.string().min(1),
    sequence: z.number().int().nonnegative(),
    lineage: eventLineageSchema,
  });
}

function feedEventSchema<L extends string, P extends z.ZodType, F extends z.ZodType>(
  bindingLabel: L,
  bindingDigest: string,
  payload: P,
  failure: F,
) {
  const identity = eventIdentitySchema(bindingLabel, bindingDigest);
  return z.discriminatedUnion("tag", [
    identity.extend({ tag: z.literal("Started") }),
    identity.extend({ tag: z.literal("Data"), payload }),
    identity.extend({ tag: z.literal("Correction"), replaces: z.string().min(1), payload }),
    identity.extend({ tag: z.literal("Retraction"), retracts: z.string().min(1), reason: z.string().min(1) }),
    identity.extend({
      tag: z.literal("Gap"),
      fromSequence: z.number().int().nonnegative(),
      toSequence: z.number().int().nonnegative(),
      reason: z.string().min(1),
    }),
    identity.extend({
      tag: z.literal("SnapshotEnd"),
      snapshotId: z.string().min(1),
      continuation: z.string().nullable(),
    }),
    identity.extend({ tag: z.literal("ItemFailure"), failure: recoverableItemFailureSchema }),
    identity.extend({ tag: z.literal("Completed") }),
    identity.extend({ tag: z.literal("Failed"), failure }),
    identity.extend({ tag: z.literal("Cancelled"), reason: z.string().min(1) }),
  ]);
}

export const richFeedEventSchema = feedEventSchema(adaptedRichFeedBindingLabel, adaptedRichFeedBinding, richCandleSchema, feedFailureSchema);
export const baseFeedEventSchema = feedEventSchema(baseFeedBindingLabel, baseFeedBinding, baseFeedDeclaration.payload, baseFeedDeclaration.failure);

export type RichFeedEvent = z.output<typeof richFeedEventSchema>;
export type BaseFeedEvent = z.output<typeof baseFeedEventSchema>;
export type FeedTag = RichFeedEvent["tag"];
export type NonterminalFeedEvent = Exclude<RichFeedEvent, { tag: "Completed" | "Failed" | "Cancelled" }>;
export type TerminalFeedEvent = Extract<RichFeedEvent, { tag: "Completed" | "Failed" | "Cancelled" }>;
export interface FeedEventEnvelope {
  readonly tag: string;
  readonly eventId: string;
  readonly binding: string;
  readonly bindingLabel: string;
  readonly source: string;
  readonly generation: string;
  readonly partition: string;
  readonly sequence: number;
  readonly lineage: z.output<typeof eventLineageSchema>;
}

export type FeedEventSchema<L extends string, P extends z.ZodType, F extends z.ZodType> =
  FeedDefinition<L, P, F>["schema"];
export type DerivedFeedEvent<L extends string, P extends z.ZodType, F extends z.ZodType> =
  z.output<FeedEventSchema<L, P, F>>;

export class FeedDefinition<L extends string, P extends z.ZodType, F extends z.ZodType> {
  readonly bindingLabel: L;
  readonly binding: string;
  readonly payload: P;
  readonly failure: F;
  readonly #schema;

  private constructor(bindingLabel: L, binding: string, payload: P, failure: F) {
    this.bindingLabel = bindingLabel;
    this.binding = binding;
    this.payload = payload;
    this.failure = failure;
    this.#schema = feedEventSchema(bindingLabel, binding, payload, failure);
  }

  static create<L extends string, P extends z.ZodType, F extends z.ZodType>(
    bindingLabel: L,
    binding: string,
    payload: P,
    failure: F,
  ): FeedDefinition<L, P, F> {
    return new FeedDefinition(bindingLabel, binding, payload, failure);
  }

  get schema() {
    return this.#schema;
  }
}

export function defineFeed<L extends string, P extends z.ZodType, F extends z.ZodType>(
  bindingLabel: L,
  binding: string,
  payload: P,
  failure: F,
) {
  return FeedDefinition.create(bindingLabel, binding, payload, failure);
}

export const richFeedDefinition = defineFeed(adaptedRichFeedBindingLabel, adaptedRichFeedBinding, richCandleSchema, feedFailureSchema);
export const adaptedRichFeedDefinition = richFeedDefinition;
export const baseFeedDefinition = defineFeed(baseFeedBindingLabel, baseFeedBinding, baseFeedDeclaration.payload, baseFeedDeclaration.failure);

export const projectionOperator = Object.freeze({
  kind: "structural-projection",
  binding: baseFeedBinding,
  version: "rich-candle-to-base-v1",
}) satisfies z.output<typeof eventLineageSchema>["operators"][number];

function projectedEventId(sourceEventId: string): string {
  return `${sourceEventId}::${projectionOperator.version}`;
}

function projectedLineage(event: RichFeedEvent): z.output<typeof eventLineageSchema> {
  return {
    sourceBinding: event.binding,
    sourceEventId: event.eventId,
    operators: [...event.lineage.operators, projectionOperator],
  };
}

function projectedIdentity(event: RichFeedEvent) {
  return {
    eventId: projectedEventId(event.eventId),
    binding: baseFeedBinding,
    bindingLabel: baseFeedBindingLabel,
    source: event.source,
    generation: event.generation,
    partition: event.partition,
    sequence: event.sequence,
    lineage: projectedLineage(event),
  };
}

/**
 * Total control projection. Every control tag is preserved exactly once; only
 * declared rich payloads and references are projected.
 */
export function projectRichEventToBase(event: RichFeedEvent): BaseFeedEvent {
  const identity = projectedIdentity(event);
  switch (event.tag) {
    case "Started":
      return baseFeedEventSchema.parse({ ...identity, tag: "Started" });
    case "Data":
      return baseFeedEventSchema.parse({ ...identity, tag: "Data", payload: projectRichCandleToBase(event.payload) });
    case "Correction":
      return baseFeedEventSchema.parse({
        ...identity,
        tag: "Correction",
        replaces: projectedEventId(event.replaces),
        payload: projectRichCandleToBase(event.payload),
      });
    case "Retraction":
      return baseFeedEventSchema.parse({ ...identity, tag: "Retraction", retracts: projectedEventId(event.retracts), reason: event.reason });
    case "Gap":
      return baseFeedEventSchema.parse({ ...identity, tag: "Gap", fromSequence: event.fromSequence, toSequence: event.toSequence, reason: event.reason });
    case "SnapshotEnd":
      return baseFeedEventSchema.parse({ ...identity, tag: "SnapshotEnd", snapshotId: event.snapshotId, continuation: event.continuation });
    case "ItemFailure":
      return baseFeedEventSchema.parse({ ...identity, tag: "ItemFailure", failure: event.failure });
    case "Completed":
      return baseFeedEventSchema.parse({ ...identity, tag: "Completed" });
    case "Failed":
      return baseFeedEventSchema.parse({ ...identity, tag: "Failed", failure: event.failure });
    case "Cancelled":
      return baseFeedEventSchema.parse({ ...identity, tag: "Cancelled", reason: event.reason });
  }
}

export interface SeenEvent {
  readonly eventId: string;
  readonly sequence: number;
  readonly source: string;
  readonly generation: string;
  readonly partition: string;
  readonly tag: string;
  readonly encoded: string;
}

export type FeedPhase = "active" | "terminal";

export interface FeedPartitionState<Event> {
  readonly source: string;
  readonly partition: string;
  readonly generation: string;
  readonly phase: FeedPhase;
  readonly latestSequence: number;
  readonly seen: readonly SeenEvent[];
  readonly history: readonly Event[];
}

export type FeedRejectionCode =
  | "invalid-event"
  | "binding-mismatch"
  | "missing-start"
  | "duplicate-id-conflict"
  | "out-of-order"
  | "duplicate-start"
  | "after-terminal"
  | "unknown-correction-target"
  | "unknown-retraction-target"
  | "invalid-gap-range";

export type FeedAcceptance<Event> =
  | { readonly tag: "accepted"; readonly evolution: "advanced" | "duplicate"; readonly event: Event; readonly state: FeedPartitionState<Event> }
  | { readonly tag: "rejected"; readonly code: FeedRejectionCode; readonly detail: string };

interface MutablePartition<Event> {
  readonly source: string;
  readonly partition: string;
  readonly generation: string;
  phase: FeedPhase;
  latestSequence: number;
  seen: SeenEvent[];
  history: Event[];
}

function terminalTag(tag: string): boolean {
  return tag === "Completed" || tag === "Failed" || tag === "Cancelled";
}

function publicState<Event>(state: MutablePartition<Event>): FeedPartitionState<Event> {
  return {
    source: state.source,
    partition: state.partition,
    generation: state.generation,
    phase: state.phase,
    latestSequence: state.latestSequence,
    seen: [...state.seen],
    history: [...state.history],
  };
}

function targetFact(seen: SeenEvent[], event: FeedEventEnvelope, target: string): boolean {
  return seen.some((candidate) =>
    candidate.eventId === target &&
    (candidate.tag === "Data" || candidate.tag === "Correction") &&
    candidate.source === event.source &&
    candidate.generation === event.generation &&
    candidate.partition === event.partition,
  );
}

/** One generic machine is instantiated for both rich and base event schemas. */
export class FeedControlMachine<D extends FeedDefinition<string, z.ZodType, z.ZodType>> {
  readonly #definition: D;
  readonly #partitions: MutablePartition<z.output<D["schema"]>>[] = [];

  constructor(definition: D) {
    this.#definition = definition;
  }

  accept(raw: unknown): FeedAcceptance<z.output<D["schema"]>> {
    const decoded = z.safeParse<D["schema"]>(this.#definition.schema, raw);
    if (!decoded.success) return { tag: "rejected", code: "invalid-event", detail: decoded.error.message };
    const event = decoded.data;
    if (event.binding !== this.#definition.binding || event.bindingLabel !== this.#definition.bindingLabel) {
      return { tag: "rejected", code: "binding-mismatch", detail: `${event.bindingLabel}/${event.binding}` };
    }

    const existing = this.#partitions.find((candidate) =>
      candidate.source === event.source &&
      candidate.partition === event.partition &&
      candidate.generation === event.generation,
    );
    const encoded = JSON.stringify(event);
    if (existing === undefined) {
      if (event.tag !== "Started") return { tag: "rejected", code: "missing-start", detail: event.eventId };
      const created: MutablePartition<z.output<D["schema"]>> = {
        source: event.source,
        partition: event.partition,
        generation: event.generation,
        phase: "active",
        latestSequence: event.sequence,
        seen: [{ eventId: event.eventId, sequence: event.sequence, source: event.source, generation: event.generation, partition: event.partition, tag: event.tag, encoded }],
        history: [event],
      };
      this.#partitions.push(created);
      return { tag: "accepted", evolution: "advanced", event, state: publicState(created) };
    }

    const seen = existing.seen.find((candidate) => candidate.eventId === event.eventId);
    if (seen !== undefined) {
      if (seen.encoded !== encoded) return { tag: "rejected", code: "duplicate-id-conflict", detail: event.eventId };
      return { tag: "accepted", evolution: "duplicate", event, state: publicState(existing) };
    }
    if (event.sequence <= existing.latestSequence) {
      return { tag: "rejected", code: "out-of-order", detail: `${event.sequence} <= ${existing.latestSequence}` };
    }
    if (event.tag === "Started") return { tag: "rejected", code: "duplicate-start", detail: event.eventId };
    if (existing.phase === "terminal") return { tag: "rejected", code: "after-terminal", detail: event.eventId };
    if (event.tag === "Correction" && !targetFact(existing.seen, event, event.replaces)) {
      return { tag: "rejected", code: "unknown-correction-target", detail: event.replaces };
    }
    if (event.tag === "Retraction" && !targetFact(existing.seen, event, event.retracts)) {
      return { tag: "rejected", code: "unknown-retraction-target", detail: event.retracts };
    }
    if (event.tag === "Gap" && event.fromSequence > event.toSequence) {
      return { tag: "rejected", code: "invalid-gap-range", detail: `${event.fromSequence} > ${event.toSequence}` };
    }

    existing.seen.push({ eventId: event.eventId, sequence: event.sequence, source: event.source, generation: event.generation, partition: event.partition, tag: event.tag, encoded });
    existing.history.push(event);
    existing.latestSequence = event.sequence;
    if (terminalTag(event.tag)) existing.phase = "terminal";
    return { tag: "accepted", evolution: "advanced", event, state: publicState(existing) };
  }

  states(): readonly FeedPartitionState<z.output<D["schema"]>>[] {
    return this.#partitions.map(publicState);
  }
}

const stageIdentitySchema = z.strictObject({
  recordKind: z.literal("event"),
  domain: z.literal("controlled"),
  binding: z.literal(controlledBinding),
  bindingLabel: z.literal(controlledBindingLabel),
  eventId: z.string().min(1),
  intentRevision: z.string().min(1),
  attemptId: z.string().min(1),
  sequence: z.number().int().nonnegative(),
});

export const controlledStageEventSchema = z.discriminatedUnion("slot", [
  stageIdentitySchema.extend({ slot: z.literal("prepared"), payload: controlledStageDeclaration.slots.prepared }),
  stageIdentitySchema.extend({ slot: z.literal("ack"), payload: controlledStageDeclaration.slots.ack }),
  stageIdentitySchema.extend({ slot: z.literal("observation"), payload: controlledStageDeclaration.slots.observation }),
  stageIdentitySchema.extend({ slot: z.literal("failure"), payload: controlledStageDeclaration.slots.failure }),
]);
export type ControlledStageEvent = z.output<typeof controlledStageEventSchema>;
export type StageSlot = ControlledStageEvent["slot"];

export const commandRecordSchema = z.discriminatedUnion("command", [
  z.strictObject({ kind: z.literal("command"), command: z.literal("subscribe"), binding: z.string().min(1), requestId: z.string().min(1) }),
  z.strictObject({ kind: z.literal("command"), command: z.literal("replay"), binding: z.string().min(1), requestId: z.string().min(1) }),
]);
export type CommandRecord = z.output<typeof commandRecordSchema>;

export const workRecordSchema = z.discriminatedUnion("work", [
  z.strictObject({ kind: z.literal("work"), work: z.literal("decode-feed-frame"), binding: z.string().min(1), requestId: z.string().min(1) }),
  z.strictObject({ kind: z.literal("work"), work: z.literal("project-base-event"), binding: z.string().min(1), requestId: z.string().min(1) }),
]);
export type WorkRecord = z.output<typeof workRecordSchema>;

export const transportRecordSchema = z.strictObject({
  kind: z.literal("transport"),
  protocol: z.literal(1),
  binding: z.string().min(1),
  slot: z.enum(["feed", "controlled"]),
  payload: z.json(),
});
export type TransportRecord = z.output<typeof transportRecordSchema>;

export const diagnosticRecordSchema = z.strictObject({
  kind: z.literal("diagnostic"),
  code: z.string().min(1),
  detail: z.string().min(1),
});
export type DiagnosticRecord = z.output<typeof diagnosticRecordSchema>;

export const richFeedJournalRecordSchema = z.strictObject({
  kind: z.literal("event"),
  domain: z.literal("feed-rich"),
  bindingLabel: z.literal(adaptedRichFeedBindingLabel),
  binding: z.literal(adaptedRichFeedBinding),
  slot: z.literal("feed"),
  event: richFeedEventSchema,
});
export const baseFeedJournalRecordSchema = z.strictObject({
  kind: z.literal("event"),
  domain: z.literal("feed-base"),
  bindingLabel: z.literal(baseFeedBindingLabel),
  binding: z.literal(baseFeedBinding),
  slot: z.literal("feed"),
  event: baseFeedEventSchema,
});
export const stageJournalRecordSchema = controlledStageEventSchema;
export const journalRecordSchema = z.union([richFeedJournalRecordSchema, baseFeedJournalRecordSchema, stageJournalRecordSchema]);
export type JournalRecord = z.output<typeof journalRecordSchema>;
export interface StageState {
  readonly phase: "prepared" | "observing" | "concluded";
  readonly conclusion: "filled" | "rejected" | "transport-unknown" | null;
  readonly evolution: "advanced" | "duplicate";
  readonly intentRevision: string;
  readonly attemptId: string;
  readonly history: readonly ControlledStageEvent[];
}

interface StageSeen {
  readonly eventId: string;
  readonly encoded: string;
}

/** Prepared is the aggregate barrier; late Ack never regresses a conclusion. */
export class StageControlMachine {
  readonly #binding: string;
  readonly #bindingLabel: string;
  readonly #events: ControlledStageEvent[] = [];
  readonly #seen: StageSeen[] = [];
  #phase: StageState["phase"] = "prepared";
  #conclusion: StageState["conclusion"] = null;
  #intentRevision: string | undefined;
  #attemptId: string | undefined;
  #latestSequence = -1;

  constructor(binding: string = controlledBinding, bindingLabel: string = controlledBindingLabel) {
    this.#binding = binding;
    this.#bindingLabel = bindingLabel;
  }

  accept(raw: unknown): StageState | {
    readonly tag: "rejected";
    readonly code: "invalid" | "binding-mismatch" | "wrong-revision" | "wrong-attempt" | "out-of-order" | "duplicate-id-conflict" | "missing-prepared" | "duplicate-prepared" | "after-conclusion";
    readonly detail: string;
  } {
    const decoded = controlledStageEventSchema.safeParse(raw);
    if (!decoded.success) return { tag: "rejected", code: "invalid", detail: decoded.error.message };
    const event = decoded.data;
    if (event.binding !== this.#binding || event.bindingLabel !== this.#bindingLabel) {
      return { tag: "rejected", code: "binding-mismatch", detail: `${event.bindingLabel}/${event.binding}` };
    }
    if (this.#intentRevision !== undefined && event.intentRevision !== this.#intentRevision) {
      return { tag: "rejected", code: "wrong-revision", detail: event.intentRevision };
    }
    if (this.#attemptId !== undefined && event.attemptId !== this.#attemptId) {
      return { tag: "rejected", code: "wrong-attempt", detail: event.attemptId };
    }
    const encoded = JSON.stringify(event);
    const prior = this.#seen.find((candidate) => candidate.eventId === event.eventId);
    if (prior !== undefined) {
      if (prior.encoded !== encoded) return { tag: "rejected", code: "duplicate-id-conflict", detail: event.eventId };
      return this.current("duplicate");
    }
    if (this.#events.length === 0 && event.slot !== "prepared") {
      return { tag: "rejected", code: "missing-prepared", detail: event.slot };
    }
    if (event.sequence <= this.#latestSequence) return { tag: "rejected", code: "out-of-order", detail: `${event.sequence} <= ${this.#latestSequence}` };
    if (event.slot === "prepared" && this.#events.length > 0) return { tag: "rejected", code: "duplicate-prepared", detail: event.eventId };
    if (this.#conclusion !== null && event.slot !== "ack" && !(event.slot === "observation" && event.payload.tag === "transport-unknown")) {
      return { tag: "rejected", code: "after-conclusion", detail: event.eventId };
    }
    this.#intentRevision ??= event.intentRevision;
    this.#attemptId ??= event.attemptId;
    this.#seen.push({ eventId: event.eventId, encoded });
    this.#events.push(event);
    this.#latestSequence = event.sequence;
    if (event.slot === "observation") {
      if (event.payload.tag === "working") this.#phase = "observing";
      if (event.payload.tag === "filled" || event.payload.tag === "rejected" || event.payload.tag === "transport-unknown") {
        if (this.#conclusion === null) this.#conclusion = event.payload.tag;
        this.#phase = "concluded";
      }
    }
    return this.current("advanced");
  }

  private current(evolution: StageState["evolution"]): StageState {
    return {
      phase: this.#phase,
      conclusion: this.#conclusion,
      evolution,
      intentRevision: this.#intentRevision ?? "",
      attemptId: this.#attemptId ?? "",
      history: [...this.#events],
    };
  }
}

export const declaredAdapterBinding = adapterBinding;
export const declaredAdapter = adapterDeclaration;
export const declaredFeedBinding = feedSourceDeclaration.binding;
export const declaredControlledBinding = controlledBinding;
