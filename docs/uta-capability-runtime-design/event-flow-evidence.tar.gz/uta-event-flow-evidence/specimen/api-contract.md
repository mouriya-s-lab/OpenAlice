# 事件声明、交付与持久关系实验

本目录是设计的从属可执行证据，不是生产 UTA。它不读取用户账户、Broker 凭据或配置，不连接真实 Provider。

## 单一声明与构造边界

`source.ts` 拥有基础/扩展 Candle、Provider Order、可恢复单项错误、来源终态错误及 controlled 阶段的全部 payload schema。Feed digest 包含 item、终态错误、单项错误；controlled digest 包含输入与全部阶段槽位。这是固定本地声明 profile 的摘要，不是完整 RFC 8785 或生产 capability certification。

`types.ts` 的 `FeedDefinition` 私有构造函数从槽位生成私有 schema；调用者不能提交另一份 event schema。`FeedEventSchema` 与 `DerivedFeedEvent` 从该拥有者的 schema 推导，不维护第二份事件 DTO。静态 literal label 区分同形声明，运行时 parser 校验 digest。`FeedControlMachine` 用同一实现处理 rich 与 base，保持来源/分区/代际的接纳、重复、修订引用和终态约束。

所有 frame 在这个固定 fixture profile 下都带来源 lineage；这是样例提供的字段，不是主设计对所有 Started/Terminal 的通用要求。source sequence 也是这个生产者声明的局部顺序，不是原生交易所承诺。

`projectRichEventToBase` 是穷尽的总投影：只从 Data/Correction 的 payload 去掉 vwap/trades/nativeEvent，重新绑定事件身份与引用，保留控制、基础值及因果来源。`reader.ts` 在新进程检查持久记录的16组配对关系；它不调用被测事件投影函数生成期望值。

## 实际运行路径

在归档根目录安装锁定依赖后运行：

```sh
node verify-evidence.mjs
```

可单独执行实际入口：

```sh
node --import tsx specimen/run.ts
node --import tsx specimen/reader.ts specimen/event-evidence/events.ndjson
node --import tsx specimen/reader-mutations.ts
node --import tsx specimen/composition.ts
```

`run.ts` 启动独立 Python 生产者，再启动 CLI。17帧包含一次重复 Data；CLI 记录16条 rich 事件及16条 base 派生事件。三个分区交错，SnapshotEnd 后继续修订/撤回；终态分别为 Cancelled、Failed、Completed。ItemFailure 只表示可恢复单项错误，不代替已关闭来源的 Failed。

窄 controlled 路径记录 prepared、filled observation、transport-unknown observation、late ack；重复 ack 不追加。reader 重新解析全部槽位、intent revision、attempt，保留 filled 结论。此实验没有 native send、授权、DispatchGrant 或完整交易判据。

CLI 逐条追加并 fsync；它先完成文件写入再输出相应已记录事件。普通 transport、command、work 和 diagnostic 不进入此文件。rich/base 两条记录不是同一个数据库事务，不据此承诺跨记录崩溃原子性。

## 反例与输出

- `type-cases.ts` 的8项消费者误用经严格编译及移除 expect-error 的独立编译验证。
- CLI 拒绝跨 binding、跨 slot、乱序、wrong revision、ack-before-prepared 五类输入。
- `reader-mutations.ts` 产生三份仍可通过单条 schema 的损坏文件：基础值变化、错误 source lineage、错误 correction target。新 reader 进程必须分别拒绝。
- `composition.ts` 完整执行五组有限 merge 场景，见 `composition-guide.md`。

`specimen/event-evidence/` 保存生产输入、CLI输出、主 journal、reader结果、负面输入/结果；重新运行会更新该实验自己的文件。每轮执行器的 stdout/stderr/退出码另存于独立 `verification-run-*`，不隐藏工具链诊断。

未证明：生产 Provider 接入、原生 Push/credit/replay、并发 writer、真实授权、真实成交/补偿、R/P与资源拥有权联合、完整 filter/window/join、Alice 持久接纳或配置/迁移运行时。设计的这些义务仍完整保留。
