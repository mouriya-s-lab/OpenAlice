import { readFile } from "node:fs/promises";
import { z } from "zod";
import {
  adaptedRichFeedBinding,
  adaptedRichFeedBindingLabel,
  baseFeedBinding,
  baseFeedBindingLabel,
  candleBaseSchema,
  controlledBinding,
  controlledBindingLabel,
} from "./source.js";
import {
  journalRecordSchema,
  type BaseFeedEvent,
  type JournalRecord,
  type RichFeedEvent,
} from "./types.js";
interface PartitionOrder {
  readonly domain: "feed-rich" | "feed-base";
  readonly source: string;
  readonly partition: string;
  readonly generation: string;
  readonly sequences: number[];
}

interface TerminalSeen {
  readonly domain: "feed-rich" | "feed-base";
  readonly source: string;
  readonly partition: string;
  readonly generation: string;
  readonly tag: "Completed" | "Failed" | "Cancelled";
}

function ensureTerminalOrder(terminals: TerminalSeen[], domain: TerminalSeen["domain"], source: string, partition: string, generation: string, tag: string): void {
  const previous = terminals.find((item) => item.domain === domain && item.source === source && item.partition === partition && item.generation === generation);
  if (previous !== undefined) throw new Error(`event after terminal: ${domain}/${source}/${partition}/${previous.tag} -> ${tag}`);
  if (tag === "Completed" || tag === "Failed" || tag === "Cancelled") terminals.push({ domain, source, partition, generation, tag });
}

function rememberOrder(orders: PartitionOrder[], domain: PartitionOrder["domain"], source: string, partition: string, generation: string, sequence: number): void {
  const found = orders.find((item) => item.domain === domain && item.source === source && item.partition === partition && item.generation === generation);
  if (found === undefined) {
    orders.push({ domain, source, partition, generation, sequences: [sequence] });
    return;
  }
  const prior = found.sequences.at(-1);
  if (prior !== undefined && sequence <= prior) throw new Error(`persisted sequence regressed: ${domain}/${source}/${partition} ${sequence} <= ${prior}`);
  found.sequences.push(sequence);
}

function richTags(records: readonly JournalRecord[]): readonly string[] {
  return records
    .filter((record): record is Extract<JournalRecord, { domain: "feed-rich" }> => "kind" in record && record.kind === "event" && record.domain === "feed-rich")
    .map((record) => record.event.tag);
}

function baseTags(records: readonly JournalRecord[]): readonly string[] {
  return records
    .filter((record): record is Extract<JournalRecord, { domain: "feed-base" }> => "kind" in record && record.kind === "event" && record.domain === "feed-base")
    .map((record) => record.event.tag);
}

function checkRichLineage(event: RichFeedEvent): void {
  if (event.binding !== adaptedRichFeedBinding || event.bindingLabel !== adaptedRichFeedBindingLabel) throw new Error(`rich binding mismatch: ${event.eventId}`);
  if (event.lineage.sourceBinding === event.binding) throw new Error(`rich event lost source binding: ${event.eventId}`);
  if (!event.lineage.operators.some((operator) => operator.kind === "input-adaptation")) throw new Error(`adapter lineage missing: ${event.eventId}`);
}

function checkBaseLineage(event: BaseFeedEvent): void {
  if (event.binding !== baseFeedBinding || event.bindingLabel !== baseFeedBindingLabel) throw new Error(`base binding mismatch: ${event.eventId}`);
  if (event.lineage.sourceBinding === event.binding) throw new Error(`base event masquerades as source: ${event.eventId}`);
  if (!event.lineage.operators.some((operator) => operator.kind === "structural-projection")) throw new Error(`projection lineage missing: ${event.eventId}`);
}

function checkProjectionRelations(records: readonly JournalRecord[]): number {
  const rich = records.flatMap((record) => record.domain === "feed-rich" ? [record.event] : []);
  const base = records.flatMap((record) => record.domain === "feed-base" ? [record.event] : []);
  if (rich.length !== base.length) throw new Error("projection cardinality changed");
  for (const [index, source] of rich.entries()) {
    const projected = base[index];
    if (projected === undefined) throw new Error("projected event missing");
    if (projected.lineage.sourceBinding !== source.binding || projected.lineage.sourceEventId !== source.eventId || projected.eventId === source.eventId) {
      throw new Error("source lineage changed");
    }
    if (projected.source !== source.source || projected.generation !== source.generation || projected.partition !== source.partition || projected.sequence !== source.sequence || projected.tag !== source.tag) {
      throw new Error("source ordering boundary changed");
    }
    if ((source.tag === "Data" || source.tag === "Correction") && (projected.tag === "Data" || projected.tag === "Correction")) {
      if (JSON.stringify(candleBaseSchema.strip().parse(source.payload)) !== JSON.stringify(projected.payload)) throw new Error("base payload changed");
    }
    if (source.tag === "Correction" && projected.tag === "Correction") {
      const target = base.find((event) => event.eventId === projected.replaces && (event.tag === "Data" || event.tag === "Correction"));
      if (target?.lineage.sourceEventId !== source.replaces) throw new Error("correction target changed");
    }
    if (source.tag === "Retraction" && projected.tag === "Retraction") {
      const target = base.find((event) => event.eventId === projected.retracts && (event.tag === "Data" || event.tag === "Correction"));
      if (target?.lineage.sourceEventId !== source.retracts) throw new Error("retraction target changed");
    }
    if (source.tag === "Gap" && projected.tag === "Gap" && (source.fromSequence !== projected.fromSequence || source.toSequence !== projected.toSequence || source.reason !== projected.reason)) throw new Error("gap evidence changed");
    if (source.tag === "SnapshotEnd" && projected.tag === "SnapshotEnd" && (source.snapshotId !== projected.snapshotId || source.continuation !== projected.continuation)) throw new Error("snapshot boundary changed");
    if ((source.tag === "Failed" || source.tag === "ItemFailure") && (projected.tag === "Failed" || projected.tag === "ItemFailure") && JSON.stringify(source.failure) !== JSON.stringify(projected.failure)) throw new Error("typed failure changed");
    if (source.tag === "Cancelled" && projected.tag === "Cancelled" && source.reason !== projected.reason) throw new Error("cancellation reason changed");
  }
  return rich.length;
}


function readLines(raw: string): readonly JournalRecord[] {
  return raw.split("\n").filter((line) => line.length > 0).map((line) => journalRecordSchema.parse(JSON.parse(line)));
}

export async function readTypedJournal(path: string): Promise<{
  readonly recordCount: number;
  readonly projectionRelationsChecked: number;
  readonly richTags: readonly string[];
  readonly baseTags: readonly string[];
  readonly terminalTags: readonly string[];
  readonly stageSlots: readonly string[];
  readonly stageObservationTags: readonly string[];
  readonly stageConclusion: "filled" | "rejected" | "transport-unknown" | null;
  readonly stageIntentRevision: string | null;
  readonly stageAttemptId: string | null;
  readonly partitions: readonly PartitionOrder[];
  readonly slotsReassociated: boolean;
}> {
  const records = readLines(await readFile(path, "utf8"));
  const orders: PartitionOrder[] = [];
  const terminalTags: string[] = [];
  const terminals: TerminalSeen[] = [];
  const stageSlots: string[] = [];
  const stageObservationTags: string[] = [];
  let stageConclusion: "filled" | "rejected" | "transport-unknown" | null = null;
  let stageIntentRevision: string | null = null;
  let stageAttemptId: string | null = null;
  let latestStageSequence = -1;
  let richCount = 0;
  let baseCount = 0;
  for (const record of records) {
    if ("kind" in record && record.kind === "event" && record.domain === "feed-rich") {
      richCount += 1;
      rememberOrder(orders, "feed-rich", record.event.source, record.event.partition, record.event.generation, record.event.sequence);
      ensureTerminalOrder(terminals, "feed-rich", record.event.source, record.event.partition, record.event.generation, record.event.tag);
      checkRichLineage(record.event);
      if (record.event.tag === "Completed" || record.event.tag === "Failed" || record.event.tag === "Cancelled") terminalTags.push(record.event.tag);
    } else if ("kind" in record && record.kind === "event" && record.domain === "feed-base") {
      baseCount += 1;
      rememberOrder(orders, "feed-base", record.event.source, record.event.partition, record.event.generation, record.event.sequence);
      ensureTerminalOrder(terminals, "feed-base", record.event.source, record.event.partition, record.event.generation, record.event.tag);
      checkBaseLineage(record.event);
    } else if ("recordKind" in record) {
      if (record.binding !== controlledBinding || record.bindingLabel !== controlledBindingLabel) throw new Error(`stage binding mismatch: ${record.bindingLabel}/${record.binding}`);
      if (record.sequence <= latestStageSequence) throw new Error(`stage sequence regressed: ${record.sequence} <= ${latestStageSequence}`);
      latestStageSequence = record.sequence;
      if (stageIntentRevision === null) stageIntentRevision = record.intentRevision;
      if (stageAttemptId === null) stageAttemptId = record.attemptId;
      if (stageIntentRevision !== record.intentRevision || stageAttemptId !== record.attemptId) throw new Error("stage revision or attempt changed");
      stageSlots.push(record.slot);
      if (record.slot === "observation") {
        stageObservationTags.push(record.payload.tag);
        if (record.payload.tag === "filled" || record.payload.tag === "rejected" || record.payload.tag === "transport-unknown") {
          if (stageConclusion === null || stageConclusion === "transport-unknown") stageConclusion = record.payload.tag;
        }
      }
    }
  }
  const rich = richTags(records);
  const base = baseTags(records);
  if (JSON.stringify(rich) !== JSON.stringify(base)) throw new Error("base projection changed control tags/order");
  if (richCount !== baseCount) throw new Error(`projection cardinality changed: ${richCount} != ${baseCount}`);
  const projectionRelationsChecked = checkProjectionRelations(records);
  const requiredTags = ["Data", "Correction", "Retraction", "Gap", "SnapshotEnd", "ItemFailure", "Completed", "Failed", "Cancelled"];
  if (!requiredTags.every((tag) => rich.includes(tag))) throw new Error("required Feed event tag missing");
  const hasSnapshotEnd = rich.includes("SnapshotEnd");
  const hasPostSnapshotDataOrRevision = rich.some((tag, index) => tag === "SnapshotEnd" && rich.slice(index + 1).some((later) => later === "Data" || later === "Correction" || later === "Retraction"));
  if (!hasSnapshotEnd || !hasPostSnapshotDataOrRevision) throw new Error("SnapshotEnd was treated as terminal");
  if (stageObservationTags.includes("filled") && stageConclusion !== "filled") throw new Error("stage conclusion regressed after Filled");
  return {
    recordCount: records.length,
    projectionRelationsChecked,
    richTags: rich,
    baseTags: base,
    terminalTags,
    stageSlots,
    stageObservationTags,
    stageConclusion,
    stageIntentRevision,
    stageAttemptId,
    partitions: orders,
    slotsReassociated: richCount === baseCount && rich.every((tag, index) => base[index] === tag),
  };
}

const path = process.argv[2];
if (path !== undefined && process.argv[1]?.endsWith("/reader.ts")) {
  readTypedJournal(path).then((summary) => {
    process.stdout.write(`${JSON.stringify(summary)}\n`);
  }, (error: unknown) => {
    process.stderr.write(`${error instanceof Error ? error.message : "non-Error failure"}\n`);
    process.exitCode = 2;
  });
}
