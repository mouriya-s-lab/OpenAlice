import { createHash } from "node:crypto";
import { z } from "zod";

/**
 * This file is the only payload declaration owned by this specimen.  Event
 * envelopes below consume these schemas; they do not repeat the candle/order
 * fields as a second DTO.
 */

export const decimal = z.string().regex(/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/);
export const nonnegativeDecimal = z.string().regex(/^(?:0|[1-9]\d*)(?:\.\d+)?$/);
export const positiveDecimal = z.string().regex(/^(?:[1-9]\d*(?:\.\d+)?|0\.\d*[1-9]\d*)$/);

export const instrumentSchema = z.strictObject({
  source: z.string().min(1),
  nativeId: z.string().min(1),
});

export const candleBaseSchema = z.strictObject({
  source: z.string().min(1),
  generation: z.string().min(1),
  instrument: instrumentSchema,
  interval: z.literal("1m"),
  openedAt: z.iso.datetime(),
  open: decimal,
  high: decimal,
  low: decimal,
  close: decimal,
  volume: z.strictObject({
    amount: nonnegativeDecimal,
    unit: z.literal("base-asset"),
    evidence: z.string().min(1),
  }),
  timezone: z.literal("UTC"),
  session: z.literal("continuous"),
  adjustment: z.literal("unadjusted"),
  finality: z.discriminatedUnion("tag", [
    z.strictObject({ tag: z.literal("provisional"), reason: z.string() }),
    z.strictObject({ tag: z.literal("closed"), evidence: z.string() }),
    z.strictObject({ tag: z.literal("unknown"), reason: z.string() }),
  ]),
  revision: z.discriminatedUnion("tag", [
    z.strictObject({ tag: z.literal("original"), id: z.string().min(1) }),
    z.strictObject({ tag: z.literal("correction"), id: z.string().min(1), replaces: z.string().min(1) }),
  ]),
});

export const richCandleSchema = z.strictObject({
  ...candleBaseSchema.shape,
  vwap: decimal,
  trades: z.number().int().nonnegative(),
  nativeEvent: z.string().min(1),
});

export const feedFailureSchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("unknown-instrument"), nativeId: z.string().min(1) }),
  z.strictObject({ tag: z.literal("source-disconnected"), generation: z.string().min(1) }),
]);

export const recoverableItemFailureSchema = z.strictObject({
  tag: z.literal("recoverable-item-failure"),
  itemId: z.string().min(1),
  reason: z.string().min(1),
});

export const providerOrderSchema = z.strictObject({
  account: z.string().min(1),
  instrument: instrumentSchema,
  side: z.enum(["buy", "sell"]),
  quantity: positiveDecimal,
  pricing: z.strictObject({ tag: z.literal("limit"), price: positiveDecimal }),
  session: z.enum(["regular", "extended"]),
  postOnly: z.boolean(),
  clientReference: z.string().min(1),
});

export const adapterInputSchema = z.strictObject({
  nativeId: z.string().min(1),
  count: z.number().int().min(1).max(3),
});
export const adapterFailureSchema = z.strictObject({
  tag: z.literal("unsupported-symbol"),
  nativeId: z.string().min(1),
});

export const stagePreparedPayloadSchema = z.strictObject({
  intent: providerOrderSchema,
  compiler: z.literal("fixture-compiler-v1"),
  planDigest: z.string().min(1),
});
export const stageAckPayloadSchema = z.strictObject({
  tag: z.literal("accepted"),
  externalId: z.string().min(1),
});
export const stageObservationPayloadSchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("working"), externalId: z.string().min(1) }),
  z.strictObject({
    tag: z.literal("filled"),
    externalId: z.string().min(1),
    quantity: positiveDecimal,
    averagePrice: positiveDecimal,
  }),
  z.strictObject({ tag: z.literal("rejected"), externalId: z.string().min(1), reason: z.string().min(1) }),
  z.strictObject({ tag: z.literal("transport-unknown"), reason: z.string().min(1) }),
]);
export const stageFailurePayloadSchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("prepare-failure"), reason: z.string().min(1) }),
  z.strictObject({ tag: z.literal("dispatch-failure"), reason: z.string().min(1) }),
  z.strictObject({ tag: z.literal("observe-failure"), reason: z.string().min(1) }),
]);

function digest(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function schemaDigest(schema: z.ZodType): string {
  const exported = z.toJSONSchema(schema, { target: "draft-2020-12", unrepresentable: "throw" });
  return digest(JSON.stringify(exported));
}

function contractBinding(label: string, schemas: readonly z.ZodType[]): string {
  const body = JSON.stringify({ label, schemas: schemas.map((schema) => schemaDigest(schema)) });
  return digest(`uta-event-specimen/v1\u0000${body}`);
}

export const richFeedBindingLabel = "rich-candle-feed";
export const baseFeedBindingLabel = "base-candle-feed";
export const adapterBindingLabel = "native-symbol-adapter";
export const adaptedRichFeedBindingLabel = "adapted-rich-candle-feed";
export const controlledBindingLabel = "fixture-controlled-order";

export const richFeedBinding = contractBinding(richFeedBindingLabel, [richCandleSchema, recoverableItemFailureSchema, feedFailureSchema]);
export const baseFeedBinding = contractBinding(baseFeedBindingLabel, [candleBaseSchema, recoverableItemFailureSchema, feedFailureSchema]);
export const adapterBinding = contractBinding(adapterBindingLabel, [adapterInputSchema, richCandleSchema, adapterFailureSchema]);
export const adaptedRichFeedBinding = contractBinding(adaptedRichFeedBindingLabel, [richCandleSchema, recoverableItemFailureSchema, feedFailureSchema, adapterInputSchema]);
export const controlledBinding = contractBinding(controlledBindingLabel, [
  providerOrderSchema,
  stagePreparedPayloadSchema,
  stageAckPayloadSchema,
  stageObservationPayloadSchema,
  stageFailurePayloadSchema,
]);

export const feedSourceDeclaration = Object.freeze({
  provider: "fixture",
  path: Object.freeze(["market", "candle-feed"]),
  revision: "1",
  payload: richCandleSchema,
  failure: feedFailureSchema,
  bindingLabel: richFeedBindingLabel,
  binding: richFeedBinding,
});

export const baseFeedDeclaration = Object.freeze({
  provider: "fixture",
  path: Object.freeze(["market", "candle-feed-base"]),
  revision: "1",
  payload: candleBaseSchema,
  failure: feedFailureSchema,
  bindingLabel: baseFeedBindingLabel,
  binding: baseFeedBinding,
});

export const adapterDeclaration = Object.freeze({
  provider: "fixture",
  path: Object.freeze(["market", "native-candle-adapter"]),
  revision: "native-symbol-v1",
  input: adapterInputSchema,
  output: richCandleSchema,
  failure: adapterFailureSchema,
  bindingLabel: adapterBindingLabel,
  binding: adapterBinding,
});

export const controlledStageDeclaration = Object.freeze({
  bindingLabel: controlledBindingLabel,
  binding: controlledBinding,
  slots: Object.freeze({
    prepared: stagePreparedPayloadSchema,
    ack: stageAckPayloadSchema,
    observation: stageObservationPayloadSchema,
    failure: stageFailurePayloadSchema,
  }),
});

export function projectRichCandleToBase(value: z.output<typeof richCandleSchema>): z.output<typeof candleBaseSchema> {
  return candleBaseSchema.strip().parse(value);
}

export function richCandleAt(index: number, nativeEvent: string): z.output<typeof richCandleSchema> {
  return richCandleSchema.parse({
    source: "fixture",
    generation: "g1",
    instrument: { source: "fixture", nativeId: "BTC-USD" },
    interval: "1m",
    openedAt: `2026-09-09T00:0${index}:00.000Z`,
    open: "100",
    high: "103",
    low: "99",
    close: `${101 + index}`,
    volume: { amount: "2.50", unit: "base-asset", evidence: "fixture-volume-v1" },
    timezone: "UTC",
    session: "continuous",
    adjustment: "unadjusted",
    finality: { tag: "provisional", reason: "source has not closed interval" },
    revision: { tag: "original", id: `revision-${index}` },
    vwap: "101.25",
    trades: 4 + index,
    nativeEvent,
  });
}
