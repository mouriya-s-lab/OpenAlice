# 有限两成员 merge 的动态语义

`composition.ts` 复用 `source.ts` 的 Candle/失败 schema、`baseFeedEventSchema` 与 `FeedControlMachine`。每个成员有自己的接纳与生命周期；外层另有 policy 和终态。事件使用固定 fixture generation `g1`。

## 策略与派生输出

- `fail-fast`：child Failed 结束外层为 Failed；外层不会补 Completed。
- `partial-on-failure`：显式声明 `Partial` 与 `MemberOutcome`。失败值来自来源的 failure schema，带 member/source binding 和 terminal=Failed；它不是可恢复 ItemFailure。失败成员关闭，剩余成员仍可继续。
- child Completed 不直接成为 outer Completed。只有所有成员已关闭且外层仍 active，才正常结束。最后一个成员是 Failed、甚至两个成员均 Failed，都遵循同一关闭条件；Partial 不升级为完整覆盖。
- Cancelled 采用显式的外层取消策略。该分支已编译，但本轮五组场景不把它算作已执行的 merge 验收。

`MemberEvent` 是本地合并追踪记录，嵌套完整的已解析来源事件；`Partial` 是本组合明确声明的结果，不是新增的全局 Feed tag。此处未实现持续 `Data<MemberOutcome>` profile。

## 五组实际入口场景

```sh
node --import tsx specimen/composition.ts
```

1. 左流先 Completed：拒绝其后续 Data，右流继续，最后只发一个 outer Completed。
2. 默认失败：一个 child Failed 立即产生 outer Failed；右流后续输入被外层终态拒绝。
3. 部分失败：保留一个 typed MemberOutcome，拒绝失败成员后续 Data，右流仍继续并关闭外层。
4. 右流先完成、左流最后失败：仍能关闭，不把结束条件写成“最后必须收到 Completed”。
5. 两个成员均失败：最后 Partial 同时保留两项失败，外层仅正常结束一次。

CLI 对这些消费者可观察结果执行断言并输出完整26步轨迹。每步记录 input、接纳/拒绝、成员/外层状态与实际 emitted 输出；没有只检查输出非空或数量增长。

不证明 native 流、资源引用释放、取消远端协议、并发反压、window/join/filter、权限/服务联合、完整交易原子性或生产补偿。失败是在真实运行的本地 merge operator 中被解释，但来源输入仍是固定 schema fixture。
