import { JSDOM } from "jsdom";
import { readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const dom = new JSDOM("<!doctype html><html><body></body></html>");
globalThis.window = dom.window;
globalThis.document = dom.window.document;
const { default: mermaid } = await import("mermaid");

const paths = process.argv.slice(2);
if (paths.length === 0) throw new Error("Pass the Markdown documents to parse");
mermaid.initialize({ startOnLoad: false, securityLevel: "strict" });
const results = [];
for (const path of paths) {
  const text = await readFile(path, "utf8");
  const blocks = [...text.matchAll(/^```mermaid\s*\n([\s\S]*?)^```\s*$/gm)];
  if (blocks.length === 0) throw new Error(`No Mermaid diagrams in ${path}`);
  for (const block of blocks) {
    const line = text.slice(0, block.index).split("\n").length;
    try {
      const parsed = await mermaid.parse(block[1]);
      if (parsed === false) throw new Error("Parser did not accept diagram");
      results.push({ path, line, status: "passed", diagramType: parsed.diagramType });
    } catch (error) {
      results.push({ path, line, status: "failed", error: String(error) });
    }
  }
}
const failures = results.filter((result) => result.status === "failed");
await writeFile(join(dirname(fileURLToPath(import.meta.url)), "diagram-evidence.json"), `${JSON.stringify({ results, failures }, null, 2)}\n`);
console.log(JSON.stringify({ diagrams: results.length, failures: failures.length }));
for (const failure of failures) console.error(JSON.stringify(failure));
if (failures.length) process.exitCode = 1;
