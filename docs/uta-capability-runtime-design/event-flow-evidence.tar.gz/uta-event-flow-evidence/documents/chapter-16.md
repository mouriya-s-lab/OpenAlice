<a id="event-flows"></a>

## 16. 事件类型、限界上下文与动态语义

能力声明定义可组合的值与效果；事件流定义它们在时间中的行为。二者是同一设计的静态面与动态面。只写 `Effect<A,E,R>`、一组状态名或成功时序，不能验证扩展值是否仍沿正确路径流动，也不能确定两个上下文对同一事实的解释何时生效。

[完整事件流册](uta-capability-runtime-design/event-flows.md)展开 EF01–EF14：从声明载入与数据读取，到受控执行、外部激活、Alice 决策交接、配置生命周期和投影迁移。本章给这些流共用的类型派生与时序规则。原有能力定义、初版设计和逐项承接仍是输入，不因增加事件流而被替换。

### 16.1 先区分消息种类，再讨论流

事件不是任何一次函数调用的同义词。图中每条跨边界连线必须说明它是命令、事实、已提交事件、交付帧或调用结果；这些信息不能全部压进 `type:string, payload:unknown`。

| 种类 | 含义与产生者 | 生效条件 | 不能据此推断 |
|---|---|---|---|
| Command | 主体向拥有者提出改变或查询请求，例如 SubmitIntent、RespondDecision | 接收者校验输入、权限、版本和幂等身份后作决定 | 请求送达等于已接纳、批准或执行 |
| ExternalFact | Provider 已观察到的 Candle、订单回报、余额等；边界 codec 认证来源与槽位 | 通过该来源的结构与身份校验；仍携带完整性和时间边界 | 来源事实自动成为交易权限或本地已提交事件 |
| DomainEvent | 某个上下文已经接受的状态变化，例如保存准备值、记录原生观察 | 相应拥有者的权威写入完成；交易决定相关事件与投影同事务 | 另一上下文已处理，或外部系统发生了超出证据的效果 |
| DeliveryFrame | 一次 Pull/Push 调用的输出与控制帧，含数据、gap、终态 | 该次调用的协议和拥有权允许发出；接收方按绑定解析 | 帧被发出等于远端收到，或必须持久化进交易 WAL |
| WorkDescription | 控制拥有者交给可信解释器的内部工作说明 | 接纳事务已提交；解释器仍须满足工作所需服务与权限 | 对外结果、批准或可重建的发送许可 |
| DurableReceipt / ControlHandle | 已持久接纳的身份、决定或可查询句柄 | 相应接纳记录先 commit；重投可取得原结果 | 接纳等于外部完成；receipt 不是 DispatchGrant |
| QueryResult | 读取者按声明返回的值、范围和质量信息 | 读取契约成立；是否读取持久投影由该声明决定 | 必然来自交易日志、已被订阅方消费或可以授权交易 |
| Diagnostic | 调试、进程或传输诊断 | 诊断通道自身的记录规则 | 业务成功、失败终态、批准或恢复决定 |

一次 ExternalFact 被 UTA 接纳后，才可能产生该上下文的 `ObservationRecorded`；后者被 Alice 展示时，又可形成 Alice 的投影事实。三者可以互相引用，但不是同一个事件，也不共享一个冒充全局的 sequence。

现有 `src/core/event-log.ts:19–36` 的泛型 payload 与字符串 type 并未建立 schema 关联；`129–162` 的 append/listener fan-out 也不构成跨进程接纳或交易 writer。`docs/event-system.md` 所述 Alice 事件总线已经退休。本设计中的事件流不要求重建它；本地调用、数据库事务、stdout、HTTP 与 outbox 都可以承载各自适用的消息。

### 16.2 限界上下文同时拥有语言、决定与时间

上下文不是按类、SDK 或操作系统进程机械分组。判断边界要同时回答：谁定义这个值的含义，谁有权改变它，以及在哪个时间/版本边界上这个改变成立。一个 UTA 进程可包含多个上下文；一个 Provider 上下文也可跨 UTA 与受信任 SDK 子进程。

| 上下文 | 拥有的语言与决定 | 顺序/连续性权威 | 跨界交换 |
|---|---|---|---|
| 声明与能力目录 | schema 槽位、实现绑定、结构支持与当前可用性 | catalog revision；历史 resolver 的精确版本保留 | 已绑定描述、可用性变化、新调用准入结果 |
| Provider 观察 | 原生身份、数值、回报、原生错误与完整性 | 原生 sequence/cursor 的实际承诺；connection generation；无法续传则 gap | 经过 codec 的 ExternalFact，不输出本地批准 |
| 交付与数据组合 | 订阅拥有权、范围、投影、join/window 及交付终态 | invocation/subscription 内序列，各来源位置及声明的窗口边界 | Data/Correction/Gap 等帧和有来源的派生值 |
| UTA 效果控制 | intent、plan、批准、attempt、reservation、判据与恢复责任 | aggregate revision、writer commit order、授权/计划有效期 | 已提交控制事件、私有一次性发送许可、redacted 查询结果 |
| UTA 延后激活 | source/predicate/checkpoint、activation epoch、决定句柄 | checkpoint commit、future boundary、控制版本 CAS | 选中证据、决定请求；不是授权 |
| Alice 决策交付与 Workspace | 持久接纳、exact/reconstructed 会话、run 归属与用户可见报告 | Alice admission identity、Session/run 生命周期和本地提交顺序 | 可验证接纳结果、带精确版本的响应命令 |
| 配置与运行生命周期 | Alice 配置/秘密修订；UTA 应用配置；Guardian 进程拥有权 | config revision、connection generation、owner epoch | 应用/健康/停止结果，不决定订单终态 |
| 审计与产品活动投影 | 从所属领域事实构造可读历史、Inbox/活动视图 | 各投影自己的 cursor/checkpoint 和消费进度 | 可重建视图，不反向获得领域写入权 |

同一条“订单已成交”原生回报可以先被 Provider 观察、后被 UTA 提交、再被 Alice 展示。UI 较晚看到它，不改变原生成交时间；writer 较晚接纳 ack，也不能把已经记录的成交降回 working。限界上下文之间需要因果引用和接纳协议，而不是共享可变状态或统一时钟。

### 16.3 事件 payload 从声明槽位派生

以下是目标关系记法，不是另一套手写 DTO。D 是能力定义；B 是已认证的具体绑定，包含 ProviderInstance、CapabilityId、Revision 与 ContractDigest，并解析到 D。`WireInput(B,s)` 是槽位 s 的编码输入，`Value(B,s)` 是其 schema 解码后的值；输入槽位在内部同样使用解码后的 Output，而不把未验证的 wire 输入传给实现。事件构造器从 B、事件家族、kind 与槽位一次派生 parser、编码 schema 和本地类型，不能允许调用者分别填写三份不相关描述。

```text
WireInput(B, s)               = InputOf(SchemaOf(B, s))
Value(B, s)                   = OutputOf(SchemaOf(B, s))
Event(B, k, s)                = EnvelopeOf(B, k, s) × Value(B, s)
DataFrame(B)                  = Event(B, Data, item)
CorrectionFrame(B)            = CorrectionRef(B) × Event(B, Correction, item)
IntentAccepted(A)             = EffectEvent(A.binding, IntentAccepted, intent)
PlanPrepared(A)               = EffectEvent(A.binding, PlanPrepared, prepared)
DispatchStarted(A)            = ControlEvent(A.binding, attempt, boundPlan, StartCommit)
DispatchOutcome(A)            = NativeAckRecorded(A) | UnknownRecorded(A) | DispatchFailureRecorded(A)
NativeAckRecorded(A)          = EffectEvent(A.binding, NativeAckRecorded, ack)
NativeObservationRecorded(A)  = EffectEvent(A.binding, NativeObservationRecorded, observation)
```

Envelope 是按事件家族构造的 product type，不是所有上下文共用一份 optional-field soup。领域事件、来源事实与交付帧各有必要字段；slot 不存在的控制事件不能随意添加一个空 payload 来凑接口。事件名称只在对应家族与上下文中解释，不维护包含所有 Provider 业务动作的全局 union。

`DispatchStarted` 使用内核控制 schema，关联已准备计划、attempt 和 writer 提交；它不是一个臆造的 Provider `prepare-started` 槽位。`UnknownRecorded` 记录当前证据不足以判定发送结果，而不捏造 ack。已有可靠观察满足判据时，传输丢失只追加该诊断，不能生成会覆盖结论的 Unknown。一次性 DispatchGrant 仅交给当前私有 worker，不进入可重复读取的事件 payload，也不从 Start 记录恢复。

| 派生家族 | 来自哪项声明 | payload 与控制关系 |
|---|---|---|
| Pull invocation | input、success、domain-failure、交付契约 | 输入解析后产生结果或精确失败；结果 envelope 保留范围、as-of、coverage。一次结果不是持久交易提交事件 |
| Feed data | 同一 Unit/item schema | Data 携带 Item；Correction 携带同一 Item 和被修订证据引用；Retraction 携带引用与明确原因，不凭空填一个 Item |
| Feed control | delivery profile 和声明的失败 schema | Started、Gap、SnapshotEnd、ItemFailure 及三个终态；来源未提供 correction/retraction 能力时，不能仅因内核认识该 tag 就制造对应事实 |
| Controlled stages | 同一 RecipeAssociation 的 intent/prepared/ack/observation/recovery/compensation 槽位 | 每阶段事件保留所属能力和阶段失败类型。回执成功不擦除后续结果关联，ack 与 observation 不是可互换的相似 JSON |
| Deferred activation | source schema、predicate checkpoint/evidence schema、continuation response schema | CheckpointAdvanced、EvidenceSelected、DecisionRequested 及回应事件从相同关联派生；新 epoch 不接纳旧响应 |
| Projection / combination | 原定义与版本化 operator、输出 schema、损失/一致性策略 | 输出事件绑定新定义，同时保留源事件 lineage；不能假装仍由原 Provider 原生发出 |

例如，Candle 增加 vwap/tradeCount 后，Data 与 Correction 的 value 类型自动携带这些字段；Gap、SnapshotEnd 和终止规则不因字段增加而改变。Order 增加 session、post-only 或原生保护条款后，intent/prepared 事件携带相应类型，仍经过同一个接纳、批准、Start、观察与恢复协议。若新增条款改变编译、判据或原生语义，则绑定新实现/契约修订；“事件流骨架不变”不授权沿用旧批准。

动态加载时不存在新的编译期 union。每个消息的编码先按已解析的 capability binding、事件家族、kind 与 slot 认证，再生成对应 BoundDocument。重新读取持久事件也必须使用原版本的事件 codec 和解释身份；当前目录出现同形 schema，不能替代历史关联。

### 16.4 事件身份、因果与时间不能折叠

槽位关联解决“这个 payload 是什么”，身份与时间关系继续决定“它能推进哪一个状态”。即使 payload 解码成功，错来源、错代际或错控制版本的事件仍不能接纳。

| 字段关系 | 回答的问题 | 不能替代的关系 |
|---|---|---|
| EventIdentity / SourceOccurrenceRef | 哪一事实或哪一次受限接收；用于去重和修订引用 | command key、显示 hash、全局授权 |
| Origin / CausationRef | 根来源事实的来源位置，或直接导致本事件的已接纳命令/事件 | 整个业务会话的 correlation id；外部自发事实不伪造 UTA 命令父项 |
| CorrelationRef | 哪个 invocation、intent、attempt、decision 或派生计算关联这些消息 | 接收次序、原生幂等保证 |
| SourcePosition + generation | 来源承诺的顺序及连续性边界 | UTA commit sequence；接收时钟不是原生 cursor |
| AggregateRevision + commit position | 本地决定基于哪个版本、在哪次原子提交生效 | 远端事实发生顺序或跨上下文全序 |
| observedAt / receivedAt / committedAt | 来源宣称发生、主机接收、本地生效的不同时间 | 彼此的默认值；缺失 source time 保持未知 |
| Effective interval / watermark / deadline | 值的有效区间、完整性进度或本地等待策略 | 不同语义的时钟；deadline 到达不证明外部流完整 |
| DecisionRequest / reply identity | request key、principal、intent revision、activation epoch、expected control version 与有效期 | 仅靠 revision 或 UI 当前选中行判定回复是否有效 |

跨源只建立能够证明的偏序。writer 可以为自己的记录建立提交全序，但它不能证明两个 venue 的物理先后。重连改变 generation；只有来源给出可核验续传关系，才能把两个连接拼成连续流。Correction 可以引用较早事实，甚至跨连接代际；这种关系必须有来源/绑定证据，不能因为接收时间更晚就擅自覆盖其他来源。

来源事实去重与命令去重是两套关系。来源按其承诺的 EventIdentity / SourceOccurrenceRef 和规范事实判断重复；同一事实身份却有不同内容时，只能走已声明的修订关系或冲突处理。没有原生事件 ID 的来源只能使用已声明的接收边界，它证明本地重复接纳控制，不证明远端从未重发或漏发。

命令的幂等 key 绑定完整规范语义：具体 capability binding、principal/scope、intent revision、expected version、输入和授权声明。同 key 且上述语义相同才可重取原 receipt；任一改变都产生冲突，不能沿用旧接纳或批准。不同 key 竞争同一 expected version 仍由 writer CAS 裁决。来源事件的身份不能代替命令 key。

Origin 是显式分支：来源自发事实携带 SourceOrigin；由已接纳命令或事件导出的记录携带 CausedBy 引用。跨上下文引用包含 origin/context/partition 与事件身份，不能把 UTA 的数值 sequence 填入 Alice 本地 `causedBy`。request expiry、approval expiry、worker lease、数据 watermark 和历史解释器 retention 各有拥有者与时钟；任一个到期都不能替其他边界作决定。

### 16.5 透明扩展与事件组合的不同规律

对一个有效扩展值，令 `p` 是保留全部基础字段及约束的总投影。将 p 提升为事件投影时，Data/Correction 的 value 使用 p，其他控制含义保持；派生 binding 与 event identity 按 operator 重新建立，并保存源引用。不能直接复制原 binding 宣称这是原生基础事件。

```mermaid
flowchart TB
  RichValue[有效扩展 Unit 与同一交付契约] -->|派生事件 schema| RichTrace[扩展事件轨迹]
  RichValue -->|总基础投影 p| BaseValue[基础 Unit]
  RichTrace -->|提升 p 并保留 lineage| DerivedTrace[重新绑定的基础事件轨迹]
  BaseValue -->|相同控制协议| BaseTrace[基础事件轨迹]
  DerivedTrace -->|控制种类 顺序 终态 因果结构相同| Law[透明扩展规律]
  BaseTrace -->|在明确身份对应下比较| Law
```

比较的是明确身份对应下的控制轨迹和基础值，不是 raw bytes 或哈希相等。一个新调用必然可以有新的 invocation id；投影也有新的声明身份。规律要求其 source lineage、相对次序、coverage、finality、权限要求和资源释放责任不被篡改。

这条透明规律还要求失败、服务 R 和权限 P 的要求相同。投影若新增服务、权限、可失败分支或语义约束，必须显式体现在新声明中，便不再是完整意义上的透明投影。merge/join 等组合至少保留所有成员的 R/P 与失败分支，再加入 operator 自身的要求；不能靠合并值类型擦除任何成员的效果要求。

| 组合 | 事件类型怎样派生 | 动态语义与限制 |
|---|---|---|
| extend / total base projection | Item 由积类型扩展或投影；Data/Correction 使用同一生成器 | 一入一出，控制种类和次序不变；不得丢 gap/修订/终态 |
| 可失败转换 | 新 success schema 与原失败/转换失败的和 | 失败必须走声明的 ItemFailure 或流失败策略；不能称为透明扩展 |
| filter | value 子集与保留的来源位置/修订依赖 | 不可把被过滤的数据误当成连续无缺口证据；已输出项的撤回仍需传播 |
| merge | 带 source binding 的和类型，不只合并 payload | 保留各源顺序；子流终态由组合器消费，外层按组合策略终止；不制造跨源全序 |
| zip / join | 带成员事实引用的一组积类型与一致性/部分失败结果 | 原子快照不能由函数组合推出；缺失成员、late data、correction 与重算均需明确 |
| window / aggregate | 结果 schema 加窗口身份、成员证据、revision/quality | 只有声明的 watermark/关闭策略能结束窗口；receivedAt 超时不能升级为原生 finality |
| flatMap / switch | 分支能力关联、错误/服务/权限联合 | 分支作用域和取消次序明确；释放旧订阅不等于撤销已提交效果 |
| deferUntil | checkpoint/evidence/decision 关联从 source 与 predicate 派生 | 数据到达、命中、持久选中、请求决定和取得授权是不同步骤 |
| withTransaction / 批次组合 | 接纳、准备、观察、补偿事件保持每成员 RecipeAssociation | 事件相邻不证明跨 Broker 原子性；同一决定中的前一步事件先演进再判断后一步 |

merge 消费子流终态，而不把左源 Completed 原样发布为整个组合 Completed。默认的子源 Failed 使外层 Failed；Cancelled 按明确的取消策略处理。确实需要部分结果时，组合声明可以把 `MemberOutcome{sourceBinding, terminal, failure}` 纳入自己的输出类型；若要实时报告它，则输出 Unit 必须声明相应 Data 分支。源的 Failed 仍是终态，该源不会继续发数据；不能把它改名成表示可恢复单项错误的 ItemFailure。

外层在拥有者存活且可完成协议时只选择一个 Terminal；进程崩溃可能只有 EOF，没有机会补造终态。部分结果策略决定仍开放的成员如何继续，以及何时关闭组合；外层 Failed 后不能再发 Completed。窗口可以按声明的处理时间 deadline 产生 Partial 结果，但不能据此升级为来源 watermark 或原生 finality。窗口和交易组合会改变事件结构，却不会因为 payload 恰好多了一个字段而换一套控制实现。

对每个可接纳事件，先在扩展状态上推进再投影，与先投影状态和事件再由基础控制机推进，必须得到相同的基础值、控制状态和释放责任。去重身份与修订引用也经过同一对应关系；只比较 tag 数组不足以证明这条规律。

### 16.6 用异常时序检验边界

设计验收至少需要回答以下反例，具体步骤见事件流册：

- native fill 在 submit ack 前到达：按 attempt/native identity 保存观察，后到 ack 补充证据，不使已观察状态回退。
- Start 已提交但 grant 丢失：观察或恢复；查询持久记录不能重建发送许可。
- 原生已接受但本地 ack 未提交：保留同一个 attempt，历史解释器观察；目录变化不触发 reprepare。
- 部分成交之后 cancel/replace：撤销或替换确认不消除既有成交与敞口；补偿是另一个受控效果。
- SnapshotEnd 后继续 live：结束的是历史段，不是订阅。
- 左源结束、右源继续：组合拥有者仍保有右源；取消一个子订阅不能释放其他订阅的共享连接。
- correction/retraction 在新 epoch 后迟到：根据证据依赖与版本判定影响，不能更改无关新 checkpoint，也不能抹去已发出的交易事实。
- Alice 已接纳请求但响应丢失：重取同一 admission；不得启动第二个无归属 Agent。
- reply 与 expiry 同时出现：由同一控制版本 CAS 决定一个结果；UI 收到顺序不决定授权。
- query/Git/产品活动投影写失败：报告 lag/投影失败；不能回滚领域提交或再次发送交易。

这些时序使类型关系可被证伪：如果同形 ack 可以被当成 observation、一个扩展导致 Gap 被滤掉、或新版本 codec 能直接解释旧 attempt，问题就位于声明派生或上下文边界，而不只是某个 Provider 的实现细节。

### 16.7 声明派生的可执行反例

本章附带独立的[事件流实验归档](uta-capability-runtime-design/event-flow-evidence.tar.gz)，不覆盖第15章的原实验。它保存完整源码、锁定依赖、独立 Python 生产者、CLI、持久 NDJSON、读取与合并轨迹，以及每条验证命令的 stdout/stderr/退出码。

样例的入口来自真正被编译和执行的 `specimen/source.ts` 与 `specimen/types.ts`：

```ts
const richFeedDefinition = defineFeed(
  adaptedRichFeedBindingLabel,
  adaptedRichFeedBinding,
  richCandleSchema,
  feedFailureSchema,
);
type RichEvent = z.output<typeof richFeedDefinition.schema>;
const richControl = new FeedControlMachine(richFeedDefinition);
const baseControl = new FeedControlMachine(baseFeedDefinition);
```

`defineFeed` 的拥有者构造 schema，而不接受独立填写的 event schema。其私有 schema 字段阻止调用者拼装一份同形但无关联的 definition；`RichEvent` 从真正的 schema 推导，不另写十种事件的 DTO。静态 label 保留声明区别，运行时 digest 校验编码的具体绑定。controlled 样例同样从 source 模块的 prepared/ack/observation/failure 槽位生成阶段事件，digest 包含全部这些 schema；Provider Order 的 session/postOnly 等字段进入 prepared 的精确 intent，而不改变阶段控制机。

执行环境为 Node v26.8.1、Python 3.14.7；锁定 Zod 4.3.6、TypeScript 5.9.3、tsx 4.21.0，图解析器为 Mermaid 11.17.2。实际结果：

| 反例 | 实际执行与观察 | 证明边界 |
|---|---|---|
| 同形消息能否绕过关联 | 严格类型检查通过；在内存移除 expect-error 后，8个消费者反例各产生预期诊断，包含同形 Started 的不同 label、伪造 definition、prepared/ack 槽位和基础/扩展字段混用 | 静态关联与构造入口；不是恶意插件沙箱或原生授权 |
| 扩展是否改变基础流 | Python 发出17帧；一个重复 Data 被去重。CLI 用同一泛型控制机接纳16条扩展事件及16条基础投影，保留 Data/Correction/Retraction/Gap/SnapshotEnd/ItemFailure 与三种终态 | 三个交错分区的有限 NDJSON 交付；不是原生 SDK Push |
| 只比较 tag 是否会漏错 | 新进程读取36条 fsync 记录，逐对核对16组来源/分区/代际/顺序、基础 payload、修订引用、gap、失败及 lineage | 32条 feed 记录加4条阶段记录；不声称跨记录事务 |
| 同形但语义损坏的持久事件 | 分别改写基础 close、source lineage、Correction target；三份文件仍通过单条 schema 校验，却均被新 reader 进程以对应关系错误拒绝 | 值与因果关联真实参与验证，不仅是序列长度或 tag 相同 |
| 早到成交能否被后续消息覆盖 | 持久顺序为 prepared、filled observation、transport-unknown observation、late ack；重复 ack 不追加。新进程读取后结论仍是 filled，intent revision 与 attempt 不变 | 窄阶段控制规则；没有实际 native send、批准或完整成交判据 |
| 错边界是否只靠约定 | 实际 CLI 拒绝跨 binding、跨 slot、乱序、错误 intent revision 和 prepared 之前的 ack，共5种负面输入 | 编码与时序接纳边界 |
| 子流终态能否错误结束组合 | 左流 Completed 后右流继续 Data；默认子流 Failed 只产生一个外层 Failed；部分结果模式保留 typed MemberOutcome，关闭成员的后续数据被拒绝 | 显式两成员 merge policy，不自动推出 join/window 语义 |
| 最后一个成员失败时会不会悬挂 | 另外执行“右流先完成、左流最后失败”和“两流均失败”；部分结果模式都只产生一个外层 Completed，最后 Partial 保留相应一个或两个失败成员 | 交付正常完成不把 Partial coverage 升级为 Complete |

五组 merge 场景共26次输入；三个来源终态分别保持 Cancelled、Failed、Completed，没有把来源 Failed 改名成可恢复 ItemFailure。15张新增 Mermaid 图经过真实解析器检查，不只检查代码块数量。旧承接的99个 section 全部关联到具体 EF 流；该覆盖只查缺项，不替代上表的行为证据。

复现归档的完整相关验证：

```sh
tar -xzf event-flow-evidence.tar.gz
cd uta-event-flow-evidence
npm ci --ignore-scripts --no-audit --no-fund
node verify-evidence.mjs
```

执行器依次运行严格类型检查、8个静态反例、Python/CLI/新 reader、三种持久关系损坏、五组 merge 场景和图解析。每次创建独立的 `verification-run-*` 命令日志目录；`specimen/event-evidence/` 保存本轮输入、持久文件与读取结果。完整 stderr 保留，不能通过隐藏诊断替代修复。

### 16.8 事件流规格与实现验收不能混同

EF01–EF14 都是本设计的目标动态语义；局部样例不是这些生产上下文的完整实现。特别是：

- EF01–EF02 的真实安装、动态目录、entitlement 与权限认证，仍需对应 Provider/运行时入口。
- EF03–EF04 的原生 Push、credit/replay、共享连接释放、buffer overflow、R/P 联合及完整 filter/window/join，不由有限 producer 与两成员 merge 证明。透明关系要求的释放责任也尚未在本轮跨进程 feed 样例中实现。
- EF05 的真实 FX、估值、账户账、snapshot 与同步，以及 EF06–EF10 的完整批准、风险、发送、补偿和激活协议，需要各自完整状态实现。第15章的 SQLite/独立 venue 实验保留其原有窄证明范围。
- EF11–EF14 的 Alice 持久接纳与 exact/reconstructed 会话、真实 config/secret apply、Mock admin 接入、产品活动投影和迁移切换，本轮只有设计、源码对照与可解析时序，不声称已经运行。

扩展值能通过基础控制流，并不替某个 Provider 证明 finality、完整查询、原生幂等或补偿保证。设计中这些边界必须明确；实现完成时还必须分别触发真实入口并核对最终状态。
