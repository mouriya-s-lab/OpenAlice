import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { dirname, join, resolve, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";

const evidenceRoot = dirname(fileURLToPath(import.meta.url));
const repo = resolve(process.argv[2] ?? ".");
const hashRecord = z.strictObject({ path: z.string().min(1), sha256: z.string().regex(/^[0-9a-f]{64}$/) });
const sectionSchema = z.object({ id: z.string().min(1), title: z.string().min(1) });
const canonicalSchema = z.object({ sections: z.array(sectionSchema) });
const flowId = z.string().regex(/^EF(?:0[1-9]|1[0-4])$/);
const coverageSchema = z.strictObject({
  schema: z.literal("uta-event-flow-coverage/v1"), design: z.string(), flowAtlas: z.string(), legacy: z.string(),
  sections: z.array(z.strictObject({
    section: z.string(), anchor: z.string(), title: z.string(), flows: z.array(flowId).nonempty(),
    associations: z.array(z.strictObject({ flows: z.array(flowId).nonempty(), reason: z.string().min(1) })).nonempty(),
  })),
});
const baseline = z.array(hashRecord).parse(JSON.parse(await readFile(join(evidenceRoot, "preservation-baseline.json"), "utf8")));
const protectedChecks = [];
for (const record of baseline) {
  const current = createHash("sha256").update(await readFile(join(repo, record.path))).digest("hex");
  protectedChecks.push({ path: record.path, unchanged: current === record.sha256 });
}
const canonical = canonicalSchema.parse(JSON.parse(await readFile(join(repo, "docs/uta-capability-runtime-design/legacy-accommodation.json"), "utf8")));
const coverage = coverageSchema.parse(JSON.parse(await readFile(join(repo, "docs/uta-capability-runtime-design/event-flow-coverage.json"), "utf8")));
const expectedIds = canonical.sections.map((section) => section.id);
const actualIds = coverage.sections.map((section) => section.section);
const atlasPath = join(repo, "docs/uta-capability-runtime-design/event-flows.md");
const atlas = await readFile(atlasPath, "utf8");
const atlasIds = [...atlas.matchAll(/^## (EF\d{2}) — /gm)].map((match) => match[1]);
const expectedFlowIds = Array.from({ length: 14 }, (_, index) => `EF${String(index + 1).padStart(2, "0")}`);
const coverageMatches = JSON.stringify(expectedIds) === JSON.stringify(actualIds) && coverage.sections.every((row) =>
  row.anchor === row.section.toLowerCase() && JSON.stringify(row.flows) === JSON.stringify([...new Set(row.associations.flatMap((association) => association.flows))].sort()));
const links = [];
for (const path of [join(repo, "docs/uta-capability-runtime-design.md"), atlasPath]) {
  const text = await readFile(path, "utf8");
  for (const match of text.matchAll(/\[[^\]\n]*\]\(([^\s)]+)\)/g)) {
    const target = match[1];
    if (/^[a-z][a-z0-9+.-]*:/i.test(target)) continue;
    const [file, fragment] = target.split("#");
    const resolved = file ? resolve(dirname(path), decodeURIComponent(file)) : path;
    try {
      const contents = await readFile(resolved);
      let valid = true;
      if (fragment && /^L\d+(?:-L\d+)?$/.test(fragment)) {
        valid = Math.max(...fragment.match(/\d+/g).map(Number)) <= contents.toString("utf8").split("\n").length;
      } else if (fragment && extname(resolved) === ".md") {
        const decoded = contents.toString("utf8");
        valid = decoded.includes(`id="${fragment}"`) || [...decoded.matchAll(/^#+\s+(.+)$/gm)].some((heading) =>
          heading[1].toLowerCase().replace(/[^\p{L}\p{N}_\-\s]/gu, "").replace(/\s/g, "-") === decodeURIComponent(fragment));
      }
      links.push({ from: path.slice(repo.length + 1), target, valid });
    } catch (error) {
      links.push({ from: path.slice(repo.length + 1), target, valid: false, error: String(error) });
    }
  }
}
const changedProtected = protectedChecks.filter((record) => !record.unchanged);
const invalidLinks = links.filter((link) => !link.valid);
const result = { protectedFiles: baseline.length, changedProtected, canonicalSections: expectedIds.length, coverageMatches, atlasIds, flowsMatch: JSON.stringify(atlasIds) === JSON.stringify(expectedFlowIds), checkedLinks: links.length, invalidLinks };
await writeFile(join(evidenceRoot, "publication-evidence.json"), `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify(result));
if (changedProtected.length || !coverageMatches || !result.flowsMatch || invalidLinks.length) process.exitCode = 1;
