from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile


def main() -> None:
    root = Path(__file__).resolve().parent
    run_root = Path(tempfile.mkdtemp(prefix="control-evidence-", dir=root))
    transcript = []
    snapshots = {}
    executable = root / "node_modules/.bin/tsx"
    program = root / "control-specimen/control.ts"

    def call(case: str, command: str, *arguments: str, expected_exit: int = 0):
        directory = run_root / case
        directory.mkdir(exist_ok=True)
        argv = [str(executable), str(program), command, "--host-db", str(directory / "host.sqlite")]
        if command != "deferred":
            argv += ["--venue-db", str(directory / "venue.sqlite")]
        argv += list(arguments)
        result = subprocess.run(argv, cwd=root, text=True, capture_output=True, timeout=30)
        transcript.append({"case": case, "command": argv, "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        assert result.returncode == expected_exit, (case, command, result.returncode, result.stdout, result.stderr)
        frames = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
        assert len(frames) == 1 and isinstance(frames[0], dict), (case, command, frames)
        return frames[0]

    def inspect(case: str):
        value = call(case, "inspect")
        snapshots.setdefault(case, []).append(value)
        return value

    try:
        call("accepted-crash", "init")
        first = call("accepted-crash", "admit", "--mode", "same")
        duplicate = call("accepted-crash", "admit", "--mode", "same")
        conflict = call("accepted-crash", "admit", "--mode", "conflict")
        assert first["outcome"] == "accepted"
        assert duplicate["outcome"] == "deduplicated" and duplicate["mutated"] is False
        assert conflict["outcome"] == "rejected" and conflict["reason"] == "conflicting-semantics"
        before = inspect("accepted-crash")
        assert before["venue"]["counts"]["receiveCount"] == 0
        crash = call("accepted-crash", "dispatch", "--now", "100", "--crash-after-venue-acceptance", expected_exit=91)
        assert crash["hostAckPersisted"] is False
        cut = inspect("accepted-crash")
        assert cut["venue"]["counts"]["receiveCount"] == 1
        assert cut["venue"]["counts"]["accepted"] == 1
        assert cut["host"]["plans"][0]["state"] == "DispatchStarted"
        retry = call("accepted-crash", "dispatch", "--now", "200")
        assert retry["start"]["transition"] == "AlreadyStarted" and retry["start"]["grantIssued"] is False
        call("accepted-crash", "catalog-remove")
        recovered = call("accepted-crash", "recover", "--now", "200")
        assert recovered["outcome"] == "recovered-by-observation" and recovered["dispatchedAgain"] is False
        call("accepted-crash", "recover", "--now", "300")
        after = inspect("accepted-crash")
        assert after["venue"]["counts"]["receiveCount"] == 1
        assert after["host"]["plans"][0]["state"] == "Acknowledged"

        call("missing-history", "init")
        call("missing-history", "admit", "--mode", "same")
        call("missing-history", "dispatch", "--now", "100", "--crash-after-venue-acceptance", expected_exit=91)
        original = inspect("missing-history")
        call("missing-history", "history-remove")
        missing = call("missing-history", "recover", "--now", "200")
        assert missing["outcome"] == "RecoveryRequired" and missing["reprepared"] is False
        preserved = inspect("missing-history")
        assert preserved["venue"]["counts"]["receiveCount"] == 1
        assert preserved["host"]["plans"][0]["state"] == "RecoveryRequired"
        for key in ("intent_bytes", "plan_bytes"):
            assert original["host"]["plans"][0][key] == preserved["host"]["plans"][0][key]

        call("lost-grant", "init")
        call("lost-grant", "admit", "--mode", "same")
        call("lost-grant", "dispatch", "--now", "100", "--lose-dispatch-grant-before-send", expected_exit=92)
        retry = call("lost-grant", "dispatch", "--now", "200")
        assert retry["start"]["transition"] == "AlreadyStarted" and retry["start"]["grantIssued"] is False
        lost = call("lost-grant", "recover", "--now", "200")
        assert lost["dispatchedAgain"] is False
        lost_state = inspect("lost-grant")
        assert lost_state["venue"]["counts"]["receiveCount"] == 0
        assert lost_state["venue"]["counts"]["accepted"] == 0

        call("deferred", "init")
        call("deferred", "deferred", "--action", "claim-owner")
        owner_duplicate = call("deferred", "deferred", "--action", "claim-owner")
        assert owner_duplicate["liveOwnerCount"] == 1
        baseline = call("deferred", "deferred", "--action", "fact-false")
        assert baseline["transition"] == "NoActivation"
        crossed = call("deferred", "deferred", "--action", "fact-cross")
        assert crossed["transition"] == "Candidate" and crossed["authorizationGranted"] is False
        denied = call("deferred", "deferred", "--action", "evidence-dispatch")
        assert denied["reason"] == "evidence-is-not-authorization" and denied["mutated"] is False
        kept = call("deferred", "deferred", "--action", "keep")
        assert kept["outcome"] == "kept"
        inspect("deferred")
        rearmed = call("deferred", "deferred", "--action", "rearm")
        assert rearmed["newEpoch"] > rearmed["oldEpoch"]
        call("deferred", "deferred", "--action", "stale")
        call("deferred", "deferred", "--action", "claim-owner")
        deferred_state = inspect("deferred")
        assert deferred_state["venue"]["counts"]["receiveCount"] == 0

        call("gap", "init")
        call("gap", "deferred", "--action", "claim-owner")
        call("gap", "deferred", "--action", "fact-false")
        gap = call("gap", "deferred", "--action", "fact-gap")
        next_fact = call("gap", "deferred", "--action", "fact-after-gap")
        assert gap["transition"] == "Gap" and gap["candidate"] is False
        assert next_fact["transition"] == "NoActivation" and next_fact["candidate"] is False
        gap_state = inspect("gap")
        assert gap_state["venue"]["counts"]["receiveCount"] == 0
        summary = {"status": "passed", "runRoot": str(run_root), "processInvocations": len(transcript), "cases": list(snapshots), "acceptedCrashReceiveCount": after["venue"]["counts"]["receiveCount"], "lostGrantReceiveCount": lost_state["venue"]["counts"]["receiveCount"]}
        (root / "control-runtime-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps(summary, ensure_ascii=False))
    finally:
        evidence = {"runRoot": str(run_root), "invocations": transcript, "snapshots": snapshots}
        (root / "control-runtime-evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
