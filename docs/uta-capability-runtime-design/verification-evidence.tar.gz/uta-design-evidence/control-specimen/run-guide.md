# Control specimen run guide

本目录是设计书的可执行 falsifier，不是生产 broker/runtime。`control.ts` 只拥有 host SQLite；`venue-worker.py` 是独立 Python 进程，并且只拥有自己的 venue SQLite。两份数据库必须保持分离。

归档根目录的 `run-control-evidence.py` 已执行五组隔离场景、43 次真实进程调用；完整 stdout/stderr、退出码与两份数据库快照见 `../control-runtime-evidence.json`。以下命令用于独立复现各个控制边界，不能推断真实 Broker 保证。

本目录包含 `control.ts` 与 `venue-worker.py`。归档只含虚构账户和固定输入，不需要交易凭据。
## 运行约定

在本目录的父目录（包含 `node_modules/`）执行：

```sh
ROOT="$PWD"
TSX="$ROOT/node_modules/.bin/tsx"
CONTROL="$ROOT/control-specimen/control.ts"
```

每个 case 都使用全新的目录；`init` 会创建 host schema 并通过独立 venue worker 创建 venue schema。`control.ts` 的 fixed fixture 不接受任意 intent/plan JSON：`admit --mode same` 是唯一可执行计划，`admit --mode conflict` 只用于固定冲突语义的拒绝场景。所有输出是一行 JSON；长字段 `intentBytes`、`planBytes`、`requestBytes` 和 `evidenceBytes` 不做展示层截断。

```sh
RUN="$(mktemp -d "$ROOT/control-specimen/run-control.XXXXXX")"
HOST="$RUN/host.sqlite"
VENUE="$RUN/venue.sqlite"
```

若运行 shell 在 `dispatch --crash-after-venue-acceptance` 后因 `set -e` 停止，请暂时关闭该选项；该命令预期返回退出码 **91**，这是刻意模拟 owner termination，不是程序异常。

## 1. Admission 的原子性和幂等性

```sh
"$TSX" "$CONTROL" init --host-db "$HOST" --venue-db "$VENUE"
"$TSX" "$CONTROL" admit --host-db "$HOST" --venue-db "$VENUE" --mode same
"$TSX" "$CONTROL" admit --host-db "$HOST" --venue-db "$VENUE" --mode same
"$TSX" "$CONTROL" admit --host-db "$HOST" --venue-db "$VENUE" --mode conflict
"$TSX" "$CONTROL" inspect --host-db "$HOST" --venue-db "$VENUE"
```

应观察：

- 第一个 `admit` 为 `{"tag":"admission","outcome":"accepted",...}`，且 `atomic.receipt`、`atomic.outbox`、`atomic.reservation` 均为 `true`；reservation/outbox 从 0 变为 1。
- 第二个相同 encoded semantics 为 `outcome:"deduplicated"`、`mutated:false`，同一 `receipt`、同一 `planId`，reservation/outbox 数量不增加。
- `--mode conflict` 仍使用同一个 `commandKey`，但固定 quantity/clientReference 不同；应为 `outcome:"rejected"`、`reason:"conflicting-semantics"`、`mutated:false`，且 `reservationCountBefore === reservationCountAfter`、`outboxCountBefore === outboxCountAfter`。
- `inspect` 的 host `admissions`、`plans`、`reservations`、`outboxes` 各只有一条对应 fixed plan；venue `counts.accepted === 0`、`counts.receiveCount === 0`。拒绝路径没有 venue 调用。

这证明的是本 fixture 的 single-writer transaction 和 command-key 语义比较；它不证明任何真实 venue 的 idempotency。

## 2. First falsifier：venue 已接受，owner 在 host ack 前退出

沿用第 1 节的数据库，执行：

```sh
set +e
"$TSX" "$CONTROL" dispatch --host-db "$HOST" --venue-db "$VENUE" --now 100 --crash-after-venue-acceptance
CRASH_STATUS=$?
set -e
printf 'crash-status=%s\n' "$CRASH_STATUS"
"$TSX" "$CONTROL" inspect --host-db "$HOST" --venue-db "$VENUE"
```

StartFresh 已经提交；重复/query Start 不应取得同一个 grant：
```sh
"$TSX" "$CONTROL" dispatch --host-db "$HOST" --venue-db "$VENUE" --now 200
"$TSX" "$CONTROL" inspect --host-db "$HOST" --venue-db "$VENUE"
```

重复 Start 应观察 `outcome:"not-dispatched"`，`start.transition:"AlreadyStarted"`、`start.grantIssued:false`、`start.evidenceOnly:true`；venue `counts.receiveCount` 仍为 1。持久化的 `DispatchStarted` 是 evidence，不是可重放 grant；lease/query 不能重建 process-bound one-use grant。

应观察：

- `crash-status=91`。
- dispatch 输出 `tag:"dispatch"`、`outcome:"owner-exit"`、`cut:"after-venue-acceptance-before-host-ack"`、`start.transition:"StartFresh"`、`start.grantConsumed:true`、`hostStateAfterCommit:"DispatchStarted"`、`hostAckPersisted:false`。
- host `events` 已有 `AdmissionAccepted` 和 `DispatchStarted`，没有 `VenueAckRecorded`；host `attempts[0].state === "Started"`，`outbox[0].state === "Started"`，`plans[0].state === "DispatchStarted"`，reservation 仍为 `Held`。
- venue `accepted` 恰有一条 fixed `requestId/attemptId/planId`，`counts.receiveCount` 恰为 1；这条 acceptance 已在独立 venue transaction 中提交。

这就是 protected first falsifier 的 crash cut：远端 acceptance 先 durable，host ack 尚未 durable。
### 2.1 Lost grant before native send

该额外 case 专门覆盖 `StartFresh` commit 后 response/grant 丢失的分支；它必须使用全新数据库：

```sh
RUN_LOST="$(mktemp -d "$ROOT/control-specimen/run-lost-grant.XXXXXX")"
HOST_LOST="$RUN_LOST/host.sqlite"
VENUE_LOST="$RUN_LOST/venue.sqlite"
"$TSX" "$CONTROL" init --host-db "$HOST_LOST" --venue-db "$VENUE_LOST"
"$TSX" "$CONTROL" admit --host-db "$HOST_LOST" --venue-db "$VENUE_LOST" --mode same
set +e
"$TSX" "$CONTROL" dispatch --host-db "$HOST_LOST" --venue-db "$VENUE_LOST" --now 100 --lose-dispatch-grant-before-send
LOST_STATUS=$?
set -e
printf 'lost-grant-status=%s\n' "$LOST_STATUS"
"$TSX" "$CONTROL" dispatch --host-db "$HOST_LOST" --venue-db "$VENUE_LOST" --now 200
"$TSX" "$CONTROL" recover --host-db "$HOST_LOST" --venue-db "$VENUE_LOST" --now 200
"$TSX" "$CONTROL" inspect --host-db "$HOST_LOST" --venue-db "$VENUE_LOST"
```

应观察 `lost-grant-status=92`，第一次 dispatch 的 `cut:"after-start-commit-before-native-send"`、`start.transition:"StartFresh"`、`start.grantIssued:true`、`start.grantConsumed:false`、`venueNativeSend:false`；第二次 Start 为 `AlreadyStarted` 且 `grantIssued:false`。recover 只能 lookup（此 fixture 中 venue 未接受，所以结果为 `Unknown`/`RecoveryRequired`），不得为了 lease expiry 重建 grant；venue `counts.receiveCount === 0`、`counts.accepted === 0`，host 仍只有一个 `DispatchStarted`。

## 3. Fresh invocation、移除 current catalog leaf、lease expiry 后只观察不重发

```sh
"$TSX" "$CONTROL" catalog-remove --host-db "$HOST" --venue-db "$VENUE"
"$TSX" "$CONTROL" recover --host-db "$HOST" --venue-db "$VENUE" --now 200
"$TSX" "$CONTROL" inspect --host-db "$HOST" --venue-db "$VENUE"
```

应观察：

- `catalog-remove` 报告 `currentCatalogAvailable:false`，同时 `historicalInterpretationAvailable:true`。
- 这是新的进程 invocation；`recover --now 200` 应报告 `outcome:"recovered-by-observation"`、`leaseExpired:true`、`currentCatalogAvailable:false`、`historicalInterpretationResolved:true`、`dispatchedAgain:false`、`hostAckPersisted:true`。
- recovery 输出的 `historicalObserver.id/version` 来自 durable interpretation binding，而不是 current catalog。它通过 venue `lookup` 观察已提交 acceptance，再由 host writer 记录 `VenueObserved`；不得调用 venue `accept`。
- host 现在恰有一个 `DispatchStarted` 和一个 ack-equivalent durable observation（`VenueObserved`；正常未崩溃路径的 ack event 是 `VenueAckRecorded`）；`plans[0].state === "Acknowledged"`、`attempts[0].state === "Acknowledged"`、`outboxes[0].state === "Acked"`，reservation 仍保留。
- venue `counts.accepted === 1`、`counts.receiveCount === 1`、`counts.lookups >= 1`。再次执行同一个 `recover --now 300` 只应报告 `outcome:"already-resolved"`，`dispatchedAgain:false`，且 venue `counts.receiveCount` 仍为 1。

因此 current catalog leaf 的删除不会关闭历史 observer；lease 到期不会成为旧 attempt 的 resend permission。该垂直 slice 只证明 host law 和 controlled fixture 的 lookup 路径，不证明真实 venue 的 native idempotency、原子性或 replay horizon。

## 4. Historical implementation 缺失：RecoveryRequired，保留原 bytes/identities，不 reprepare

使用另一份全新数据库，避免第 3 节已经 resolved 的 plan：

```sh
RUN_MISSING="$(mktemp -d "$ROOT/control-specimen/run-missing-history.XXXXXX")"
HOST_MISSING="$RUN_MISSING/host.sqlite"
VENUE_MISSING="$RUN_MISSING/venue.sqlite"
"$TSX" "$CONTROL" init --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING"
"$TSX" "$CONTROL" admit --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING" --mode same
set +e
"$TSX" "$CONTROL" dispatch --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING" --now 100 --crash-after-venue-acceptance
CRASH_STATUS_MISSING=$?
set -e
printf 'crash-status-missing-history=%s\n' "$CRASH_STATUS_MISSING"
"$TSX" "$CONTROL" history-remove --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING"
"$TSX" "$CONTROL" recover --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING" --now 200
"$TSX" "$CONTROL" inspect --host-db "$HOST_MISSING" --venue-db "$VENUE_MISSING"
```

应观察：

- crash status 仍为 91，venue `accepted` 恰一条。
- recovery 为 `outcome:"RecoveryRequired"`、`reason:"missing-historical-interpretation"`、`historicalInterpretationResolved:false`、`dispatchedAgain:false`、`reprepared:false`。
- recovery 的 `original` 同时保留 `intentBytes`、`planBytes`、`capabilityBinding`、`declarationRevision`、`semanticDigest`、`implementationId/version`、`requestId`、`attemptId`；这些值来自 host durable plan/attempt，不是重新构造的 plan。
- host `attempts[0].state === "RecoveryRequired"`、`plans[0].state === "RecoveryRequired"`、`outboxes[0].state === "RecoveryRequired"`，reservation 仍 `Held`；不得有 `VenueObserved` 或 host ack。
- venue `counts.accepted === 1`、`counts.receiveCount === 1`；历史 implementation 缺失不能触发新 native send。

这是 fixture 对 A5 的 fail-closed 分支；它不声称缺失 implementation 时真实部署能自动补装 observer。

## 5. Deferred predicate：false baseline、gap、single owner、decision/Keep/rearm fencing

### 5.1 False baseline survives a process exit and then crosses

使用第 1 节的 `HOST`，或另起全新 host（venue 不参与 deferred transition）：

```sh
RUN_DEFER="$(mktemp -d "$ROOT/control-specimen/run-deferred.XXXXXX")"
HOST_DEFER="$RUN_DEFER/host.sqlite"
VENUE_DEFER="$RUN_DEFER/venue.sqlite"
"$TSX" "$CONTROL" init --host-db "$HOST_DEFER" --venue-db "$VENUE_DEFER"
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action claim-owner
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action claim-owner
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action fact-false
# 上一个命令已经退出；以下是 fresh invocation
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action fact-cross
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action evidence-dispatch
"$TSX" "$CONTROL" inspect --host-db "$HOST_DEFER" --venue-db "$VENUE_DEFER"
```

应观察：

- `claim-owner` 为 `outcome:"claimed"`、`liveOwnerCount:1`；再次运行相同命令为 `outcome:"already-owned"`、`mutated:false`，仍只有一个 live owner。
- `fact-false` 为 `transition:"NoActivation"`、`reason:"baseline-established"`、`candidate:false`，且 checkpoint 中保存 sequence 1、value 90 对应的 false baseline。该行写入并在命令退出后由下一 invocation 重新读取。
- `fact-cross` 为 `transition:"Candidate"`、`candidate:true`、`authorizationGranted:false`、`dispatchStarted:false`，并持久化一个 `decision_handles` row；它只产生 `DeferredCandidate`，不产生 `DispatchStarted` 或 venue `counts.receiveCount`。
- `evidence-dispatch` 为 `reason:"evidence-is-not-authorization"`、`mutated:false`、`dispatchStartedCountBefore === dispatchStartedCountAfter`；证据只能 request decision，不能成为 writer permission。

### 5.2 Continuity gap cannot manufacture a crossing

Gap case 使用另一份全新 host：

```sh
RUN_GAP="$(mktemp -d "$ROOT/control-specimen/run-deferred-gap.XXXXXX")"
HOST_GAP="$RUN_GAP/host.sqlite"
VENUE_GAP="$RUN_GAP/venue.sqlite"
"$TSX" "$CONTROL" init --host-db "$HOST_GAP" --venue-db "$VENUE_GAP"
"$TSX" "$CONTROL" deferred --host-db "$HOST_GAP" --action claim-owner
"$TSX" "$CONTROL" deferred --host-db "$HOST_GAP" --action fact-false
"$TSX" "$CONTROL" deferred --host-db "$HOST_GAP" --action fact-gap
"$TSX" "$CONTROL" deferred --host-db "$HOST_GAP" --action fact-after-gap
"$TSX" "$CONTROL" inspect --host-db "$HOST_GAP" --venue-db "$VENUE_GAP"
```

应观察：

- `fact-gap` 使用 sequence 3（expected 2）且 value 110；结果为 `transition:"Gap"`、`candidate:false`，checkpoint 状态 `Gap`，baseline/lastTruth 被清空。
- `fact-after-gap` sequence 4 只重新建立 baseline，即 `transition:"NoActivation"`、`reason:"baseline-established-after-gap"`、`candidate:false`；它不能把 gap 之后的第一个高值伪造成 crossing。
- host `events` 没有 `DeferredCandidate`，也没有 `DispatchStarted`；venue accepted/receiveCount 仍为 0。

### 5.3 Keep、new epoch/future boundary、stale reply/correction

在 5.1 的 `HOST_DEFER` 上继续执行（此时已有 pending handle）：

```sh
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action keep
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action rearm
"$TSX" "$CONTROL" deferred --host-db "$HOST_DEFER" --action stale
"$TSX" "$CONTROL" inspect --host-db "$HOST_DEFER" --venue-db "$VENUE_DEFER"
```

应观察：

- `keep` 为 `outcome:"kept"`、`persistedHandle` 非空、`authorizationGranted:false`、`dispatchStarted:false`；该 handle 的 status 为 `Kept`，不是 transient stdout 草稿。
- `rearm` 为 `outcome:"rearmed"`，`oldEpoch:1`、`newEpoch:2`，`newFutureBoundary` 大于旧 boundary；epoch 1 handle 被 `Superseded`，epoch 1 owner 被 `Released`，当前 revision 为新 epoch 且无 baseline。
- `stale` 的 reply 和 correction 均为 `outcome:"Fenced"`、`mutated:false`、`dispatchAuthorized:false`。旧 epoch 的 response/correction 不能修改新 epoch checkpoint，也不能产生 dispatch。
- rearm 后执行 `deferred --action claim-owner` 可以取得 epoch 2 的新 owner；同一 epoch 重复 claim 仍只有一个 live owner。

## 6. State/authority inspection fields

`inspect` 返回以下权威状态及证据投影，供命令输出与两份数据库交叉核对：

- `host.plans` 保存完整 encoded plan 和 identities；`host.attempts` 保存 request bytes、digest、`started_event_id` 和 ack/unknown state。
- `host.events` 保存每个 control transition 的 encoded payload；`DispatchStarted` 和 `VenueAckRecorded`/`VenueObserved` 的顺序可直接检查。
- `host.reservations`、`host.admissions`、`host.outboxes` 可用来核对 rejection/duplicate 是否产生 mutation。
- `host.deferred`、`host.owners`、`host.handles`、event payload 可用来核对 checkpoint、owner epoch、decision handle、rearm 和 fencing。
- `venue.accepted` 是独立 durable acceptance ledger；`venue.invocations` 是每次 native-call receive（故意和 accepted 分表）；`venue.lookups` 是 recovery observation；`venue.counts.receiveCount` 是 host 可检查的 dispatch receive 计数。

## Unsupported branches and claims boundary

本 specimen 不实现：真实 SDK/HTTP/TCP broker、凭据注入、网络故障、真实 venue idempotency/native atomicity、跨节点 clock/lease fencing、真实 provider catalog discovery、sealed execution payload、compensation/fill/exposure reconciliation、Alice delivery、workflow engine、并发压力、SQLite commit 内部崩溃注入、`SuspendControl`/`CloseWithoutDispatch`/`EscalateDecision` 的其他冻结处置，以及自动安装缺失 historical interpretation。已执行命令检验的范围仅为：

1. host writer 对 fixed encoded intent/plan 的 dedup/conflict/atomic admission；
2. `DispatchStarted` commit-before-send 与独立 venue acceptance/host-ack crash cut；
3. exact historical binding lookup、current catalog removal 后 observation、missing interpretation 的 `RecoveryRequired` 与 no-reprepare/no-resend；
4. writer permit 的 plan/attempt/request digest binding；
5. bounded pure `advance`、durable false baseline、continuity-gap fencing、one live activation owner、decision-only evidence、persistent Keep、new epoch/future boundary 和 stale reply/correction fencing。

本 specimen 的 digest 仅是 fixed fixture 的 UTF-8 SHA-256 over its already-fixed JSON bytes；它不实现 common-model 要求的 RFC8785 JCS、完整 domain-separated digest 组合，因此不能被当作目标协议 digest conformance。

因此 venue `accepted`/`receiveCount` 计数不能升级为真实 venue 的原生保证；它们只提供受控 fixture 的可检查证据，用于区分主机规律与需要 Provider 实测的保证。
