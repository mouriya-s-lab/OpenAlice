import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { z } from "zod";

/*
 * This file is a deliberately small control authority.  It is not a broker
 * runtime: the only venue is venue-worker.py, an independent deterministic
 * process whose SQLite ledger is never opened by this process.
 */

const FIXTURE_SCHEMA = "control-specimen-v1";
const CAPABILITY_ID = "order.place";
const CAPABILITY_BINDING = "fixture/order.place@revision-1#semantic-control-v1";
const DECLARATION_REVISION = "1";
const SEMANTIC_VERSION = "control-semantics-v1";
const IMPLEMENTATION_ID = "fixture-order-compiler";
const IMPLEMENTATION_VERSION = "1";
const SCOPE = "account:fixture/alice";
const POLICY = "IndependentBatch";
const CRITERION = "acknowledged-or-observe";
const COMMAND_KEY = "control-command-1";
const DEFERRED_REVISION_ID = "deferred-revision-1";
const DEFERRED_SOURCE_ID = "fixture-price-source";
const DEFERRED_PREDICATE_ID = "price-at-least-100";
const DEFERRED_PREDICATE_REVISION = "predicate-revision-1";
const DEFERRED_PLAN_ID = "plan-control-1";
const FIXTURE_NOW = 100;
const INITIAL_FUTURE_BOUNDARY = 100;
const LEASE_DURATION = 10;

const digestSchema = z.string().regex(/^[0-9a-f]{64}$/);
type Digest = z.output<typeof digestSchema>;

const orderIntentSchema = z.strictObject({
  schemaVersion: z.literal("control.intent.v1"),
  accountScope: z.literal(SCOPE),
  instrument: z.strictObject({
    source: z.literal("fixture"),
    nativeId: z.literal("ALPHA"),
  }),
  side: z.enum(["buy", "sell"]),
  quantity: z.string().regex(/^(?:[1-9]\d*|0)(?:\.\d{2})$/),
  limitPrice: z.string().regex(/^(?:[1-9]\d*|0)(?:\.\d{2})$/),
  clientReference: z.string().min(1),
});
type OrderIntent = z.output<typeof orderIntentSchema>;

const preparedSchema = z.strictObject({
  schemaVersion: z.literal("control.prepared.v1"),
  nativeSymbol: z.literal("FIXTURE-ALPHA"),
  side: z.literal("BUY"),
  quantity: z.string().regex(/^(?:[1-9]\d*|0)(?:\.\d{2})$/),
  limitPrice: z.string().regex(/^(?:[1-9]\d*|0)(?:\.\d{2})$/),
  clientReference: z.string().min(1),
  lookupIdentity: z.string().min(1),
});
type Prepared = z.output<typeof preparedSchema>;

const policySchema = z.enum(["IndependentBatch"]);
const planSchema = z.strictObject({
  schemaVersion: z.literal("control.plan.v1"),
  planId: z.string().min(1),
  commandKey: z.literal(COMMAND_KEY),
  capability: z.strictObject({
    id: z.literal(CAPABILITY_ID),
    binding: z.literal(CAPABILITY_BINDING),
    declarationRevision: z.literal(DECLARATION_REVISION),
    semanticVersion: z.literal(SEMANTIC_VERSION),
  }),
  implementation: z.strictObject({
    id: z.literal(IMPLEMENTATION_ID),
    version: z.literal(IMPLEMENTATION_VERSION),
  }),
  semanticDigest: digestSchema,
  intentBytes: z.string().min(2),
  preparedBytes: z.string().min(2),
  requestId: z.string().min(1),
  attemptId: z.string().min(1),
  requestBytes: z.string().min(2),
  requestDigest: digestSchema,
  scope: z.literal(SCOPE),
  policy: policySchema,
  criterion: z.literal(CRITERION),
  expiry: z.number().int().nonnegative(),
});
type Plan = z.output<typeof planSchema>;

type AdmissionMode = "same" | "conflict";
type Fixture = Readonly<{
  intent: OrderIntent;
  prepared: Prepared;
  plan: Plan;
  intentBytes: string;
  preparedBytes: string;
  planBytes: string;
  semanticsDigest: Digest;
}>;

const planStateSchema = z.enum(["Admitted", "DispatchStarted", "Acknowledged", "RecoveryRequired"]);
type PlanState = z.output<typeof planStateSchema>;
const attemptStateSchema = z.enum(["Started", "Acknowledged", "Unknown", "RecoveryRequired"]);
type AttemptState = z.output<typeof attemptStateSchema>;
const outboxStateSchema = z.enum(["Ready", "Started", "Acked", "RecoveryRequired"]);
type OutboxState = z.output<typeof outboxStateSchema>;
const reservationStateSchema = z.enum(["Held", "Released"]);
type ReservationState = z.output<typeof reservationStateSchema>;
const ownerStatusSchema = z.enum(["Live", "Released"]);
type OwnerStatus = z.output<typeof ownerStatusSchema>;
const deferredStatusSchema = z.enum(["Waiting", "DecisionPending", "Suspended", "Rearmed"]);
type DeferredStatus = z.output<typeof deferredStatusSchema>;
const handleStatusSchema = z.enum(["Pending", "Kept", "Superseded", "Closed"]);
type HandleStatus = z.output<typeof handleStatusSchema>;
const eventKindSchema = z.enum([
  "AdmissionAccepted",
  "DispatchStarted",
  "VenueAckRecorded",
  "VenueObserved",
  "RecoveryRequired",
  "VenueObservationMissing",
  "CatalogLeafRemoved",
  "HistoricalInterpretationRemoved",
  "DeferredOwnerClaimed",
  "DeferredCheckpointAdvanced",
  "DeferredGap",
  "DeferredCandidate",
  "DecisionKept",
  "DeferredRearmed",
]);
type EventKind = z.output<typeof eventKindSchema>;

const planRowSchema = z.strictObject({
  plan_id: z.string(),
  command_key: z.string(),
  semantics_digest: digestSchema,
  capability_binding: z.string(),
  capability_id: z.string(),
  declaration_revision: z.string(),
  semantic_digest: digestSchema,
  implementation_id: z.string(),
  implementation_version: z.string(),
  intent_bytes: z.string(),
  plan_bytes: z.string(),
  request_id: z.string(),
  attempt_id: z.string(),
  request_bytes: z.string(),
  request_digest: digestSchema,
  scope: z.string(),
  policy: policySchema,
  criterion: z.string(),
  expiry: z.number().int(),
  state: planStateSchema,
});
type PlanRow = z.output<typeof planRowSchema>;

const admissionRowSchema = z.strictObject({
  command_key: z.string(),
  semantics_digest: digestSchema,
  plan_id: z.string(),
  receipt_bytes: z.string(),
});
type AdmissionRow = z.output<typeof admissionRowSchema>;

const reservationRowSchema = z.strictObject({
  reservation_id: z.string(),
  plan_id: z.string(),
  scope: z.string(),
  state: reservationStateSchema,
});
type ReservationRow = z.output<typeof reservationRowSchema>;

const outboxRowSchema = z.strictObject({
  outbox_id: z.string(),
  plan_id: z.string(),
  state: outboxStateSchema,
  lease_until: z.number().int().nullable(),
  attempt_id: z.string().nullable(),
});
type OutboxRow = z.output<typeof outboxRowSchema>;

const attemptRowSchema = z.strictObject({
  attempt_id: z.string(),
  plan_id: z.string(),
  request_id: z.string(),
  request_bytes: z.string(),
  request_digest: digestSchema,
  started_event_id: z.number().int(),
  state: attemptStateSchema,
  ack_bytes: z.string().nullable(),
});
type AttemptRow = z.output<typeof attemptRowSchema>;

const eventRowSchema = z.strictObject({
  event_id: z.number().int(),
  kind: eventKindSchema,
  aggregate_id: z.string(),
  payload_bytes: z.string(),
});
type EventRow = z.output<typeof eventRowSchema>;

const catalogRowSchema = z.strictObject({
  binding_id: z.string(),
  capability_id: z.string(),
  declaration_revision: z.string(),
  semantic_digest: digestSchema,
  implementation_id: z.string(),
  implementation_version: z.string(),
  available: z.number().int().min(0).max(1),
});
type CatalogRow = z.output<typeof catalogRowSchema>;

const interpretationRowSchema = z.strictObject({
  binding_id: z.string(),
  capability_id: z.string(),
  declaration_revision: z.string(),
  semantic_digest: digestSchema,
  implementation_id: z.string(),
  implementation_version: z.string(),
  observer_id: z.string(),
  observer_version: z.string(),
  available: z.number().int().min(0).max(1),
});
type InterpretationRow = z.output<typeof interpretationRowSchema>;

const predicateSchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("greater-than-or-equal"), threshold: z.number().int() }),
]);
type Predicate = z.output<typeof predicateSchema>;

const checkpointSchema = z.strictObject({
  revisionId: z.literal(DEFERRED_REVISION_ID),
  epoch: z.number().int().positive(),
  sourceId: z.literal(DEFERRED_SOURCE_ID),
  predicateId: z.literal(DEFERRED_PREDICATE_ID),
  predicateRevision: z.literal(DEFERRED_PREDICATE_REVISION),
  futureBoundary: z.number().int().nonnegative(),
  lastSequence: z.number().int().nonnegative().nullable(),
  baseline: z.number().int().nullable(),
  lastTruth: z.boolean().nullable(),
  status: z.enum(["Ready", "Gap"]),
});
type Checkpoint = z.output<typeof checkpointSchema>;

const sourceFactSchema = z.discriminatedUnion("kind", [
  z.strictObject({
    kind: z.literal("value"),
    epoch: z.number().int().positive(),
    sourceId: z.literal(DEFERRED_SOURCE_ID),
    eventId: z.string().min(1),
    sequence: z.number().int().positive(),
    observedAt: z.number().int().nonnegative(),
    value: z.number().int(),
  }),
  z.strictObject({
    kind: z.literal("correction"),
    epoch: z.number().int().positive(),
    sourceId: z.literal(DEFERRED_SOURCE_ID),
    eventId: z.string().min(1),
    sequence: z.number().int().positive(),
    observedAt: z.number().int().nonnegative(),
    value: z.number().int(),
    replacesEventId: z.string().min(1),
  }),
]);
type SourceFact = z.output<typeof sourceFactSchema>;

const evidenceSchema = z.strictObject({
  evidenceId: z.string().min(1),
  revisionId: z.literal(DEFERRED_REVISION_ID),
  epoch: z.number().int().positive(),
  sourceId: z.literal(DEFERRED_SOURCE_ID),
  eventId: z.string().min(1),
  sequence: z.number().int().positive(),
  observedAt: z.number().int().nonnegative(),
  beforeValue: z.number().int(),
  afterValue: z.number().int(),
  predicateRevision: z.literal(DEFERRED_PREDICATE_REVISION),
});
type Evidence = z.output<typeof evidenceSchema>;

const deferredRowSchema = z.strictObject({
  revision_id: z.string(),
  plan_id: z.string(),
  epoch: z.number().int().positive(),
  source_id: z.string(),
  predicate_id: z.string(),
  predicate_revision: z.string(),
  threshold: z.number().int(),
  future_boundary: z.number().int().nonnegative(),
  checkpoint_bytes: z.string(),
  status: deferredStatusSchema,
  disposition: z.literal("RequestDecision"),
  selected_evidence_id: z.string().nullable(),
});
type DeferredRow = z.output<typeof deferredRowSchema>;

const ownerRowSchema = z.strictObject({
  owner_id: z.string(),
  revision_id: z.string(),
  epoch: z.number().int().positive(),
  status: ownerStatusSchema,
  acquired_at: z.number().int().nonnegative(),
});
type OwnerRow = z.output<typeof ownerRowSchema>;

const handleRowSchema = z.strictObject({
  handle_id: z.string(),
  revision_id: z.string(),
  epoch: z.number().int().positive(),
  evidence_bytes: z.string(),
  status: handleStatusSchema,
  disposition: z.literal("RequestDecision"),
});
type HandleRow = z.output<typeof handleRowSchema>;

const receiptSchema = z.strictObject({
  tag: z.literal("receipt"),
  commandKey: z.literal(COMMAND_KEY),
  planId: z.string(),
  semanticsDigest: digestSchema,
});
type Receipt = z.output<typeof receiptSchema>;

const venueAcceptedSchema = z.strictObject({
  tag: z.literal("accepted"),
  requestId: z.string(),
  attemptId: z.string(),
  planId: z.string(),
  payloadDigest: digestSchema,
  outcome: z.enum(["new", "duplicate"]),
  acceptedSequence: z.number().int().positive(),
  acceptedCount: z.number().int().nonnegative(),
  receiveCount: z.number().int().nonnegative(),
});
type VenueAccepted = z.output<typeof venueAcceptedSchema>;

const venueLookupMissingSchema = z.strictObject({
  tag: z.literal("lookup"),
  requestId: z.string(),
  attemptId: z.string(),
  found: z.literal(false),
  receiveCount: z.number().int().nonnegative(),
  lookupCount: z.number().int().nonnegative(),
});
const venueLookupFoundSchema = z.strictObject({
  tag: z.literal("lookup"),
  requestId: z.string(),
  attemptId: z.string(),
  found: z.literal(true),
  planId: z.string(),
  payloadBytes: z.string(),
  payloadDigest: digestSchema,
  acceptedSequence: z.number().int().positive(),
  receiveCount: z.number().int().nonnegative(),
  lookupCount: z.number().int().nonnegative(),
});
type VenueLookup = z.output<typeof venueLookupMissingSchema> | z.output<typeof venueLookupFoundSchema>;

const venueDumpSchema = z.strictObject({
  tag: z.literal("dump"),
  schema: z.literal("venue-ledger-v1"),
  accepted: z.array(z.strictObject({
    requestId: z.string(),
    attemptId: z.string(),
    planId: z.string(),
    payloadBytes: z.string(),
    payloadDigest: digestSchema,
    acceptedSequence: z.number().int().positive(),
  })),
  invocations: z.array(z.strictObject({
    invocationSequence: z.number().int().positive(),
    requestId: z.string(),
    attemptId: z.string(),
    planId: z.string(),
    payloadDigest: digestSchema,
  })),
  lookups: z.array(z.strictObject({
    lookupSequence: z.number().int().positive(),
    requestId: z.string(),
    attemptId: z.string(),
  })),
  counts: z.strictObject({
    accepted: z.number().int().nonnegative(),
    receiveCount: z.number().int().nonnegative(),
    lookups: z.number().int().nonnegative(),
  }),
});
type VenueDump = z.output<typeof venueDumpSchema>;

const venueInitializedSchema = z.strictObject({
  tag: z.literal("initialized"),
  schema: z.literal("venue-ledger-v1"),
  acceptedCount: z.number().int().nonnegative(),
  receiveCount: z.number().int().nonnegative(),
});
const venueResponseSchema = z.union([
  venueInitializedSchema,
  venueAcceptedSchema,
  venueLookupMissingSchema,
  venueLookupFoundSchema,
  venueDumpSchema,
]);
type VenueResponse = z.output<typeof venueResponseSchema>;

type VenueOperation =
  | { readonly tag: "init" }
  | { readonly tag: "accept"; readonly requestId: string; readonly attemptId: string; readonly planId: string; readonly payloadBytes: string; readonly payloadDigest: Digest }
  | { readonly tag: "lookup"; readonly requestId: string; readonly attemptId: string }
  | { readonly tag: "dump" };
type VenueCall = Readonly<{ response: VenueResponse; rawBytes: string }>;

const PROCESS_GRANT_TOKEN = Symbol("control-process-bound-grant");

type ConsumedWriterPermit<PlanId extends string = string, AttemptId extends string = string> = Readonly<{
  readonly tag: "consumed-writer-permit";
  readonly planId: PlanId;
  readonly attemptId: AttemptId;
  readonly requestId: string;
  readonly requestDigest: Digest;
}>;

/**
 * The grant is deliberately a non-serializable, process-bound one-use
 * capability.  Persisted DispatchStarted evidence is not this grant.
 */
class WriterPermit<PlanId extends string = string, AttemptId extends string = string> {
  private consumed = false;
  private readonly processToken = PROCESS_GRANT_TOKEN;

  constructor(
    readonly planId: PlanId,
    readonly attemptId: AttemptId,
    readonly requestId: string,
    readonly requestDigest: Digest,
  ) {}

  consume(): ConsumedWriterPermit<PlanId, AttemptId> {
    if (this.processToken !== PROCESS_GRANT_TOKEN || this.consumed) {
      throw new Error("dispatch grant is not live");
    }
    this.consumed = true;
    return {
      tag: "consumed-writer-permit",
      planId: this.planId,
      attemptId: this.attemptId,
      requestId: this.requestId,
      requestDigest: this.requestDigest,
    };
  }
}

type NativeDispatch = Readonly<{ call: VenueCall; permit: ConsumedWriterPermit }>;

type AdvanceResult =
  | Readonly<{ tag: "NoActivation"; checkpoint: Checkpoint; reason: "baseline-established" | "baseline-established-after-gap" | "before-future-boundary" | "stale-epoch" | "correction-requires-maintenance" }>
  | Readonly<{ tag: "Candidate"; checkpoint: Checkpoint; evidence: Evidence }>
  | Readonly<{ tag: "Gap"; checkpoint: Checkpoint; expectedSequence: number; receivedSequence: number; reason: "source-identity-gap" | "continuity-gap" }>;

const optionValueNameSchema = z.enum(["host-db", "venue-db", "mode", "now", "action"]);
type OptionValueName = z.output<typeof optionValueNameSchema>;
type CliFlag =
  | Readonly<{ tag: "value"; name: OptionValueName; value: string }>
  | Readonly<{ tag: "switch"; name: "crash-after-venue-acceptance" | "lose-dispatch-grant-before-send" }>;
type FlagName = OptionValueName | "crash-after-venue-acceptance" | "lose-dispatch-grant-before-send";

const actionSchema = z.enum([
  "claim-owner",
  "fact-false",
  "fact-cross",
  "fact-gap",
  "fact-after-gap",
  "evidence-dispatch",
  "keep",
  "rearm",
  "stale",
]);
type DeferredAction = z.output<typeof actionSchema>;

type Command =
  | Readonly<{ tag: "init"; hostDb: string; venueDb: string }>
  | Readonly<{ tag: "admit"; hostDb: string; venueDb: string; mode: AdmissionMode }>
  | Readonly<{ tag: "dispatch"; hostDb: string; venueDb: string; now: number; crashCut: boolean; loseGrant: boolean }>
  | Readonly<{ tag: "recover"; hostDb: string; venueDb: string; now: number }>
  | Readonly<{ tag: "catalog-remove"; hostDb: string; venueDb: string }>
  | Readonly<{ tag: "history-remove"; hostDb: string; venueDb: string }>
  | Readonly<{ tag: "inspect"; hostDb: string; venueDb: string }>
  | Readonly<{ tag: "deferred"; hostDb: string; action: DeferredAction }>;

function assertNever(value: never): never {
  throw new Error(`unhandled variant: ${String(value)}`);
}

function encodeObject(value: unknown): string {
  const bytes = JSON.stringify(value);
  if (bytes === undefined) throw new Error("value is not JSON encodable");
  return bytes;
}

function digest(value: string): Digest {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function parseNonnegativeInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) throw new Error(`invalid ${name}`);
  return parsed;
}

function buildFixture(mode: AdmissionMode): Fixture {
  const conflict = mode === "conflict";
  const quantity = conflict ? "2.00" : "1.25";
  const clientReference = conflict ? "control-conflicting-intent" : "control-intent-1";
  const intent = orderIntentSchema.parse({
    schemaVersion: "control.intent.v1",
    accountScope: SCOPE,
    instrument: { source: "fixture", nativeId: "ALPHA" },
    side: "buy",
    quantity,
    limitPrice: "100.50",
    clientReference,
  });
  const prepared = preparedSchema.parse({
    schemaVersion: "control.prepared.v1",
    nativeSymbol: "FIXTURE-ALPHA",
    side: "BUY",
    quantity,
    limitPrice: "100.50",
    clientReference,
    lookupIdentity: `fixture-order:${clientReference}`,
  });
  const intentBytes = encodeObject(intent);
  const preparedBytes = encodeObject(prepared);
  const semanticsDigest = digest(`${intentBytes}\n${preparedBytes}`);
  const plan = planSchema.parse({
    schemaVersion: "control.plan.v1",
    planId: conflict ? "plan-control-conflict" : "plan-control-1",
    commandKey: COMMAND_KEY,
    capability: {
      id: CAPABILITY_ID,
      binding: CAPABILITY_BINDING,
      declarationRevision: DECLARATION_REVISION,
      semanticVersion: SEMANTIC_VERSION,
    },
    implementation: { id: IMPLEMENTATION_ID, version: IMPLEMENTATION_VERSION },
    semanticDigest: semanticsDigest,
    intentBytes,
    preparedBytes,
    requestId: conflict ? "request-control-conflict" : "request-control-1",
    attemptId: conflict ? "attempt-control-conflict" : "attempt-control-1",
    requestBytes: preparedBytes,
    requestDigest: digest(preparedBytes),
    scope: SCOPE,
    policy: POLICY,
    criterion: CRITERION,
    expiry: 1000,
  });
  const planBytes = encodeObject(plan);
  return { intent, prepared, plan, intentBytes, preparedBytes, planBytes, semanticsDigest };
}

function parsePlanBytes(bytes: string): Plan {
  const plan = planSchema.parse(JSON.parse(bytes));
  const intent = orderIntentSchema.parse(JSON.parse(plan.intentBytes));
  const prepared = preparedSchema.parse(JSON.parse(plan.preparedBytes));
  if (encodeObject(intent) !== plan.intentBytes) throw new Error("intent bytes are not canonical");
  if (encodeObject(prepared) !== plan.preparedBytes) throw new Error("prepared bytes are not canonical");
  if (plan.semanticDigest !== digest(`${plan.intentBytes}\n${plan.preparedBytes}`)) throw new Error("plan semantic digest mismatch");
  if (plan.requestBytes !== plan.preparedBytes) throw new Error("request does not retain prepared bytes");
  if (plan.requestDigest !== digest(plan.requestBytes)) throw new Error("request digest mismatch");
  return plan;
}

function configureHost(db: DatabaseSync): void {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = FULL;
    CREATE TABLE IF NOT EXISTS plans (
      plan_id TEXT PRIMARY KEY,
      command_key TEXT NOT NULL,
      semantics_digest TEXT NOT NULL,
      capability_binding TEXT NOT NULL,
      capability_id TEXT NOT NULL,
      declaration_revision TEXT NOT NULL,
      semantic_digest TEXT NOT NULL,
      implementation_id TEXT NOT NULL,
      implementation_version TEXT NOT NULL,
      intent_bytes TEXT NOT NULL,
      plan_bytes TEXT NOT NULL,
      request_id TEXT NOT NULL,
      attempt_id TEXT NOT NULL,
      request_bytes TEXT NOT NULL,
      request_digest TEXT NOT NULL,
      scope TEXT NOT NULL,
      policy TEXT NOT NULL,
      criterion TEXT NOT NULL,
      expiry INTEGER NOT NULL,
      state TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS admissions (
      command_key TEXT PRIMARY KEY,
      semantics_digest TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      receipt_bytes TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reservations (
      reservation_id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL UNIQUE,
      scope TEXT NOT NULL,
      state TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS outbox (
      outbox_id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL UNIQUE,
      state TEXT NOT NULL,
      lease_until INTEGER,
      attempt_id TEXT
    );
    CREATE TABLE IF NOT EXISTS attempts (
      attempt_id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL,
      request_id TEXT NOT NULL,
      request_bytes TEXT NOT NULL,
      request_digest TEXT NOT NULL,
      started_event_id INTEGER NOT NULL,
      state TEXT NOT NULL,
      ack_bytes TEXT
    );
    CREATE TABLE IF NOT EXISTS events (
      event_id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      aggregate_id TEXT NOT NULL,
      payload_bytes TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS current_catalog (
      binding_id TEXT PRIMARY KEY,
      capability_id TEXT NOT NULL,
      declaration_revision TEXT NOT NULL,
      semantic_digest TEXT NOT NULL,
      implementation_id TEXT NOT NULL,
      implementation_version TEXT NOT NULL,
      available INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS interpretations (
      binding_id TEXT PRIMARY KEY,
      capability_id TEXT NOT NULL,
      declaration_revision TEXT NOT NULL,
      semantic_digest TEXT NOT NULL,
      implementation_id TEXT NOT NULL,
      implementation_version TEXT NOT NULL,
      observer_id TEXT NOT NULL,
      observer_version TEXT NOT NULL,
      available INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS deferred_revisions (
      revision_id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL,
      epoch INTEGER NOT NULL,
      source_id TEXT NOT NULL,
      predicate_id TEXT NOT NULL,
      predicate_revision TEXT NOT NULL,
      threshold INTEGER NOT NULL,
      future_boundary INTEGER NOT NULL,
      checkpoint_bytes TEXT NOT NULL,
      status TEXT NOT NULL,
      disposition TEXT NOT NULL,
      selected_evidence_id TEXT
    );
    CREATE TABLE IF NOT EXISTS deferred_owners (
      owner_id TEXT PRIMARY KEY,
      revision_id TEXT NOT NULL,
      epoch INTEGER NOT NULL,
      status TEXT NOT NULL,
      acquired_at INTEGER NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS one_live_deferred_owner

      ON deferred_owners(revision_id) WHERE status = 'Live';
    CREATE TABLE IF NOT EXISTS deferred_consumed (
      revision_id TEXT NOT NULL,
      epoch INTEGER NOT NULL,
      source_event_id TEXT NOT NULL,
      sequence INTEGER NOT NULL,
      fact_bytes TEXT NOT NULL,
      PRIMARY KEY (revision_id, epoch, source_event_id)
    );
    CREATE TABLE IF NOT EXISTS decision_handles (
      handle_id TEXT PRIMARY KEY,
      revision_id TEXT NOT NULL,
      epoch INTEGER NOT NULL,
      evidence_bytes TEXT NOT NULL,
      status TEXT NOT NULL,
      disposition TEXT NOT NULL
    );
  `);
}

function openHost(path: string): DatabaseSync {
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  configureHost(db);
  return db;
}

function withHost<A>(path: string, work: (db: DatabaseSync) => A): A {
  const db = openHost(path);
  try {
    return work(db);
  } finally {
    db.close();
  }
}

function inTransaction<A>(db: DatabaseSync, work: () => A): A {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = work();
    db.exec("COMMIT");
    return result;
  } catch (error) {
    try {
      db.exec("ROLLBACK");
    } catch {
      // Preserve the original failure; the outer command reports it.
    }
    throw error;
  }
}

function appendEvent(db: DatabaseSync, kind: EventKind, aggregateId: string, payload: unknown): number {
  const result = db.prepare(
    "INSERT INTO events(kind, aggregate_id, payload_bytes) VALUES (?, ?, ?)",
  ).run(kind, aggregateId, encodeObject(payload));
  return Number(result.lastInsertRowid);
}

function getPlan(db: DatabaseSync, planId: string): PlanRow | null {
  const row = db.prepare(
    `SELECT plan_id, command_key, semantics_digest, capability_binding, capability_id,
      declaration_revision, semantic_digest, implementation_id, implementation_version,
      intent_bytes, plan_bytes, request_id, attempt_id, request_bytes, request_digest,
      scope, policy, criterion, expiry, state FROM plans WHERE plan_id = ?`,
  ).get(planId);
  if (row === undefined || row === null) return null;
  return planRowSchema.parse(row);
}

function getAdmission(db: DatabaseSync, commandKey: string): AdmissionRow | null {
  const row = db.prepare(
    "SELECT command_key, semantics_digest, plan_id, receipt_bytes FROM admissions WHERE command_key = ?",
  ).get(commandKey);
  if (row === undefined || row === null) return null;
  return admissionRowSchema.parse(row);
}

function getReservation(db: DatabaseSync, planId: string): ReservationRow | null {
  const row = db.prepare(
    "SELECT reservation_id, plan_id, scope, state FROM reservations WHERE plan_id = ?",
  ).get(planId);
  if (row === undefined || row === null) return null;
  return reservationRowSchema.parse(row);
}

function getOutbox(db: DatabaseSync, planId: string): OutboxRow | null {
  const row = db.prepare(
    "SELECT outbox_id, plan_id, state, lease_until, attempt_id FROM outbox WHERE plan_id = ?",
  ).get(planId);
  if (row === undefined || row === null) return null;
  return outboxRowSchema.parse(row);
}

type StartEvidence = Readonly<{
  readonly planId: string;
  readonly attemptId: string | null;
  readonly state: PlanState;
  readonly leaseUntil: number | null;
}>;

function startEvidence(db: DatabaseSync): StartEvidence | null {
  const plan = getPlan(db, "plan-control-1");
  if (plan === null) return null;
  const outbox = getOutbox(db, plan.plan_id);
  return {
    planId: plan.plan_id,
    attemptId: outbox?.attempt_id ?? null,
    state: plan.state,
    leaseUntil: outbox?.lease_until ?? null,
  };
}

function getAttempt(db: DatabaseSync, attemptId: string): AttemptRow | null {
  const row = db.prepare(
    `SELECT attempt_id, plan_id, request_id, request_bytes, request_digest,
      started_event_id, state, ack_bytes FROM attempts WHERE attempt_id = ?`,
  ).get(attemptId);
  if (row === undefined || row === null) return null;
  return attemptRowSchema.parse(row);
}

function getCatalog(db: DatabaseSync): CatalogRow | null {
  const row = db.prepare(
    `SELECT binding_id, capability_id, declaration_revision, semantic_digest,
      implementation_id, implementation_version, available
      FROM current_catalog WHERE binding_id = ? AND capability_id = ?
      AND declaration_revision = ? AND semantic_digest = ? AND available = 1`,
  ).get(CAPABILITY_BINDING, CAPABILITY_ID, DECLARATION_REVISION, buildFixture("same").semanticsDigest);
  if (row === undefined || row === null) return null;
  return catalogRowSchema.parse(row);
}

function getInterpretation(db: DatabaseSync, plan: PlanRow): InterpretationRow | null {
  const row = db.prepare(
    `SELECT binding_id, capability_id, declaration_revision, semantic_digest,
      implementation_id, implementation_version, observer_id, observer_version, available
      FROM interpretations WHERE binding_id = ? AND capability_id = ?
      AND declaration_revision = ? AND semantic_digest = ?
      AND implementation_id = ? AND implementation_version = ? AND available = 1`,
  ).get(
    plan.capability_binding,
    plan.capability_id,
    plan.declaration_revision,
    plan.semantic_digest,
    plan.implementation_id,
    plan.implementation_version,
  );
  if (row === undefined || row === null) return null;
  return interpretationRowSchema.parse(row);
}

function countReservations(db: DatabaseSync): number {
  const row = db.prepare("SELECT COUNT(*) AS count FROM reservations").get();
  const parsed = z.strictObject({ count: z.number().int().nonnegative() }).parse(row);
  return parsed.count;
}

function countOutboxes(db: DatabaseSync): number {
  const row = db.prepare("SELECT COUNT(*) AS count FROM outbox").get();
  const parsed = z.strictObject({ count: z.number().int().nonnegative() }).parse(row);
  return parsed.count;
}

function countDispatchStarted(db: DatabaseSync): number {
  const row = db.prepare("SELECT COUNT(*) AS count FROM events WHERE kind = 'DispatchStarted'").get();
  const parsed = z.strictObject({ count: z.number().int().nonnegative() }).parse(row);
  return parsed.count;
}

function countAckEvents(db: DatabaseSync): number {
  const row = db.prepare("SELECT COUNT(*) AS count FROM events WHERE kind = 'VenueAckRecorded'").get();
  const parsed = z.strictObject({ count: z.number().int().nonnegative() }).parse(row);
  return parsed.count;
}

function receiptFromBytes(bytes: string): Receipt {
  return receiptSchema.parse(JSON.parse(bytes));
}

function commandInit(command: Extract<Command, { tag: "init" }>): number {
  const fixture = buildFixture("same");
  const venue = runVenue(command.venueDb, { tag: "init" });
  if (venue.response.tag !== "initialized") throw new Error("venue did not initialize");
  const checkpoint = checkpointSchema.parse({
    revisionId: DEFERRED_REVISION_ID,
    epoch: 1,
    sourceId: DEFERRED_SOURCE_ID,
    predicateId: DEFERRED_PREDICATE_ID,
    predicateRevision: DEFERRED_PREDICATE_REVISION,
    futureBoundary: INITIAL_FUTURE_BOUNDARY,
    lastSequence: null,
    baseline: null,
    lastTruth: null,
    status: "Ready",
  });
  withHost(command.hostDb, (db) => {
    inTransaction(db, () => {
      db.prepare(
        `INSERT OR IGNORE INTO current_catalog(
          binding_id, capability_id, declaration_revision, semantic_digest,
          implementation_id, implementation_version, available
        ) VALUES (?, ?, ?, ?, ?, ?, 1)`,
      ).run(
        CAPABILITY_BINDING,
        CAPABILITY_ID,
        DECLARATION_REVISION,
        fixture.semanticsDigest,
        IMPLEMENTATION_ID,
        IMPLEMENTATION_VERSION,
      );
      db.prepare(
        `INSERT OR IGNORE INTO interpretations(
          binding_id, capability_id, declaration_revision, semantic_digest,
          implementation_id, implementation_version, observer_id, observer_version, available
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      ).run(
        CAPABILITY_BINDING,
        CAPABILITY_ID,
        DECLARATION_REVISION,
        fixture.semanticsDigest,
        IMPLEMENTATION_ID,
        IMPLEMENTATION_VERSION,
        "fixture-order-observer",
        "1",
      );
      db.prepare(
        `INSERT OR IGNORE INTO deferred_revisions(
          revision_id, plan_id, epoch, source_id, predicate_id, predicate_revision,
          threshold, future_boundary, checkpoint_bytes, status, disposition, selected_evidence_id
        ) VALUES (?, ?, 1, ?, ?, ?, 100, ?, ?, 'Waiting', 'RequestDecision', NULL)`,
      ).run(
        DEFERRED_REVISION_ID,
        DEFERRED_PLAN_ID,
        DEFERRED_SOURCE_ID,
        DEFERRED_PREDICATE_ID,
        DEFERRED_PREDICATE_REVISION,
        INITIAL_FUTURE_BOUNDARY,
        encodeObject(checkpoint),
      );
    });
    emitJson({
      tag: "initialized",
      schema: FIXTURE_SCHEMA,
      hostDb: command.hostDb,
      venueDb: command.venueDb,
      capabilityBinding: CAPABILITY_BINDING,
      currentCatalogAvailable: getCatalog(db) !== null,
      historicalInterpretationAvailable: getInterpretation(db, planRowForFixture(fixture)) !== null,
      deferredRevisionId: DEFERRED_REVISION_ID,
      venue: venue.response,
    });
  });
  return 0;
}

function planRowForFixture(fixture: Fixture): PlanRow {
  return planRowSchema.parse({
    plan_id: fixture.plan.planId,
    command_key: fixture.plan.commandKey,
    semantics_digest: fixture.semanticsDigest,
    capability_binding: fixture.plan.capability.binding,
    capability_id: fixture.plan.capability.id,
    declaration_revision: fixture.plan.capability.declarationRevision,
    semantic_digest: fixture.plan.semanticDigest,
    implementation_id: fixture.plan.implementation.id,
    implementation_version: fixture.plan.implementation.version,
    intent_bytes: fixture.plan.intentBytes,
    plan_bytes: fixture.planBytes,
    request_id: fixture.plan.requestId,
    attempt_id: fixture.plan.attemptId,
    request_bytes: fixture.plan.requestBytes,
    request_digest: fixture.plan.requestDigest,
    scope: fixture.plan.scope,
    policy: fixture.plan.policy,
    criterion: fixture.plan.criterion,
    expiry: fixture.plan.expiry,
    state: "Admitted",
  });
}

function commandAdmit(command: Extract<Command, { tag: "admit" }>): number {
  const fixture = buildFixture(command.mode);
  return withHost(command.hostDb, (db) => {
    const existing = getAdmission(db, COMMAND_KEY);
    if (existing !== null) {
      const beforeReservations = countReservations(db);
      const beforeOutboxes = countOutboxes(db);
      if (existing.semantics_digest === fixture.semanticsDigest) {
        emitJson({
          tag: "admission",
          outcome: "deduplicated",
          commandKey: COMMAND_KEY,
          planId: existing.plan_id,
          semanticsDigest: existing.semantics_digest,
          receipt: receiptFromBytes(existing.receipt_bytes),
          mutated: false,
          reservationCountBefore: beforeReservations,
          reservationCountAfter: countReservations(db),
          outboxCountBefore: beforeOutboxes,
          outboxCountAfter: countOutboxes(db),
        });
        return 0;
      }
      emitJson({
        tag: "admission",
        outcome: "rejected",
        reason: "conflicting-semantics",
        commandKey: COMMAND_KEY,
        submittedSemanticsDigest: fixture.semanticsDigest,
        storedSemanticsDigest: existing.semantics_digest,
        mutated: false,
        reservationCountBefore: beforeReservations,
        reservationCountAfter: countReservations(db),
        outboxCountBefore: beforeOutboxes,
        outboxCountAfter: countOutboxes(db),
      });
      return 0;
    }

    if (command.mode !== "same") {
      throw new Error("conflict mode requires an existing command identity");
    }
    const catalog = getCatalog(db);
    const beforeReservations = countReservations(db);
    const beforeOutboxes = countOutboxes(db);
    if (catalog === null) {
      emitJson({
        tag: "admission",
        outcome: "rejected",
        reason: "current-catalog-leaf-unavailable",
        commandKey: COMMAND_KEY,
        submittedSemanticsDigest: fixture.semanticsDigest,
        mutated: false,
        reservationCountBefore: beforeReservations,
        reservationCountAfter: countReservations(db),
        outboxCountBefore: beforeOutboxes,
        outboxCountAfter: countOutboxes(db),
      });
      return 0;
    }

    const receipt = receiptSchema.parse({
      tag: "receipt",
      commandKey: COMMAND_KEY,
      planId: fixture.plan.planId,
      semanticsDigest: fixture.semanticsDigest,
    });
    const receiptBytes = encodeObject(receipt);
    const plan = planRowForFixture(fixture);
    inTransaction(db, () => {
      db.prepare(
        `INSERT INTO plans(
          plan_id, command_key, semantics_digest, capability_binding, capability_id,
          declaration_revision, semantic_digest, implementation_id, implementation_version,
          intent_bytes, plan_bytes, request_id, attempt_id, request_bytes, request_digest,
          scope, policy, criterion, expiry, state
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Admitted')`,
      ).run(
        plan.plan_id,
        plan.command_key,
        plan.semantics_digest,
        plan.capability_binding,
        plan.capability_id,
        plan.declaration_revision,
        plan.semantic_digest,
        plan.implementation_id,
        plan.implementation_version,
        plan.intent_bytes,
        plan.plan_bytes,
        plan.request_id,
        plan.attempt_id,
        plan.request_bytes,
        plan.request_digest,
        plan.scope,
        plan.policy,
        plan.criterion,
        plan.expiry,
      );
      db.prepare(
        "INSERT INTO admissions(command_key, semantics_digest, plan_id, receipt_bytes) VALUES (?, ?, ?, ?)",
      ).run(COMMAND_KEY, fixture.semanticsDigest, plan.plan_id, receiptBytes);
      db.prepare(
        "INSERT INTO reservations(reservation_id, plan_id, scope, state) VALUES (?, ?, ?, 'Held')",
      ).run(`reservation:${plan.plan_id}`, plan.plan_id, plan.scope);
      db.prepare(
        "INSERT INTO outbox(outbox_id, plan_id, state, lease_until, attempt_id) VALUES (?, ?, 'Ready', NULL, NULL)",
      ).run(`outbox:${plan.plan_id}`, plan.plan_id);
      appendEvent(db, "AdmissionAccepted", plan.plan_id, {
        commandKey: COMMAND_KEY,
        planId: plan.plan_id,
        semanticsDigest: fixture.semanticsDigest,
        intentBytes: plan.intent_bytes,
        planBytes: plan.plan_bytes,
        receiptBytes,
      });
    });
    emitJson({
      tag: "admission",
      outcome: "accepted",
      commandKey: COMMAND_KEY,
      planId: plan.plan_id,
      semanticsDigest: fixture.semanticsDigest,
      receipt,
      mutated: true,
      atomic: { receipt: true, outbox: true, reservation: true },
      reservationCountBefore: beforeReservations,
      reservationCountAfter: countReservations(db),
      outboxCountBefore: beforeOutboxes,
      outboxCountAfter: countOutboxes(db),
    });
    return 0;
  });
}

function commandCatalogRemove(command: Extract<Command, { tag: "catalog-remove" }>): number {
  return withHost(command.hostDb, (db) => {
    const removed = inTransaction(db, () => {
      const result = db.prepare("DELETE FROM current_catalog WHERE binding_id = ?").run(CAPABILITY_BINDING);
      if (Number(result.changes) > 0) appendEvent(db, "CatalogLeafRemoved", CAPABILITY_BINDING, { binding: CAPABILITY_BINDING });
      return Number(result.changes);
    });
    emitJson({
      tag: "catalog",
      outcome: removed > 0 ? "removed" : "already-absent",
      currentCatalogAvailable: getCatalog(db) !== null,
      historicalInterpretationAvailable: getInterpretation(db, requirePlanForControl(db)) !== null,
      mutated: removed > 0,
    });
    return 0;
  });
}

function commandHistoryRemove(command: Extract<Command, { tag: "history-remove" }>): number {
  return withHost(command.hostDb, (db) => {
    const removed = inTransaction(db, () => {
      const result = db.prepare("DELETE FROM interpretations WHERE binding_id = ?").run(CAPABILITY_BINDING);
      if (Number(result.changes) > 0) appendEvent(db, "HistoricalInterpretationRemoved", CAPABILITY_BINDING, { binding: CAPABILITY_BINDING });
      return Number(result.changes);
    });
    emitJson({
      tag: "historical-interpretation",
      outcome: removed > 0 ? "removed" : "already-absent",
      currentCatalogAvailable: getCatalog(db) !== null,
      historicalInterpretationAvailable: getInterpretation(db, requirePlanForControl(db)) !== null,
      mutated: removed > 0,
    });
    return 0;
  });
}

function requirePlanForControl(db: DatabaseSync): PlanRow {
  const plan = getPlan(db, DEFERRED_PLAN_ID);
  if (plan !== null) return plan;
  return planRowForFixture(buildFixture("same"));
}

function claimDispatch(db: DatabaseSync, now: number): Readonly<
  | { tag: "claimed"; plan: PlanRow; permit: WriterPermit; startedEventId: number; leaseUntil: number }
  | { tag: "not-claimable"; reason: "missing-plan" | "missing-outbox" | "current-catalog-unavailable" | "already-started-evidence-only" | "not-ready" }
> {
  return inTransaction(db, () => {
    const plan = getPlan(db, "plan-control-1");
    if (plan === null) return { tag: "not-claimable", reason: "missing-plan" };
    const outbox = getOutbox(db, plan.plan_id);
    if (outbox === null) return { tag: "not-claimable", reason: "missing-outbox" };
    if (outbox.state !== "Ready" || plan.state !== "Admitted") {
      if (outbox.state === "Started" || outbox.state === "Acked" || plan.state === "DispatchStarted" || plan.state === "Acknowledged") {
        return { tag: "not-claimable", reason: "already-started-evidence-only" };
      }
      return { tag: "not-claimable", reason: "not-ready" };
    }
    if (getCatalog(db) === null) return { tag: "not-claimable", reason: "current-catalog-unavailable" };
    const parsedPlan = parsePlanBytes(plan.plan_bytes);
    const leaseUntil = now + LEASE_DURATION;
    const startedEventId = appendEvent(db, "DispatchStarted", plan.plan_id, {
      planId: plan.plan_id,
      attemptId: parsedPlan.attemptId,
      requestId: parsedPlan.requestId,
      requestBytes: parsedPlan.requestBytes,
      requestDigest: parsedPlan.requestDigest,
      leaseUntil,
      startTransition: "StartFresh",
    });
    db.prepare("UPDATE plans SET state = 'DispatchStarted' WHERE plan_id = ?").run(plan.plan_id);
    db.prepare(
      "UPDATE outbox SET state = 'Started', lease_until = ?, attempt_id = ? WHERE plan_id = ?",
    ).run(leaseUntil, parsedPlan.attemptId, plan.plan_id);
    db.prepare(
      `INSERT INTO attempts(
        attempt_id, plan_id, request_id, request_bytes, request_digest,
        started_event_id, state, ack_bytes
      ) VALUES (?, ?, ?, ?, ?, ?, 'Started', NULL)`,
    ).run(
      parsedPlan.attemptId,
      plan.plan_id,
      parsedPlan.requestId,
      parsedPlan.requestBytes,
      parsedPlan.requestDigest,
      startedEventId,
    );
    /*
     * inTransaction commits before this return is visible to the caller.
     * The object is process-bound and cannot be reconstructed from the
     * persisted DispatchStarted evidence after a restart.
     */
    const permit = new WriterPermit(
      plan.plan_id,
      parsedPlan.attemptId,
      parsedPlan.requestId,
      parsedPlan.requestDigest,
    );
    return { tag: "claimed", plan, permit, startedEventId, leaseUntil };
  });
}

function venueWorkerPath(): string {
  return fileURLToPath(new URL("./venue-worker.py", import.meta.url));
}

function runVenue(path: string, operation: VenueOperation): VenueCall {
  const child = spawnSync(
    "python3",
    [venueWorkerPath(), "--db", path, "--op", operation.tag],
    { input: `${encodeObject(operation)}\n`, encoding: "utf8" },
  );
  if (child.error !== undefined) throw new Error(`venue process error: ${child.error.message}`);
  if (child.status !== 0) throw new Error(`venue process exited ${String(child.status)}`);
  const output = child.stdout.trimEnd();
  if (output.length === 0) throw new Error("venue process returned no observation");
  const lines = output.split("\n");
  const rawBytes = lines[lines.length - 1];
  if (rawBytes === undefined || rawBytes.length === 0) throw new Error("venue observation line is empty");
  const response = venueResponseSchema.parse(JSON.parse(rawBytes));
  return { response, rawBytes };
}

function dispatchVenue(db: DatabaseSync, venueDb: string, plan: PlanRow, grant: WriterPermit): NativeDispatch {
  const attempt = getAttempt(db, grant.attemptId);
  if (grant.planId !== plan.plan_id || grant.requestId !== plan.request_id || grant.requestDigest !== plan.request_digest) {
    throw new Error("writer permit does not bind plan and attempt");
  }
  if (attempt === null || attempt.state !== "Started" || attempt.plan_id !== plan.plan_id) {
    throw new Error("native send attempted without durable DispatchStarted");
  }
  /*
   * Consuming happens at the durable-send boundary.  If the child process
   * fails after this line, this grant cannot be reused; recovery observes.
   */
  const permit = grant.consume();
  const call = runVenue(venueDb, {
    tag: "accept",
    requestId: permit.requestId,
    attemptId: permit.attemptId,
    planId: permit.planId,
    payloadBytes: plan.request_bytes,
    payloadDigest: permit.requestDigest,
  });
  return { call, permit };
}

function recordAck(db: DatabaseSync, plan: PlanRow, permit: ConsumedWriterPermit, ackBytes: string): void {
  inTransaction(db, () => {
    const attempt = getAttempt(db, permit.attemptId);
    const outbox = getOutbox(db, plan.plan_id);
    if (attempt === null || attempt.state !== "Started" || outbox === null || outbox.state !== "Started") {
      throw new Error("ack does not match started attempt");
    }
    appendEvent(db, "VenueAckRecorded", plan.plan_id, {
      planId: plan.plan_id,
      attemptId: permit.attemptId,
      requestId: permit.requestId,
      ackBytes,
    });
    db.prepare("UPDATE attempts SET state = 'Acknowledged', ack_bytes = ? WHERE attempt_id = ?").run(ackBytes, permit.attemptId);
    db.prepare("UPDATE outbox SET state = 'Acked', lease_until = NULL WHERE plan_id = ?").run(plan.plan_id);
    db.prepare("UPDATE plans SET state = 'Acknowledged' WHERE plan_id = ?").run(plan.plan_id);
  });
}

function commandDispatch(command: Extract<Command, { tag: "dispatch" }>): number {
  if (command.crashCut && command.loseGrant) throw new Error("crash cut and lost-grant cut are mutually exclusive");
  return withHost(command.hostDb, (db) => {
    const claim = claimDispatch(db, command.now);
    if (claim.tag !== "claimed") {
      emitJson({
        tag: "dispatch",
        outcome: "not-dispatched",
        start: {
          transition: claim.reason === "already-started-evidence-only" ? "AlreadyStarted" : "StartRejected",
          grantIssued: false,
          evidenceOnly: claim.reason === "already-started-evidence-only",
        },
        evidenceOnlyReceipt: startEvidence(db),
        reason: claim.reason,
        dispatchStartedCount: countDispatchStarted(db),
        ackCount: countAckEvents(db),
      });
      return 0;
    }
    if (command.loseGrant) {
      /*
       * Drop the process-bound grant after StartFresh commits.  A later
       * invocation must use observation, not reconstruct a new grant.
       */
      emitJson({
        tag: "dispatch",
        outcome: "owner-exit",
        cut: "after-start-commit-before-native-send",
        exitCode: 92,
        start: {
          transition: "StartFresh",
          grantIssued: true,
          grantConsumed: false,
          processBound: true,
          oneUse: true,
        },
        hostStateAfterCommit: "DispatchStarted",
        hostAckPersisted: false,
        venueNativeSend: false,
        dispatchStartedCount: countDispatchStarted(db),
      });
      return 92;
    }
    const native = dispatchVenue(db, command.venueDb, claim.plan, claim.permit);
    if (native.call.response.tag !== "accepted") throw new Error("venue returned a non-accept response to accept");
    if (native.call.response.outcome !== "new") throw new Error("fresh host attempt encountered an existing venue request");
    if (command.crashCut) {
      emitJson({
        tag: "dispatch",
        outcome: "owner-exit",
        cut: "after-venue-acceptance-before-host-ack",
        exitCode: 91,
        start: {
          transition: "StartFresh",
          grantIssued: true,
          grantConsumed: true,
          processBound: true,
          oneUse: true,
        },
        startedEventId: claim.startedEventId,
        leaseUntil: claim.leaseUntil,
        hostStateAfterCommit: "DispatchStarted",
        hostAckPersisted: countAckEvents(db) > 0,
        venueAcceptance: native.call.response,
        writerPermit: { planId: native.permit.planId, attemptId: native.permit.attemptId, requestId: native.permit.requestId },
      });
      return 91;
    }
    recordAck(db, claim.plan, native.permit, native.call.rawBytes);
    emitJson({
      tag: "dispatch",
      outcome: "acknowledged",
      start: {
        transition: "StartFresh",
        grantIssued: true,
        grantConsumed: true,
        processBound: true,
        oneUse: true,
      },
      startedEventId: claim.startedEventId,
      venueAcceptance: native.call.response,
      hostAckPersisted: true,
      dispatchStartedCount: countDispatchStarted(db),
      ackCount: countAckEvents(db),
    });
    return 0;
  });
}

function markRecoveryRequired(db: DatabaseSync, plan: PlanRow, attempt: AttemptRow, reason: "missing-historical-interpretation" | "venue-observation-missing"): boolean {
  if (plan.state === "RecoveryRequired" && attempt.state === "RecoveryRequired") return false;
  inTransaction(db, () => {
    appendEvent(db, reason === "missing-historical-interpretation" ? "RecoveryRequired" : "VenueObservationMissing", plan.plan_id, {
      reason,
      planId: plan.plan_id,
      attemptId: attempt.attempt_id,
      requestId: attempt.request_id,
      originalIntentBytes: plan.intent_bytes,
      originalPlanBytes: plan.plan_bytes,
      capabilityBinding: plan.capability_binding,
      declarationRevision: plan.declaration_revision,
      semanticDigest: plan.semantic_digest,
      implementationId: plan.implementation_id,
      implementationVersion: plan.implementation_version,
    });
    db.prepare("UPDATE attempts SET state = ? WHERE attempt_id = ?").run(
      reason === "missing-historical-interpretation" ? "RecoveryRequired" : "Unknown",
      attempt.attempt_id,
    );
    db.prepare("UPDATE outbox SET state = 'RecoveryRequired' WHERE plan_id = ?").run(plan.plan_id);
    db.prepare("UPDATE plans SET state = 'RecoveryRequired' WHERE plan_id = ?").run(plan.plan_id);
  });
  return true;
}

function commandRecover(command: Extract<Command, { tag: "recover" }>): number {
  return withHost(command.hostDb, (db) => {
    const plan = getPlan(db, "plan-control-1");
    if (plan === null) throw new Error("control plan is absent");
    const attempt = getAttempt(db, plan.attempt_id);
    const outbox = getOutbox(db, plan.plan_id);
    if (attempt === null || outbox === null) throw new Error("started attempt or outbox is absent");
    const leaseExpired = outbox.lease_until !== null && command.now >= outbox.lease_until;
    const currentCatalogAvailable = getCatalog(db) !== null;
    if (plan.state === "Acknowledged" && attempt.state === "Acknowledged") {
      emitJson({
        tag: "recovery",
        outcome: "already-resolved",
        planId: plan.plan_id,
        leaseExpired,
        currentCatalogAvailable,
        dispatchedAgain: false,
        hostAckPersisted: true,
        dispatchStartedCount: countDispatchStarted(db),
        ackCount: countAckEvents(db),
      });
      return 0;
    }

    const historical = getInterpretation(db, plan);
    if (historical === null) {
      const mutated = markRecoveryRequired(db, plan, attempt, "missing-historical-interpretation");
      emitJson({
        tag: "recovery",
        outcome: "RecoveryRequired",
        reason: "missing-historical-interpretation",
        planId: plan.plan_id,
        attemptId: attempt.attempt_id,
        leaseExpired,
        currentCatalogAvailable,
        historicalInterpretationResolved: false,
        dispatchedAgain: false,
        reprepared: false,
        mutated,
        original: {
          intentBytes: plan.intent_bytes,
          planBytes: plan.plan_bytes,
          capabilityBinding: plan.capability_binding,
          declarationRevision: plan.declaration_revision,
          semanticDigest: plan.semantic_digest,
          implementationId: plan.implementation_id,
          implementationVersion: plan.implementation_version,
          requestId: attempt.request_id,
          attemptId: attempt.attempt_id,
        },
        dispatchStartedCount: countDispatchStarted(db),
        ackCount: countAckEvents(db),
      });
      return 0;
    }

    const lookupCall = runVenue(command.venueDb, {
      tag: "lookup",
      requestId: attempt.request_id,
      attemptId: attempt.attempt_id,
    });
    if (lookupCall.response.tag !== "lookup") throw new Error("venue returned a non-lookup response to lookup");
    const lookup: VenueLookup = lookupCall.response;
    if (!lookup.found) {
      const mutated = markRecoveryRequired(db, plan, attempt, "venue-observation-missing");
      emitJson({
        tag: "recovery",
        outcome: "Unknown",
        reason: "venue-observation-missing",
        planId: plan.plan_id,
        leaseExpired,
        currentCatalogAvailable,
        historicalInterpretationResolved: true,
        historicalObserver: { id: historical.observer_id, version: historical.observer_version },
        dispatchedAgain: false,
        mutated,
        venue: lookup,
        originalRequestBytes: attempt.request_bytes,
        dispatchStartedCount: countDispatchStarted(db),
        ackCount: countAckEvents(db),
      });
      return 0;
    }
    if (lookup.planId !== plan.plan_id || lookup.payloadBytes !== attempt.request_bytes || lookup.payloadDigest !== attempt.request_digest) {
      throw new Error("historical venue observation does not match persisted request");
    }
    inTransaction(db, () => {
      appendEvent(db, "VenueObserved", plan.plan_id, {
        planId: plan.plan_id,
        attemptId: attempt.attempt_id,
        requestId: attempt.request_id,
        historicalBinding: plan.capability_binding,
        observerId: historical.observer_id,
        observerVersion: historical.observer_version,
        observationBytes: lookupCall.rawBytes,
      });
      db.prepare("UPDATE attempts SET state = 'Acknowledged', ack_bytes = ? WHERE attempt_id = ?").run(lookupCall.rawBytes, attempt.attempt_id);
      db.prepare("UPDATE outbox SET state = 'Acked', lease_until = NULL WHERE plan_id = ?").run(plan.plan_id);
      db.prepare("UPDATE plans SET state = 'Acknowledged' WHERE plan_id = ?").run(plan.plan_id);
    });
    emitJson({
      tag: "recovery",
      outcome: "recovered-by-observation",
      planId: plan.plan_id,
      attemptId: attempt.attempt_id,
      leaseExpired,
      currentCatalogAvailable,
      historicalInterpretationResolved: true,
      historicalObserver: { id: historical.observer_id, version: historical.observer_version },
      dispatchedAgain: false,
      hostAckPersisted: true,
      venue: lookup,
      dispatchStartedCount: countDispatchStarted(db),
      ackCount: countAckEvents(db),
    });
    return 0;
  });
}

function getDeferred(db: DatabaseSync): DeferredRow | null {
  const row = db.prepare(
    `SELECT revision_id, plan_id, epoch, source_id, predicate_id, predicate_revision,
      threshold, future_boundary, checkpoint_bytes, status, disposition, selected_evidence_id
      FROM deferred_revisions WHERE revision_id = ?`,
  ).get(DEFERRED_REVISION_ID);
  if (row === undefined || row === null) return null;
  return deferredRowSchema.parse(row);
}

function getCheckpoint(row: DeferredRow): Checkpoint {
  const checkpoint = checkpointSchema.parse(JSON.parse(row.checkpoint_bytes));
  if (checkpoint.epoch !== row.epoch || checkpoint.futureBoundary !== row.future_boundary) {
    throw new Error("deferred row/checkpoint mismatch");
  }
  return checkpoint;
}

function getLiveOwner(db: DatabaseSync, epoch: number): OwnerRow | null {
  const row = db.prepare(
    `SELECT owner_id, revision_id, epoch, status, acquired_at FROM deferred_owners
      WHERE revision_id = ? AND epoch = ? AND status = 'Live'`,
  ).get(DEFERRED_REVISION_ID, epoch);
  if (row === undefined || row === null) return null;
  return ownerRowSchema.parse(row);
}

function getHandle(db: DatabaseSync, handleId: string): HandleRow | null {
  const row = db.prepare(
    `SELECT handle_id, revision_id, epoch, evidence_bytes, status, disposition
      FROM decision_handles WHERE handle_id = ?`,
  ).get(handleId);
  if (row === undefined || row === null) return null;
  return handleRowSchema.parse(row);
}

function getPendingHandle(db: DatabaseSync): HandleRow | null {
  const row = db.prepare(
    `SELECT handle_id, revision_id, epoch, evidence_bytes, status, disposition
      FROM decision_handles WHERE revision_id = ? AND status = 'Pending'
      ORDER BY handle_id LIMIT 1`,
  ).get(DEFERRED_REVISION_ID);
  if (row === undefined || row === null) return null;
  return handleRowSchema.parse(row);
}

function evaluatePredicate(predicate: Predicate, value: number): boolean {
  switch (predicate.tag) {
    case "greater-than-or-equal":
      return value >= predicate.threshold;
  }
}

function nextCheckpoint(checkpoint: Checkpoint, patch: Readonly<{
  lastSequence: number | null;
  baseline: number | null;
  lastTruth: boolean | null;
  status: "Ready" | "Gap";
}>): Checkpoint {
  return checkpointSchema.parse({ ...checkpoint, ...patch });
}

/** Pure A7 transition.  It never writes a checkpoint or authorizes a send. */
export function advance(
  checkpoint: Checkpoint,
  sourceFact: SourceFact,
  predicate: Predicate,
  futureBoundary: number,
): AdvanceResult {
  switch (sourceFact.kind) {
    case "correction":
      return { tag: "NoActivation", checkpoint, reason: "correction-requires-maintenance" };
    case "value": {
      if (sourceFact.epoch !== checkpoint.epoch) {
        return { tag: "NoActivation", checkpoint, reason: "stale-epoch" };
      }
      if (sourceFact.sourceId !== checkpoint.sourceId) {
        const changed = nextCheckpoint(checkpoint, {
          lastSequence: sourceFact.sequence,
          baseline: null,
          lastTruth: null,
          status: "Gap",
        });
        return {
          tag: "Gap",
          checkpoint: changed,
          expectedSequence: checkpoint.lastSequence === null ? 1 : checkpoint.lastSequence + 1,
          receivedSequence: sourceFact.sequence,
          reason: "source-identity-gap",
        };
      }
      const expectedSequence = checkpoint.lastSequence === null ? 1 : checkpoint.lastSequence + 1;
      if (sourceFact.sequence !== expectedSequence) {
        const changed = nextCheckpoint(checkpoint, {
          lastSequence: sourceFact.sequence,
          baseline: null,
          lastTruth: null,
          status: "Gap",
        });
        return {
          tag: "Gap",
          checkpoint: changed,
          expectedSequence,
          receivedSequence: sourceFact.sequence,
          reason: "continuity-gap",
        };
      }
      const currentTruth = evaluatePredicate(predicate, sourceFact.value);
      const changed = nextCheckpoint(checkpoint, {
        lastSequence: sourceFact.sequence,
        baseline: sourceFact.value,
        lastTruth: currentTruth,
        status: "Ready",
      });
      if (checkpoint.baseline === null || checkpoint.lastTruth === null) {
        return {
          tag: "NoActivation",
          checkpoint: changed,
          reason: checkpoint.status === "Gap" ? "baseline-established-after-gap" : "baseline-established",
        };
      }
      if (sourceFact.observedAt < futureBoundary) {
        return { tag: "NoActivation", checkpoint: changed, reason: "before-future-boundary" };
      }
      if (!checkpoint.lastTruth && currentTruth) {
        const evidence = evidenceSchema.parse({
          evidenceId: `evidence-${DEFERRED_REVISION_ID}-epoch-${checkpoint.epoch}-${sourceFact.eventId}`,
          revisionId: DEFERRED_REVISION_ID,
          epoch: checkpoint.epoch,
          sourceId: sourceFact.sourceId,
          eventId: sourceFact.eventId,
          sequence: sourceFact.sequence,
          observedAt: sourceFact.observedAt,
          beforeValue: checkpoint.baseline,
          afterValue: sourceFact.value,
          predicateRevision: DEFERRED_PREDICATE_REVISION,
        });
        return { tag: "Candidate", checkpoint: changed, evidence };
      }
      return { tag: "NoActivation", checkpoint: changed, reason: "baseline-established" };
    }
    default:
      return assertNever(sourceFact);
  }
}

function fixedFact(action: DeferredAction, epoch: number): SourceFact | null {
  switch (action) {
    case "fact-false":
      return sourceFactSchema.parse({ kind: "value", epoch, sourceId: DEFERRED_SOURCE_ID, eventId: "fixture-event-1", sequence: 1, observedAt: 110, value: 90 });
    case "fact-cross":
      return sourceFactSchema.parse({ kind: "value", epoch, sourceId: DEFERRED_SOURCE_ID, eventId: "fixture-event-2", sequence: 2, observedAt: 120, value: 110 });
    case "fact-gap":
      return sourceFactSchema.parse({ kind: "value", epoch, sourceId: DEFERRED_SOURCE_ID, eventId: "fixture-event-3-gap", sequence: 3, observedAt: 130, value: 110 });
    case "fact-after-gap":
      return sourceFactSchema.parse({ kind: "value", epoch, sourceId: DEFERRED_SOURCE_ID, eventId: "fixture-event-4-after-gap", sequence: 4, observedAt: 140, value: 110 });
    case "claim-owner":
    case "evidence-dispatch":
    case "keep":
    case "rearm":
    case "stale":
      return null;
    default:
      return assertNever(action);
  }
}

function ownerCount(db: DatabaseSync, epoch: number): number {
  const row = db.prepare(
    "SELECT COUNT(*) AS count FROM deferred_owners WHERE revision_id = ? AND epoch = ? AND status = 'Live'",
  ).get(DEFERRED_REVISION_ID, epoch);
  return z.strictObject({ count: z.number().int().nonnegative() }).parse(row).count;
}

function deferredClaimOwner(db: DatabaseSync): void {
  const row = getDeferred(db);
  if (row === null) throw new Error("deferred revision is absent");
  const existing = getLiveOwner(db, row.epoch);
  if (existing !== null) {
    emitJson({
      tag: "deferred-owner",
      outcome: "already-owned",
      revisionId: row.revision_id,
      epoch: row.epoch,
      ownerId: existing.owner_id,
      liveOwnerCount: ownerCount(db, row.epoch),
      mutated: false,
    });
    return;
  }
  const ownerId = `owner-${row.revision_id}-epoch-${row.epoch}`;
  inTransaction(db, () => {
    db.prepare(
      "INSERT INTO deferred_owners(owner_id, revision_id, epoch, status, acquired_at) VALUES (?, ?, ?, 'Live', ?)",
    ).run(ownerId, row.revision_id, row.epoch, FIXTURE_NOW);
    appendEvent(db, "DeferredOwnerClaimed", row.revision_id, { ownerId, epoch: row.epoch });
  });
  emitJson({
    tag: "deferred-owner",
    outcome: "claimed",
    revisionId: row.revision_id,
    epoch: row.epoch,
    ownerId,
    liveOwnerCount: ownerCount(db, row.epoch),
    mutated: true,
  });
}

type FactMutation =
  | Readonly<{ tag: "fenced"; reason: "stale-epoch" | "suspended" | "owner-not-live"; eventId: string; dispatchStartedCount: number; mutated: false }>
  | Readonly<{ tag: "duplicate"; eventId: string; sequence: number; dispatchStartedCount: number; mutated: false }>
  | Readonly<{ tag: "applied"; transition: "NoActivation" | "Candidate" | "Gap"; eventId: string; sequence: number; reason: string | null; evidenceId: string | null; authorizationGranted: false; dispatchStartedCount: number; mutated: true }>;

function applyFact(db: DatabaseSync, fact: SourceFact): FactMutation {
  const beforeDispatchStarted = countDispatchStarted(db);
  const row = getDeferred(db);
  if (row === null) throw new Error("deferred revision is absent");
  if (fact.epoch !== row.epoch) return { tag: "fenced", reason: "stale-epoch", eventId: fact.eventId, dispatchStartedCount: beforeDispatchStarted, mutated: false };
  if (row.status === "Suspended") return { tag: "fenced", reason: "suspended", eventId: fact.eventId, dispatchStartedCount: beforeDispatchStarted, mutated: false };
  if (getLiveOwner(db, row.epoch) === null) return { tag: "fenced", reason: "owner-not-live", eventId: fact.eventId, dispatchStartedCount: beforeDispatchStarted, mutated: false };
  const consumed = db.prepare(
    `SELECT source_event_id FROM deferred_consumed
      WHERE revision_id = ? AND epoch = ? AND source_event_id = ?`,
  ).get(row.revision_id, row.epoch, fact.eventId);
  if (consumed !== undefined && consumed !== null) {
    return { tag: "duplicate", eventId: fact.eventId, sequence: fact.sequence, dispatchStartedCount: beforeDispatchStarted, mutated: false };
  }
  const predicate = predicateSchema.parse({ tag: "greater-than-or-equal", threshold: row.threshold });
  const checkpoint = getCheckpoint(row);
  const transition = advance(checkpoint, fact, predicate, row.future_boundary);
  const mutation = inTransaction<FactMutation>(db, () => {
    db.prepare(
      `INSERT INTO deferred_consumed(revision_id, epoch, source_event_id, sequence, fact_bytes)
        VALUES (?, ?, ?, ?, ?)`,
    ).run(row.revision_id, row.epoch, fact.eventId, fact.sequence, encodeObject(fact));
    switch (transition.tag) {
      case "Gap":
        db.prepare(
          `UPDATE deferred_revisions SET checkpoint_bytes = ?, status = 'Waiting', selected_evidence_id = NULL
            WHERE revision_id = ?`,
        ).run(encodeObject(transition.checkpoint), row.revision_id);
        appendEvent(db, "DeferredGap", row.revision_id, {
          eventId: fact.eventId,
          expectedSequence: transition.expectedSequence,
          receivedSequence: transition.receivedSequence,
          checkpointBytes: encodeObject(transition.checkpoint),
        });
        return { tag: "applied", transition: "Gap", eventId: fact.eventId, sequence: fact.sequence, reason: transition.reason, evidenceId: null, authorizationGranted: false, dispatchStartedCount: beforeDispatchStarted, mutated: true };
      case "Candidate": {
        const evidenceBytes = encodeObject(transition.evidence);
        const handleId = `handle-${transition.evidence.evidenceId}`;
        db.prepare(
          `UPDATE deferred_revisions SET checkpoint_bytes = ?, status = 'DecisionPending', selected_evidence_id = ?
            WHERE revision_id = ?`,
        ).run(encodeObject(transition.checkpoint), transition.evidence.evidenceId, row.revision_id);
        db.prepare(
          `INSERT INTO decision_handles(handle_id, revision_id, epoch, evidence_bytes, status, disposition)
            VALUES (?, ?, ?, ?, 'Pending', 'RequestDecision')`,
        ).run(handleId, row.revision_id, row.epoch, evidenceBytes);
        appendEvent(db, "DeferredCandidate", row.revision_id, {
          handleId,
          evidenceBytes,
          authorizationGranted: false,
          dispatchStarted: false,
        });
        return { tag: "applied", transition: "Candidate", eventId: fact.eventId, sequence: fact.sequence, reason: null, evidenceId: transition.evidence.evidenceId, authorizationGranted: false, dispatchStartedCount: beforeDispatchStarted, mutated: true };
      }
      case "NoActivation":
        db.prepare(
          `UPDATE deferred_revisions SET checkpoint_bytes = ?, status = 'Waiting', selected_evidence_id = NULL
            WHERE revision_id = ?`,
        ).run(encodeObject(transition.checkpoint), row.revision_id);
        appendEvent(db, "DeferredCheckpointAdvanced", row.revision_id, {
          eventId: fact.eventId,
          reason: transition.reason,
          checkpointBytes: encodeObject(transition.checkpoint),
        });
        return { tag: "applied", transition: "NoActivation", eventId: fact.eventId, sequence: fact.sequence, reason: transition.reason, evidenceId: null, authorizationGranted: false, dispatchStartedCount: beforeDispatchStarted, mutated: true };
    }
  });
  return mutation;
}

function deferredFact(db: DatabaseSync, action: DeferredAction): void {
  const row = getDeferred(db);
  if (row === null) throw new Error("deferred revision is absent");
  const fact = fixedFact(action, row.epoch);
  if (fact === null) throw new Error("action is not a fact action");
  const mutation = applyFact(db, fact);
  switch (mutation.tag) {
    case "fenced":
      emitJson({
        tag: "deferred-fact",
        outcome: "fenced",
        reason: mutation.reason,
        eventId: mutation.eventId,
        candidate: false,
        authorizationGranted: false,
        dispatchStarted: false,
        dispatchStartedCount: mutation.dispatchStartedCount,
        mutated: false,
      });
      return;
    case "duplicate":
      emitJson({
        tag: "deferred-fact",
        outcome: "duplicate",
        eventId: mutation.eventId,
        sequence: mutation.sequence,
        candidate: false,
        authorizationGranted: false,
        dispatchStarted: false,
        dispatchStartedCount: mutation.dispatchStartedCount,
        mutated: false,
      });
      return;
    case "applied":
      emitJson({
        tag: "deferred-fact",
        outcome: "applied",
        transition: mutation.transition,
        eventId: mutation.eventId,
        sequence: mutation.sequence,
        reason: mutation.reason,
        evidenceId: mutation.evidenceId,
        candidate: mutation.transition === "Candidate",
        authorizationGranted: mutation.authorizationGranted,
        dispatchStarted: false,
        dispatchStartedCount: mutation.dispatchStartedCount,
        mutated: mutation.mutated,
      });
      return;
    default:
      return assertNever(mutation);
  }
}

function deferredEvidenceDispatch(db: DatabaseSync): void {
  const before = countDispatchStarted(db);
  emitJson({
    tag: "deferred-evidence-rejection",
    outcome: "rejected",
    reason: "evidence-is-not-authorization",
    authorizationGranted: false,
    dispatchStarted: false,
    dispatchStartedCountBefore: before,
    dispatchStartedCountAfter: countDispatchStarted(db),
    mutated: false,
  });
}

function deferredKeep(db: DatabaseSync): void {
  const row = getDeferred(db);
  if (row === null) throw new Error("deferred revision is absent");
  const handle = getPendingHandle(db);
  if (handle === null) {
    emitJson({ tag: "deferred-keep", outcome: "rejected", reason: "no-pending-decision", mutated: false });
    return;
  }
  if (handle.epoch !== row.epoch) {
    emitJson({ tag: "deferred-keep", outcome: "rejected", reason: "stale-handle", mutated: false });
    return;
  }
  inTransaction(db, () => {
    db.prepare("UPDATE decision_handles SET status = 'Kept' WHERE handle_id = ? AND status = 'Pending'").run(handle.handle_id);
    db.prepare("UPDATE deferred_revisions SET status = 'Suspended' WHERE revision_id = ? AND epoch = ?").run(row.revision_id, row.epoch);
    db.prepare("UPDATE deferred_owners SET status = 'Released' WHERE revision_id = ? AND epoch = ? AND status = 'Live'").run(row.revision_id, row.epoch);
    appendEvent(db, "DecisionKept", row.revision_id, { handleId: handle.handle_id, epoch: row.epoch, disposition: "RequestDecision" });
  });
  emitJson({
    tag: "deferred-keep",
    outcome: "kept",
    handleId: handle.handle_id,
    epoch: row.epoch,
    persistedHandle: getHandle(db, handle.handle_id),
    authorizationGranted: false,
    dispatchStarted: false,
    mutated: true,
  });
}

function deferredRearm(db: DatabaseSync): void {
  const row = getDeferred(db);
  if (row === null) throw new Error("deferred revision is absent");
  const oldEpoch = row.epoch;
  const newEpoch = oldEpoch + 1;
  const newFutureBoundary = row.future_boundary + 100;
  const checkpoint = checkpointSchema.parse({
    revisionId: DEFERRED_REVISION_ID,
    epoch: newEpoch,
    sourceId: DEFERRED_SOURCE_ID,
    predicateId: DEFERRED_PREDICATE_ID,
    predicateRevision: DEFERRED_PREDICATE_REVISION,
    futureBoundary: newFutureBoundary,
    lastSequence: null,
    baseline: null,
    lastTruth: null,
    status: "Ready",
  });
  inTransaction(db, () => {
    db.prepare(
      `UPDATE decision_handles SET status = 'Superseded'
        WHERE revision_id = ? AND epoch < ? AND status IN ('Pending', 'Kept')`,
    ).run(row.revision_id, newEpoch);
    db.prepare(
      "UPDATE deferred_owners SET status = 'Released' WHERE revision_id = ? AND status = 'Live'",
    ).run(row.revision_id);
    db.prepare(
      `UPDATE deferred_revisions SET epoch = ?, future_boundary = ?, checkpoint_bytes = ?,
        status = 'Rearmed', selected_evidence_id = NULL WHERE revision_id = ?`,
    ).run(newEpoch, newFutureBoundary, encodeObject(checkpoint), row.revision_id);
    appendEvent(db, "DeferredRearmed", row.revision_id, {
      oldEpoch,
      newEpoch,
      oldFutureBoundary: row.future_boundary,
      newFutureBoundary,
      checkpointBytes: encodeObject(checkpoint),
    });
  });
  emitJson({
    tag: "deferred-rearm",
    outcome: "rearmed",
    revisionId: row.revision_id,
    oldEpoch,
    newEpoch,
    oldFutureBoundary: row.future_boundary,
    newFutureBoundary,
    checkpoint: getCheckpoint(getDeferred(db) ?? row),
    liveOwnerCount: ownerCount(db, newEpoch),
    mutated: true,
  });
}

function deferredStale(db: DatabaseSync): void {
  const current = getDeferred(db);
  if (current === null) throw new Error("deferred revision is absent");
  const staleEpoch = 1;
  const staleEvidenceId = `evidence-${DEFERRED_REVISION_ID}-epoch-1-fixture-event-2`;
  const staleHandleId = `handle-${staleEvidenceId}`;
  const handle = getHandle(db, staleHandleId);
  const replyFenced = handle === null || handle.epoch !== current.epoch || current.epoch !== staleEpoch || handle.status !== "Pending";
  const correctionFenced = current.epoch !== staleEpoch || current.selected_evidence_id !== staleEvidenceId;
  emitJson({
    tag: "deferred-stale",
    reply: {
      outcome: replyFenced ? "Fenced" : "Accepted",
      handleId: staleHandleId,
      replyEpoch: staleEpoch,
      currentEpoch: current.epoch,
      mutated: false,
      dispatchAuthorized: false,
    },
    correction: {
      outcome: correctionFenced ? "Fenced" : "Accepted",
      evidenceId: staleEvidenceId,
      correctionEpoch: staleEpoch,
      currentEpoch: current.epoch,
      mutated: false,
      dispatchAuthorized: false,
    },
    dispatchStarted: false,
  });
}

function commandDeferred(command: Extract<Command, { tag: "deferred" }>): number {
  return withHost(command.hostDb, (db) => {
    switch (command.action) {
      case "claim-owner":
        deferredClaimOwner(db);
        return 0;
      case "fact-false":
      case "fact-cross":
      case "fact-gap":
      case "fact-after-gap":
        deferredFact(db, command.action);
        return 0;
      case "evidence-dispatch":
        deferredEvidenceDispatch(db);
        return 0;
      case "keep":
        deferredKeep(db);
        return 0;
      case "rearm":
        deferredRearm(db);
        return 0;
      case "stale":
        deferredStale(db);
        return 0;
      default:
        return assertNever(command.action);
    }
  });
}

function listPlans(db: DatabaseSync): readonly PlanRow[] {
  return db.prepare(
    `SELECT plan_id, command_key, semantics_digest, capability_binding, capability_id,
      declaration_revision, semantic_digest, implementation_id, implementation_version,
      intent_bytes, plan_bytes, request_id, attempt_id, request_bytes, request_digest,
      scope, policy, criterion, expiry, state FROM plans ORDER BY plan_id`,
  ).all().map((row) => planRowSchema.parse(row));
}

function listAdmissions(db: DatabaseSync): readonly AdmissionRow[] {
  return db.prepare(
    "SELECT command_key, semantics_digest, plan_id, receipt_bytes FROM admissions ORDER BY command_key",
  ).all().map((row) => admissionRowSchema.parse(row));
}

function listReservations(db: DatabaseSync): readonly ReservationRow[] {
  return db.prepare(
    "SELECT reservation_id, plan_id, scope, state FROM reservations ORDER BY reservation_id",
  ).all().map((row) => reservationRowSchema.parse(row));
}

function listOutboxes(db: DatabaseSync): readonly OutboxRow[] {
  return db.prepare(
    "SELECT outbox_id, plan_id, state, lease_until, attempt_id FROM outbox ORDER BY outbox_id",
  ).all().map((row) => outboxRowSchema.parse(row));
}

function listAttempts(db: DatabaseSync): readonly AttemptRow[] {
  return db.prepare(
    `SELECT attempt_id, plan_id, request_id, request_bytes, request_digest,
      started_event_id, state, ack_bytes FROM attempts ORDER BY attempt_id`,
  ).all().map((row) => attemptRowSchema.parse(row));
}

function listEvents(db: DatabaseSync): readonly EventRow[] {
  return db.prepare(
    "SELECT event_id, kind, aggregate_id, payload_bytes FROM events ORDER BY event_id",
  ).all().map((row) => eventRowSchema.parse(row));
}

function listOwners(db: DatabaseSync): readonly OwnerRow[] {
  return db.prepare(
    "SELECT owner_id, revision_id, epoch, status, acquired_at FROM deferred_owners ORDER BY owner_id",
  ).all().map((row) => ownerRowSchema.parse(row));
}

function listHandles(db: DatabaseSync): readonly HandleRow[] {
  return db.prepare(
    "SELECT handle_id, revision_id, epoch, evidence_bytes, status, disposition FROM decision_handles ORDER BY handle_id",
  ).all().map((row) => handleRowSchema.parse(row));
}

function commandInspect(command: Extract<Command, { tag: "inspect" }>): number {
  const venue = runVenue(command.venueDb, { tag: "dump" });
  if (venue.response.tag !== "dump") throw new Error("venue returned a non-dump response to dump");
  const host = withHost(command.hostDb, (db) => ({
    plans: listPlans(db),
    admissions: listAdmissions(db),
    reservations: listReservations(db),
    outboxes: listOutboxes(db),
    attempts: listAttempts(db),
    events: listEvents(db),
    deferred: getDeferred(db),
    owners: listOwners(db),
    handles: listHandles(db),
    counts: {
      reservations: countReservations(db),
      outboxes: countOutboxes(db),
      dispatchStarted: countDispatchStarted(db),
      acknowledgements: countAckEvents(db),
    },
  }));
  emitJson({ tag: "inspect", host, venue: venue.response });
  return 0;
}

function requiredOption(flags: readonly CliFlag[], name: OptionValueName): string {
  const value = optionalOption(flags, name);
  if (value === null || value.length === 0) throw new Error(`missing --${name}`);
  return value;
}

function optionalOption(flags: readonly CliFlag[], name: OptionValueName): string | null {
  let found: string | null = null;
  for (const flag of flags) {
    if (flag.tag === "value" && flag.name === name) {
      if (found !== null) throw new Error(`duplicate --${name}`);
      found = flag.value;
    }
  }
  return found;
}


function hasSwitch(flags: readonly CliFlag[], name: "crash-after-venue-acceptance" | "lose-dispatch-grant-before-send"): boolean {
  return flags.some((flag) => flag.tag === "switch" && flag.name === name);
}

function ensureAllowed(flags: readonly CliFlag[], allowed: readonly FlagName[]): void {
  for (const flag of flags) {
    if (!allowed.includes(flag.name)) throw new Error(`option --${flag.name} is not valid for this command`);
  }
}
function parseFlags(tokens: readonly string[]): readonly CliFlag[] {
  const flags: CliFlag[] = [];
  let index = 0;
  while (index < tokens.length) {
    const token = tokens[index];
    if (token === undefined || !token.startsWith("--")) throw new Error("options must start with --");
    const name = token.slice(2);
    if (name === "crash-after-venue-acceptance" || name === "lose-dispatch-grant-before-send") {
      flags.push({ tag: "switch", name });
      index += 1;
      continue;
    }
    const parsedName = optionValueNameSchema.safeParse(name);
    if (!parsedName.success) throw new Error(`unknown option --${name}`);
    const value = tokens[index + 1];
    if (value === undefined || value.startsWith("--")) throw new Error(`missing value for --${name}`);
    flags.push({ tag: "value", name: parsedName.data, value });
    index += 2;
  }
  return flags;
}

function parseCommand(tokens: readonly string[]): Command {
  const name = tokens[0];
  if (name === undefined) throw new Error("command is required");
  const flags = parseFlags(tokens.slice(1));
  switch (name) {
    case "init":
      ensureAllowed(flags, ["host-db", "venue-db"]);
      return { tag: "init", hostDb: requiredOption(flags, "host-db"), venueDb: requiredOption(flags, "venue-db") };
    case "admit": {
      ensureAllowed(flags, ["host-db", "venue-db", "mode"]);
      const mode = z.enum(["same", "conflict"]).parse(optionalOption(flags, "mode") ?? "same");
      return { tag: "admit", hostDb: requiredOption(flags, "host-db"), venueDb: requiredOption(flags, "venue-db"), mode };
    }
    case "dispatch": {
      ensureAllowed(flags, ["host-db", "venue-db", "now", "crash-after-venue-acceptance", "lose-dispatch-grant-before-send"]);
      const crashCut = hasSwitch(flags, "crash-after-venue-acceptance");
      const loseGrant = hasSwitch(flags, "lose-dispatch-grant-before-send");
      if (crashCut && loseGrant) throw new Error("crash cut and lost-grant cut are mutually exclusive");
      return {
        tag: "dispatch",
        hostDb: requiredOption(flags, "host-db"),
        venueDb: requiredOption(flags, "venue-db"),
        now: parseNonnegativeInteger(optionalOption(flags, "now") ?? String(FIXTURE_NOW), "now"),
        crashCut,
        loseGrant,
      };
    }
    case "recover":
      ensureAllowed(flags, ["host-db", "venue-db", "now"]);
      return {
        tag: "recover",
        hostDb: requiredOption(flags, "host-db"),
        venueDb: requiredOption(flags, "venue-db"),
        now: parseNonnegativeInteger(optionalOption(flags, "now") ?? "200", "now"),
      };
    case "catalog-remove":
      ensureAllowed(flags, ["host-db", "venue-db"]);
      return { tag: "catalog-remove", hostDb: requiredOption(flags, "host-db"), venueDb: requiredOption(flags, "venue-db") };
    case "history-remove":
      ensureAllowed(flags, ["host-db", "venue-db"]);
      return { tag: "history-remove", hostDb: requiredOption(flags, "host-db"), venueDb: requiredOption(flags, "venue-db") };
    case "inspect":
      ensureAllowed(flags, ["host-db", "venue-db"]);
      return { tag: "inspect", hostDb: requiredOption(flags, "host-db"), venueDb: requiredOption(flags, "venue-db") };
    case "deferred":
      ensureAllowed(flags, ["host-db", "action"]);
      return { tag: "deferred", hostDb: requiredOption(flags, "host-db"), action: actionSchema.parse(requiredOption(flags, "action")) };
    default:
      throw new Error(`unknown command ${name}`);
  }
}

function emitJson(value: unknown): void {
  process.stdout.write(`${encodeObject(value)}\n`);
}

function execute(command: Command): number {
  switch (command.tag) {
    case "init":
      return commandInit(command);
    case "admit":
      return commandAdmit(command);
    case "dispatch":
      return commandDispatch(command);
    case "recover":
      return commandRecover(command);
    case "catalog-remove":
      return commandCatalogRemove(command);
    case "history-remove":
      return commandHistoryRemove(command);
    case "inspect":
      return commandInspect(command);
    case "deferred":
      return commandDeferred(command);
    default:
      return assertNever(command);
  }
}

function run(): number {
  try {
    return execute(parseCommand(process.argv.slice(2)));
  } catch (error) {
    const reason = error instanceof Error ? error.message : "unexpected control failure";
    emitJson({ tag: "error", reason });
    return 1;
  }
}

process.exitCode = run();
