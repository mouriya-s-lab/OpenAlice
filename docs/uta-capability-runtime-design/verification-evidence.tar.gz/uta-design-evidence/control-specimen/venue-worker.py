#!/usr/bin/env python3
"""Deterministic venue fixture with its own durable SQLite ledger.

This is intentionally not a broker adapter.  It records every native-call
invocation separately from the accepted-request ledger so the host can prove
that recovery observed one acceptance without making a second send.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import sys
from typing import Any


DB_SCHEMA = "venue-ledger-v1"


def emit(value: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":"), sort_keys=True) + "\n")
    sys.stdout.flush()


def fail(reason: str) -> None:
    emit({"tag": "error", "reason": reason})
    raise SystemExit(2)


def connect(path: str) -> sqlite3.Connection:
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=FULL")
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS accepted_requests (
          request_id TEXT PRIMARY KEY,
          attempt_id TEXT NOT NULL,
          plan_id TEXT NOT NULL,
          payload_bytes TEXT NOT NULL,
          payload_digest TEXT NOT NULL,
          accepted_sequence INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS invocation_log (
          invocation_sequence INTEGER PRIMARY KEY AUTOINCREMENT,
          request_id TEXT NOT NULL,
          attempt_id TEXT NOT NULL,
          plan_id TEXT NOT NULL,
          payload_digest TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS lookup_log (
          lookup_sequence INTEGER PRIMARY KEY AUTOINCREMENT,
          request_id TEXT NOT NULL,
          attempt_id TEXT NOT NULL
        );
        """
    )
    return connection


def require_object(value: Any, keys: set[str]) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        fail("malformed-request")
    return value


def require_string(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value:
        fail(f"invalid-{name}")
    return value


def require_digest(value: Any) -> str:
    digest = require_string(value, "payload-digest")
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        fail("invalid-payload-digest")
    return digest


def operation_init(path: str) -> None:
    connection = connect(path)
    try:
        accepted_count = int(connection.execute("SELECT COUNT(*) FROM accepted_requests").fetchone()[0])
        invocation_count = int(connection.execute("SELECT COUNT(*) FROM invocation_log").fetchone()[0])
        emit(
            {
                "tag": "initialized",
                "schema": DB_SCHEMA,
                "acceptedCount": accepted_count,
                "receiveCount": invocation_count,
            }
        )
    finally:
        connection.close()


def operation_accept(path: str, request: dict[str, Any]) -> None:
    fields = require_object(request, {"tag", "requestId", "attemptId", "planId", "payloadBytes", "payloadDigest"})
    if fields["tag"] != "accept":
        fail("unexpected-operation")
    request_id = require_string(fields["requestId"], "request-id")
    attempt_id = require_string(fields["attemptId"], "attempt-id")
    plan_id = require_string(fields["planId"], "plan-id")
    payload_bytes = require_string(fields["payloadBytes"], "payload-bytes")
    payload_digest = require_digest(fields["payloadDigest"])
    actual_digest = hashlib.sha256(payload_bytes.encode("utf-8")).hexdigest()
    if actual_digest != payload_digest:
        fail("payload-digest-mismatch")

    connection = connect(path)
    try:
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(
            "INSERT INTO invocation_log(request_id, attempt_id, plan_id, payload_digest) VALUES (?, ?, ?, ?)",
            (request_id, attempt_id, plan_id, payload_digest),
        )
        existing = connection.execute(
            "SELECT accepted_sequence FROM accepted_requests WHERE request_id = ?", (request_id,)
        ).fetchone()
        if existing is None:
            accepted_sequence = int(
                connection.execute(
                    "SELECT COALESCE(MAX(accepted_sequence), 0) + 1 FROM accepted_requests"
                ).fetchone()[0]
            )
            connection.execute(
                "INSERT INTO accepted_requests(request_id, attempt_id, plan_id, payload_bytes, payload_digest, accepted_sequence) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (request_id, attempt_id, plan_id, payload_bytes, payload_digest, accepted_sequence),
            )
            outcome = "new"
        else:
            accepted_sequence = int(existing[0])
            outcome = "duplicate"
        connection.commit()
        accepted_count = int(connection.execute("SELECT COUNT(*) FROM accepted_requests").fetchone()[0])
        invocation_count = int(connection.execute("SELECT COUNT(*) FROM invocation_log").fetchone()[0])
        emit(
            {
                "tag": "accepted",
                "requestId": request_id,
                "attemptId": attempt_id,
                "planId": plan_id,
                "payloadDigest": payload_digest,
                "outcome": outcome,
                "acceptedSequence": accepted_sequence,
                "acceptedCount": accepted_count,
                "receiveCount": invocation_count,
            }
        )
    except BaseException:
        connection.rollback()
        raise
    finally:
        connection.close()


def operation_lookup(path: str, request: dict[str, Any]) -> None:
    fields = require_object(request, {"tag", "requestId", "attemptId"})
    if fields["tag"] != "lookup":
        fail("unexpected-operation")
    request_id = require_string(fields["requestId"], "request-id")
    attempt_id = require_string(fields["attemptId"], "attempt-id")
    connection = connect(path)
    try:
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(
            "INSERT INTO lookup_log(request_id, attempt_id) VALUES (?, ?)", (request_id, attempt_id)
        )
        row = connection.execute(
            "SELECT request_id, attempt_id, plan_id, payload_bytes, payload_digest, accepted_sequence "
            "FROM accepted_requests WHERE request_id = ? AND attempt_id = ?",
            (request_id, attempt_id),
        ).fetchone()
        connection.commit()
        lookup_count = int(connection.execute("SELECT COUNT(*) FROM lookup_log").fetchone()[0])
        accept_invocation_count = int(
            connection.execute("SELECT COUNT(*) FROM invocation_log").fetchone()[0]
        )
        if row is None:
            emit(
                {
                    "tag": "lookup",
                    "requestId": request_id,
                    "attemptId": attempt_id,
                    "found": False,
                    "receiveCount": accept_invocation_count,
                    "lookupCount": lookup_count,
                }
            )
            return
        emit(
            {
                "tag": "lookup",
                "requestId": request_id,
                "attemptId": attempt_id,
                "found": True,
                "planId": str(row[2]),
                "payloadBytes": str(row[3]),
                "payloadDigest": str(row[4]),
                "acceptedSequence": int(row[5]),
                "receiveCount": accept_invocation_count,
                "lookupCount": lookup_count,
            }
        )
    except BaseException:
        connection.rollback()
        raise
    finally:
        connection.close()


def operation_dump(path: str) -> None:
    connection = connect(path)
    try:
        accepted_rows = connection.execute(
            "SELECT request_id, attempt_id, plan_id, payload_bytes, payload_digest, accepted_sequence "
            "FROM accepted_requests ORDER BY accepted_sequence"
        ).fetchall()
        invocation_rows = connection.execute(
            "SELECT invocation_sequence, request_id, attempt_id, plan_id, payload_digest "
            "FROM invocation_log ORDER BY invocation_sequence"
        ).fetchall()
        lookup_rows = connection.execute(
            "SELECT lookup_sequence, request_id, attempt_id FROM lookup_log ORDER BY lookup_sequence"
        ).fetchall()
        emit(
            {
                "tag": "dump",
                "schema": DB_SCHEMA,
                "accepted": [
                    {
                        "requestId": str(row[0]),
                        "attemptId": str(row[1]),
                        "planId": str(row[2]),
                        "payloadBytes": str(row[3]),
                        "payloadDigest": str(row[4]),
                        "acceptedSequence": int(row[5]),
                    }
                    for row in accepted_rows
                ],
                "invocations": [
                    {
                        "invocationSequence": int(row[0]),
                        "requestId": str(row[1]),
                        "attemptId": str(row[2]),
                        "planId": str(row[3]),
                        "payloadDigest": str(row[4]),
                    }
                    for row in invocation_rows
                ],
                "lookups": [
                    {
                        "lookupSequence": int(row[0]),
                        "requestId": str(row[1]),
                        "attemptId": str(row[2]),
                    }
                    for row in lookup_rows
                ],
                "counts": {
                    "accepted": len(accepted_rows),
                    "receiveCount": len(invocation_rows),
                    "lookups": len(lookup_rows),
                },
            }
        )
    finally:
        connection.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True)
    parser.add_argument("--op", choices=("init", "accept", "lookup", "dump"), required=True)
    options = parser.parse_args()
    if options.op == "init":
        operation_init(options.db)
        return 0
    line = sys.stdin.readline()
    if not line:
        fail("missing-request")
    try:
        request = json.loads(line)
    except json.JSONDecodeError:
        fail("invalid-json")
    if options.op == "accept":
        operation_accept(options.db, request)
    elif options.op == "lookup":
        operation_lookup(options.db, request)
    else:
        operation_dump(options.db)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
