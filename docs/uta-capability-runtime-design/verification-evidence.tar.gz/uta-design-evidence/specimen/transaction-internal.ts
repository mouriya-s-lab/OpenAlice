import { Context, Effect } from "effect";
import { open } from "node:fs/promises";
import { createHash } from "node:crypto";
import { z } from "zod";
import { Pull, decode, failDeclared, type BoundaryFailure, type Meaning, type TransformResult } from "./algebra.js";
import { exportedSchema, portable } from "./portable.js";

export const receiptSchema = z.strictObject({ tag: z.literal("admitted"), intent: z.string(), binding: z.string(), journal: z.string() });
export const admissionFailure = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("storage"), operation: z.literal("append-fsync"), detail: z.string() }),
  z.strictObject({ tag: z.literal("identity-conflict"), command: z.string() }),
  z.strictObject({ tag: z.literal("denied"), principal: z.string() }),
]);
export type AdmissionFailure = z.output<typeof admissionFailure>;
export const admissionRecord = z.strictObject({
  command: z.string(), principal: z.string(), policy: z.literal("IndependentBatch"), policyRevision: z.string(),
  binding: z.string(), recipeRevision: z.string(), prepared: z.json(),
});
export type AdmissionRecord = z.output<typeof admissionRecord>;
export interface Admission {
  readonly append: (record: AdmissionRecord) => Effect.Effect<z.output<typeof receiptSchema>, AdmissionFailure>;
}
export const Admission = Context.GenericTag<Admission>("specimen/Admission");
export interface SubmissionPolicy { readonly tag: "IndependentBatch"; readonly revision: string; readonly principal: string; }

/** Internal authoring type: only public controlled handles leave this module. */
class Recipe<I extends z.ZodType, P extends z.ZodType, E extends z.ZodType> {
  readonly #compile: (input: z.output<I>) => TransformResult<z.output<P>, z.output<E>>;
  readonly identity: string;
  constructor(readonly input: I, readonly prepared: P, readonly failure: E, readonly revision: string,
    readonly nativeInterpretation: string,
    compile: (input: z.output<NoInfer<I>>) => TransformResult<z.output<NoInfer<P>>, z.output<NoInfer<E>>>) {
    portable(input); portable(prepared); portable(failure);
    this.#compile = compile;
    this.identity = createHash("sha256").update(JSON.stringify({ revision, nativeInterpretation, input: exportedSchema(input), prepared: exportedSchema(prepared), failure: exportedSchema(failure) })).digest("hex");
  }
  prepare(input: z.output<I>) { return this.#compile(input); }
}
export function defineRecipe<I extends z.ZodType, P extends z.ZodType, E extends z.ZodType>(
  input: I, prepared: P, failure: E, revision: string, nativeInterpretation: string,
  compile: (input: z.output<NoInfer<I>>) => TransformResult<z.output<NoInfer<P>>, z.output<NoInfer<E>>>,
) { return new Recipe(input, prepared, failure, revision, nativeInterpretation, compile); }

export function withTransaction<I extends z.ZodType, P extends z.ZodType, E extends z.ZodType>(
  recipe: Recipe<I, P, E>, policy: SubmissionPolicy, meaning: Meaning,
) {
  const input = z.strictObject({ command: z.string().min(1), intent: z.nonoptional(recipe.input) });
  const failure = z.union([recipe.failure, admissionFailure]);
  return new Pull<typeof input, typeof receiptSchema, typeof failure, Admission, "controlled">(
    { ...meaning, dependencies: [recipe.identity, createHash("sha256").update(JSON.stringify(policy)).digest("hex")] },
    { input, output: receiptSchema, failure }, [Admission.key], "controlled",
    (request, bound) => Effect.catchAll(
      Effect.suspend<z.output<typeof receiptSchema>, z.output<E> | AdmissionFailure | BoundaryFailure, Admission>(() => {
        const result = recipe.prepare(request.intent);
        if (result.tag === "failure") return Effect.flatMap(decode(recipe.failure, result.failure, "failure"), Effect.fail);
        return Effect.flatMap(decode(recipe.prepared, result.value, "output"), (prepared) => Effect.flatMap(Admission, (writer) => writer.append({
          command: request.command, principal: policy.principal, policy: policy.tag, policyRevision: policy.revision,
          binding: bound.binding, recipeRevision: recipe.revision, prepared: z.json().parse(prepared),
        })));
      }), (error) => failDeclared(failure, error)));
}

/** One process/one writer fixture. File remains the admission authority on restart. */
export function fileAdmission(path: string, allowedPrincipal: string): Admission {
  let tail: Promise<void> = Promise.resolve();
  return {
    append(record) {
      return Effect.tryPromise({
        try: () => {
          const pending = tail.then(async (): Promise<TransformResult<z.output<typeof receiptSchema>, AdmissionFailure>> => {
            if (record.principal !== allowedPrincipal) return { tag: "failure", failure: admissionFailure.parse({ tag: "denied", principal: record.principal }) };
            const handle = await open(path, "a+");
            try {
              const content = await handle.readFile("utf8");
              const rows = content.split("\n").filter((line) => line.length > 0).map((line) => { const raw: unknown = JSON.parse(line); return admissionRecord.parse(raw); });
              const prior = rows.find((row) => row.command === record.command);
              const bytes = JSON.stringify(admissionRecord.parse(record));
              if (prior && JSON.stringify(prior) !== bytes) return { tag: "failure", failure: admissionFailure.parse({ tag: "identity-conflict", command: record.command }) };
              if (!prior) { await handle.writeFile(`${bytes}\n`); await handle.sync(); }
              return { tag: "value", value: receiptSchema.parse({ tag: "admitted", intent: createHash("sha256").update(bytes).digest("hex"), binding: record.binding, journal: path }) };
            } finally { await handle.close(); }
          });
          tail = pending.then(() => undefined, () => undefined);
          return pending;
        },
        catch: (error): AdmissionFailure => admissionFailure.parse({ tag: "storage", operation: "append-fsync", detail: error instanceof Error ? error.message : "non-Error storage failure" }),
      }).pipe(Effect.flatMap((result) => result.tag === "failure" ? Effect.fail(result.failure) : Effect.succeed(result.value)));
    },
  };
}
