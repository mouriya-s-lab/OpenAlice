/** Public consumer surface. No Recipe, constructor, raw native handler, or writer is exported. */
export type { Pull, Push, Meaning, Slots, Descriptor, BoundaryFailure, TransformResult } from "./algebra.js";
export { adaptInput, projectOutput, combineReads } from "./algebra.js";
export { Catalog } from "./catalog.js";
export type { Principal, TreeNode, Namespace, CatalogDescription, Output, Terminal } from "./catalog.js";
export { candlePull, candlePush, controlledOrder } from "./providers.js";
export type { RichCandle, ProviderOrder } from "./units.js";
