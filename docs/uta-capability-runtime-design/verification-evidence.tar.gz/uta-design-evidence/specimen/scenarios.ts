import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFile, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Effect } from "effect";
import { z } from "zod";
import { candlePull, candlePush, controlledOrder, adaptedCandles, projectedCandles, candleMeaning, fixtureMarket, MarketData } from "./providers.js";
import { candlePage, extend, orderBase, providerOrder, richCandle } from "./units.js";
import { portable } from "./portable.js";
import { withForeign } from "./foreign.js";
import { Admission, admissionRecord, fileAdmission } from "./transaction-internal.js";
import { Catalog, pullEntry, pushEntry } from "./catalog.js";
import { combineReads } from "./algebra.js";

const directory = fileURLToPath(new URL(".", import.meta.url));
function cli(args: readonly string[], expectedStatus: number) {
  const evidenceDirectory = mkdtempSync(join(directory, "resource-evidence-"));
  const lifecyclePath = join(evidenceDirectory, "lifecycle.ndjson");
  try {
    writeFileSync(lifecyclePath, "", "utf8");
    const child = spawnSync(process.execPath, ["--import", "tsx", "cli.ts", ...args], {
      cwd: directory, encoding: "utf8", timeout: 15000,
      env: { ...process.env, UTA_SPECIMEN_RESOURCE_LOG: lifecyclePath },
    });
    process.stderr.write(child.stderr);
    if (child.error) throw child.error;
    assert.equal(child.status, expectedStatus, child.stderr + child.stdout);
    const frames = child.stdout.trim().split("\n").filter(Boolean).map((line) => { const raw: unknown = JSON.parse(line); return z.json().parse(raw); });
    return { frames, lifecycle: readFileSync(lifecyclePath, "utf8") };
  } finally { rmSync(evidenceDirectory, { recursive: true, force: true }); }
}
function assertReleased(lifecycle: string, subscription: string): void {
  const event = z.strictObject({ event: z.enum(["acquired", "released"]), subscription: z.string() });
  const events = lifecycle.trim().split("\n").filter(Boolean).map((line) => { const raw: unknown = JSON.parse(line); return event.parse(raw); });
  assert.deepEqual(events, [{ event: "acquired", subscription }, { event: "released", subscription }]);
}
const query = { instrument: { source: "fixture", nativeId: "BTC-USD" }, limit: 2 };
const outcome = z.discriminatedUnion("tag", [z.object({ tag: z.literal("output"), value: candlePage }), z.object({ tag: z.literal("failure"), failure: z.json() })]);
const pull = cli(["invoke", "fixture", "market/candles", candlePull.descriptor.binding, JSON.stringify(query)], 0);
const finite = outcome.parse(pull.frames[0]);
assert.equal(finite.tag, "output");
if (finite.tag === "output") {
  assert.equal(finite.value.items[0]?.vwap, "101.25");
  assert.equal(finite.value.items[0]?.finality.tag, "provisional");
  assert.equal(finite.value.coverage.tag, "partial");
}
const streamed = cli(["subscribe", "fixture", "market/candle-feed", candlePush.descriptor.binding, JSON.stringify(query)], 0);
assert.deepEqual(streamed.frames.at(-1), { tag: "Completed" });
assertReleased(streamed.lifecycle, "fixture-BTC-USD");
const pushed = z.strictObject({ tag: z.literal("data"), value: richCandle.schema }).parse(streamed.frames[1]);
assert.equal(pushed.value.vwap, "101.25");
assert.equal(pushed.value.finality.tag, "provisional");
const cancelled = cli(["subscribe", "fixture", "market/candle-feed", candlePush.descriptor.binding, JSON.stringify(query), "2"], 0);
assert.deepEqual(cancelled.frames.at(-1), { tag: "Cancelled" });
assert(!cancelled.frames.some((frame) => z.object({ tag: z.literal("Completed") }).safeParse(frame).success));
assertReleased(cancelled.lifecycle, "fixture-BTC-USD");
const failed = cli(["subscribe", "fixture", "market/candle-feed", candlePush.descriptor.binding, JSON.stringify({ ...query, instrument: { source: "fixture", nativeId: "BTC-FAIL" } })], 2);
assert(z.object({ tag: z.literal("Failed") }).safeParse(failed.frames.at(-1)).success);
assert(!failed.frames.some((frame) => z.object({ tag: z.literal("Completed") }).safeParse(frame).success));
assertReleased(failed.lifecycle, "fixture-BTC-FAIL");
cli(["invoke", "fixture", "market/candles", candlePull.descriptor.binding, JSON.stringify({ ...query, limit: "2" })], 2);
cli(["invoke", "fixture", "order/cancel", "unbound", "{}"], 2);
cli(["invoke", "fixture", "market/candles", "stale", JSON.stringify(query)], 2);

assert.throws(() => portable(z.string().refine((value) => value === "not-portable")), /unsupported portable check/);
assert.throws(() => portable(z.string().transform((value) => value.length)), /unsupported portable/);
assert.throws(() => portable(z.string().optional()), /unsupported portable constructor: optional/);
assert.throws(() => portable(z.nonoptional(z.string().optional())), /unsupported portable constructor: optional/);
assert.throws(() => extend(orderBase.refine(() => true), z.strictObject({ custom: z.string() })), /unsupported portable check/);
// Dynamic schema input still reaches the runtime collision guard; no type assertion hides it.
const dynamicBase: z.ZodObject<z.ZodRawShape> = orderBase;
const dynamicExtension: z.ZodObject<z.ZodRawShape> = z.strictObject({ side: z.string() });
assert.throws(() => Reflect.apply(extend, undefined, [dynamicBase, dynamicExtension]), /duplicate field/);
const adapted = await Effect.runPromise(adaptedCandles.provide(MarketData, fixtureMarket).invoke({ nativeId: "BTC-USD", count: 2 }));
assert.equal(adapted.items[0]?.nativeEvent, "event-0");
const projected = await Effect.runPromise(projectedCandles.provide(MarketData, fixtureMarket).invoke(query));
assert.equal(projected.items[0]?.vwap, "101.25");
assert.equal(projected.items[0]?.finality.tag, "provisional");
assert.equal(projected.coverage.tag, "partial");
assert.equal(Object.hasOwn(projected, "asOf"), false);

const combined = combineReads(candlePull, candlePull, { ...candleMeaning, path: ["market", "paired-candles"] }).provide(MarketData, fixtureMarket);
const paired = await Effect.runPromise(combined.invoke({ left: { ...query, limit: 1 }, right: query }));
assert.equal(paired.left.items[0]?.nativeEvent, "event-0");
assert.equal(paired.left.items[0]?.close, "101");
assert.equal(paired.right.items[1]?.nativeEvent, "event-1");
assert.equal(paired.right.items[1]?.close, "102");
assert.equal(paired.left.coverage.tag, "partial");
assert.equal(paired.right.coverage.tag, "partial");
const secondReadFailure = await Effect.runPromise(Effect.match(combined.invoke({
  left: query, right: { ...query, instrument: { source: "fixture", nativeId: "SECOND-READ-MISSING" } },
}), { onSuccess: () => "unexpected-success", onFailure: (error) => error }));
assert.deepEqual(secondReadFailure, { tag: "unknown-instrument", nativeId: "SECOND-READ-MISSING" });

const catalog = new Catalog();
catalog.register(pullEntry(candlePull.provide(MarketData, fixtureMarket)));
catalog.register(pushEntry(candlePush.provide(MarketData, fixtureMarket)));
assert.deepEqual(catalog.discover({ id: "no-entitlement", permits: [] }).children, []);

await withForeign(async (provider) => {
  const certificate = await provider.invoke({ through: 10 });
  const known = z.strictObject({ sum: z.number().int(), algorithm: z.literal("triangular-v1") });
  assert.equal(certificate.project(provider.binding, "output", known).sum, 55);
  assert.throws(() => certificate.project(provider.binding, "input", known), /binding\/slot mismatch/);
  assert.throws(() => certificate.project("different-capability", "output", known), /binding\/slot mismatch/);
  await assert.rejects(provider.invoke({ through: "10" }));
  const foreignCli = cli(["invoke", provider.descriptor.provider, provider.descriptor.path.join("/"), provider.binding, '{"through":10}'], 0);
  assert.deepEqual(foreignCli.frames, [{ tag: "output", value: { sum: 55, algorithm: "triangular-v1" } }]);
  const malformedCli = cli(["invoke", provider.descriptor.provider, provider.descriptor.path.join("/"), provider.binding, '{"through":10}', "--malformed-foreign"], 2);
  assert(z.object({ tag: z.literal("Failed") }).safeParse(malformedCli.frames.at(-1)).success);
});
await assert.rejects(withForeign(async (provider) => provider.invoke({ through: 10 }), "malformed-output"));

const path = fileURLToPath(new URL("./scenario-admission.ndjson", import.meta.url));
await rm(path, { force: true });
try {
  const order = providerOrder.schema.parse({ account: "fixture-account", instrument: { source: "fixture", nativeId: "BTC-USD" }, side: "buy", quantity: "1.25", pricing: { tag: "limit", price: "99.50" }, session: "regular", postOnly: true, clientReference: "specimen" });
  const invocation = { command: "scenario-command", intent: order };
  const admitted = controlledOrder.provide(Admission, fileAdmission(path, "fixture-agent"));
  const receipt = await Effect.runPromise(admitted.invoke(invocation));
  const reconstructed = controlledOrder.provide(Admission, fileAdmission(path, "fixture-agent"));
  assert.deepEqual(await Effect.runPromise(reconstructed.invoke(invocation)), receipt);
  const rows = (await readFile(path, "utf8")).trim().split("\n").map((line) => { const raw: unknown = JSON.parse(line); return admissionRecord.parse(raw); });
  assert.deepEqual(rows.map((row) => row.command), ["scenario-command"]);
  assert.equal(rows[0]?.binding, controlledOrder.descriptor.binding);
  await assert.rejects(Effect.runPromise(reconstructed.invoke({ command: "scenario-command", intent: { ...order, quantity: "2.50" } })));
  const denied = controlledOrder.provide(Admission, fileAdmission(path, "nobody"));
  await assert.rejects(Effect.runPromise(denied.invoke({ ...invocation, command: "denied-command" })));
  const invalidStore = controlledOrder.provide(Admission, fileAdmission(path + "/not-a-directory", "fixture-agent"));
  await assert.rejects(Effect.runPromise(invalidStore.invoke({ ...invocation, command: "storage-failure" })));
} finally { await rm(path, { force: true }); }
console.log(JSON.stringify({ tag: "specimen-scenarios-passed", scope: "local algebra, CLI, owned stream, independent Python schema boundary, append-fsync admission only" }));
