import { Context, Effect, Stream } from "effect";
import { createHash } from "node:crypto";
import { z } from "zod";
import { exportedSchema, portable } from "./portable.js";

export const boundaryFailure = z.strictObject({ tag: z.literal("boundary"), slot: z.enum(["input", "output", "failure"]), detail: z.string() });
export type BoundaryFailure = z.output<typeof boundaryFailure>;
export type Control = "read" | "controlled";
export interface Meaning {
  readonly provider: string;
  readonly path: readonly string[];
  readonly revision: string;
  readonly semanticVersion: string;
  readonly description: string;
  readonly permission: string;
  readonly dependencies: readonly string[];
  readonly transformations: readonly { readonly kind: "input-adaptation" | "structural-projection"; readonly version: string; readonly loss: readonly string[] }[];
}
export interface Slots<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType> {
  readonly input: I; readonly output: O; readonly failure: E;
}
export interface Descriptor extends Meaning {
  readonly binding: string; readonly delivery: "pull" | "push"; readonly control: Control;
  readonly resources: readonly string[];
  readonly input: z.output<z.ZodJSONSchema>; readonly output: z.output<z.ZodJSONSchema>; readonly failure: z.output<z.ZodJSONSchema>;
}
function descriptor<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(
  meaning: Meaning, slots: Slots<I, O, E>, resources: readonly string[], delivery: "pull" | "push", control: Control,
): Descriptor {
  if (meaning.path.length === 0 || meaning.path.some((part) => !/^[a-z][a-z0-9-]*$/.test(part))) throw new Error("invalid capability path");
  const body = { ...meaning, resources, delivery, control, input: exportedSchema(slots.input), output: exportedSchema(slots.output), failure: exportedSchema(slots.failure) };
  return Object.freeze({ ...body, binding: createHash("sha256").update(JSON.stringify(body)).digest("hex") });
}
export function decode<S extends z.ZodType>(schema: S, raw: unknown, slot: BoundaryFailure["slot"]): Effect.Effect<z.output<S>, BoundaryFailure> {
  return Effect.suspend(() => {
    const result = schema.safeParse(raw);
    return result.success ? Effect.succeed(result.data) : Effect.fail(boundaryFailure.parse({ tag: "boundary", slot, detail: result.error.message }));
  });
}

/** Reconstructs the associated sum channel at an operator's schema boundary. */
export function failDeclared<S extends z.ZodType>(schema: S, failure: unknown): Effect.Effect<never, z.output<S> | BoundaryFailure> {
  const boundary = boundaryFailure.safeParse(failure);
  return boundary.success ? Effect.fail(boundary.data) : Effect.flatMap(decode(schema, failure, "failure"), Effect.fail);
}

/** Constructor is trusted interpreter plumbing, not exported by public.ts. */
export class Pull<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType, R, C extends Control> {
  readonly delivery = "pull";
  readonly descriptor: Descriptor;
  readonly #run: (input: z.output<I>, bound: Descriptor) => Effect.Effect<z.output<O>, z.output<E> | BoundaryFailure, R>;
  constructor(readonly meaning: Meaning, readonly slots: Slots<I, O, E>, readonly resources: readonly string[], readonly control: C,
    run: (input: z.output<I>, bound: Descriptor) => Effect.Effect<z.output<O>, z.output<E> | BoundaryFailure, R>) {
    this.descriptor = descriptor(meaning, slots, resources, "pull", control);
    this.#run = run;
  }
  invoke = (input: z.input<I>) => this.accept(input);
  accept = (input: unknown): Effect.Effect<z.output<O>, z.output<E> | BoundaryFailure, R> =>
    Effect.flatMap(decode(this.slots.input, input, "input"), (parsed) => Effect.flatMap(this.#run(parsed, this.descriptor), (value) => decode(this.slots.output, value, "output")));
  provide<Id, Service>(tag: Context.Tag<Id, Service>, service: NoInfer<Service>): Pull<I, O, E, Exclude<R, Id>, C> {
    return new Pull(this.meaning, this.slots, this.resources, this.control, (input) => Effect.provideService(this.accept(input), tag, service));
  }
}
export function definePull<Id, Service>(resource: Context.Tag<Id, Service>) {
  return <I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(meaning: Meaning, slots: Slots<I, O, E>,
    handler: (service: Service, input: z.output<NoInfer<I>>) => Effect.Effect<z.output<NoInfer<O>>, z.output<NoInfer<E>>>) =>
    new Pull(meaning, slots, [resource.key], "read", (input) => Effect.flatMap(resource, (service) =>
      Effect.catchAll(handler(service, input), (failure) => Effect.flatMap(decode(slots.failure, failure, "failure"), Effect.fail))));
}

export class Push<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType, R> {
  readonly delivery = "push";
  readonly control = "read";
  readonly descriptor: Descriptor;
  readonly #run: (input: z.output<I>) => Stream.Stream<z.output<O>, z.output<E> | BoundaryFailure, R>;
  constructor(readonly meaning: Meaning, readonly slots: Slots<I, O, E>, readonly resources: readonly string[],
    run: (input: z.output<I>) => Stream.Stream<z.output<O>, z.output<E> | BoundaryFailure, R>) {
    this.descriptor = descriptor(meaning, slots, resources, "push", "read");
    this.#run = run;
  }
  subscribe = (input: z.input<I>) => this.accept(input);
  accept = (input: unknown): Stream.Stream<z.output<O>, z.output<E> | BoundaryFailure, R> =>
    Stream.unwrap(Effect.map(decode(this.slots.input, input, "input"), (parsed) =>
      Stream.mapEffect(this.#run(parsed), (frame) => decode(this.slots.output, frame, "output"))));
  provide<Id, Service>(tag: Context.Tag<Id, Service>, service: NoInfer<Service>): Push<I, O, E, Exclude<R, Id>> {
    return new Push(this.meaning, this.slots, this.resources, (input) => Stream.provideService(this.accept(input), tag, service));
  }
}
export function definePush<Id, Service>(resource: Context.Tag<Id, Service>) {
  return <I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(meaning: Meaning, slots: Slots<I, O, E>,
    handler: (service: Service, input: z.output<NoInfer<I>>) => Stream.Stream<z.output<NoInfer<O>>, z.output<NoInfer<E>>>) =>
    new Push(meaning, slots, [resource.key], (input) => Stream.unwrap(Effect.map(resource, (service) =>
      Stream.catchAll(handler(service, input), (failure) => Stream.fromEffect(Effect.flatMap(decode(slots.failure, failure, "failure"), Effect.fail))))));
}

export type TransformResult<A, E> = { readonly tag: "value"; readonly value: A } | { readonly tag: "failure"; readonly failure: E };
export function adaptInput<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType, R, C extends Control,
  N extends z.ZodType, F extends z.ZodType>(base: Pull<I, O, E, R, C>, input: N, failure: F, version: string,
  adapt: (value: z.output<NoInfer<N>>) => TransformResult<z.input<NoInfer<I>>, z.output<NoInfer<F>>>) {
  portable(failure);
  const failures = z.union([base.slots.failure, failure]);
  return new Pull<N, O, typeof failures, R, C>(
    { ...base.meaning, dependencies: [base.descriptor.binding], transformations: [...base.meaning.transformations, { kind: "input-adaptation", version, loss: [] }] },
    { input, output: base.slots.output, failure: failures }, base.resources, base.control,
    (value) => Effect.catchAll(Effect.suspend<z.output<O>, z.output<E> | z.output<F> | BoundaryFailure, R>(() => {
      const result = adapt(value);
      return result.tag === "value" ? base.invoke(result.value) : Effect.flatMap(decode(failure, result.failure, "failure"), Effect.fail);
    }), (error) => failDeclared(failures, error)));
}

/** Structural projection cannot replace retained evidence, finality or coverage. */
export function projectOutput<I extends z.ZodType, B extends z.ZodRawShape, E extends z.ZodType, R, C extends Control,
  M extends { [K in keyof B]?: true }>(base: Pull<I, z.ZodObject<B>, E, R, C>,
  mask: M & Record<Exclude<keyof M, keyof B>, never>, version: string) {
  const output = base.slots.output.pick(mask);
  const loss = Object.keys(base.slots.output.shape).filter((key) => !Object.hasOwn(mask, key));
  return new Pull<I, typeof output, E, R, C>(
    { ...base.meaning, dependencies: [base.descriptor.binding], transformations: [...base.meaning.transformations, { kind: "structural-projection", version, loss }] },
    { ...base.slots, output }, base.resources, base.control,
    (input) => Effect.map(base.accept(input), (value) => output.strip().parse(value)));
}

/** Sequential finite reads preserve both complete per-source result envelopes. */
export function combineReads<I1 extends z.ZodType, O1 extends z.ZodType, E1 extends z.ZodType, R1,
  I2 extends z.ZodType, O2 extends z.ZodType, E2 extends z.ZodType, R2>(
  left: Pull<I1, O1, E1, R1, "read">, right: Pull<I2, O2, E2, R2, "read">, meaning: Meaning,
) {
  const slots = { input: z.strictObject({ left: z.nonoptional(left.slots.input), right: z.nonoptional(right.slots.input) }),
    output: z.strictObject({ left: z.nonoptional(left.slots.output), right: z.nonoptional(right.slots.output) }),
    failure: z.union([left.slots.failure, right.slots.failure]) };
  return new Pull<typeof slots.input, typeof slots.output, typeof slots.failure, R1 | R2, "read">(
    { ...meaning, dependencies: [left.descriptor.binding, right.descriptor.binding] },
    slots, [...new Set([...left.resources, ...right.resources])], "read", (input) =>
      Effect.catchAll(Effect.flatMap(Effect.zip(left.accept(input.left), right.accept(input.right)),
        ([first, second]) => decode(slots.output, { left: first, right: second }, "output")),
      (error) => failDeclared(slots.failure, error)));
}
