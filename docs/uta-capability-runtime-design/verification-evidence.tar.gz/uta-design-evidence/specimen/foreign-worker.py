"""Independent imperative provider. NDJSON protocol v1; no host TS types/SDK required."""
import json
import sys

NUMBER = {"type": "integer", "minimum": 0, "maximum": 1000}
INPUT = {"type": "object", "properties": {"through": NUMBER}, "required": ["through"], "additionalProperties": False}
OUTPUT = {"type": "object", "properties": {"sum": {"type": "integer", "minimum": 0, "maximum": 500500}, "algorithm": {"type": "string", "const": "triangular-v1"}}, "required": ["sum", "algorithm"], "additionalProperties": False}
ERROR = {"type": "object", "properties": {"reason": {"type": "string", "const": "invalid-range"}}, "required": ["reason"], "additionalProperties": False}
DESCRIPTOR = {"provider": "python-arithmetic", "path": ["arithmetic", "sum"], "revision": "1", "input": INPUT, "output": OUTPUT, "failure": ERROR}

def emit(value):
    sys.stdout.write(json.dumps(value, separators=(",", ":")) + "\n")
    sys.stdout.flush()

for line in sys.stdin:
    if len(line) > 65536:
        sys.exit(2)
    request = json.loads(line)
    if request["tag"] == "hello":
        emit({"tag": "hello", "protocol": 1, "request": request["request"]})
    elif request["tag"] == "discover":
        emit({"tag": "descriptor", "request": request["request"], "value": DESCRIPTOR})
    elif request["tag"] == "call":
        if request["revision"] != "1" or request["path"] != DESCRIPTOR["path"]:
            sys.exit(3)
        value = request["input"]
        valid = isinstance(value, dict) and set(value) == {"through"} and type(value["through"]) is int and 0 <= value["through"] <= 1000
        if not valid:
            emit({"tag": "failure", "request": request["request"], "value": {"reason": "invalid-range"}})
        else:
            n = value["through"]
            emit({"tag": "output", "request": request["request"], "value": {"sum": "not-an-integer" if "malformed-output" in sys.argv else n * (n + 1) // 2, "algorithm": "triangular-v1"}})
    elif request["tag"] == "close":
        emit({"tag": "closed", "request": request["request"]})
        break
    else:
        sys.exit(4)
