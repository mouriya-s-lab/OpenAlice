import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { z } from "zod";
import { Catalog, foreignEntry, type Json, type Principal } from "./catalog.js";
import { registerFixture } from "./providers.js";
import { withForeign } from "./foreign.js";

const emit = (value: Json) => { process.stdout.write(`${JSON.stringify(value)}\n`); };
const principal: Principal = { id: "fixture-agent", permits: ["market:read", "order:submit", "arithmetic:read"] };

/** Providers register entries. No CLI switch contains provider names or verbs. */
export async function main(args: readonly string[]): Promise<number> {
  const journal = fileURLToPath(new URL("./admission.ndjson", import.meta.url));
  return withForeign(async (foreign) => {
    const catalog = new Catalog();
    const registrations = [
      (target: Catalog) => registerFixture(target, journal),
      (target: Catalog) => target.register(foreignEntry(foreign)),
    ];
    for (const register of registrations) register(catalog);
    const [operation, provider, path, binding, encoded, cancellation] = args;
    if (operation === "discover" || operation === "help") {
      emit(z.json().parse(catalog.discover(principal)));
      return 0;
    }
    if (operation !== "invoke" && operation !== "subscribe" && operation !== "describe") throw new Error("usage: discover | describe provider path binding | invoke provider path binding JSON | subscribe provider path binding JSON [cancel-after-frames]");
    if (provider === undefined || path === undefined || binding === undefined) throw new Error("provider, path and discovered binding required");
    const entry = catalog.resolve(principal, provider, path, binding);
    if (operation === "describe") { emit(z.json().parse(entry.description)); return 0; }
    if (encoded === undefined) throw new Error("encoded input required");
    const raw: unknown = JSON.parse(encoded);
    if (operation === "invoke") {
      if (entry.tag !== "pull") throw new Error("delivery mismatch: use subscribe");
      const result = await entry.invoke(raw);
      emit(z.json().parse(result));
      return result.tag === "output" ? 0 : 2;
    }
    if (entry.tag !== "push") throw new Error("delivery mismatch: use invoke");
    const controller = new AbortController();
    const onInterrupt = () => controller.abort();
    process.once("SIGINT", onInterrupt);
    const cancelAfter = cancellation === undefined ? undefined : z.number().int().positive().parse(Number(cancellation));
    let frames = 0;
    try {
      const terminal = await entry.subscribe(raw, controller.signal, (frame) => {
        emit(frame);
        frames += 1;
        if (cancelAfter !== undefined && frames >= cancelAfter) controller.abort();
      });
      emit(z.json().parse(terminal));
      return terminal.tag === "Failed" ? 2 : 0;
    } finally { process.removeListener("SIGINT", onInterrupt); }
  }, args.includes("--malformed-foreign") ? "malformed-output" : "none");
}
const entry = process.argv[1];
if (entry !== undefined && resolve(entry) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).then((code) => { process.exitCode = code; }, (error: unknown) => {
    emit({ tag: "Failed", failure: { tag: "cli-boundary", message: error instanceof Error ? error.message : "non-Error failure" } });
    process.exitCode = 2;
  });
}
