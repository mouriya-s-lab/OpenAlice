import { appendFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { Context, Effect, Stream } from "effect";
import { z } from "zod";
import { definePull, definePush, adaptInput, projectOutput, type Meaning, type TransformResult } from "./algebra.js";
import { candleAt, candleFailure, candleFrame, candlePage, candleQuery, providerOrder } from "./units.js";
import { Admission, defineRecipe, fileAdmission, withTransaction } from "./transaction-internal.js";
import { Catalog, pullEntry, pushEntry } from "./catalog.js";

export interface MarketData { readonly generation: string; readonly report: (event: "acquired" | "released", subscription: string) => void; }
export const MarketData = Context.GenericTag<MarketData>("specimen/MarketData");
const resourceEvidencePath = z.string().min(1).parse(process.env.UTA_SPECIMEN_RESOURCE_LOG ??
  fileURLToPath(new URL("./resource-lifecycle.ndjson", import.meta.url)));
export const fixtureMarket: MarketData = {
  generation: "g1",
  report: (event, subscription) => { appendFileSync(resourceEvidencePath, `${JSON.stringify({ event, subscription })}\n`, "utf8"); },
};
export const candleMeaning: Meaning = {
  provider: "fixture", path: ["market", "candles"], revision: "1", semanticVersion: "candle-fixture-v1",
  description: "Finite rich Candle page, explicitly partial and provisional", permission: "market:read", transformations: [], dependencies: [],
};
export const candlePull = definePull(MarketData)(candleMeaning,
  { input: candleQuery, output: candlePage, failure: candleFailure },
  (service, input) => input.instrument.nativeId !== "BTC-USD" ? Effect.fail(candleFailure.parse({ tag: "unknown-instrument", nativeId: input.instrument.nativeId })) :
    Effect.succeed(candlePage.parse({ items: Array.from({ length: input.limit }, (_, index) => candleAt(index)), asOf: "2026-09-09T00:03:00.000Z",
      coverage: { tag: "partial", reason: `bounded source generation ${service.generation}`, continuation: "minute-3" } })));

export const candlePush = definePush(MarketData)({ ...candleMeaning, path: ["market", "candle-feed"], description: "Owned source-order stream; 1-item sequential delivery; no replay guarantee" },
  { input: candleQuery, output: candleFrame, failure: candleFailure },
  (service, input) => {
    const subscription = `fixture-${input.instrument.nativeId}`;
    return Stream.flatMap(Stream.acquireRelease(
      Effect.sync(() => { service.report("acquired", subscription); return subscription; }),
      (owned) => Effect.sync(() => service.report("released", owned)),
    ), () => {
      const start = candleFrame.parse({ tag: "start", generation: service.generation });
      const frames = [start, ...Array.from({ length: input.limit }, (_, index) => candleFrame.parse({ tag: "data", value: candleAt(index) }))];
      const data = Stream.mapEffect(Stream.fromIterable(frames), (frame) => Effect.map(Effect.sleep("20 millis"), () => frame));
      return input.instrument.nativeId === "BTC-FAIL" ? Stream.concat(Stream.take(data, 2), Stream.fail(candleFailure.parse({ tag: "source-disconnected", generation: service.generation }))) :
        input.instrument.nativeId === "BTC-USD" ? data : Stream.fail(candleFailure.parse({ tag: "unknown-instrument", nativeId: input.instrument.nativeId }));
    });
  });

const adapterFailure = z.strictObject({ tag: z.literal("unsupported-symbol"), nativeId: z.string() });
export const adaptedCandles = adaptInput(candlePull,
  z.strictObject({ nativeId: z.string(), count: z.number().int().min(1).max(3) }),
  adapterFailure, "native-symbol-v1",
  (input): TransformResult<z.input<typeof candleQuery>, z.output<typeof adapterFailure>> => input.nativeId.includes("/") ? { tag: "failure", failure: { tag: "unsupported-symbol", nativeId: input.nativeId } } :
    { tag: "value", value: { instrument: { source: "fixture", nativeId: input.nativeId }, limit: input.count } });
export const projectedCandles = projectOutput(candlePull, { items: true, coverage: true }, "omit-asof-v1");

const preparedOrder = z.strictObject({ nativeInterpretation: z.literal("fixture-native-v1"), terms: providerOrder.schema,
  criterion: z.literal("native-acknowledged"), compensation: z.literal("None") });
const prepareFailure = z.strictObject({ tag: z.literal("post-only-extended-conflict"), reason: z.string() });
const recipe = defineRecipe(providerOrder.schema, preparedOrder, prepareFailure, "recipe-v1", "fixture-native-v1",
  (input): TransformResult<z.output<typeof preparedOrder>, z.output<typeof prepareFailure>> => input.postOnly && input.session === "extended" ?
    { tag: "failure", failure: { tag: "post-only-extended-conflict", reason: "this fixture interpretation forbids this combination" } } :
    { tag: "value", value: { nativeInterpretation: "fixture-native-v1", terms: input, criterion: "native-acknowledged", compensation: "None" } });
export const controlledOrder = withTransaction(recipe, { tag: "IndependentBatch", revision: "policy-v1", principal: "fixture-agent" }, {
  ...candleMeaning, path: ["order", "submit"], semanticVersion: "fixture-limit-order-v1", description: "Admit a serializable limit-order recipe; never dispatch from CLI", permission: "order:submit",
});
export function registerFixture(catalog: Catalog, journal: string): void {
  catalog.register(pullEntry(candlePull.provide(MarketData, fixtureMarket)));
  catalog.register(pushEntry(candlePush.provide(MarketData, fixtureMarket)));
  catalog.register(pullEntry(controlledOrder.provide(Admission, fileAdmission(journal, "fixture-agent"))));
}
