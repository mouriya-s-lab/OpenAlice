import { Context, Effect } from "effect";
import { z } from "zod";
import { adaptInput, combineReads, definePull, projectOutput, type BoundaryFailure } from "./algebra.js";
import { pullEntry } from "./catalog.js";
import { candleFailure, candlePage, candleQuery, extend, orderBase, providerOrder, type ProviderOrder, type RichCandle } from "./units.js";
import { candleMeaning, candlePull, candlePush, controlledOrder, fixtureMarket, MarketData } from "./providers.js";
import { withTransaction } from "./transaction-internal.js";

type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2) ? true : false;
type Assert<T extends true> = T;
type Invocation<F extends (...args: never[]) => unknown> = ReturnType<F>;
export type ExactSuccess = Assert<Equal<Effect.Effect.Success<Invocation<typeof candlePull.invoke>>, z.output<typeof candlePage>>>;
export type ExactFailure = Assert<Equal<Effect.Effect.Error<Invocation<typeof candlePull.invoke>>, z.output<typeof candleFailure> | BoundaryFailure>>;
export type ExactRequirement = Assert<Equal<Effect.Effect.Context<Invocation<typeof candlePull.invoke>>, MarketData>>;
export type SameUnit = Assert<Equal<z.output<typeof candlePage>["items"][number], RichCandle>>;

const valid: ProviderOrder = { account: "fixture-account", instrument: { source: "fixture", nativeId: "BTC-USD" }, side: "buy",
  quantity: "1.25", pricing: { tag: "limit", price: "99.50" }, session: "regular", postOnly: true, clientReference: "case" };
providerOrder.projectBase(valid);
candlePull.invoke({ instrument: { source: "fixture", nativeId: "BTC-USD" }, limit: 2 });
pullEntry(candlePull.provide(MarketData, fixtureMarket));
const projected = projectOutput(candlePull, { items: true, coverage: true }, "type-projection-v1");
const controlledProjection = projectOutput(controlledOrder, { intent: true }, "receipt-id-v1");
export type PreservedAuthority = Assert<Equal<typeof controlledProjection.control, "controlled">>;

// @ts-expect-error Composition cannot overwrite a base field, even with the same schema.
extend(orderBase, z.strictObject({ side: z.enum(["buy", "sell"]) }));
// @ts-expect-error The legal limit-order product requires its price.
const missingPrice: ProviderOrder = { ...valid, pricing: { tag: "limit" } };
// @ts-expect-error An unsupported native parameter alternative does not widen the present leaf.
const unsupportedSession: ProviderOrder = { ...valid, session: "overnight" };
// @ts-expect-error Provider extension fields stay required.
const missingExtension: ProviderOrder = { ...valid, postOnly: undefined };
// @ts-expect-error Numeric quantities do not cross the exact decimal-string boundary.
const numericQuantity: ProviderOrder = { ...valid, quantity: 1.25 };
// @ts-expect-error Invalid input is rejected by the typed local call before the runtime boundary.
candlePull.invoke({ instrument: { source: "fixture", nativeId: "BTC-USD" }, limit: "2" });
// @ts-expect-error A missing declared resource cannot be erased when registering an executable leaf.
pullEntry(candlePull);
// @ts-expect-error Providing a resource of the wrong structural type cannot satisfy its service tag.
candlePull.provide(MarketData, { generation: "g1" });
// @ts-expect-error Projecting an undeclared field is not a capability-compatible transformation.
projectOutput(candlePull, { fabricatedFinality: true }, "bad-projection");
// @ts-expect-error Retained output failure is not silently narrowed to success-only.
const noFailure: Effect.Effect<z.output<typeof candlePage>, never, MarketData> = candlePull.invoke({ instrument: { source: "fixture", nativeId: "BTC-USD" }, limit: 1 });
// @ts-expect-error The projected result no longer claims asOf.
const projectedAsOf = projected.slots.output.shape.asOf;
// @ts-expect-error A mutation recipe is nominal/private, not an already executing query.
withTransaction(candlePull, { tag: "IndependentBatch", revision: "1", principal: "fixture-agent" }, candleMeaning);
// @ts-expect-error There is no native dispatch on the controlled public handle.
controlledOrder.dispatch;
// @ts-expect-error There is no recipe member to unwrap from the controlled handle.
controlledOrder.recipe;
// @ts-expect-error Push and finite invocation are different delivery types.
pullEntry(candlePush.provide(MarketData, fixtureMarket));
// @ts-expect-error Read combination cannot launder controlled authority into read authority.
combineReads(candlePull, controlledOrder, candleMeaning);

const badAdaptFailure = z.strictObject({ tag: z.literal("bad-adapt") });
// @ts-expect-error An input adapter must produce the original exact input, not an output page.
adaptInput(candlePull, candleQuery, badAdaptFailure, "bad-adapter", () => ({ tag: "value", value: { items: [] } }));
// @ts-expect-error Binding interpretation cannot add an undeclared failure channel.
definePull(MarketData)(candleMeaning, { input: candleQuery, output: candlePage, failure: candleFailure }, () => Effect.fail({ tag: "invented-error" }));
// @ts-expect-error Binding interpretation cannot lose the declared success fields.
definePull(MarketData)(candleMeaning, { input: candleQuery, output: candlePage, failure: candleFailure }, () => Effect.succeed({ items: [] }));

interface Clock { readonly epoch: string; }
const Clock = Context.GenericTag<Clock>("specimen/Clock");
const clockFailure = z.strictObject({ tag: z.literal("clock-unavailable") });
const clock = definePull(Clock)({ ...candleMeaning, path: ["clock", "read"] }, {
  input: z.strictObject({ request: z.literal("now") }), output: z.strictObject({ epoch: z.string() }), failure: clockFailure,
}, (service) => Effect.succeed({ epoch: service.epoch }));
const combined = combineReads(candlePull, clock, { ...candleMeaning, path: ["combined", "read"] });
export type CombinedRequirements = Assert<Equal<Effect.Effect.Context<Invocation<typeof combined.invoke>>, MarketData | Clock>>;
export type CombinedFailures = Assert<Equal<Effect.Effect.Error<Invocation<typeof combined.invoke>>, z.output<typeof candleFailure> | z.output<typeof clockFailure> | BoundaryFailure>>;
void [missingPrice, unsupportedSession, missingExtension, numericQuantity, noFailure, projectedAsOf];
