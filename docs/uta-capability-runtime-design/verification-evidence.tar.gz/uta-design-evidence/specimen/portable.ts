import { z } from "zod";

/** Pinned to Zod 4.3.6 internals; reject rather than erase callback semantics. */
export function portable<S extends z.ZodType>(schema: S): S {
  function inspect(node: z.core.$ZodType): void {
    for (const check of node._zod.def.checks ?? []) {
      if (check instanceof z.core.$ZodCheckGreaterThan || check instanceof z.core.$ZodCheckLessThan ||
          check instanceof z.core.$ZodCheckMinLength || check instanceof z.core.$ZodCheckMaxLength ||
          check instanceof z.core.$ZodCheckNumberFormat || check instanceof z.core.$ZodCheckRegex) continue;
      throw new Error(`unsupported portable check: ${check._zod.def.check}`);
    }
    if (node instanceof z.ZodObject) {
      if (!(node._zod.def.catchall instanceof z.ZodNever)) throw new Error("public objects must be exact");
      for (const child of Object.values(node.shape)) inspect(child);
      return;
    }
    if (node instanceof z.ZodArray) { inspect(node.element); return; }
    if (node instanceof z.ZodUnion) { for (const child of node.options) inspect(child); return; }
    if (node instanceof z.ZodNullable) { inspect(node.unwrap()); return; }
    if (node instanceof z.ZodNonOptional) { inspect(node.unwrap()); return; }
    if (node instanceof z.ZodISODateTime) return;
    if (node instanceof z.ZodString || node instanceof z.ZodNumber || node instanceof z.ZodBoolean) {
      if (node._zod.def.coerce) throw new Error("coercion is not an encoded contract");
      return;
    }
    if (node instanceof z.ZodLiteral || node instanceof z.ZodEnum || node instanceof z.ZodNull || node instanceof z.ZodNever) return;
    throw new Error(`unsupported portable constructor: ${node._zod.def.type}`);
  }
  inspect(schema);
  z.toJSONSchema(schema, { target: "draft-2020-12", unrepresentable: "throw" });
  return schema;
}

export function exportedSchema(schema: z.ZodType): z.output<z.ZodJSONSchema> {
  const exported = z.toJSONSchema(portable(schema), { target: "draft-2020-12", unrepresentable: "throw" });
  // Zod 4.3.6 finalize attaches nonenumerable ~standard after finalizing the JSON
  // document. The wire channel is its enumerable own fields, not that helper.
  // Keep every enumerable field; z.json still rejects non-JSON values within it.
  return z.json().parse({ ...exported });
}
