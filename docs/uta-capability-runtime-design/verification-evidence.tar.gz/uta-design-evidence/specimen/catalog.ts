import { Effect, Stream } from "effect";
import { z } from "zod";
import type { Descriptor, Pull, Push, Control } from "./algebra.js";
import type { ForeignProvider } from "./foreign.js";

export type Json = z.output<z.ZodJSONSchema>;
export type Output = { readonly tag: "output"; readonly value: Json } | { readonly tag: "failure"; readonly failure: Json };
export type Terminal = { readonly tag: "Completed" } | { readonly tag: "Failed"; readonly failure: Json } | { readonly tag: "Cancelled" };
export interface CatalogDescription { readonly provider: string; readonly path: readonly string[]; readonly revision: string; readonly binding: string; readonly delivery: "pull" | "push"; readonly permission: string; readonly contract: Json; }
export interface PullEntry { readonly tag: "pull"; readonly description: CatalogDescription; readonly invoke: (input: unknown) => Promise<Output>; }
export interface PushEntry { readonly tag: "push"; readonly description: CatalogDescription; readonly subscribe: (input: unknown, signal: AbortSignal, emit: (frame: Json) => void) => Promise<Terminal>; }
export type Entry = PullEntry | PushEntry;
export interface Namespace { readonly tag: "namespace"; readonly name: string; readonly children: readonly TreeNode[]; }
export type TreeNode = Namespace | { readonly tag: "capability"; readonly name: string; readonly description: CatalogDescription };
export interface Principal { readonly id: string; readonly permits: readonly string[]; }

function describe(descriptor: Descriptor): CatalogDescription {
  return { provider: descriptor.provider, path: descriptor.path, revision: descriptor.revision, binding: descriptor.binding,
    delivery: descriptor.delivery, permission: descriptor.permission, contract: z.json().parse(descriptor) };
}
export function pullEntry<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType, C extends Control>(capability: Pull<I, O, E, never, C>): PullEntry {
  return { tag: "pull", description: describe(capability.descriptor), invoke: (input) => Effect.runPromise(Effect.match(capability.accept(input), {
    onSuccess: (value): Output => ({ tag: "output", value: z.json().parse(value) }),
    onFailure: (failure): Output => ({ tag: "failure", failure: z.json().parse(failure) }),
  })) };
}
export function pushEntry<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(capability: Push<I, O, E, never>): PushEntry {
  return {
    tag: "push", description: describe(capability.descriptor),
    async subscribe(input, signal, emit) {
      const computation = Stream.runForEach(capability.accept(input), (frame) => Effect.sync(() => emit(z.json().parse(frame))));
      try {
        return await Effect.runPromise(Effect.match(computation, {
          onSuccess: (): Terminal => ({ tag: "Completed" }),
          onFailure: (failure): Terminal => ({ tag: "Failed", failure: z.json().parse(failure) }),
        }), { signal });
      } catch (error: unknown) {
        if (signal.aborted) return { tag: "Cancelled" };
        return { tag: "Failed", failure: { tag: "interpreter-defect", message: error instanceof Error ? error.message : "non-Error defect" } };
      }
    },
  };
}
export function foreignEntry(provider: ForeignProvider): PullEntry {
  return { tag: "pull", description: { provider: provider.descriptor.provider, path: provider.descriptor.path,
    revision: provider.descriptor.revision, binding: provider.binding, delivery: "pull", permission: "arithmetic:read", contract: z.json().parse(provider.descriptor) },
    async invoke(input) {
      const result = await provider.invoke(input);
      return result.slot === "output" ? { tag: "output", value: result.value } : { tag: "failure", failure: result.value };
    },
  };
}

export class Catalog {
  readonly #entries: Entry[] = [];
  register(entry: Entry): void {
    if (this.#entries.some((current) => current.description.provider === entry.description.provider && current.description.path.join("/") === entry.description.path.join("/"))) throw new Error("duplicate provider capability");
    this.#entries.push(entry);
  }
  discover(principal: Principal): Namespace {
    const visible = this.#entries.filter((entry) => principal.permits.includes(entry.description.permission));
    function branch(name: string, prefix: readonly string[], entries: readonly Entry[]): Namespace {
      const children: TreeNode[] = [];
      const segments = new Set(entries.map((entry) => [entry.description.provider, ...entry.description.path][prefix.length]));
      for (const segment of segments) {
        if (segment === undefined) throw new Error("invalid capability path");
        const selected = entries.filter((entry) => [entry.description.provider, ...entry.description.path][prefix.length] === segment);
        const leaf = selected.find((entry) => entry.description.path.length + 1 === prefix.length + 1);
        if (leaf) {
          if (selected.length !== 1) throw new Error("leaf/namespace collision");
          children.push({ tag: "capability", name: segment, description: leaf.description });
        } else children.push(branch(segment, [...prefix, segment], selected));
      }
      return { tag: "namespace", name, children };
    }
    return branch("root", [], visible);
  }
  resolve(principal: Principal, provider: string, path: string, binding: string): Entry {
    const entry = this.#entries.find((candidate) => candidate.description.provider === provider && candidate.description.path.join("/") === path);
    if (!entry || !principal.permits.includes(entry.description.permission)) throw new Error("capability not visible");
    if (entry.description.binding !== binding) throw new Error("stale capability binding");
    return entry;
  }
}
