import { z } from "zod";
import { portable } from "./portable.js";

/** Collision is rejected statically and at the declaration boundary. */
export function extend<B extends z.ZodRawShape, X extends z.ZodRawShape>(
  base: z.ZodObject<B>, extension: z.ZodObject<X>,
  ...collision: Extract<keyof B, keyof X> extends never ? [] : [never]
) {
  void collision;
  portable(base);
  portable(extension);
  const keys = new Set(Object.keys(base.shape));
  for (const key of Object.keys(extension.shape)) {
    if (keys.has(key)) throw new Error(`duplicate field: ${key}`);
  }
  const schema = z.strictObject({ ...base.shape, ...extension.shape });
  return {
    schema,
    projectBase: (value: z.output<typeof schema>): z.output<typeof base> => base.strip().parse(value),
  };
}

export const decimal = z.string().regex(/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/);
export const nonnegativeDecimal = z.string().regex(/^(?:0|[1-9]\d*)(?:\.\d+)?$/);
export const positiveDecimal = z.string().regex(/^(?:[1-9]\d*(?:\.\d+)?|0\.\d*[1-9]\d*)$/);
export const instrument = z.strictObject({ source: z.string().min(1), nativeId: z.string().min(1) });
export const orderBase = z.strictObject({
  account: z.string().min(1), instrument, side: z.enum(["buy", "sell"]),
});
export const quantityOrder = extend(orderBase, z.strictObject({ quantity: positiveDecimal }));
export const limitOrder = extend(quantityOrder.schema, z.strictObject({
  pricing: z.strictObject({ tag: z.literal("limit"), price: positiveDecimal }),
}));
export const providerOrder = extend(limitOrder.schema, z.strictObject({
  session: z.enum(["regular", "extended"]), postOnly: z.boolean(), clientReference: z.string().min(1),
}));
export type ProviderOrder = z.output<typeof providerOrder.schema>;

export const candleBase = z.strictObject({
  source: z.string().min(1), generation: z.string().min(1), instrument,
  interval: z.literal("1m"), openedAt: z.iso.datetime(),
  open: decimal, high: decimal, low: decimal, close: decimal,
  volume: z.strictObject({ amount: nonnegativeDecimal, unit: z.literal("base-asset"), evidence: z.string().min(1) }),
  timezone: z.literal("UTC"), session: z.literal("continuous"), adjustment: z.literal("unadjusted"),
  finality: z.discriminatedUnion("tag", [
    z.strictObject({ tag: z.literal("provisional"), reason: z.string() }),
    z.strictObject({ tag: z.literal("closed"), evidence: z.string() }),
    z.strictObject({ tag: z.literal("unknown"), reason: z.string() }),
  ]),
  revision: z.discriminatedUnion("tag", [
    z.strictObject({ tag: z.literal("original"), id: z.string() }),
    z.strictObject({ tag: z.literal("correction"), id: z.string(), replaces: z.string() }),
  ]),
});
export const richCandle = extend(candleBase, z.strictObject({
  vwap: decimal, trades: z.number().int().nonnegative(), nativeEvent: z.string().min(1),
}));
export type RichCandle = z.output<typeof richCandle.schema>;
export const candleQuery = z.strictObject({ instrument, limit: z.number().int().min(1).max(3) });
export const candleFailure = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("unknown-instrument"), nativeId: z.string() }),
  z.strictObject({ tag: z.literal("source-disconnected"), generation: z.string() }),
]);
export const candlePage = z.strictObject({
  items: z.array(richCandle.schema), asOf: z.iso.datetime(),
  coverage: z.discriminatedUnion("tag", [
    z.strictObject({ tag: z.literal("complete"), scope: z.string() }),
    z.strictObject({ tag: z.literal("partial"), reason: z.string(), continuation: z.string().nullable() }),
    z.strictObject({ tag: z.literal("unavailable"), reason: z.string() }),
  ]),
});
export const candleFrame = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("start"), generation: z.string() }),
  z.strictObject({ tag: z.literal("data"), value: richCandle.schema }),
  z.strictObject({ tag: z.literal("gap"), generation: z.string(), reason: z.string() }),
]);

/** Deterministic source data, not echoed input. Provisional remains provisional. */
export function candleAt(index: number): RichCandle {
  return richCandle.schema.parse({
    source: "fixture", generation: "g1", instrument: { source: "fixture", nativeId: "BTC-USD" },
    interval: "1m", openedAt: `2026-09-09T00:0${index}:00.000Z`,
    open: "100", high: "103", low: "99", close: `${101 + index}`,
    volume: { amount: "2.50", unit: "base-asset", evidence: "fixture-volume-v1" },
    timezone: "UTC", session: "continuous", adjustment: "unadjusted",
    finality: { tag: "provisional", reason: "source has not closed interval" },
    revision: { tag: "original", id: `revision-${index}` },
    vwap: "101.25", trades: 4 + index, nativeEvent: `event-${index}`,
  });
}
