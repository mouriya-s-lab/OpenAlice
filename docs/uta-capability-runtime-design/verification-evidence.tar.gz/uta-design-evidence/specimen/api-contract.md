# 可执行声明代数：精确接口与证据边界

本目录是设计书的从属可执行材料，不是生产 UTA。接口使用 Zod 4.3.6 与 Effect 3.22.1；严格类型检查、CLI/进程/文件场景和 19 个未抑制的静态反例均已执行，完整输出保存在归档根目录。下面代码中的 `S` 均为 `z.ZodType`，`In<S> = z.input<S>`，`Out<S> = z.output<S>`；这些记号只缩短书面签名，不建立另一份 DTO。

## 文件与边界

- `units.ts`：disjoint schema product、Order 的 quantity/limit/provider extension、同一 rich Candle 单元及 Pull/Push 封装。
- `portable.ts`：钉住 Zod 4.3.6 constructor/check 类型的受限公共编码检查。拒绝 custom/refine/transform/coercion/非 exact object，而不是用成功导出 JSON Schema 推断 callback 等价。
- `algebra.ts`：关联式 Pull/Push、typed resource binding/provision、pure input adaptation、structural output projection、finite read combination。构造器是 trusted interpreter plumbing。
- `transaction-internal.ts`：不从 `public.ts` 导出的 nominal Recipe、compiler/version/native-interpretation association、IndependentBatch admission、单进程 serialized append+fsync writer。
- `catalog.ts`、`cli.ts`：最终定义的 discovery/tree/resolve/invoke/subscribe 解释器，无 provider 名称或业务 verb switch。
- `foreign.ts`、`foreign-worker.py`：独立 Python 命令实现、handshake/discover/correlation/close、运行时 portable schema validation、binding+slot certificate。
- `providers.ts`：具体 native 风格实现与注册。字段不是 adapter bags；没有 order/cancel 或 options stub。
- `public.ts`：消费者仅取得 typed handles/operators/catalog；不导出 Recipe、native handler、writer 或 capability constructor。
- `type-cases.ts`：正常推导与应拒绝的消费者代码。不得作为 runtime import；负例会执行非法调用。
- `scenarios.ts`：启动真实 CLI、Python 子进程和隔离文件接纳场景；执行输出见 `../specimen-runtime.txt`。

## Schema product 与 Order

实际签名：

```ts
function extend<B extends z.ZodRawShape, X extends z.ZodRawShape>(
  base: z.ZodObject<B>,
  extension: z.ZodObject<X>,
  ...collision: Extract<keyof B, keyof X> extends never ? [] : [never]
): {
  schema: z.ZodObject<B & X, z.core.$strict>;
  projectBase: (value: z.output<z.ZodObject<B & X>>) => z.output<z.ZodObject<B>>;
};
```

`extend` 在 shape 展开前检查两个输入的 portable profile，不能先丢失 refinement 再声称保留约束。相同 key 即使类型相同也拒绝；动态输入同样检查，不覆盖已有字段。`projectBase` 按原 base 的 strip projection 移除新增字段，然后重新解析原值；原有值不会被转换。

本实例按 schema product 推导：Order base 含 account、source-native Instrument、side；quantity fragment 增加严格正 decimal quantity；limit fragment 增加 `{ pricing: { tag: "limit", price } }`；provider fragment 增加 session、postOnly、clientReference。没有手写 quantity × pricing × session 的 Cartesian DTO。

一般 OHLC/VWAP `decimal` 允许负值；volume amount 使用独立 nonnegativeDecimal。示例 venue 的 limit price 和 quantity 使用 positiveDecimal，这是 provider 已选择的限制，不是所有市场价格的公理。Timestamp 是显式 ISO 字符串。对象 extension 保留 rich Candle 的 vwap、trades、nativeEvent，以及共同的 source/generation、interval、volume-unit evidence、timezone/session/adjustment、finality 和 revision/correction 关系。

## Typed interpretation 与 service association

```ts
interface Slots<I extends z.ZodType, O extends z.ZodType, E extends z.ZodType> {
  readonly input: I;
  readonly output: O;
  readonly failure: E;
}

type Control = "read" | "controlled";
type BoundaryFailure = {
  tag: "boundary";
  slot: "input" | "output" | "failure";
  detail: string;
};

function definePull<Id, Service>(resource: Context.Tag<Id, Service>):
  <I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(
    meaning: Meaning,
    slots: Slots<I, O, E>,
    handler: (service: Service, input: Out<NoInfer<I>>) =>
      Effect.Effect<Out<NoInfer<O>>, Out<NoInfer<E>>>
  ) => Pull<I, O, E, Id, "read">;

function definePush<Id, Service>(resource: Context.Tag<Id, Service>):
  <I extends z.ZodType, O extends z.ZodType, E extends z.ZodType>(
    meaning: Meaning,
    slots: Slots<I, O, E>,
    handler: (service: Service, input: Out<NoInfer<I>>) =>
      Stream.Stream<Out<NoInfer<O>>, Out<NoInfer<E>>>
  ) => Push<I, O, E, Id>;
```

`NoInfer` 防止 handler 的错误返回反向扩大声明的 success/failure schema。实际成功值、expected failure、input 与 Push frame 都重新按绑定 slot 解析；网络/native 错误不是不经检查的 JSON。解释器的 schema-boundary failure 是独立明确的 channel，与 leaf failure union 保留。

`exportedSchema` 在 portable constructor/check 检查后，只投影 `z.toJSONSchema` 返回值的 enumerable own fields，再以 `z.json()` 检查整个 document。Zod 4.3.6 的 `core/to-json-schema.js:346-357` 先完成 JSON document，再附加 nonenumerable `~standard` helper（含 validate 与 jsonSchema.input/output 函数）；后者是本地 StandardSchema channel，不是 wire schema。浅层 own-field projection 不删除任意 enumerable/nested 值，也不以 stringify 丢弃函数来伪装 callback 可移植。

服务以真实 `Context.Tag<Id, Service>` 关联；descriptor 使用同一个 tag 的 key，不另写一份 resource 名称。handler 接受普通 Service 值，Service 可封装任意 imperative SDK/REST/gateway 实现，不要求 native 作者采用 Effect。

```ts
// Pull<I,O,E,R,C> 实例方法
invoke(input: In<I>): Effect.Effect<Out<O>, Out<E> | BoundaryFailure, R>;
accept(input: unknown): Effect.Effect<Out<O>, Out<E> | BoundaryFailure, R>;
provide<Id, Service>(tag: Context.Tag<Id, Service>, service: NoInfer<Service>):
  Pull<I, O, E, Exclude<R, Id>, C>;

// Push<I,O,E,R> 实例方法
subscribe(input: In<I>): Stream.Stream<Out<O>, Out<E> | BoundaryFailure, R>;
accept(input: unknown): Stream.Stream<Out<O>, Out<E> | BoundaryFailure, R>;
provide<Id, Service>(tag: Context.Tag<Id, Service>, service: NoInfer<Service>):
  Push<I, O, E, Exclude<R, Id>>;
```

这些是 trusted in-process interpreter handles。它们不把已提供的 service 变成 principal permission：外部入口的 Catalog 另按 Principal.permits 过滤 discovery 并在 resolve 时检查；admission writer 另检查指定 principal。这里只实现固定 fixture permission policy，未实现生产动态 policy/scope/entitlement engine。不能把本例的 service discharge 当作完整权限模型验收。

## Adapt、Project 与组合

```ts
type TransformResult<A, F> =
  | { readonly tag: "value"; readonly value: A }
  | { readonly tag: "failure"; readonly failure: F };

function adaptInput<I extends z.ZodType, O extends z.ZodType,
  E extends z.ZodType, R, C extends Control,
  N extends z.ZodType, F extends z.ZodType>(
  base: Pull<I, O, E, R, C>, input: N, failure: F, version: string,
  adapt: (value: Out<NoInfer<N>>) => TransformResult<In<NoInfer<I>>, Out<NoInfer<F>>>
): Pull<N, O, z.ZodUnion<readonly [E, F]>, R, C>;
```

输入 adaptation 是声明版本的 pure Result 函数，原输入再经原 schema 检查；transform failure 与原 failure 并存，R 和 C 不变。它不是在 portable Zod schema 内埋入任意 refinement，也不声称 transformation 的源代码能由 JSON Schema 重建。

```ts
function projectOutput<I extends z.ZodType, B extends z.ZodRawShape,
  E extends z.ZodType, R, C extends Control,
  M extends { [K in keyof B]?: true }>(
  base: Pull<I, z.ZodObject<B>, E, R, C>,
  mask: M & Record<Exclude<keyof M, keyof B>, never>, version: string
): Pull<I,
  z.ZodObject<z.core.util.Flatten<Pick<B, Extract<keyof B, keyof M>>>>,
  E, R, C>;
```

此处的 projection **只做 structural pick**：无法把 retained finality 改成 closed、把 Partial 改成 Complete、改写 nativeEvent。被移除的字段由 operator 自动写入 loss metadata。删除 asOf 是公开的损失，不把缺失伪装成更强证据。它不证明 decimal、FX、timezone 或 Instrument identity 的语义转换。

```ts
function combineReads<I1 extends z.ZodType, O1 extends z.ZodType,
  E1 extends z.ZodType, R1, I2 extends z.ZodType, O2 extends z.ZodType,
  E2 extends z.ZodType, R2>(
  left: Pull<I1, O1, E1, R1, "read">,
  right: Pull<I2, O2, E2, R2, "read">,
  meaning: Meaning
): Pull<
  z.ZodObject<{ left: z.ZodNonOptional<I1>; right: z.ZodNonOptional<I2> }, z.core.$strict>,
  z.ZodObject<{ left: z.ZodNonOptional<O1>; right: z.ZodNonOptional<O2> }, z.core.$strict>,
  z.ZodUnion<readonly [E1, E2]>, R1 | R2, "read"
>;
```

combineReads 用顺序 Effect.zip 执行两个查询，保留两个完整 result envelopes，不汇总成更强 coverage；failure 和 requirements 是 union。controlled handle 不能传入此 read-only combinator。source binding digest 被加入 derived dependency identity，不能因 schema 同形就把另一种解释视作相同 capability。

Pair envelope 的 left/right 与 admission envelope 的 intent 使用显式 `z.nonoptional(originalSlot)`：产品字段是 required，undefined 不是编码值。portable traversal 仍进入原 slot 并拒绝 optional/undefined constructors，不能用 wrapper 悄悄把不支持的 leaf 声明变成合法声明。每个 leaf 保留原 schema 检查；组合后的 product success 与 sum failure 也由派生 schema 解码。`Effect.suspend` 与派生 Pull 显式保留 A/E/R 参数，不以 cast 假定 Zod 的泛型 conditional output 已经化简。BoundaryFailure 保持原值，expected domain failures 按派生 union slot 重新建立关联。

## 同一 Candle，不同 delivery

Pull success 是 `{ items: RichCandle[], asOf, coverage }`；Push 非终态 frame 是 Start、Data(RichCandle)、Gap。两处直接使用同一个 `richCandle.schema`，不是两个相似接口。

Stream source 用 `Stream.acquireRelease` 持有具体 subscription，数据按 source 顺序逐项经过 Effect.sleep 与 schema validation；取消或 source failure 都触发 release。descriptor 的 description 明确声明这个 fixture 是顺序 1-item delivery，无 replay 保证。catalog 外层仅在 owned computation 退出后生成一个 `Completed | Failed | Cancelled`。source failure 不能再产生 Completed；SIGINT/取消释放所有 owned resources。没有承诺 owner crash/broken stdout 之后还能发送 terminal wire frame。

生命周期证据使用独立 fixture 文件 channel：`UTA_SPECIMEN_RESOURCE_LOG` 指定文件，单独启动 CLI 时默认写同目录 `resource-lifecycle.ndjson`。stdout 只承载 capability frames/terminal；stderr 保留 Node、tsx 和 native diagnostics，不当作 NDJSON 协议。scenarios 每次创建自己独占的 evidence directory/file，将路径传给该 CLI，只解析对应文件，并在 finally 清理自己的目录；子进程 stderr 原样转发，不关闭 warning、不过滤无法解析的诊断行。

## 非公开 Recipe 与 withTransaction

```ts
// 仅 provider/internal authoring 可构造；private #compile 使其 nominal。
function defineRecipe<I extends z.ZodType, P extends z.ZodType, E extends z.ZodType>(
  input: I, prepared: P, failure: E,
  revision: string, nativeInterpretation: string,
  compile: (input: Out<NoInfer<I>>) => TransformResult<Out<NoInfer<P>>, Out<NoInfer<E>>>
): Recipe<I, P, E>;

interface SubmissionPolicy {
  readonly tag: "IndependentBatch";
  readonly revision: string;
  readonly principal: string;
}

function withTransaction<I extends z.ZodType, P extends z.ZodType, E extends z.ZodType>(
  recipe: Recipe<I, P, E>, policy: SubmissionPolicy, meaning: Meaning
): Pull<
  z.ZodObject<{ command: z.ZodString; intent: z.ZodNonOptional<I> }, z.core.$strict>,
  typeof receiptSchema,
  z.ZodUnion<readonly [E, typeof admissionFailure]>, Admission, "controlled"
>;
```

`Recipe` 不实现 invoke/subscribe，不能传给 query/stream invoker；`withTransaction` 不接受 PullCapability，更不接受已经运行的 Promise/function。具体 compiler 在无外部 IO 下产生精确 prepared terms、criterion、compensation declaration 与 installed native interpretation identity。recipe schema/interpretation/compiler identity 以及 frozen policy identity 进入 public capability binding；writer 收到实际 controlled binding。

public success 为 `{ tag: "admitted", intent, binding, journal }`。同 command+同语义 bytes 重读 prior receipt；同 command+不同 bytes 返回 identity-conflict。writer append 后 fsync，再返回 receipt；storage failure 不成为成功。prepare failure/denied/storage failure 都不会 native dispatch。这个实例没有 native dispatch 实现或可达的 native handler，不伪造 send/ack/recovery。

因此这里只支持 admission 边界及 not-already-executing recipe 的反例；**不支持** DispatchStarted permission、native acknowledgement、ambiguous-send observation、compensation、SQL transactional projection/outbox、writer crash/partial record、跨进程 writer 或 full native conformance 的已验证声明。文件 writer 只串行化本实例中的一个进程；首次创建目录项的 crash-durability 不由 file fsync 单独证明。

完整目标的 controlled 类型是 `Controlled<RecipeAssociation, AdmissionContract>`，其 receipt/status 必须保持 prepared、domain outcome、stage failure 与 admission/execution 各自的 R/P 关联。本 admission-only specimen 在内部 Recipe 保持 I/P/E 关联，但 public Pull 仅保留 receipt、input、failure 与 Admission service，不提供 typed status/rehydration。因此不能把上面的受限签名直接替代设计书的完整 controlled 类型；该差异是证据边界，不是允许生产抹除 RecipeAssociation。

## Catalog、CLI 与 foreign document

```ts
function pullEntry<I extends z.ZodType, O extends z.ZodType,
  E extends z.ZodType, C extends Control>(capability: Pull<I,O,E,never,C>): PullEntry;
function pushEntry<I extends z.ZodType, O extends z.ZodType,
  E extends z.ZodType>(capability: Push<I,O,E,never>): PushEntry;

class Catalog {
  register(entry: Entry): void;
  discover(principal: Principal): Namespace;
  resolve(principal: Principal, provider: string, path: string, binding: string): Entry;
}
```

registration 只接受已 discharge service R 的可执行 handle。entry 是 existential packaging：精确 schemas/handler 仍绑定在 closure 内，边界先验证再编码 Json。tree 从实际 entries 派生；无叶子的 namespace 根本不存在。CLI 命令只有外部 interpretation：discover/help、describe、invoke、subscribe。invoke 与 subscribe 根据已发现 leaf 的 delivery 检查，不发明业务命令。

Python provider 以自己的 exact JSON Schema 声明 triangular-sum 能力。host 的 foreign profile 只接受有界 integer 和 const string 组成的 flat exact object；其他 keywords/constructors 在 load 时拒绝。host 从实际 descriptor 构造 Zod runtime validator，没有假装得到了编译期 Python output 类型。NDJSON v1 handshake、request correlation、3s request deadline、64KiB frame检查、close/进程回收为真实 process boundary；无订阅/credit/replay 的实现或证明。

```ts
function withForeign<A>(
  use: (provider: ForeignProvider) => Promise<A>,
  fault?: "none" | "malformed-output"
): Promise<A>;

interface ForeignProvider {
  readonly descriptor: ForeignDescriptor;
  readonly binding: string;
  readonly invoke: (raw: unknown) => Promise<CertifiedDocument>;
}

// 非导出的 concrete certificate class；通过 resolved schema slot 创建。
project<S extends z.ZodType>(
  expectedBinding: string,
  expectedSlot: "input" | "output" | "failure",
  knownSchema: S
): Out<S>;
```

certificate binding digest 包含 provider identity、capability path、revision 和三个 schema slots；certificate 另绑定 output/failure slot。project 先检查相同 binding 和 slot，再执行显式 known-schema projection。相同 JSON 形状不授权另一 capability/slot 复用该 certificate。`.value` 是可显示的 JSON document；它不是 branded provider DTO。foreign fault 参数只是临时 worker 的损坏输出注入，不进入 capability input schema。

这里的摘要计算是固定 fixture object 构造顺序下的 `SHA256(JSON.stringify(...))`，用于使这些具体调用的不同声明/slot 可被反例区分；**不是**完整目标选择的 RFC8785 JCS UTF-8 加 domain-separated SHA256。没有实现跨语言 canonicalization、semantic evaluator closure digest、通用 provider-instance lifecycle 或历史 resolver。正式 book 不应以本摘要函数验收完整 binding profile。

## 执行入口与解释范围

在 `specimen/` 目录中运行，依赖安装于父目录：

```sh
../node_modules/.bin/tsc --noEmit --strict --target ES2022 --module NodeNext --moduleResolution NodeNext --skipLibCheck *.ts
node --import tsx scenarios.ts
node --import tsx cli.ts discover
```

先从 discover 输出取得 binding，再执行：

```sh
node --import tsx cli.ts invoke fixture market/candles BINDING '{"instrument":{"source":"fixture","nativeId":"BTC-USD"},"limit":2}'
node --import tsx cli.ts subscribe fixture market/candle-feed BINDING '{"instrument":{"source":"fixture","nativeId":"BTC-USD"},"limit":2}' 2
```

`BINDING` 是命令说明中的显式参数，不是程序 fallback；必须使用实际 discovery 值。`type-cases.ts` 的负例由归档根目录的 `check-negative-types.mjs` 在内存删除 expect-error 指令后检查，不修改源文件。`scenarios.ts` 启动真实 CLI 和 Python 子进程，检查 rich fields、Partial/provisional 保留、取消与失败终态、release、schema rejection、certificate misuse、append/fsync 后重建 receipt、conflict/denied/storage failure。完整结果见 `../specimen-runtime.txt`、`../negative-type-evidence.json` 与 `../negative-type-summary.txt`。

这些结果即使全部通过，也只支持这里明列的受限 structural algebra、fixture resource ownership、foreign pull schema boundary 和 admission。它们不替代完整 book 的 provider-specific semantic constraints、A5/A6 crash protocol、A7 durable activation、数据库/native broker 行为或生产权限验收。
