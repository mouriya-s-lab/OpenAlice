import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { z } from "zod";

// Deliberately small portable profile: unsupported schema keywords reject load.
// The recursive JSON type is a wire document, never a fabricated provider DTO.
const scalarSchema = z.discriminatedUnion("type", [
  z.strictObject({ type: z.literal("integer"), minimum: z.number().int(), maximum: z.number().int() }),
  z.strictObject({ type: z.literal("string"), const: z.string() }),
]);
const exactObjectSchema = z.strictObject({
  type: z.literal("object"), properties: z.record(z.string(), scalarSchema),
  required: z.array(z.string()), additionalProperties: z.literal(false),
});
const descriptorSchema = z.strictObject({
  provider: z.string().min(1), path: z.array(z.string().min(1)).min(1), revision: z.string().min(1),
  input: exactObjectSchema, output: exactObjectSchema, failure: exactObjectSchema,
});
const responseSchema = z.discriminatedUnion("tag", [
  z.strictObject({ tag: z.literal("hello"), protocol: z.literal(1), request: z.string() }),
  z.strictObject({ tag: z.literal("descriptor"), request: z.string(), value: descriptorSchema }),
  z.strictObject({ tag: z.literal("output"), request: z.string(), value: z.json() }),
  z.strictObject({ tag: z.literal("failure"), request: z.string(), value: z.json() }),
  z.strictObject({ tag: z.literal("closed"), request: z.string() }),
]);
export type ForeignDescriptor = z.output<typeof descriptorSchema>;
class CertifiedDocument {
  private constructor(readonly binding: string, readonly slot: "output" | "failure", readonly value: z.output<z.ZodJSONSchema>) {}
  static decode(binding: string, slot: "output" | "failure", schema: z.ZodType, wire: unknown) {
    return new CertifiedDocument(binding, slot, z.json().parse(schema.parse(wire)));
  }
  project<S extends z.ZodType>(expectedBinding: string, expectedSlot: "input" | "output" | "failure", knownSchema: S): z.output<S> {
    if (this.binding !== expectedBinding || this.slot !== expectedSlot) throw new Error("certificate binding/slot mismatch");
    return knownSchema.parse(this.value);
  }
}

export async function withForeign<A>(use: (provider: ForeignProvider) => Promise<A>, fault: "none" | "malformed-output" = "none"): Promise<A> {
  const child = spawn("python3", [fileURLToPath(new URL("./foreign-worker.py", import.meta.url)), fault], { stdio: ["pipe", "pipe", "inherit"] });
  const lines = createInterface({ input: child.stdout });
  const iterator = lines[Symbol.asyncIterator]();
  const closed = new Promise<void>((resolve) => { child.once("close", () => resolve()); });
  let processFailure: Error | undefined;
  child.once("error", (error) => { processFailure = error; lines.close(); });
  let serial = 0;
  // One outstanding request: bounded correlation, not a multiplexing claim.
  async function exchange(request: z.output<z.ZodJSONSchema>) {
    if (processFailure) throw processFailure;
    const id = String(++serial);
    const body = z.record(z.string(), z.json()).parse(request);
    child.stdin.write(`${JSON.stringify({ ...body, request: id })}\n`);
    const timeout = setTimeout(() => { child.kill("SIGTERM"); lines.close(); }, 3000);
    try {
      const next = await iterator.next();
      if (next.done) throw processFailure ?? new Error("foreign transport ended before response");
      if (Buffer.byteLength(next.value) > 65536) throw new Error("foreign frame exceeds 64KiB");
      const raw: unknown = JSON.parse(next.value);
      const result = responseSchema.parse(raw);
      if (result.request !== id) throw new Error("foreign correlation mismatch");
      return result;
    } finally { clearTimeout(timeout); }
  }
  try {
    const hello = await exchange({ tag: "hello", protocol: 1 });
    if (hello.tag !== "hello") throw new Error("missing protocol handshake");
    const discovery = await exchange({ tag: "discover" });
    if (discovery.tag !== "descriptor") throw new Error("missing discovery");
    const descriptor = discovery.value;
    for (const schema of [descriptor.input, descriptor.output, descriptor.failure]) {
      const keys = Object.keys(schema.properties).sort();
      if (JSON.stringify(keys) !== JSON.stringify([...schema.required].sort())) throw new Error("profile requires exactly all declared fields");
    }
    const input = z.fromJSONSchema(descriptor.input, { defaultTarget: "draft-2020-12" });
    const output = z.fromJSONSchema(descriptor.output, { defaultTarget: "draft-2020-12" });
    const failure = z.fromJSONSchema(descriptor.failure, { defaultTarget: "draft-2020-12" });
    const binding = createHash("sha256").update(JSON.stringify(descriptor)).digest("hex");
    const provider: ForeignProvider = {
      descriptor, binding,
      async invoke(raw) {
        const checked = z.json().parse(input.parse(raw));
        const result = await exchange({ tag: "call", path: descriptor.path, revision: descriptor.revision, input: checked });
        switch (result.tag) {
          case "output": return CertifiedDocument.decode(binding, "output", output, result.value);
          case "failure": return CertifiedDocument.decode(binding, "failure", failure, result.value);
          case "hello": case "descriptor": case "closed": throw new Error("unexpected invocation response");
        }
      },
    };
    const result = await use(provider);
    const goodbye = await exchange({ tag: "close" });
    if (goodbye.tag !== "closed") throw new Error("missing close acknowledgement");
    return result;
  } finally {
    child.stdin.end();
    lines.close();
    child.kill("SIGTERM");
    await closed;
  }
}
export interface ForeignProvider {
  readonly descriptor: ForeignDescriptor;
  readonly binding: string;
  readonly invoke: (raw: unknown) => Promise<CertifiedDocument>;
}
