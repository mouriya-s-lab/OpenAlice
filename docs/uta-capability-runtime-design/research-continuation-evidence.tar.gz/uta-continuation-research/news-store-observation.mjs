import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const [repository, output] = process.argv.slice(2);
if (!repository || !output || process.argv.length !== 4) throw new Error('Pass repository and a new output directory');
const outputDirectory = resolve(output);
await mkdir(outputDirectory); // Refuse an existing directory; never reuse user state.
process.env.OPENALICE_HOME = join(outputDirectory, 'isolated-home');
const { NewsCollectorStore, computeDedupKey } = await import(pathToFileURL(join(resolve(repository), 'src/domain/news/store.ts')).href);
const options = { logPath: join(outputDirectory, 'news.jsonl') };
const store = new NewsCollectorStore(options);
await store.init();
const anchor = Date.now() - 60_000;
const query = { startTime: new Date(anchor - 60_000), endTime: new Date(anchor + 60_000), limit: 10 };
const original = { title: 'Original story', content: 'Initial content', pubTime: new Date(anchor), dedupKey: computeDedupKey({ guid: 'research-guid' }), metadata: { source: 'fixture-feed-A' } };
const first = await store.ingestRecord(original);
assert.notEqual(first, null);
const before = await store.getNewsV2(query);
const correction = await store.ingestRecord({ ...original, title: 'Changed story', content: 'Changed content under the same GUID' });
assert.equal(correction, null);
assert.deepEqual(await store.getNewsV2(query), before, 'Same-key content change is not a current revision event');
const late = await store.ingestRecord({ title: 'Later arrival, earlier publication', content: 'Arrived after the first query', pubTime: new Date(anchor - 1000), dedupKey: computeDedupKey({ guid: 'research-late-guid' }), metadata: { source: 'fixture-feed-B' } });
assert.notEqual(late, null);
const after = await store.getNewsV2(query);
assert.deepEqual(before.map((item) => item.title), ['Original story']);
assert.deepEqual(after.map((item) => item.title), ['Later arrival, earlier publication', 'Original story']);
assert.deepEqual(after.map((item) => item.id), [2, 1], 'Publication ordering is not ingestion ordering');
await store.close();
const reopened = new NewsCollectorStore(options);
await reopened.init();
const recovered = await reopened.getNewsV2(query);
assert.deepEqual(recovered, after, 'Actual file-backed records survive store reconstruction');
await reopened.close();
const summary = {
  source: 'Unmodified NewsCollectorStore and computeDedupKey in current checkout; isolated real JSONL file',
  node: process.version,
  sameKeyContentChange: correction,
  query,
  before,
  after,
  recovered,
  supports: 'Same GUID content change is dropped; a later-ingested article can enter the same publication-time window; publication sort differs from local ingestion identity; records persist across reconstruction.',
  doesNotProve: 'No live RSS fetch, publisher correction/retraction guarantee, global feed completeness, native watermark, NewsGroup implementation or trading behavior.',
};
await writeFile(join(outputDirectory, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
