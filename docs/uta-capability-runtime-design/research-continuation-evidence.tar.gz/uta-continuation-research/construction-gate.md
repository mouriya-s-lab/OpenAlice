# 后继构造、消费与控制边界的 Main 裁决

本轮从实际 successor 与 projection 消费问题推进到核心论证，已进入主书 §§2、3.2、5.4、5.5、9.1、16.5 与事件流 EF02。继续以 NewsGroup、动态 Provider、多成员受控效果检验，不把本记录或提交当停止条件。

## 接受的关系

- 稳定公开描述可以是参数化契约，不要求提前得到实际值或枚举有限全体。公开组合的 k 余域须受同一声明关联约束；内部 HOF 不必都成为目录叶子。描述的物化时机与 schema 的唯一来源是两件事。
- 已知共同输出通过声明的投影/转换获得；运行时精确结果保留所选 binding/slot，不能伪造 CommonCandle。合法的可失败转换可产生已知成功类型，但需要独立失败通道；透明总投影是更窄关系。
- R 是静态服务要求，惰性 native connection 不会自动消解 R。P 是要求关系，不是 grant；实际叶子仍以当前 scope/权限解释。
- final-composite 与公开 staged selection 的分界是消费者是否必须在后继 IO 前看到分支输入/权限并参与构造，不是只要动态输出就必须拆两次公共调用。
- 纯 decide 的 Accepted 是候选通过；同一个 evolve 可计算原子复合决定的推测状态，后续决定读取它。只有 writer commit 发布持久权威；失败不提交推测写集。
- 混合业务程序可顺序构造和解释 Controlled admission；不能伪装成 read-only Query，也不把 receipt 当 native 成功。flatMap 本身不是绕过控制的原因。
- 接纳轨迹律的域由 rich 独立决定。状态关系不必为总函数；基础可见观察必须预先定义。精确重复可在该观察中等价于零步，不强迫不观察重复的下游逐一重放。
- 替换权威入口另需候选上的 admission 相容；业务谓词透明另需语义 factorization。二者不能从总字段投影自动推出。

## 没有接受的外推

- UtaConstructDescribe 报告的 dependent Σ 记法不作为必需的公共返回形状；普通复合失败不必暴露整个首段 A。固定成功类型可以是合法和/投影的上界，不要求每个分支原始类型完全相同。
- 不采纳“只有总投影才可以有静态 CommonCandle 成功类型”这一过强说法；显式可失败转换也能做到，区别在失败与透明性保证。
- 不采纳未经实际读取的 IBKR 具体 what-to-show/volume 推断作为证据；合法分界已能从消费者读前是否需要精确输入契约推导。
- UtaControlSeam 初稿误读初版 architecture 文件而非指定 capability 主书，混入旧术语；初稿保留为拒收输入。Main 指明精确文件，要求重新阅读。evolve 仅能消费已接纳事件、每个决定恰有一个 outbox、只在 Complete 才能停止读、flatMap 本身不合法等结论均未采纳。
- UtaProjectionProof 初稿的“B 输出等于 B 消费投递子序列”不是独立等价证明；主书比较 rich 自己的基础可见观察与 base 观察。稳定 Pe 本身也不证明 B 对假想重复必作 duplicate；需要 B 接纳/历史契约，当前弱律不依赖这一假想投递。
- UtaProjectionDriver 初稿把投影身份当原始身份，并要求 stderr 为空。Main 对照真实 projectedEventId 与已知工具链警告后，删除错误条件，保留完整 stderr 和实际身份重绑定比较。输入构造的自证断言删除，只比较真实输出/文件与契约。

## 实际执行

continuation-mechanics.mts 使用 Effect 3.22.1：构造阶段无观察；选择 B 只发生 B authorize/acquire/read/release；选 C 无权限仅授权失败；选 C 无资源不切到 B；首段失败不运行后继。这里授权/不换源是脚本明示政策，实验只证明该进程中的惰性组合/短路/释放机械路径，不证明 UTA descriptor/权限自动推导或 native conformance。

projection-law-observation.mts 启动未改动的归档 cli.ts project，输入 Started、e1、e1 精确重复、e2、Completed。实际 exit 0；输出/持久 journal 中 rich 与 base 各四条，逐值核对完整投影（含重绑定身份）。实际 rich vwap 谓词为 [false,true]，base close 谓词为 [false,false]。这是合法轨迹与重复消去的有限证据；不扩写为拒绝分类相容、资源释放或生产 Provider 保证。

Context7 v3 查询返回的材料主要是 CLI/vitest 文档，还有一个 main 分支 source snippet，不能作为 3.22.1 的精确 API 权威。探针使用实际锁定安装的 Effect.d.ts 中已核对的 flatMap/suspend/acquireRelease/scoped/either/runPromise，并直接运行；原始查询输出完整保留。
