#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
  printf '%s\n' 'Usage: sh replay.sh <OpenAlice checkout> <new execution directory>' >&2
  exit 2
fi
repo=$(cd "$1" && pwd -P)
evidence=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
case "$2" in
  /*) work=$2 ;;
  *) work=$PWD/$2 ;;
esac
if [ -e "$work" ] || [ -L "$work" ]; then
  printf '%s\n' "Refusing existing execution directory: $work" >&2
  exit 2
fi
mkdir -p "$work/runtime"
work=$(cd "$work" && pwd -P)
tar -xzf "$repo/docs/uta-capability-runtime-design/verification-evidence.tar.gz" -C "$work/runtime"
tar -xzf "$repo/docs/uta-capability-runtime-design/event-flow-evidence.tar.gz" -C "$work/runtime"
deps=$work/runtime/uta-design-evidence/node_modules
npm ci --ignore-scripts --no-audit --no-fund --prefix "$work/runtime/uta-design-evidence" >"$work/install.stdout" 2>"$work/install.stderr"
ln -s "$deps" "$work/node_modules"
ln -s "$deps" "$work/runtime/uta-event-flow-evidence/node_modules"
cp "$evidence/continuation-mechanics.mts" "$work/continuation-mechanics.mts"
cp "$evidence/projection-law-observation.mts" "$work/projection-law-observation.mts"
cp "$evidence/news-store-observation.mjs" "$work/news-store-observation.mjs"
(
  cd "$work"
  node --import tsx continuation-mechanics.mts >continuation-mechanics.stdout 2>continuation-mechanics.stderr
  node --import tsx projection-law-observation.mts projection-law-run >projection-law.stdout 2>projection-law.stderr
  node --import tsx news-store-observation.mjs "$repo" news-store-run >news-store.stdout 2>news-store.stderr
)
printf '%s\n' "Passed three bounded research programs; full evidence: $work" 'These observations do not establish production UTA or native Provider conformance.'
