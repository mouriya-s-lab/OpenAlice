# 核心关系扩展与收敛裁决

这是 Main 对已执行研究的裁决，不是模型票数、不替代主书，也不表示维护者认可或产品已实现。

## 不同业务怎样挑战同一关系

NewsGroup 调查回到真实 RSS/store：单 feed 失败只记录 warning；GUID/link 优先的去重键已见即不再存储；查询是保留缓冲上的发布时间窗口，seq 是本地 ingest 身份。新组程序必须保留来源/成员选择/Partial，而不能声称全部实时成员。另一个 opaque Provider group 只有在声明成员读取/投影、revision 与 coverage 关系时，才能逐成员供 News 谓词消费。Main 没有把这些差异变成新的核心 NewsGroup 分支。

拒收 News 报告的“all-members 或 negative 在 Partial 下必须一律 indeterminate”：一个反例已经足以否定 all，一个匹配也足以否定 none。未知部分是否影响结论由具体业务判断决定；Partial 不升级成 Complete。原 data-contract 旧版全局 Coverage unknown 也不进入当前公共 ADT。

动态 Provider 调查确认原 specimen 持有 runtime descriptor、binding/slot 和明确的 Promise callback/finally 进程生命周期。拒收报告里“没有 Effect R 即错误消解 R”“返回 Json 即必然擦除关联”的跳步：Entry.description/调用上下文可能仍保留关联，检查范围内没有实际消费者丢弃上下文后误用的证据。真正证据边界是没有自包含的 portable certified-result 保证、命名语义 projection/evaluator、调用时权限复核或目标 Effect 资源模型。CertifiedDocument.project 只是 binding/slot-gated structural parse，不是语义投影证明。初稿中未修正的强措辞仍是未接受输入，应结合 steering 阅读。

Controlled 调查把两种因果分开：A receipt 后接纳 B，仅是本地接纳顺序；等待 A criterion 则须消费实际 observation 并由控制 owner 等待。A 先 fill 后 ack、B reject 或 Unknown 的推演保留各自 Prepared/Observation/attempt/criterion/恢复责任。补偿是新受控 Recipe，不是逆函数。原有目标没有要求另增 public sequenceAdmission API，因此没有为“名字缺席”发明一个新核心算子。

## Main 的收敛依据

1. 关键目标可表达：静态 Unit 扩展、runtime-only 外部定义、同来源 Instrument 后继读取、Candle/NewsGroup 消费、Candle 激活 Order 并返回 Agent、多成员受控效果都有明确构造与解释边界。
2. 现实差异有解释：旧 guard 的 eager 状态、source-resolve 到 getBars 的来源重分类、RSS 的缺失/去重/时间语义、TradingGit callback 先于持久化，分别进入纯决定、固定关联、覆盖/消费承诺和 write-ahead 的理由；没有把旧对象逐个改名当证明。
3. 动态关系可推演：成功/失败短路、推测 state 与 committed state、receipt 与 native fact、重复零步与验证入口相容、rearm/correction/回复栅栏分开。
4. 不确定性定位：具体构造器 API/推导、各阶段 codec/权限/资源/writer 与实际算子实例属于实现义务；native 幂等、absence、watermark/finality/replay/补偿等级需按环境取证；风险规则的政策由业务声明选择。
5. 没有目标所需的隐藏旁路：动态 schema 不 cast 成已知单元；公开混合程序不冒称 Query；read 结果、服务值和 receipt 都不自动成为发送授权；普通数据不被全量交易化。

额外的 UtaCoreConvergence 对抗综合针对上述四条核心连接，没有给出阻断当前目标表达的反例。Main 的结论是可以交付候选核心设计；不是任意未来程序都不改核心的证明，不是维护者接受，也不是新 UTA runtime 完成。

## 实际执行及文档消费

本次真实执行了 Effect 3 continuation 探针、未改动归档 CLI 的合法轨迹，以及当前 NewsCollectorStore 的隔离 JSONL ingest/query/reconstruction。最后一项看到同 GUID 改文返回 null，晚到文章进入同一发布时间查询，结果 id 顺序为 [2,1]，重建后的查询保持。

Main 在事件时序整合时还区分首段失败、构造失败与后继解释失败：前两种都不进入后继解释。Mermaid parser 检查图的可解析性，不能替这一语义判断；模型 review 也不能替实际程序运行。完整验证、重放与原始输出均按各自证据范围保留。
