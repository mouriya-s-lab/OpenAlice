import { strict as assert } from "node:assert";
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import {
  adaptedRichFeedBinding,
  adaptedRichFeedBindingLabel,
  adapterBinding,
  adapterDeclaration,
  richCandleAt,
} from "./runtime/uta-event-flow-evidence/specimen/source.js";
import {
  baseFeedJournalRecordSchema,
  journalRecordSchema,
  projectRichEventToBase,
  richFeedEventSchema,
  richFeedJournalRecordSchema,
  transportRecordSchema,
  type BaseFeedEvent,
  type JournalRecord,
  type RichFeedEvent,
} from "./runtime/uta-event-flow-evidence/specimen/types.js";

type RichJournalRecord = z.output<typeof richFeedJournalRecordSchema>;
type BaseJournalRecord = z.output<typeof baseFeedJournalRecordSchema>;
type RichDataEvent = Extract<RichFeedEvent, { tag: "Data" }>;
type BaseDataEvent = Extract<BaseFeedEvent, { tag: "Data" }>;

type ChildExitEvidence = {
  readonly command: string;
  readonly args: readonly string[];
  readonly status: number | null;
  readonly signal: NodeJS.Signals | null;
  readonly error: string | null;
};

type ObservationSummary = {
  readonly observation: string;
  readonly archivedCli: true;
  readonly admittedTraceOnly: true;
  readonly duplicateSuppression: {
    readonly inputEventIds: readonly string[];
    readonly forwardedEventIds: readonly string[];
    readonly duplicateSuppressed: true;
  };
  readonly fullProjectionCompared: true;
  readonly predicates: {
    readonly richVwapAtLeast100: readonly boolean[];
    readonly baseCloseAtLeast100: readonly boolean[];
    readonly differingPredicatesNotTransparent: true;
  };
  readonly limits: string;
  readonly evidenceDirectory: string;
};

function isRichJournalRecord(record: JournalRecord): record is RichJournalRecord {
  return "kind" in record && record.kind === "event" && record.domain === "feed-rich";
}

function isBaseJournalRecord(record: JournalRecord): record is BaseJournalRecord {
  return "kind" in record && record.kind === "event" && record.domain === "feed-base";
}

function isRichDataRecord(record: RichJournalRecord): record is RichJournalRecord & { readonly event: RichDataEvent } {
  return record.event.tag === "Data";
}

function isBaseDataRecord(record: BaseJournalRecord): record is BaseJournalRecord & { readonly event: BaseDataEvent } {
  return record.event.tag === "Data";
}

function parseJournalLines(text: string, label: string): JournalRecord[] {
  return text
    .split(/\r?\n/)
    .filter((line) => line.length > 0)
    .map((line, index) => {
      try {
        return journalRecordSchema.parse(JSON.parse(line));
      } catch (error: unknown) {
        const detail = error instanceof Error ? error.message : "non-Error failure";
        throw new Error(`${label} line ${index + 1} is not a journal record: ${detail}`);
      }
    });
}

function itemAt<T>(items: readonly T[], index: number, label: string): T {
  const item = items[index];
  if (item === undefined) throw new Error(`${label} is missing at index ${index}`);
  return item;
}

function eventIdentity(eventId: string, sequence: number) {
  return {
    eventId,
    binding: adaptedRichFeedBinding,
    bindingLabel: adaptedRichFeedBindingLabel,
    source: "fixture",
    generation: "g1",
    partition: "BTC-USD",
    sequence,
    lineage: {
      sourceBinding: adapterBinding,
      sourceEventId: `native-${eventId}`,
      operators: [
        {
          kind: "input-adaptation",
          binding: adapterBinding,
          version: adapterDeclaration.revision,
        },
      ],
    },
  };
}

function buildTrace(): {
  readonly forwarded: readonly RichFeedEvent[];
  readonly input: readonly RichFeedEvent[];
} {
  const started = richFeedEventSchema.parse({
    ...eventIdentity("event-started", 0),
    tag: "Started",
  });
  const dataE1 = richFeedEventSchema.parse({
    ...eventIdentity("event-e1", 1),
    tag: "Data",
    payload: {
      ...richCandleAt(1, "native-e1"),
      close: "99",
      vwap: "99",
    },
  });
  const dataE2 = richFeedEventSchema.parse({
    ...eventIdentity("event-e2", 2),
    tag: "Data",
    payload: {
      ...richCandleAt(2, "native-e2"),
      close: "99",
      vwap: "101",
    },
  });
  const completed = richFeedEventSchema.parse({
    ...eventIdentity("event-completed", 3),
    tag: "Completed",
  });

  return {
    forwarded: [started, dataE1, dataE2, completed],
    input: [started, dataE1, dataE1, dataE2, completed],
  };
}

function main(): void {
  const rawOutputDirectory = process.argv[2];
  if (rawOutputDirectory === undefined || process.argv.length !== 3) {
    throw new Error("usage: node --import tsx projection-law-observation.mts <fresh-output-directory>");
  }

  const researchRoot = dirname(fileURLToPath(import.meta.url));
  const outputDirectory = resolve(process.cwd(), rawOutputDirectory);
  if (existsSync(outputDirectory)) {
    throw new Error(`refusing existing output directory: ${outputDirectory}`);
  }
  mkdirSync(outputDirectory);

  const { forwarded, input } = buildTrace();
  const wireRecords = input.map((event) => transportRecordSchema.parse({
    kind: "transport",
    protocol: 1,
    binding: adaptedRichFeedBinding,
    slot: "feed",
    payload: event,
  }));
  const inputNdjson = `${wireRecords.map((record) => JSON.stringify(record)).join("\n")}\n`;
  const inputPath = resolve(outputDirectory, "input.ndjson");
  const stdoutPath = resolve(outputDirectory, "child.stdout");
  const stderrPath = resolve(outputDirectory, "child.stderr");
  const exitPath = resolve(outputDirectory, "child.exit.json");
  const journalPath = resolve(outputDirectory, "journal.ndjson");
  const summaryPath = resolve(outputDirectory, "summary.json");
  writeFileSync(inputPath, inputNdjson, "utf8");

  const cliPath = resolve(researchRoot, "runtime/uta-event-flow-evidence/specimen/cli.ts");
  const childArgs = ["--import", "tsx", cliPath, "project", "--journal", journalPath];
  const child = spawnSync(process.execPath, childArgs, {
    cwd: researchRoot,
    input: inputNdjson,
    encoding: "utf8",
  });
  const childStdout = child.stdout ?? "";
  const childStderr = child.stderr ?? "";
  const exitEvidence: ChildExitEvidence = {
    command: process.execPath,
    args: childArgs,
    status: child.status,
    signal: child.signal,
    error: child.error === undefined ? null : child.error.message,
  };
  writeFileSync(stdoutPath, childStdout, "utf8");
  writeFileSync(stderrPath, childStderr, "utf8");
  writeFileSync(exitPath, `${JSON.stringify(exitEvidence, null, 2)}\n`, "utf8");

  const journalText = existsSync(journalPath) ? readFileSync(journalPath, "utf8") : "";
  if (!existsSync(journalPath)) writeFileSync(journalPath, journalText, "utf8");

  assert.equal(child.status, 0, `archived CLI did not exit 0: ${JSON.stringify(exitEvidence)}`);
  assert.equal(child.signal, null, "archived CLI exited by signal");
  assert.equal(child.error, undefined, "archived CLI could not be spawned");
  assert.equal(childStderr, "", "archived CLI wrote stderr");

  const stdoutRecords = parseJournalLines(childStdout, "child stdout");
  const journalRecords = parseJournalLines(journalText, "journal");
  assert.deepEqual(stdoutRecords, journalRecords, "child stdout and journal differ");

  const richRecords = journalRecords.filter(isRichJournalRecord);
  const baseRecords = journalRecords.filter(isBaseJournalRecord);
  const inputEventIds = input.map((event) => event.eventId);
  const forwardedEventIds = forwarded.map((event) => event.eventId);
  assert.deepEqual(inputEventIds, ["event-started", "event-e1", "event-e1", "event-e2", "event-completed"]);
  assert.equal(JSON.stringify(itemAt(wireRecords, 1, "wireRecords")), JSON.stringify(itemAt(wireRecords, 2, "wireRecords")), "e1 input records are not exact duplicates");
  assert.notEqual(itemAt(forwarded, 1, "forwarded").eventId, itemAt(forwarded, 2, "forwarded").eventId, "Data event IDs are not distinct");
  assert.deepEqual(richRecords.map((record) => record.event.eventId), forwardedEventIds);
  assert.deepEqual(baseRecords.map((record) => record.event.eventId), forwardedEventIds);
  assert.deepEqual(richRecords.map((record) => record.event.tag), ["Started", "Data", "Data", "Completed"]);
  assert.deepEqual(richRecords.map((record) => record.event.sequence), [0, 1, 2, 3]);
  assert.equal(richRecords.filter((record) => record.event.eventId === "event-e1").length, 1);
  assert.equal(richRecords.length, forwarded.length, "duplicate Data event was not suppressed");

  const baseTemplate = baseRecords[0];
  if (baseTemplate === undefined) throw new Error("archived CLI emitted no base records");
  const expectedBaseRecords = richRecords.map((record) => ({
    kind: "event",
    domain: "feed-base",
    bindingLabel: baseTemplate.bindingLabel,
    binding: baseTemplate.binding,
    slot: "feed",
    event: projectRichEventToBase(record.event),
  }));
  assert.deepEqual(baseRecords, expectedBaseRecords, "base records are not full projections of rich records");
  assert.deepEqual(
    journalRecords.map((record) => record.domain),
    ["feed-rich", "feed-base", "feed-rich", "feed-base", "feed-rich", "feed-base", "feed-rich", "feed-base"],
  );

  const richDataRecords = richRecords.filter(isRichDataRecord);
  const baseDataRecords = baseRecords.filter(isBaseDataRecord);
  assert.deepEqual(richDataRecords.map((record) => record.event.payload.vwap), ["99", "101"]);
  assert.deepEqual(baseDataRecords.map((record) => record.event.payload.close), ["99", "99"]);
  const richVwapAtLeast100 = richDataRecords.map((record) => Number(record.event.payload.vwap) >= 100);
  const baseCloseAtLeast100 = baseDataRecords.map((record) => Number(record.event.payload.close) >= 100);
  assert.deepEqual(richVwapAtLeast100, [false, true]);
  assert.deepEqual(baseCloseAtLeast100, [false, false]);

  const summary: ObservationSummary = {
    observation: "archived CLI; admitted-trace only; duplicate suppression observed; differing predicates not transparent; no claim about acceptance equivalence for rejected candidates, resources, or native providers",
    archivedCli: true,
    admittedTraceOnly: true,
    duplicateSuppression: {
      inputEventIds,
      forwardedEventIds,
      duplicateSuppressed: true,
    },
    fullProjectionCompared: true,
    predicates: {
      richVwapAtLeast100,
      baseCloseAtLeast100,
      differingPredicatesNotTransparent: true,
    },
    limits: "No claim about acceptance equivalence for rejected candidates, resources or native providers.",
    evidenceDirectory: outputDirectory,
  };
  writeFileSync(summaryPath, `${JSON.stringify(summary, null, 2)}\n`, "utf8");
  process.stdout.write(`${JSON.stringify(summary)}\n`);
}

try {
  main();
} catch (error: unknown) {
  const detail = error instanceof Error ? error.message : "non-Error failure";
  process.stderr.write(`${detail}\n`);
  process.exitCode = 1;
}
