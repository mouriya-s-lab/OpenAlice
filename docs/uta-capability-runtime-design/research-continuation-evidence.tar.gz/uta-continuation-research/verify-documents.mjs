import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';

const [repository, output] = process.argv.slice(2);
if (!repository || !output || process.argv.length !== 4) throw new Error('Pass repository and a new output directory');
const root = resolve(repository);
const outputDirectory = resolve(output);
await mkdir(outputDirectory);
const requireUi = createRequire(join(root, 'ui/package.json'));
const { marked } = requireUi('marked');
const inputs = [
  'docs/uta-capability-runtime-design.md',
  'docs/uta-capability-runtime-design/event-flows.md',
  'docs/uta-capability-runtime-design/research-practice.md',
  'plans/uta-core-design-research.md',
];
const sourceCache = new Map();
async function source(path) {
  if (!sourceCache.has(path)) sourceCache.set(path, await readFile(path, 'utf8'));
  return sourceCache.get(path);
}
const checkedLinks = [];
const rendered = [];
for (const input of inputs) {
  const path = join(root, input);
  const text = await source(path);
  const tokens = marked.lexer(text);
  const links = [];
  marked.walkTokens(tokens, (token) => { if (token.type === 'link') links.push(token.href); });
  for (const href of links) {
    if (/^[a-z][a-z\d+.-]*:/i.test(href) || href.startsWith('//')) continue;
    const [relative, fragment] = href.split('#');
    const target = relative ? resolve(dirname(path), decodeURIComponent(relative)) : path;
    await access(target);
    if (fragment) {
      const targetText = await source(target);
      const lineRange = /^L(\d+)(?:-L(\d+))?$/.exec(fragment);
      if (lineRange && !target.endsWith('.md')) {
        const first = Number(lineRange[1]);
        const last = Number(lineRange[2] ?? lineRange[1]);
        const lines = targetText.trimEnd().split('\n').length;
        if (first < 1 || last < first || last > lines) throw new Error(`Invalid source line range ${href} in ${input}`);
      } else {
        const anchors = new Set([...targetText.matchAll(/\bid=["']([^"']+)["']/g)].map((match) => match[1]));
        if (!anchors.has(decodeURIComponent(fragment))) throw new Error(`Missing explicit anchor ${href} in ${input}`);
      }
    }
    checkedLinks.push({ from: input, href });
  }
  const html = await marked.parse(text);
  const htmlPath = join(outputDirectory, input.replaceAll('/', '__') + '.html');
  await writeFile(htmlPath, '<!doctype html><meta charset="utf-8"><article>' + html + '</article>\n');
  rendered.push({ input, htmlPath });
}
const planIndex = await readFile(join(root, 'PLANS.md'), 'utf8');
if (!planIndex.includes('[[plans/uta-core-design-research.md]]')) throw new Error('Active held-branch plan is not indexed');
const guideIndex = await readFile(join(root, 'docs/README.md'), 'utf8');
if (!guideIndex.includes('uta-capability-runtime-design/research-practice.md')) throw new Error('Research owner guide is not indexed');
const result = { node: process.version, rendered, checkedLinks, limits: 'Markdown rendering, explicit local anchors and source line-range bounds only; no architectural acceptance or validation of cited source claims.' };
await writeFile(join(outputDirectory, 'verification.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ documentsRendered: rendered.length, localLinksChecked: checkedLinks.length, outputDirectory }));
