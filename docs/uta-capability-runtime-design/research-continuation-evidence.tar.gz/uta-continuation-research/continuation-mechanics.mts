import assert from 'node:assert/strict';
import { Effect } from 'effect';

// A finite mechanical probe of Effect 3, not a UTA capability implementation.
// Authorizations and resource availability are explicit experiment inputs.
type Source = 'B' | 'C';
type Selection = { readonly source: Source; readonly instrument: string };
type Failure =
  | { readonly tag: 'DiscoveryUnavailable' }
  | { readonly tag: 'Unauthorized'; readonly source: Source }
  | { readonly tag: 'Unavailable'; readonly source: Source };
type Observation =
  | { readonly phase: 'discovery' }
  | { readonly phase: 'authorize' | 'acquire' | 'read' | 'release'; readonly source: Source };
type Scenario = {
  readonly name: string;
  readonly discovery: Selection | Failure;
  readonly allowed: ReadonlySet<Source>;
  readonly available: ReadonlySet<Source>;
};

function successor(selection: Selection, scenario: Scenario, observed: Observation[]) {
  const authorized = Effect.suspend(() => {
    observed.push({ phase: 'authorize', source: selection.source });
    return scenario.allowed.has(selection.source)
      ? Effect.succeed(selection)
      : Effect.fail<Failure>({ tag: 'Unauthorized', source: selection.source });
  });
  return Effect.flatMap(authorized, (bound) => Effect.flatMap(
    Effect.acquireRelease(
      Effect.suspend(() => {
        observed.push({ phase: 'acquire', source: bound.source });
        return scenario.available.has(bound.source)
          ? Effect.succeed(bound)
          : Effect.fail<Failure>({ tag: 'Unavailable', source: bound.source });
      }),
      (resource) => Effect.sync(() => { observed.push({ phase: 'release', source: resource.source }); }),
    ),
    (resource) => Effect.sync(() => {
      observed.push({ phase: 'read', source: resource.source });
      return { source: resource.source, instrument: resource.instrument, close: '99' };
    }),
  ));
}

const scenarios: readonly Scenario[] = [
  { name: 'selected-B-unselected-C-unavailable', discovery: { source: 'B', instrument: 'local-instrument' }, allowed: new Set<Source>(['B']), available: new Set<Source>(['B']) },
  { name: 'selected-C-not-authorized', discovery: { source: 'C', instrument: 'local-instrument' }, allowed: new Set<Source>(['B']), available: new Set<Source>(['B']) },
  { name: 'selected-C-unavailable-no-switch-to-B', discovery: { source: 'C', instrument: 'local-instrument' }, allowed: new Set<Source>(['B', 'C']), available: new Set<Source>(['B']) },
  { name: 'discovery-failed-no-successor', discovery: { tag: 'DiscoveryUnavailable' }, allowed: new Set<Source>(['B', 'C']), available: new Set<Source>(['B']) },
];
const results = [];
for (const scenario of scenarios) {
  const observed: Observation[] = [];
  const discovery = Effect.suspend(() => {
    observed.push({ phase: 'discovery' });
    return 'tag' in scenario.discovery
      ? Effect.fail(scenario.discovery)
      : Effect.succeed(scenario.discovery);
  });
  const program = Effect.flatMap(discovery, (selection) => successor(selection, scenario, observed));
  assert.deepEqual(observed, [], 'Constructing the whole program must not run any interpreter effects');
  const outcome = await Effect.runPromise(Effect.either(Effect.scoped(program)));
  switch (scenario.name) {
    case 'selected-B-unselected-C-unavailable':
      assert.equal(outcome._tag, 'Right');
      if (outcome._tag !== 'Right') throw new Error('Expected B success');
      assert.equal(outcome.right.source, 'B');
      assert.deepEqual(observed, [{ phase: 'discovery' }, { phase: 'authorize', source: 'B' }, { phase: 'acquire', source: 'B' }, { phase: 'read', source: 'B' }, { phase: 'release', source: 'B' }]);
      break;
    case 'selected-C-not-authorized':
      assert.equal(outcome._tag, 'Left');
      if (outcome._tag !== 'Left') throw new Error('Expected authorization failure');
      assert.deepEqual(outcome.left, { tag: 'Unauthorized', source: 'C' });
      assert.deepEqual(observed, [{ phase: 'discovery' }, { phase: 'authorize', source: 'C' }]);
      break;
    case 'selected-C-unavailable-no-switch-to-B':
      assert.equal(outcome._tag, 'Left');
      if (outcome._tag !== 'Left') throw new Error('Expected resource failure');
      assert.deepEqual(outcome.left, { tag: 'Unavailable', source: 'C' });
      assert.deepEqual(observed, [{ phase: 'discovery' }, { phase: 'authorize', source: 'C' }, { phase: 'acquire', source: 'C' }]);
      break;
    case 'discovery-failed-no-successor':
      assert.equal(outcome._tag, 'Left');
      if (outcome._tag !== 'Left') throw new Error('Expected discovery failure');
      assert.deepEqual(outcome.left, { tag: 'DiscoveryUnavailable' });
      assert.deepEqual(observed, [{ phase: 'discovery' }]);
      break;
  }
  results.push({ name: scenario.name, outcome, observed });
}
console.log(JSON.stringify({
  kind: 'Effect-3-continuation-mechanics',
  node: process.version,
  results,
  supports: 'Lazy result-dependent sequencing, explicit selected-branch authorization before resource use, declared failure short-circuiting, and finalization in this process.',
  doesNotProve: 'No automatic UTA descriptor derivation, permission propagation, native Provider conformance, durable recovery, pure-callback enforcement, or discharge of unprovided Effect service requirements. The authorization and no-source-switch policies are implemented experiment premises, not Effect guarantees.',
}, null, 2));
